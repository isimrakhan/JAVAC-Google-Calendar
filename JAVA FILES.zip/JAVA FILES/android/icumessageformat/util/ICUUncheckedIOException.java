package android.icumessageformat.util;

/* compiled from: PG */
/* loaded from: classes.dex */
public class ICUUncheckedIOException extends RuntimeException {
    private static final long serialVersionUID = 1210263498513384449L;

    public ICUUncheckedIOException() {
    }

    public ICUUncheckedIOException(Throwable th) {
        super(th);
    }
}
