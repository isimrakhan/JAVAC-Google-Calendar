package android.icumessageformat.util;

/* compiled from: PG */
/* loaded from: classes.dex */
public class ICUException extends RuntimeException {
    private static final long serialVersionUID = -3067399656455755650L;

    public ICUException() {
    }

    public ICUException(Throwable th) {
        super(th);
    }
}
