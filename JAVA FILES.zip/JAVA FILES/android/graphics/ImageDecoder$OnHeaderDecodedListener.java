package android.graphics;

/* loaded from: classes.dex */
public /* synthetic */ interface ImageDecoder$OnHeaderDecodedListener {
    static {
        throw new NoClassDefFoundError();
    }
}
