package android.view.accessibility;

/* loaded from: classes.dex */
public /* synthetic */ interface AccessibilityManager$AccessibilityServicesStateChangeListener {
    static {
        throw new NoClassDefFoundError();
    }
}
