package android.view;

/* loaded from: classes.dex */
public /* synthetic */ interface Window$OnFrameMetricsAvailableListener {
    static {
        throw new NoClassDefFoundError();
    }
}
