package android.animation;

/* loaded from: classes.dex */
public /* synthetic */ interface ValueAnimator$DurationScaleChangeListener {
    static {
        throw new NoClassDefFoundError();
    }
}
