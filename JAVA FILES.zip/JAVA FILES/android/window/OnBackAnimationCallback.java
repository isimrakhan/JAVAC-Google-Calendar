package android.window;

/* loaded from: classes.dex */
public /* synthetic */ interface OnBackAnimationCallback extends OnBackInvokedCallback {
    static {
        throw new NoClassDefFoundError();
    }
}
