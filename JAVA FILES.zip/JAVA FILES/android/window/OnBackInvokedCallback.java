package android.window;

/* loaded from: classes.dex */
public /* synthetic */ interface OnBackInvokedCallback {
    static {
        throw new NoClassDefFoundError();
    }
}
