package android.app.appsearch;

/* loaded from: classes.dex */
public /* synthetic */ interface BatchResultCallback {
    static {
        throw new NoClassDefFoundError();
    }
}
