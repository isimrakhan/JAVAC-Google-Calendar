package android.app.appsearch;

/* loaded from: classes.dex */
public /* synthetic */ class Migrator {
    static {
        throw new NoClassDefFoundError();
    }
}
