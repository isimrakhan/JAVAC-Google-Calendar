package android.app.appsearch.exceptions;

/* loaded from: classes.dex */
public /* synthetic */ class AppSearchException extends Exception {
    static {
        throw new NoClassDefFoundError();
    }
}
