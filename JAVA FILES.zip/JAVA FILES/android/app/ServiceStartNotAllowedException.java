package android.app;

/* loaded from: classes.dex */
public /* synthetic */ class ServiceStartNotAllowedException extends IllegalStateException {
    static {
        throw new NoClassDefFoundError();
    }
}
