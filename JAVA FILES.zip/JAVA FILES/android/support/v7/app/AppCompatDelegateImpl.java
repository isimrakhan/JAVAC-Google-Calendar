package android.support.v7.app;

import android.R;
import android.app.Activity;
import android.app.Dialog;
import android.app.UiModeManager;
import android.content.BroadcastReceiver;
import android.content.ComponentName;
import android.content.Context;
import android.content.ContextWrapper;
import android.content.pm.ActivityInfo;
import android.content.pm.PackageManager;
import android.content.res.Configuration;
import android.content.res.Resources;
import android.content.res.TypedArray;
import android.graphics.Insets;
import android.graphics.Rect;
import android.graphics.drawable.Drawable;
import android.location.LocationManager;
import android.os.Build;
import android.os.Bundle;
import android.os.LocaleList;
import android.support.v7.app.AppCompatDelegateImpl;
import android.support.v7.view.menu.ExpandedMenuView;
import android.support.v7.widget.ActionBarContextView;
import android.support.v7.widget.ContentFrameLayout;
import android.support.v7.widget.Toolbar;
import android.support.v7.widget.ViewStubCompat;
import android.text.TextUtils;
import android.util.AndroidRuntimeException;
import android.util.AttributeSet;
import android.util.TypedValue;
import android.view.ContextThemeWrapper;
import android.view.KeyCharacterMap;
import android.view.KeyEvent;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewConfiguration;
import android.view.ViewGroup;
import android.view.ViewParent;
import android.view.Window;
import android.view.WindowInsets;
import android.view.WindowManager;
import android.widget.FrameLayout;
import android.widget.ListAdapter;
import android.widget.PopupWindow;
import android.widget.TextView;
import android.window.OnBackInvokedCallback;
import android.window.OnBackInvokedDispatcher;
import cal.abh;
import cal.afm;
import cal.ahm;
import cal.aiu;
import cal.aiv;
import cal.akx;
import cal.als;
import cal.alu;
import cal.alv;
import cal.amd;
import cal.ame;
import cal.amp;
import cal.amq;
import cal.anq;
import cal.auo;
import cal.auu;
import cal.fr;
import cal.fs;
import cal.gf;
import cal.gg;
import cal.gl;
import cal.gn;
import cal.go;
import cal.gp;
import cal.gr;
import cal.gs;
import cal.gt;
import cal.gu;
import cal.gw;
import cal.gy;
import cal.gz;
import cal.hb;
import cal.hc;
import cal.hd;
import cal.he;
import cal.hf;
import cal.hh;
import cal.hl;
import cal.hr;
import cal.hu;
import cal.hz;
import cal.ia;
import cal.jd;
import cal.je;
import cal.jf;
import cal.jk;
import cal.jz;
import cal.ka;
import cal.kc;
import cal.ke;
import cal.kh;
import cal.mi;
import cal.nx;
import cal.sv;
import cal.tr;
import cal.wa;
import java.lang.ref.WeakReference;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.util.LinkedHashSet;
import java.util.Locale;

/* compiled from: PG */
/* loaded from: classes.dex */
public class AppCompatDelegateImpl extends gl implements LayoutInflater.Factory2, kc {
    static final String EXCEPTION_HANDLER_MESSAGE_SUFFIX = ". If the resource you are trying to use is a vector resource, you may be referencing it in an unsupported way. See AppCompatDelegate.setCompatVectorFromResourcesEnabled() for more info.";
    private static boolean sInstalledExceptionHandler;
    fr mActionBar;
    private gu mActionMenuPresenterCallback;
    public je mActionMode;
    public PopupWindow mActionModePopup;
    public ActionBarContextView mActionModeView;
    private int mActivityHandlesConfigFlags;
    private boolean mActivityHandlesConfigFlagsChecked;
    final gg mAppCompatCallback;
    private AppCompatViewInflater mAppCompatViewInflater;
    private gy mAppCompatWindowCallback;
    private hb mAutoBatteryNightModeManager;
    private hb mAutoTimeNightModeManager;
    private OnBackInvokedCallback mBackCallback;
    private boolean mBaseContextAttached;
    private boolean mClosingActionMenu;
    public final Context mContext;
    private boolean mCreated;
    private nx mDecorContentParent;
    public boolean mDestroyed;
    private OnBackInvokedDispatcher mDispatcher;
    private Configuration mEffectiveConfiguration;
    private boolean mEnableDefaultActionBarUp;
    public amq mFadeAnim;
    private boolean mFeatureIndeterminateProgress;
    private boolean mFeatureProgress;
    private boolean mHandleNativeActionModes;
    public boolean mHasActionBar;
    final Object mHost;
    public int mInvalidatePanelMenuFeatures;
    public boolean mInvalidatePanelMenuPosted;
    private final Runnable mInvalidatePanelMenuRunnable;
    boolean mIsFloating;
    private hl mLayoutIncludeDetector;
    private int mLocalNightMode;
    private boolean mLongPressBackDown;
    MenuInflater mMenuInflater;
    boolean mOverlayActionBar;
    boolean mOverlayActionMode;
    private hf mPanelMenuPresenterCallback;
    private he[] mPanels;
    private he mPreparedPanel;
    public Runnable mShowActionModePopup;
    private View mStatusGuard;
    public ViewGroup mSubDecor;
    private boolean mSubDecorInstalled;
    private Rect mTempRect1;
    private Rect mTempRect2;
    private int mThemeResId;
    private CharSequence mTitle;
    private TextView mTitleView;
    public Window mWindow;
    boolean mWindowNoTitle;
    private static final abh<String, Integer> sLocalNightModes = new abh<>(0);
    private static final boolean IS_PRE_LOLLIPOP = false;
    private static final int[] sWindowBackgroundStyleable = {R.attr.windowBackground};
    private static final boolean sCanReturnDifferentContext = !"robolectric".equals(Build.FINGERPRINT);

    public AppCompatDelegateImpl(Activity activity, gg ggVar) {
        this(activity, null, ggVar, activity);
    }

    private boolean applyApplicationSpecificConfig(boolean z) {
        return applyApplicationSpecificConfig(z, true);
    }

    private void applyFixedSizeWindow() {
        ContentFrameLayout contentFrameLayout = (ContentFrameLayout) this.mSubDecor.findViewById(R.id.content);
        View decorView = this.mWindow.getDecorView();
        contentFrameLayout.h.set(decorView.getPaddingLeft(), decorView.getPaddingTop(), decorView.getPaddingRight(), decorView.getPaddingBottom());
        if (contentFrameLayout.isLaidOut()) {
            contentFrameLayout.requestLayout();
        }
        TypedArray obtainStyledAttributes = this.mContext.obtainStyledAttributes(ia.j);
        if (contentFrameLayout.b == null) {
            contentFrameLayout.b = new TypedValue();
        }
        obtainStyledAttributes.getValue(124, contentFrameLayout.b);
        if (contentFrameLayout.c == null) {
            contentFrameLayout.c = new TypedValue();
        }
        obtainStyledAttributes.getValue(125, contentFrameLayout.c);
        if (obtainStyledAttributes.hasValue(122)) {
            if (contentFrameLayout.d == null) {
                contentFrameLayout.d = new TypedValue();
            }
            obtainStyledAttributes.getValue(122, contentFrameLayout.d);
        }
        if (obtainStyledAttributes.hasValue(123)) {
            if (contentFrameLayout.e == null) {
                contentFrameLayout.e = new TypedValue();
            }
            obtainStyledAttributes.getValue(123, contentFrameLayout.e);
        }
        if (obtainStyledAttributes.hasValue(120)) {
            if (contentFrameLayout.f == null) {
                contentFrameLayout.f = new TypedValue();
            }
            obtainStyledAttributes.getValue(120, contentFrameLayout.f);
        }
        if (obtainStyledAttributes.hasValue(121)) {
            if (contentFrameLayout.g == null) {
                contentFrameLayout.g = new TypedValue();
            }
            obtainStyledAttributes.getValue(121, contentFrameLayout.g);
        }
        obtainStyledAttributes.recycle();
        contentFrameLayout.requestLayout();
    }

    private void attachToWindow(Window window) {
        if (this.mWindow == null) {
            Window.Callback callback = window.getCallback();
            if (!(callback instanceof gy)) {
                gy gyVar = new gy(this, callback);
                this.mAppCompatWindowCallback = gyVar;
                window.setCallback(gyVar);
                Context context = this.mContext;
                sv svVar = new sv(context, context.obtainStyledAttributes((AttributeSet) null, sWindowBackgroundStyleable));
                Drawable c = svVar.c(0);
                if (c != null) {
                    window.setBackgroundDrawable(c);
                }
                svVar.b.recycle();
                this.mWindow = window;
                if (Build.VERSION.SDK_INT >= 33 && this.mDispatcher == null) {
                    setOnBackInvokedDispatcher(null);
                    return;
                }
                return;
            }
            throw new IllegalStateException("AppCompat has already installed itself into the Window");
        }
        throw new IllegalStateException("AppCompat has already installed itself into the Window");
    }

    private int calculateNightMode() {
        int i = this.mLocalNightMode;
        if (i != -100) {
            return i;
        }
        return getDefaultNightMode();
    }

    private void cleanupAutoManagers() {
        BroadcastReceiver broadcastReceiver;
        BroadcastReceiver broadcastReceiver2;
        hb hbVar = this.mAutoTimeNightModeManager;
        if (hbVar != null && (broadcastReceiver2 = hbVar.b) != null) {
            try {
                hbVar.c.mContext.unregisterReceiver(broadcastReceiver2);
            } catch (IllegalArgumentException unused) {
            }
            hbVar.b = null;
        }
        hb hbVar2 = this.mAutoBatteryNightModeManager;
        if (hbVar2 != null && (broadcastReceiver = hbVar2.b) != null) {
            try {
                hbVar2.c.mContext.unregisterReceiver(broadcastReceiver);
            } catch (IllegalArgumentException unused2) {
            }
            hbVar2.b = null;
        }
    }

    private Configuration createOverrideAppConfiguration(Context context, int i, aiu aiuVar, Configuration configuration, boolean z) {
        int i2;
        if (i != 1) {
            if (i != 2) {
                if (z) {
                    i2 = 0;
                } else {
                    i2 = context.getApplicationContext().getResources().getConfiguration().uiMode & 48;
                }
            } else {
                i2 = 32;
            }
        } else {
            i2 = 16;
        }
        Configuration configuration2 = new Configuration();
        configuration2.fontScale = 0.0f;
        if (configuration != null) {
            configuration2.setTo(configuration);
        }
        configuration2.uiMode = i2 | (configuration2.uiMode & (-49));
        if (aiuVar != null) {
            setConfigurationLocales(configuration2, aiuVar);
        }
        return configuration2;
    }

    private ViewGroup createSubDecor() {
        ViewGroup viewGroup;
        Context context;
        TypedArray obtainStyledAttributes = this.mContext.obtainStyledAttributes(ia.j);
        if (obtainStyledAttributes.hasValue(117)) {
            if (obtainStyledAttributes.getBoolean(126, false)) {
                requestWindowFeature(1);
            } else if (obtainStyledAttributes.getBoolean(117, false)) {
                requestWindowFeature(gl.FEATURE_SUPPORT_ACTION_BAR);
            }
            if (obtainStyledAttributes.getBoolean(118, false)) {
                requestWindowFeature(gl.FEATURE_SUPPORT_ACTION_BAR_OVERLAY);
            }
            if (obtainStyledAttributes.getBoolean(119, false)) {
                requestWindowFeature(10);
            }
            this.mIsFloating = obtainStyledAttributes.getBoolean(0, false);
            obtainStyledAttributes.recycle();
            ensureWindow();
            this.mWindow.getDecorView();
            LayoutInflater from = LayoutInflater.from(this.mContext);
            if (!this.mWindowNoTitle) {
                if (this.mIsFloating) {
                    viewGroup = (ViewGroup) from.inflate(com.google.android.calendar.R.layout.abc_dialog_title_material, (ViewGroup) null);
                    this.mOverlayActionBar = false;
                    this.mHasActionBar = false;
                } else if (this.mHasActionBar) {
                    TypedValue typedValue = new TypedValue();
                    this.mContext.getTheme().resolveAttribute(com.google.android.calendar.R.attr.actionBarTheme, typedValue, true);
                    if (typedValue.resourceId != 0) {
                        context = new wa(this.mContext, typedValue.resourceId);
                    } else {
                        context = this.mContext;
                    }
                    viewGroup = (ViewGroup) LayoutInflater.from(context).inflate(com.google.android.calendar.R.layout.abc_screen_toolbar, (ViewGroup) null);
                    nx nxVar = (nx) viewGroup.findViewById(com.google.android.calendar.R.id.decor_content_parent);
                    this.mDecorContentParent = nxVar;
                    nxVar.k(getWindowCallback());
                    if (this.mOverlayActionBar) {
                        this.mDecorContentParent.b(gl.FEATURE_SUPPORT_ACTION_BAR_OVERLAY);
                    }
                    if (this.mFeatureProgress) {
                        this.mDecorContentParent.b(2);
                    }
                    if (this.mFeatureIndeterminateProgress) {
                        this.mDecorContentParent.b(5);
                    }
                } else {
                    viewGroup = null;
                }
            } else {
                viewGroup = this.mOverlayActionMode ? (ViewGroup) from.inflate(com.google.android.calendar.R.layout.abc_screen_simple_overlay_action_mode, (ViewGroup) null) : (ViewGroup) from.inflate(com.google.android.calendar.R.layout.abc_screen_simple, (ViewGroup) null);
            }
            if (viewGroup != null) {
                alu.k(viewGroup, new go(this));
                if (this.mDecorContentParent == null) {
                    this.mTitleView = (TextView) viewGroup.findViewById(com.google.android.calendar.R.id.title);
                }
                try {
                    Method method = viewGroup.getClass().getMethod("makeOptionalFitsSystemWindows", null);
                    if (!method.isAccessible()) {
                        method.setAccessible(true);
                    }
                    method.invoke(viewGroup, null);
                } catch (IllegalAccessException | NoSuchMethodException | InvocationTargetException unused) {
                }
                ContentFrameLayout contentFrameLayout = (ContentFrameLayout) viewGroup.findViewById(com.google.android.calendar.R.id.action_bar_activity_content);
                ViewGroup viewGroup2 = (ViewGroup) this.mWindow.findViewById(R.id.content);
                if (viewGroup2 != null) {
                    while (viewGroup2.getChildCount() > 0) {
                        View childAt = viewGroup2.getChildAt(0);
                        viewGroup2.removeViewAt(0);
                        contentFrameLayout.addView(childAt);
                    }
                    viewGroup2.setId(-1);
                    contentFrameLayout.setId(R.id.content);
                    if (viewGroup2 instanceof FrameLayout) {
                        ((FrameLayout) viewGroup2).setForeground(null);
                    }
                }
                this.mWindow.setContentView(viewGroup);
                contentFrameLayout.i = new gp(this);
                return viewGroup;
            }
            throw new IllegalArgumentException("AppCompat does not support the current theme features: { windowActionBar: " + this.mHasActionBar + ", windowActionBarOverlay: " + this.mOverlayActionBar + ", android:windowIsFloating: " + this.mIsFloating + ", windowActionModeOverlay: " + this.mOverlayActionMode + ", windowNoTitle: " + this.mWindowNoTitle + " }");
        }
        obtainStyledAttributes.recycle();
        throw new IllegalStateException("You need to use a Theme.AppCompat theme (or descendant) with this activity.");
    }

    private void ensureSubDecor() {
        if (!this.mSubDecorInstalled) {
            this.mSubDecor = createSubDecor();
            CharSequence title = getTitle();
            if (!TextUtils.isEmpty(title)) {
                nx nxVar = this.mDecorContentParent;
                if (nxVar != null) {
                    nxVar.l(title);
                } else if (peekSupportActionBar() != null) {
                    peekSupportActionBar().q(title);
                } else {
                    TextView textView = this.mTitleView;
                    if (textView != null) {
                        textView.setText(title);
                    }
                }
            }
            applyFixedSizeWindow();
            onSubDecorInstalled(this.mSubDecor);
            this.mSubDecorInstalled = true;
            he panelState = getPanelState(0, false);
            if (!this.mDestroyed) {
                if (panelState == null || panelState.j == null) {
                    invalidatePanelMenu(gl.FEATURE_SUPPORT_ACTION_BAR);
                }
            }
        }
    }

    private void ensureWindow() {
        if (this.mWindow == null) {
            Object obj = this.mHost;
            if (obj instanceof Activity) {
                attachToWindow(((Activity) obj).getWindow());
            }
        }
        if (this.mWindow != null) {
        } else {
            throw new IllegalStateException("We have not been given a Window");
        }
    }

    private static Configuration generateConfigDelta(Configuration configuration, Configuration configuration2) {
        LocaleList locales;
        LocaleList locales2;
        boolean equals;
        int i;
        int i2;
        int i3;
        int i4;
        int i5;
        int i6;
        int i7;
        int i8;
        Configuration configuration3 = new Configuration();
        configuration3.fontScale = 0.0f;
        if (configuration2 != null && configuration.diff(configuration2) != 0) {
            if (configuration.fontScale != configuration2.fontScale) {
                configuration3.fontScale = configuration2.fontScale;
            }
            if (configuration.mcc != configuration2.mcc) {
                configuration3.mcc = configuration2.mcc;
            }
            if (configuration.mnc != configuration2.mnc) {
                configuration3.mnc = configuration2.mnc;
            }
            locales = configuration.getLocales();
            locales2 = configuration2.getLocales();
            equals = locales.equals(locales2);
            if (!equals) {
                configuration3.setLocales(locales2);
                configuration3.locale = configuration2.locale;
            }
            if (configuration.touchscreen != configuration2.touchscreen) {
                configuration3.touchscreen = configuration2.touchscreen;
            }
            if (configuration.keyboard != configuration2.keyboard) {
                configuration3.keyboard = configuration2.keyboard;
            }
            if (configuration.keyboardHidden != configuration2.keyboardHidden) {
                configuration3.keyboardHidden = configuration2.keyboardHidden;
            }
            if (configuration.navigation != configuration2.navigation) {
                configuration3.navigation = configuration2.navigation;
            }
            if (configuration.navigationHidden != configuration2.navigationHidden) {
                configuration3.navigationHidden = configuration2.navigationHidden;
            }
            if (configuration.orientation != configuration2.orientation) {
                configuration3.orientation = configuration2.orientation;
            }
            if ((configuration.screenLayout & 15) != (configuration2.screenLayout & 15)) {
                configuration3.screenLayout |= configuration2.screenLayout & 15;
            }
            if ((configuration.screenLayout & 192) != (configuration2.screenLayout & 192)) {
                configuration3.screenLayout |= configuration2.screenLayout & 192;
            }
            if ((configuration.screenLayout & 48) != (configuration2.screenLayout & 48)) {
                configuration3.screenLayout |= configuration2.screenLayout & 48;
            }
            if ((configuration.screenLayout & 768) != (configuration2.screenLayout & 768)) {
                configuration3.screenLayout |= configuration2.screenLayout & 768;
            }
            i = configuration.colorMode;
            int i9 = i & 3;
            i2 = configuration2.colorMode;
            if (i9 != (i2 & 3)) {
                i7 = configuration3.colorMode;
                i8 = configuration2.colorMode;
                configuration3.colorMode = i7 | (i8 & 3);
            }
            i3 = configuration.colorMode;
            int i10 = i3 & 12;
            i4 = configuration2.colorMode;
            if (i10 != (i4 & 12)) {
                i5 = configuration3.colorMode;
                i6 = configuration2.colorMode;
                configuration3.colorMode = i5 | (i6 & 12);
            }
            if ((configuration.uiMode & 15) != (configuration2.uiMode & 15)) {
                configuration3.uiMode |= configuration2.uiMode & 15;
            }
            if ((configuration.uiMode & 48) != (configuration2.uiMode & 48)) {
                configuration3.uiMode |= configuration2.uiMode & 48;
            }
            if (configuration.screenWidthDp != configuration2.screenWidthDp) {
                configuration3.screenWidthDp = configuration2.screenWidthDp;
            }
            if (configuration.screenHeightDp != configuration2.screenHeightDp) {
                configuration3.screenHeightDp = configuration2.screenHeightDp;
            }
            if (configuration.smallestScreenWidthDp != configuration2.smallestScreenWidthDp) {
                configuration3.smallestScreenWidthDp = configuration2.smallestScreenWidthDp;
            }
            if (configuration.densityDpi != configuration2.densityDpi) {
                configuration3.densityDpi = configuration2.densityDpi;
            }
        }
        return configuration3;
    }

    private int getActivityHandlesConfigChangesFlags(Context context) {
        int i;
        if (!this.mActivityHandlesConfigFlagsChecked && (this.mHost instanceof Activity)) {
            PackageManager packageManager = context.getPackageManager();
            if (packageManager == null) {
                return 0;
            }
            try {
                if (Build.VERSION.SDK_INT >= 29) {
                    i = 269221888;
                } else {
                    i = 786432;
                }
                ActivityInfo activityInfo = packageManager.getActivityInfo(new ComponentName(context, this.mHost.getClass()), i);
                if (activityInfo != null) {
                    this.mActivityHandlesConfigFlags = activityInfo.configChanges;
                }
            } catch (PackageManager.NameNotFoundException unused) {
                this.mActivityHandlesConfigFlags = 0;
            }
        }
        this.mActivityHandlesConfigFlagsChecked = true;
        return this.mActivityHandlesConfigFlags;
    }

    private hb getAutoBatteryNightModeManager(Context context) {
        if (this.mAutoBatteryNightModeManager == null) {
            this.mAutoBatteryNightModeManager = new gz(this, context);
        }
        return this.mAutoBatteryNightModeManager;
    }

    private void initWindowDecorActionBar() {
        ensureSubDecor();
        if (this.mHasActionBar && this.mActionBar == null) {
            Object obj = this.mHost;
            if (obj instanceof Activity) {
                this.mActionBar = new hz((Activity) obj, this.mOverlayActionBar);
            } else if (obj instanceof Dialog) {
                this.mActionBar = new hz((Dialog) obj);
            }
            fr frVar = this.mActionBar;
            if (frVar != null) {
                frVar.j(this.mEnableDefaultActionBarUp);
            }
        }
    }

    private boolean initializePanelContent(he heVar) {
        View view = heVar.i;
        if (view != null) {
            heVar.h = view;
            return true;
        }
        if (heVar.j == null) {
            return false;
        }
        if (this.mPanelMenuPresenterCallback == null) {
            this.mPanelMenuPresenterCallback = new hf(this);
        }
        hf hfVar = this.mPanelMenuPresenterCallback;
        if (heVar.k == null) {
            heVar.k = new ka(heVar.l);
            ka kaVar = heVar.k;
            kaVar.e = hfVar;
            ke keVar = heVar.j;
            Context context = keVar.a;
            keVar.r.add(new WeakReference(kaVar));
            kaVar.c(context, keVar);
            keVar.i = true;
        }
        ka kaVar2 = heVar.k;
        ViewGroup viewGroup = heVar.g;
        if (kaVar2.d == null) {
            kaVar2.d = (ExpandedMenuView) kaVar2.b.inflate(com.google.android.calendar.R.layout.abc_expanded_menu_layout, viewGroup, false);
            if (kaVar2.f == null) {
                kaVar2.f = new jz(kaVar2);
            }
            kaVar2.d.setAdapter((ListAdapter) kaVar2.f);
            kaVar2.d.setOnItemClickListener(kaVar2);
        }
        heVar.h = kaVar2.d;
        if (heVar.h != null) {
            return true;
        }
        return false;
    }

    private boolean initializePanelDecor(he heVar) {
        Context actionBarThemedContext = getActionBarThemedContext();
        TypedValue typedValue = new TypedValue();
        Resources.Theme newTheme = actionBarThemedContext.getResources().newTheme();
        newTheme.setTo(actionBarThemedContext.getTheme());
        newTheme.resolveAttribute(com.google.android.calendar.R.attr.actionBarPopupTheme, typedValue, true);
        if (typedValue.resourceId != 0) {
            newTheme.applyStyle(typedValue.resourceId, true);
        }
        newTheme.resolveAttribute(com.google.android.calendar.R.attr.panelMenuListTheme, typedValue, true);
        if (typedValue.resourceId != 0) {
            newTheme.applyStyle(typedValue.resourceId, true);
        } else {
            newTheme.applyStyle(com.google.android.calendar.R.style.Theme_AppCompat_CompactMenu, true);
        }
        wa waVar = new wa(actionBarThemedContext, 0);
        waVar.getTheme().setTo(newTheme);
        heVar.l = waVar;
        TypedArray obtainStyledAttributes = waVar.obtainStyledAttributes(ia.j);
        heVar.b = obtainStyledAttributes.getResourceId(86, 0);
        heVar.f = obtainStyledAttributes.getResourceId(1, 0);
        obtainStyledAttributes.recycle();
        heVar.g = new hd(this, heVar.l);
        heVar.c = 81;
        return true;
    }

    private boolean initializePanelMenu(he heVar) {
        Resources.Theme theme;
        Context context = this.mContext;
        int i = heVar.a;
        if ((i == 0 || i == 108) && this.mDecorContentParent != null) {
            TypedValue typedValue = new TypedValue();
            Resources.Theme theme2 = context.getTheme();
            theme2.resolveAttribute(com.google.android.calendar.R.attr.actionBarTheme, typedValue, true);
            if (typedValue.resourceId != 0) {
                theme = context.getResources().newTheme();
                theme.setTo(theme2);
                theme.applyStyle(typedValue.resourceId, true);
                theme.resolveAttribute(com.google.android.calendar.R.attr.actionBarWidgetTheme, typedValue, true);
            } else {
                theme2.resolveAttribute(com.google.android.calendar.R.attr.actionBarWidgetTheme, typedValue, true);
                theme = null;
            }
            if (typedValue.resourceId != 0) {
                if (theme == null) {
                    theme = context.getResources().newTheme();
                    theme.setTo(theme2);
                }
                theme.applyStyle(typedValue.resourceId, true);
            }
            if (theme != null) {
                wa waVar = new wa(context, 0);
                waVar.getTheme().setTo(theme);
                context = waVar;
            }
        }
        ke keVar = new ke(context);
        keVar.d = this;
        heVar.a(keVar);
        return true;
    }

    private void invalidatePanelMenu(int i) {
        this.mInvalidatePanelMenuFeatures = (1 << i) | this.mInvalidatePanelMenuFeatures;
        if (!this.mInvalidatePanelMenuPosted) {
            View decorView = this.mWindow.getDecorView();
            Runnable runnable = this.mInvalidatePanelMenuRunnable;
            int[] iArr = ame.a;
            decorView.postOnAnimation(runnable);
            this.mInvalidatePanelMenuPosted = true;
        }
    }

    private boolean onKeyDownPanel(int i, KeyEvent keyEvent) {
        if (keyEvent.getRepeatCount() == 0) {
            he panelState = getPanelState(i, true);
            if (!panelState.o) {
                return preparePanel(panelState, keyEvent);
            }
            return false;
        }
        return false;
    }

    /* JADX WARN: Code restructure failed: missing block: B:37:0x005a, code lost:
    
        if (preparePanel(r2, r6) != false) goto L32;
     */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct code enable 'Show inconsistent code' option in preferences
    */
    private boolean onKeyUpPanel(int r5, android.view.KeyEvent r6) {
        /*
            r4 = this;
            cal.je r0 = r4.mActionMode
            r1 = 0
            if (r0 == 0) goto L6
            return r1
        L6:
            r0 = 1
            cal.he r2 = r4.getPanelState(r5, r0)
            if (r5 != 0) goto L43
            cal.nx r5 = r4.mDecorContentParent
            if (r5 == 0) goto L43
            boolean r5 = r5.m()
            if (r5 == 0) goto L43
            android.content.Context r5 = r4.mContext
            android.view.ViewConfiguration r5 = android.view.ViewConfiguration.get(r5)
            boolean r5 = r5.hasPermanentMenuKey()
            if (r5 != 0) goto L43
            cal.nx r5 = r4.mDecorContentParent
            boolean r5 = r5.p()
            if (r5 != 0) goto L3c
            boolean r5 = r4.mDestroyed
            if (r5 != 0) goto L60
            boolean r5 = r4.preparePanel(r2, r6)
            if (r5 == 0) goto L60
            cal.nx r5 = r4.mDecorContentParent
            boolean r0 = r5.r()
            goto L66
        L3c:
            cal.nx r5 = r4.mDecorContentParent
            boolean r0 = r5.n()
            goto L66
        L43:
            boolean r5 = r2.o
            if (r5 != 0) goto L62
            boolean r3 = r2.n
            if (r3 == 0) goto L4c
            goto L62
        L4c:
            boolean r5 = r2.m
            if (r5 == 0) goto L60
            boolean r5 = r2.r
            if (r5 == 0) goto L5c
            r2.m = r1
            boolean r5 = r4.preparePanel(r2, r6)
            if (r5 == 0) goto L60
        L5c:
            r4.openPanel(r2, r6)
            goto L66
        L60:
            r0 = r1
            goto L66
        L62:
            r4.closePanel(r2, r0)
            r0 = r5
        L66:
            if (r0 == 0) goto L83
            android.content.Context r5 = r4.mContext
            android.content.Context r5 = r5.getApplicationContext()
            java.lang.String r6 = "audio"
            java.lang.Object r5 = r5.getSystemService(r6)
            android.media.AudioManager r5 = (android.media.AudioManager) r5
            if (r5 == 0) goto L7c
            r5.playSoundEffect(r1)
            goto L83
        L7c:
            java.lang.String r5 = "AppCompatDelegate"
            java.lang.String r6 = "Couldn't get audio manager"
            android.util.Log.w(r5, r6)
        L83:
            return r0
        */
        throw new UnsupportedOperationException("Method not decompiled: android.support.v7.app.AppCompatDelegateImpl.onKeyUpPanel(int, android.view.KeyEvent):boolean");
    }

    /* JADX WARN: Code restructure failed: missing block: B:53:0x00b2, code lost:
    
        if (r3 > 0) goto L59;
     */
    /* JADX WARN: Removed duplicated region for block: B:34:0x0117  */
    /* JADX WARN: Removed duplicated region for block: B:36:? A[RETURN, SYNTHETIC] */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct code enable 'Show inconsistent code' option in preferences
    */
    private void openPanel(cal.he r12, android.view.KeyEvent r13) {
        /*
            Method dump skipped, instructions count: 286
            To view this dump change 'Code comments level' option to 'DEBUG'
        */
        throw new UnsupportedOperationException("Method not decompiled: android.support.v7.app.AppCompatDelegateImpl.openPanel(cal.he, android.view.KeyEvent):void");
    }

    private boolean performPanelShortcut(he heVar, int i, KeyEvent keyEvent, int i2) {
        ke keVar;
        boolean z = false;
        if (keyEvent.isSystem()) {
            return false;
        }
        if ((heVar.m || preparePanel(heVar, keyEvent)) && (keVar = heVar.j) != null) {
            z = keVar.performShortcut(i, keyEvent, i2);
        }
        if (z && (i2 & 1) == 0 && this.mDecorContentParent == null) {
            closePanel(heVar, true);
            return true;
        }
        return z;
    }

    private boolean preparePanel(he heVar, KeyEvent keyEvent) {
        boolean z;
        nx nxVar;
        nx nxVar2;
        int i;
        boolean z2;
        nx nxVar3;
        nx nxVar4;
        if (this.mDestroyed) {
            return false;
        }
        if (heVar.m) {
            return true;
        }
        he heVar2 = this.mPreparedPanel;
        if (heVar2 != null && heVar2 != heVar) {
            closePanel(heVar2, false);
        }
        Window.Callback windowCallback = getWindowCallback();
        if (windowCallback != null) {
            heVar.i = windowCallback.onCreatePanelView(heVar.a);
        }
        int i2 = heVar.a;
        if (i2 != 0 && i2 != 108) {
            z = false;
        } else {
            z = true;
        }
        if (z && (nxVar4 = this.mDecorContentParent) != null) {
            nxVar4.j();
        }
        if (heVar.i == null && (!z || !(peekSupportActionBar() instanceof hr))) {
            ke keVar = heVar.j;
            if (keVar == null || heVar.r) {
                if (keVar == null) {
                    initializePanelMenu(heVar);
                    if (heVar.j == null) {
                        return false;
                    }
                }
                if (z && (nxVar2 = this.mDecorContentParent) != null) {
                    if (this.mActionMenuPresenterCallback == null) {
                        this.mActionMenuPresenterCallback = new gu(this);
                    }
                    nxVar2.i(heVar.j, this.mActionMenuPresenterCallback);
                }
                ke keVar2 = heVar.j;
                if (!keVar2.n) {
                    keVar2.n = true;
                    keVar2.o = false;
                    keVar2.p = false;
                }
                if (!windowCallback.onCreatePanelMenu(heVar.a, keVar2)) {
                    heVar.a(null);
                    if (z && (nxVar = this.mDecorContentParent) != null) {
                        nxVar.i(null, this.mActionMenuPresenterCallback);
                    }
                    return false;
                }
                heVar.r = false;
            }
            ke keVar3 = heVar.j;
            if (!keVar3.n) {
                keVar3.n = true;
                keVar3.o = false;
                keVar3.p = false;
            }
            Bundle bundle = heVar.s;
            if (bundle != null) {
                keVar3.n(bundle);
                heVar.s = null;
            }
            if (!windowCallback.onPreparePanel(0, heVar.i, heVar.j)) {
                if (z && (nxVar3 = this.mDecorContentParent) != null) {
                    nxVar3.i(null, this.mActionMenuPresenterCallback);
                }
                ke keVar4 = heVar.j;
                keVar4.n = false;
                if (keVar4.o) {
                    keVar4.o = false;
                    keVar4.k(keVar4.p);
                }
                return false;
            }
            if (keyEvent != null) {
                i = keyEvent.getDeviceId();
            } else {
                i = -1;
            }
            if (KeyCharacterMap.load(i).getKeyboardType() != 1) {
                z2 = true;
            } else {
                z2 = false;
            }
            heVar.p = z2;
            ke keVar5 = heVar.j;
            keVar5.c = z2;
            keVar5.k(false);
            ke keVar6 = heVar.j;
            keVar6.n = false;
            if (keVar6.o) {
                keVar6.o = false;
                keVar6.k(keVar6.p);
            }
        }
        heVar.m = true;
        heVar.n = false;
        this.mPreparedPanel = heVar;
        return true;
    }

    private void reopenMenu(boolean z) {
        nx nxVar = this.mDecorContentParent;
        if (nxVar != null && nxVar.m() && (!ViewConfiguration.get(this.mContext).hasPermanentMenuKey() || this.mDecorContentParent.o())) {
            Window.Callback windowCallback = getWindowCallback();
            if (this.mDecorContentParent.p() && z) {
                this.mDecorContentParent.n();
                if (!this.mDestroyed) {
                    windowCallback.onPanelClosed(gl.FEATURE_SUPPORT_ACTION_BAR, getPanelState(0, true).j);
                    return;
                }
                return;
            }
            if (windowCallback != null && !this.mDestroyed) {
                if (this.mInvalidatePanelMenuPosted && (this.mInvalidatePanelMenuFeatures & 1) != 0) {
                    this.mWindow.getDecorView().removeCallbacks(this.mInvalidatePanelMenuRunnable);
                    this.mInvalidatePanelMenuRunnable.run();
                }
                he panelState = getPanelState(0, true);
                ke keVar = panelState.j;
                if (keVar != null && !panelState.r && windowCallback.onPreparePanel(0, panelState.i, keVar)) {
                    windowCallback.onMenuOpened(gl.FEATURE_SUPPORT_ACTION_BAR, panelState.j);
                    this.mDecorContentParent.r();
                    return;
                }
                return;
            }
            return;
        }
        he panelState2 = getPanelState(0, true);
        panelState2.q = true;
        closePanel(panelState2, false);
        openPanel(panelState2, null);
    }

    private int sanitizeWindowFeatureId(int i) {
        if (i == 8) {
            return gl.FEATURE_SUPPORT_ACTION_BAR;
        }
        if (i == 9) {
            return gl.FEATURE_SUPPORT_ACTION_BAR_OVERLAY;
        }
        return i;
    }

    private boolean shouldInheritContext(ViewParent viewParent) {
        if (viewParent == null) {
            return false;
        }
        View decorView = this.mWindow.getDecorView();
        while (viewParent != null) {
            if (viewParent == decorView || !(viewParent instanceof View) || ((View) viewParent).isAttachedToWindow()) {
                return false;
            }
            viewParent = viewParent.getParent();
        }
        return true;
    }

    private void throwFeatureRequestIfSubDecorInstalled() {
        if (!this.mSubDecorInstalled) {
        } else {
            throw new AndroidRuntimeException("Window feature must be requested before adding content");
        }
    }

    private gf tryUnwrapContext() {
        for (Context context = this.mContext; context != null; context = ((ContextWrapper) context).getBaseContext()) {
            if (context instanceof gf) {
                return (gf) context;
            }
            if (!(context instanceof ContextWrapper)) {
                return null;
            }
        }
        return null;
    }

    /* JADX WARN: Multi-variable type inference failed */
    private void updateActivityConfiguration(Configuration configuration) {
        Activity activity = (Activity) this.mHost;
        if (activity instanceof auu) {
            auo a = ((auu) activity).getLifecycle().a();
            auo auoVar = auo.CREATED;
            auoVar.getClass();
            if (a.compareTo(auoVar) >= 0) {
                activity.onConfigurationChanged(configuration);
                return;
            }
            return;
        }
        if (this.mCreated && !this.mDestroyed) {
            activity.onConfigurationChanged(configuration);
        }
    }

    /* JADX WARN: Removed duplicated region for block: B:43:0x00bc  */
    /* JADX WARN: Removed duplicated region for block: B:52:0x00d1  */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct code enable 'Show inconsistent code' option in preferences
    */
    private boolean updateAppConfiguration(int r8, cal.aiu r9, boolean r10) {
        /*
            Method dump skipped, instructions count: 227
            To view this dump change 'Code comments level' option to 'DEBUG'
        */
        throw new UnsupportedOperationException("Method not decompiled: android.support.v7.app.AppCompatDelegateImpl.updateAppConfiguration(int, cal.aiu, boolean):boolean");
    }

    private void updateResourcesConfiguration(int i, aiu aiuVar, boolean z, Configuration configuration) {
        Resources resources = this.mContext.getResources();
        Configuration configuration2 = new Configuration(resources.getConfiguration());
        if (configuration != null) {
            configuration2.updateFrom(configuration);
        }
        configuration2.uiMode = i | (resources.getConfiguration().uiMode & (-49));
        if (aiuVar != null) {
            setConfigurationLocales(configuration2, aiuVar);
        }
        resources.updateConfiguration(configuration2, null);
        int i2 = this.mThemeResId;
        if (i2 != 0) {
            this.mContext.setTheme(i2);
            this.mContext.getTheme().applyStyle(this.mThemeResId, true);
        }
        if (z && (this.mHost instanceof Activity)) {
            updateActivityConfiguration(configuration2);
        }
    }

    private void updateStatusGuardColor(View view) {
        int color;
        int[] iArr = ame.a;
        if ((view.getWindowSystemUiVisibility() & 8192) != 0) {
            color = this.mContext.getColor(com.google.android.calendar.R.color.abc_decor_view_status_guard_light);
        } else {
            color = this.mContext.getColor(com.google.android.calendar.R.color.abc_decor_view_status_guard);
        }
        view.setBackgroundColor(color);
    }

    @Override // cal.gl
    public void addContentView(View view, ViewGroup.LayoutParams layoutParams) {
        ensureSubDecor();
        ((ViewGroup) this.mSubDecor.findViewById(R.id.content)).addView(view, layoutParams);
        gy gyVar = this.mAppCompatWindowCallback;
        Window.Callback callback = this.mWindow.getCallback();
        try {
            gyVar.a = true;
            callback.onContentChanged();
        } finally {
            gyVar.a = false;
        }
    }

    /* JADX WARN: Code restructure failed: missing block: B:8:0x0026, code lost:
    
        if (r0 == false) goto L10;
     */
    @Override // cal.gl
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct code enable 'Show inconsistent code' option in preferences
    */
    public boolean applyAppLocales() {
        /*
            r3 = this;
            android.content.Context r0 = r3.mContext
            boolean r0 = isAutoStorageOptedIn(r0)
            if (r0 == 0) goto L2d
            cal.aiu r0 = getRequestedAppLocales()
            if (r0 == 0) goto L2d
            cal.aiu r0 = getRequestedAppLocales()
            cal.aiu r1 = getStoredAppLocales()
            boolean r2 = r1 instanceof cal.aiu
            if (r2 == 0) goto L28
            cal.aiv r0 = r0.b
            cal.aiv r1 = r1.b
            android.os.LocaleList r1 = r1.a
            android.os.LocaleList r0 = r0.a
            boolean r0 = cal.aw$$ExternalSyntheticApiModelOutline1.m(r0, r1)
            if (r0 != 0) goto L2d
        L28:
            android.content.Context r0 = r3.mContext
            r3.asyncExecuteSyncRequestedAndStoredLocales(r0)
        L2d:
            r0 = 1
            boolean r0 = r3.applyApplicationSpecificConfig(r0)
            return r0
        */
        throw new UnsupportedOperationException("Method not decompiled: android.support.v7.app.AppCompatDelegateImpl.applyAppLocales():boolean");
    }

    @Override // cal.gl
    public boolean applyDayNight() {
        return applyApplicationSpecificConfig(true);
    }

    @Override // cal.gl
    public Context attachBaseContext2(Context context) {
        Configuration configuration;
        this.mBaseContextAttached = true;
        int mapNightMode = mapNightMode(context, calculateNightMode());
        if (isAutoStorageOptedIn(context)) {
            syncRequestedAndStoredLocales(context);
        }
        aiu calculateApplicationLocales = calculateApplicationLocales(context);
        if (context instanceof ContextThemeWrapper) {
            try {
                ((ContextThemeWrapper) context).applyOverrideConfiguration(createOverrideAppConfiguration(context, mapNightMode, calculateApplicationLocales, null, false));
            } catch (IllegalStateException unused) {
            }
            return context;
        }
        if (context instanceof wa) {
            try {
                ((wa) context).b(createOverrideAppConfiguration(context, mapNightMode, calculateApplicationLocales, null, false));
                return context;
            } catch (IllegalStateException unused2) {
            }
        }
        if (!sCanReturnDifferentContext) {
            super.attachBaseContext2(context);
            return context;
        }
        Configuration configuration2 = new Configuration();
        configuration2.uiMode = -1;
        configuration2.fontScale = 0.0f;
        Configuration configuration3 = context.createConfigurationContext(configuration2).getResources().getConfiguration();
        Configuration configuration4 = context.getResources().getConfiguration();
        configuration3.uiMode = configuration4.uiMode;
        if (!configuration3.equals(configuration4)) {
            configuration = generateConfigDelta(configuration3, configuration4);
        } else {
            configuration = null;
        }
        Configuration createOverrideAppConfiguration = createOverrideAppConfiguration(context, mapNightMode, calculateApplicationLocales, configuration, true);
        wa waVar = new wa(context, com.google.android.calendar.R.style.Theme_AppCompat_Empty);
        waVar.b(createOverrideAppConfiguration);
        try {
            if (context.getTheme() != null) {
                Resources.Theme theme = waVar.getTheme();
                if (Build.VERSION.SDK_INT >= 29) {
                    theme.rebase();
                } else {
                    synchronized (ahm.a) {
                        if (!ahm.c) {
                            try {
                                ahm.b = Resources.Theme.class.getDeclaredMethod("rebase", null);
                                ahm.b.setAccessible(true);
                            } catch (NoSuchMethodException unused3) {
                            }
                            ahm.c = true;
                        }
                        Method method = ahm.b;
                        if (method != null) {
                            try {
                                method.invoke(theme, null);
                            } catch (IllegalAccessException | InvocationTargetException unused4) {
                                ahm.b = null;
                            }
                        }
                    }
                }
            }
        } catch (NullPointerException unused5) {
        }
        super.attachBaseContext2(waVar);
        return waVar;
    }

    public aiu calculateApplicationLocales(Context context) {
        aiu requestedAppLocales;
        boolean isEmpty;
        int size;
        int size2;
        aiu aiuVar;
        int size3;
        int size4;
        Locale locale;
        boolean isEmpty2;
        if (Build.VERSION.SDK_INT >= 33 || (requestedAppLocales = getRequestedAppLocales()) == null) {
            return null;
        }
        aiu configurationLocales = getConfigurationLocales(context.getApplicationContext().getResources().getConfiguration());
        isEmpty = requestedAppLocales.b.a.isEmpty();
        if (isEmpty) {
            aiuVar = aiu.a;
        } else {
            LinkedHashSet linkedHashSet = new LinkedHashSet();
            int i = 0;
            while (true) {
                aiv aivVar = requestedAppLocales.b;
                LocaleList localeList = configurationLocales.b.a;
                size = aivVar.a.size();
                size2 = localeList.size();
                if (i >= size + size2) {
                    break;
                }
                size3 = requestedAppLocales.b.a.size();
                if (i >= size3) {
                    size4 = requestedAppLocales.b.a.size();
                    locale = configurationLocales.b.a.get(i - size4);
                } else {
                    locale = requestedAppLocales.b.a.get(i);
                }
                if (locale != null) {
                    linkedHashSet.add(locale);
                }
                i++;
            }
            aiuVar = new aiu(new aiv(new LocaleList((Locale[]) linkedHashSet.toArray(new Locale[linkedHashSet.size()]))));
        }
        isEmpty2 = aiuVar.b.a.isEmpty();
        if (isEmpty2) {
            return configurationLocales;
        }
        return aiuVar;
    }

    public void callOnPanelClosed(int i, he heVar, Menu menu) {
        if (menu == null) {
            if (heVar == null && i >= 0) {
                he[] heVarArr = this.mPanels;
                if (i < heVarArr.length) {
                    heVar = heVarArr[i];
                }
            }
            if (heVar != null) {
                menu = heVar.j;
            }
        }
        if ((heVar == null || heVar.o) && !this.mDestroyed) {
            gy gyVar = this.mAppCompatWindowCallback;
            Window.Callback callback = this.mWindow.getCallback();
            try {
                gyVar.c = true;
                callback.onPanelClosed(i, menu);
            } finally {
                gyVar.c = false;
            }
        }
    }

    public void checkCloseActionMenu(ke keVar) {
        if (this.mClosingActionMenu) {
            return;
        }
        this.mClosingActionMenu = true;
        this.mDecorContentParent.a();
        Window.Callback windowCallback = getWindowCallback();
        if (windowCallback != null && !this.mDestroyed) {
            windowCallback.onPanelClosed(gl.FEATURE_SUPPORT_ACTION_BAR, keVar);
        }
        this.mClosingActionMenu = false;
    }

    public void closePanel(int i) {
        closePanel(getPanelState(i, true), true);
    }

    /* JADX WARN: Can't fix incorrect switch cases order, some code will duplicate */
    /* JADX WARN: Code restructure failed: missing block: B:136:0x013b, code lost:
    
        if (r11.equals("Spinner") != false) goto L100;
     */
    /* JADX WARN: Code restructure failed: missing block: B:162:0x0097, code lost:
    
        if (((org.xmlpull.v1.XmlPullParser) r13).getDepth() > 1) goto L32;
     */
    /* JADX WARN: Code restructure failed: missing block: B:27:0x008b, code lost:
    
        if (cal.hl.b(r5, r7) != false) goto L32;
     */
    /* JADX WARN: Code restructure failed: missing block: B:28:0x0099, code lost:
    
        r0 = true;
     */
    /* JADX WARN: Multi-variable type inference failed */
    /* JADX WARN: Removed duplicated region for block: B:103:0x0184  */
    /* JADX WARN: Removed duplicated region for block: B:104:0x018a  */
    /* JADX WARN: Removed duplicated region for block: B:105:0x0190  */
    /* JADX WARN: Removed duplicated region for block: B:106:0x0196  */
    /* JADX WARN: Removed duplicated region for block: B:107:0x019c  */
    /* JADX WARN: Removed duplicated region for block: B:108:0x01a1  */
    /* JADX WARN: Removed duplicated region for block: B:109:0x01a7  */
    /* JADX WARN: Removed duplicated region for block: B:110:0x01ac  */
    /* JADX WARN: Removed duplicated region for block: B:111:0x01b1  */
    /* JADX WARN: Removed duplicated region for block: B:112:0x01b7  */
    /* JADX WARN: Removed duplicated region for block: B:113:0x01bd  */
    /* JADX WARN: Removed duplicated region for block: B:114:0x01c3  */
    /* JADX WARN: Removed duplicated region for block: B:115:0x01c8  */
    /* JADX WARN: Removed duplicated region for block: B:116:0x01ce  */
    /* JADX WARN: Removed duplicated region for block: B:117:0x00f3  */
    /* JADX WARN: Removed duplicated region for block: B:120:0x00fe  */
    /* JADX WARN: Removed duplicated region for block: B:123:0x0109  */
    /* JADX WARN: Removed duplicated region for block: B:126:0x0115  */
    /* JADX WARN: Removed duplicated region for block: B:129:0x0120  */
    /* JADX WARN: Removed duplicated region for block: B:132:0x012b  */
    /* JADX WARN: Removed duplicated region for block: B:135:0x0135  */
    /* JADX WARN: Removed duplicated region for block: B:137:0x013e  */
    /* JADX WARN: Removed duplicated region for block: B:140:0x0149  */
    /* JADX WARN: Removed duplicated region for block: B:143:0x0153  */
    /* JADX WARN: Removed duplicated region for block: B:146:0x015d  */
    /* JADX WARN: Removed duplicated region for block: B:149:0x0168  */
    /* JADX WARN: Removed duplicated region for block: B:152:0x0173  */
    /* JADX WARN: Removed duplicated region for block: B:155:0x017e  */
    /* JADX WARN: Removed duplicated region for block: B:156:0x00bf  */
    /* JADX WARN: Removed duplicated region for block: B:35:0x00ba  */
    /* JADX WARN: Removed duplicated region for block: B:38:0x00c3  */
    /* JADX WARN: Removed duplicated region for block: B:48:0x00e8  */
    /* JADX WARN: Removed duplicated region for block: B:52:0x0182  */
    /* JADX WARN: Removed duplicated region for block: B:57:0x01de  */
    /* JADX WARN: Removed duplicated region for block: B:61:0x01f2  */
    /* JADX WARN: Removed duplicated region for block: B:71:0x022e  */
    /* JADX WARN: Removed duplicated region for block: B:96:0x0210 A[Catch: all -> 0x021c, Exception -> 0x0224, TRY_ENTER, TRY_LEAVE, TryCatch #3 {Exception -> 0x0224, all -> 0x021c, blocks: (B:59:0x01e4, B:63:0x01f5, B:96:0x0210), top: B:58:0x01e4 }] */
    @Override // cal.gl
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct code enable 'Show inconsistent code' option in preferences
    */
    public android.view.View createView(android.view.View r10, java.lang.String r11, android.content.Context r12, android.util.AttributeSet r13) {
        /*
            Method dump skipped, instructions count: 816
            To view this dump change 'Code comments level' option to 'DEBUG'
        */
        throw new UnsupportedOperationException("Method not decompiled: android.support.v7.app.AppCompatDelegateImpl.createView(android.view.View, java.lang.String, android.content.Context, android.util.AttributeSet):android.view.View");
    }

    public void dismissPopups() {
        ke keVar;
        nx nxVar = this.mDecorContentParent;
        if (nxVar != null) {
            nxVar.a();
        }
        if (this.mActionModePopup != null) {
            this.mWindow.getDecorView().removeCallbacks(this.mShowActionModePopup);
            if (this.mActionModePopup.isShowing()) {
                try {
                    this.mActionModePopup.dismiss();
                } catch (IllegalArgumentException unused) {
                }
            }
            this.mActionModePopup = null;
        }
        endOnGoingFadeAnimation();
        he panelState = getPanelState(0, false);
        if (panelState != null && (keVar = panelState.j) != null) {
            keVar.h(true);
        }
    }

    public boolean dispatchKeyEvent(KeyEvent keyEvent) {
        View decorView;
        Object obj = this.mHost;
        if (((obj instanceof akx) || (obj instanceof hh)) && (decorView = this.mWindow.getDecorView()) != null && Build.VERSION.SDK_INT < 28) {
            int i = amd.a;
            amd amdVar = (amd) decorView.getTag(com.google.android.calendar.R.id.tag_unhandled_key_event_manager);
            if (amdVar == null) {
                amdVar = new amd();
                decorView.setTag(com.google.android.calendar.R.id.tag_unhandled_key_event_manager, amdVar);
            }
            if (amdVar.b(keyEvent)) {
                return true;
            }
        }
        if (keyEvent.getKeyCode() == 82) {
            gy gyVar = this.mAppCompatWindowCallback;
            Window.Callback callback = this.mWindow.getCallback();
            try {
                gyVar.b = true;
                if (callback.dispatchKeyEvent(keyEvent)) {
                    return true;
                }
            } finally {
                gyVar.b = false;
            }
        }
        int keyCode = keyEvent.getKeyCode();
        if (keyEvent.getAction() == 0) {
            return onKeyDown(keyCode, keyEvent);
        }
        return onKeyUp(keyCode, keyEvent);
    }

    public void doInvalidatePanelMenu(int i) {
        he panelState;
        he panelState2 = getPanelState(i, true);
        if (panelState2.j != null) {
            Bundle bundle = new Bundle();
            panelState2.j.o(bundle);
            if (bundle.size() > 0) {
                panelState2.s = bundle;
            }
            ke keVar = panelState2.j;
            if (!keVar.n) {
                keVar.n = true;
                keVar.o = false;
                keVar.p = false;
            }
            kh khVar = keVar.s;
            if (khVar != null) {
                keVar.r(khVar);
            }
            keVar.e.clear();
            keVar.k(true);
        }
        panelState2.r = true;
        panelState2.q = true;
        if ((i == 108 || i == 0) && this.mDecorContentParent != null && (panelState = getPanelState(0, false)) != null) {
            panelState.m = false;
            preparePanel(panelState, null);
        }
    }

    public void endOnGoingFadeAnimation() {
        View view;
        amq amqVar = this.mFadeAnim;
        if (amqVar != null && (view = (View) amqVar.a.get()) != null) {
            view.animate().cancel();
        }
    }

    public he findMenuPanel(Menu menu) {
        int i;
        he[] heVarArr = this.mPanels;
        if (heVarArr != null) {
            i = heVarArr.length;
        } else {
            i = 0;
        }
        for (int i2 = 0; i2 < i; i2++) {
            he heVar = heVarArr[i2];
            if (heVar != null && heVar.j == menu) {
                return heVar;
            }
        }
        return null;
    }

    @Override // cal.gl
    public <T extends View> T findViewById(int i) {
        ensureSubDecor();
        return (T) this.mWindow.findViewById(i);
    }

    final Context getActionBarThemedContext() {
        Context context;
        fr supportActionBar = getSupportActionBar();
        if (supportActionBar != null) {
            context = supportActionBar.c();
        } else {
            context = null;
        }
        if (context == null) {
            return this.mContext;
        }
        return context;
    }

    final hb getAutoTimeNightModeManager() {
        return getAutoTimeNightModeManager(this.mContext);
    }

    public aiu getConfigurationLocales(Configuration configuration) {
        LocaleList locales;
        String languageTags;
        locales = configuration.getLocales();
        languageTags = locales.toLanguageTags();
        return aiu.a(languageTags);
    }

    @Override // cal.gl
    public Context getContextForDelegate() {
        return this.mContext;
    }

    @Override // cal.gl
    public final fs getDrawerToggleDelegate() {
        return new gt();
    }

    @Override // cal.gl
    public int getLocalNightMode() {
        return this.mLocalNightMode;
    }

    @Override // cal.gl
    public MenuInflater getMenuInflater() {
        Context context;
        if (this.mMenuInflater == null) {
            initWindowDecorActionBar();
            fr frVar = this.mActionBar;
            if (frVar != null) {
                context = frVar.c();
            } else {
                context = this.mContext;
            }
            this.mMenuInflater = new jk(context);
        }
        return this.mMenuInflater;
    }

    public he getPanelState(int i, boolean z) {
        he[] heVarArr = this.mPanels;
        if (heVarArr == null || heVarArr.length <= i) {
            he[] heVarArr2 = new he[i + 1];
            if (heVarArr != null) {
                System.arraycopy(heVarArr, 0, heVarArr2, 0, heVarArr.length);
            }
            this.mPanels = heVarArr2;
            heVarArr = heVarArr2;
        }
        he heVar = heVarArr[i];
        if (heVar == null) {
            he heVar2 = new he(i);
            heVarArr[i] = heVar2;
            return heVar2;
        }
        return heVar;
    }

    ViewGroup getSubDecor() {
        return this.mSubDecor;
    }

    @Override // cal.gl
    public fr getSupportActionBar() {
        initWindowDecorActionBar();
        return this.mActionBar;
    }

    final CharSequence getTitle() {
        Object obj = this.mHost;
        if (obj instanceof Activity) {
            return ((Activity) obj).getTitle();
        }
        return this.mTitle;
    }

    public final Window.Callback getWindowCallback() {
        return this.mWindow.getCallback();
    }

    /* JADX WARN: Code restructure failed: missing block: B:14:0x002b, code lost:
    
        if (r0 == false) goto L22;
     */
    @Override // cal.gl
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct code enable 'Show inconsistent code' option in preferences
    */
    public boolean hasWindowFeature(int r4) {
        /*
            r3 = this;
            int r0 = r3.sanitizeWindowFeatureId(r4)
            r1 = 1
            if (r0 == r1) goto L29
            r2 = 2
            if (r0 == r2) goto L26
            r2 = 5
            if (r0 == r2) goto L23
            r2 = 10
            if (r0 == r2) goto L20
            r2 = 108(0x6c, float:1.51E-43)
            if (r0 == r2) goto L1d
            r2 = 109(0x6d, float:1.53E-43)
            if (r0 == r2) goto L1a
            goto L2d
        L1a:
            boolean r0 = r3.mOverlayActionBar
            goto L2b
        L1d:
            boolean r0 = r3.mHasActionBar
            goto L2b
        L20:
            boolean r0 = r3.mOverlayActionMode
            goto L2b
        L23:
            boolean r0 = r3.mFeatureIndeterminateProgress
            goto L2b
        L26:
            boolean r0 = r3.mFeatureProgress
            goto L2b
        L29:
            boolean r0 = r3.mWindowNoTitle
        L2b:
            if (r0 != 0) goto L38
        L2d:
            android.view.Window r0 = r3.mWindow
            boolean r4 = r0.hasFeature(r4)
            if (r4 == 0) goto L36
            goto L38
        L36:
            r4 = 0
            return r4
        L38:
            return r1
        */
        throw new UnsupportedOperationException("Method not decompiled: android.support.v7.app.AppCompatDelegateImpl.hasWindowFeature(int):boolean");
    }

    @Override // cal.gl
    public void installViewFactory() {
        LayoutInflater from = LayoutInflater.from(this.mContext);
        if (from.getFactory() == null) {
            from.setFactory2(this);
        } else {
            from.getFactory2();
        }
    }

    @Override // cal.gl
    public void invalidateOptionsMenu() {
        if (peekSupportActionBar() != null && !getSupportActionBar().u()) {
            invalidatePanelMenu(0);
        }
    }

    @Override // cal.gl
    public boolean isHandleNativeActionModesEnabled() {
        return this.mHandleNativeActionModes;
    }

    public int mapNightMode(Context context, int i) {
        if (i == -100) {
            return -1;
        }
        if (i != -1) {
            if (i != 0) {
                if (i != 1 && i != 2) {
                    if (i == 3) {
                        return getAutoBatteryNightModeManager(context).a();
                    }
                    throw new IllegalStateException("Unknown value set for night mode. Please use one of the MODE_NIGHT values from AppCompatDelegate.");
                }
            } else {
                if (((UiModeManager) context.getApplicationContext().getSystemService("uimode")).getNightMode() == 0) {
                    return -1;
                }
                return getAutoTimeNightModeManager(context).a();
            }
        }
        return i;
    }

    public boolean onBackPressed() {
        boolean z = this.mLongPressBackDown;
        this.mLongPressBackDown = false;
        he panelState = getPanelState(0, false);
        if (panelState != null && panelState.o) {
            if (!z) {
                closePanel(panelState, true);
            }
            return true;
        }
        je jeVar = this.mActionMode;
        if (jeVar != null) {
            jeVar.f();
            return true;
        }
        fr supportActionBar = getSupportActionBar();
        if (supportActionBar == null || !supportActionBar.t()) {
            return false;
        }
        return true;
    }

    @Override // cal.gl
    public void onConfigurationChanged(Configuration configuration) {
        fr supportActionBar;
        if (this.mHasActionBar && this.mSubDecorInstalled && (supportActionBar = getSupportActionBar()) != null) {
            supportActionBar.y();
        }
        mi.d().e(this.mContext);
        this.mEffectiveConfiguration = new Configuration(this.mContext.getResources().getConfiguration());
        applyApplicationSpecificConfig(false, false);
    }

    @Override // cal.gl
    public void onCreate(Bundle bundle) {
        String str;
        this.mBaseContextAttached = true;
        applyApplicationSpecificConfig(false);
        ensureWindow();
        Object obj = this.mHost;
        if (obj instanceof Activity) {
            try {
                Activity activity = (Activity) obj;
                try {
                    str = afm.c(activity, activity.getComponentName());
                } catch (PackageManager.NameNotFoundException e) {
                    throw new IllegalArgumentException(e);
                }
            } catch (IllegalArgumentException unused) {
                str = null;
            }
            if (str != null) {
                fr peekSupportActionBar = peekSupportActionBar();
                if (peekSupportActionBar == null) {
                    this.mEnableDefaultActionBarUp = true;
                } else {
                    peekSupportActionBar.j(true);
                }
            }
            addActiveDelegate(this);
        }
        this.mEffectiveConfiguration = new Configuration(this.mContext.getResources().getConfiguration());
        this.mCreated = true;
    }

    @Override // android.view.LayoutInflater.Factory2
    public final View onCreateView(View view, String str, Context context, AttributeSet attributeSet) {
        return createView(view, str, context, attributeSet);
    }

    /* JADX WARN: Removed duplicated region for block: B:16:0x0058  */
    @Override // cal.gl
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct code enable 'Show inconsistent code' option in preferences
    */
    public void onDestroy() {
        /*
            r3 = this;
            java.lang.Object r0 = r3.mHost
            boolean r0 = r0 instanceof android.app.Activity
            if (r0 == 0) goto L9
            removeActivityDelegate(r3)
        L9:
            boolean r0 = r3.mInvalidatePanelMenuPosted
            if (r0 == 0) goto L18
            android.view.Window r0 = r3.mWindow
            android.view.View r0 = r0.getDecorView()
            java.lang.Runnable r1 = r3.mInvalidatePanelMenuRunnable
            r0.removeCallbacks(r1)
        L18:
            r0 = 1
            r3.mDestroyed = r0
            int r0 = r3.mLocalNightMode
            r1 = -100
            if (r0 == r1) goto L45
            java.lang.Object r0 = r3.mHost
            boolean r1 = r0 instanceof android.app.Activity
            if (r1 == 0) goto L45
            android.app.Activity r0 = (android.app.Activity) r0
            boolean r0 = r0.isChangingConfigurations()
            if (r0 == 0) goto L45
            java.lang.Object r0 = r3.mHost
            cal.abh<java.lang.String, java.lang.Integer> r1 = android.support.v7.app.AppCompatDelegateImpl.sLocalNightModes
            java.lang.Class r0 = r0.getClass()
            java.lang.String r0 = r0.getName()
            int r2 = r3.mLocalNightMode
            java.lang.Integer r2 = java.lang.Integer.valueOf(r2)
            r1.put(r0, r2)
            goto L54
        L45:
            java.lang.Object r0 = r3.mHost
            cal.abh<java.lang.String, java.lang.Integer> r1 = android.support.v7.app.AppCompatDelegateImpl.sLocalNightModes
            java.lang.Class r0 = r0.getClass()
            java.lang.String r0 = r0.getName()
            r1.remove(r0)
        L54:
            cal.fr r0 = r3.mActionBar
            if (r0 == 0) goto L5b
            r0.g()
        L5b:
            r3.cleanupAutoManagers()
            return
        */
        throw new UnsupportedOperationException("Method not decompiled: android.support.v7.app.AppCompatDelegateImpl.onDestroy():void");
    }

    public boolean onKeyDown(int i, KeyEvent keyEvent) {
        boolean z = true;
        if (i != 4) {
            if (i == 82) {
                onKeyDownPanel(0, keyEvent);
                return true;
            }
        } else {
            if ((keyEvent.getFlags() & 128) == 0) {
                z = false;
            }
            this.mLongPressBackDown = z;
        }
        return false;
    }

    public boolean onKeyShortcut(int i, KeyEvent keyEvent) {
        fr supportActionBar = getSupportActionBar();
        if (supportActionBar != null && supportActionBar.v(i, keyEvent)) {
            return true;
        }
        he heVar = this.mPreparedPanel;
        if (heVar != null && performPanelShortcut(heVar, keyEvent.getKeyCode(), keyEvent, 1)) {
            he heVar2 = this.mPreparedPanel;
            if (heVar2 != null) {
                heVar2.n = true;
            }
            return true;
        }
        if (this.mPreparedPanel == null) {
            he panelState = getPanelState(0, true);
            preparePanel(panelState, keyEvent);
            boolean performPanelShortcut = performPanelShortcut(panelState, keyEvent.getKeyCode(), keyEvent, 1);
            panelState.m = false;
            if (performPanelShortcut) {
                return true;
            }
        }
        return false;
    }

    public boolean onKeyUp(int i, KeyEvent keyEvent) {
        if (i != 4) {
            if (i == 82) {
                onKeyUpPanel(0, keyEvent);
                return true;
            }
        } else if (onBackPressed()) {
            return true;
        }
        return false;
    }

    @Override // cal.kc
    public boolean onMenuItemSelected(ke keVar, MenuItem menuItem) {
        he findMenuPanel;
        Window.Callback windowCallback = getWindowCallback();
        if (windowCallback != null && !this.mDestroyed && (findMenuPanel = findMenuPanel(keVar.d())) != null) {
            return windowCallback.onMenuItemSelected(findMenuPanel.a, menuItem);
        }
        return false;
    }

    @Override // cal.kc
    public void onMenuModeChange(ke keVar) {
        reopenMenu(true);
    }

    public void onMenuOpened(int i) {
        fr supportActionBar;
        if (i == 108 && (supportActionBar = getSupportActionBar()) != null) {
            supportActionBar.e(true);
        }
    }

    public void onPanelClosed(int i) {
        if (i == 108) {
            fr supportActionBar = getSupportActionBar();
            if (supportActionBar != null) {
                supportActionBar.e(false);
                return;
            }
            return;
        }
        if (i == 0) {
            he panelState = getPanelState(0, true);
            if (panelState.o) {
                closePanel(panelState, false);
            }
        }
    }

    @Override // cal.gl
    public void onPostCreate(Bundle bundle) {
        ensureSubDecor();
    }

    @Override // cal.gl
    public void onPostResume() {
        fr supportActionBar = getSupportActionBar();
        if (supportActionBar != null) {
            supportActionBar.o(true);
        }
    }

    @Override // cal.gl
    public void onStart() {
        applyApplicationSpecificConfig(true, false);
    }

    @Override // cal.gl
    public void onStop() {
        fr supportActionBar = getSupportActionBar();
        if (supportActionBar != null) {
            supportActionBar.o(false);
        }
    }

    final fr peekSupportActionBar() {
        return this.mActionBar;
    }

    @Override // cal.gl
    public boolean requestWindowFeature(int i) {
        int sanitizeWindowFeatureId = sanitizeWindowFeatureId(i);
        if (this.mWindowNoTitle && sanitizeWindowFeatureId == 108) {
            return false;
        }
        if (this.mHasActionBar && sanitizeWindowFeatureId == 1) {
            this.mHasActionBar = false;
        }
        if (sanitizeWindowFeatureId != 1) {
            if (sanitizeWindowFeatureId != 2) {
                if (sanitizeWindowFeatureId != 5) {
                    if (sanitizeWindowFeatureId != 10) {
                        if (sanitizeWindowFeatureId != 108) {
                            if (sanitizeWindowFeatureId != 109) {
                                return this.mWindow.requestFeature(sanitizeWindowFeatureId);
                            }
                            throwFeatureRequestIfSubDecorInstalled();
                            this.mOverlayActionBar = true;
                            return true;
                        }
                        throwFeatureRequestIfSubDecorInstalled();
                        this.mHasActionBar = true;
                        return true;
                    }
                    throwFeatureRequestIfSubDecorInstalled();
                    this.mOverlayActionMode = true;
                    return true;
                }
                throwFeatureRequestIfSubDecorInstalled();
                this.mFeatureIndeterminateProgress = true;
                return true;
            }
            throwFeatureRequestIfSubDecorInstalled();
            this.mFeatureProgress = true;
            return true;
        }
        throwFeatureRequestIfSubDecorInstalled();
        this.mWindowNoTitle = true;
        return true;
    }

    public void setConfigurationLocales(Configuration configuration, aiu aiuVar) {
        String languageTags;
        LocaleList forLanguageTags;
        languageTags = aiuVar.b.a.toLanguageTags();
        forLanguageTags = LocaleList.forLanguageTags(languageTags);
        configuration.setLocales(forLanguageTags);
    }

    @Override // cal.gl
    public void setContentView(int i) {
        ensureSubDecor();
        ViewGroup viewGroup = (ViewGroup) this.mSubDecor.findViewById(R.id.content);
        viewGroup.removeAllViews();
        LayoutInflater.from(this.mContext).inflate(i, viewGroup);
        gy gyVar = this.mAppCompatWindowCallback;
        Window.Callback callback = this.mWindow.getCallback();
        try {
            gyVar.a = true;
            callback.onContentChanged();
        } finally {
            gyVar.a = false;
        }
    }

    public void setDefaultLocalesForLocaleList(aiu aiuVar) {
        String languageTags;
        LocaleList forLanguageTags;
        languageTags = aiuVar.b.a.toLanguageTags();
        forLanguageTags = LocaleList.forLanguageTags(languageTags);
        LocaleList.setDefault(forLanguageTags);
    }

    @Override // cal.gl
    public void setHandleNativeActionModesEnabled(boolean z) {
        this.mHandleNativeActionModes = z;
    }

    @Override // cal.gl
    public void setLocalNightMode(int i) {
        if (this.mLocalNightMode != i) {
            this.mLocalNightMode = i;
            if (this.mBaseContextAttached) {
                applyDayNight();
            }
        }
    }

    @Override // cal.gl
    public void setOnBackInvokedDispatcher(OnBackInvokedDispatcher onBackInvokedDispatcher) {
        OnBackInvokedDispatcher onBackInvokedDispatcher2;
        OnBackInvokedCallback onBackInvokedCallback;
        OnBackInvokedDispatcher onBackInvokedDispatcher3 = this.mDispatcher;
        if (onBackInvokedDispatcher3 != null && (onBackInvokedCallback = this.mBackCallback) != null) {
            onBackInvokedDispatcher3.unregisterOnBackInvokedCallback(onBackInvokedCallback);
            this.mBackCallback = null;
        }
        if (onBackInvokedDispatcher == null) {
            Object obj = this.mHost;
            if ((obj instanceof Activity) && ((Activity) obj).getWindow() != null) {
                onBackInvokedDispatcher2 = ((Activity) this.mHost).getOnBackInvokedDispatcher();
                this.mDispatcher = onBackInvokedDispatcher2;
                updateBackInvokedCallbackState();
            }
        }
        this.mDispatcher = onBackInvokedDispatcher;
        updateBackInvokedCallbackState();
    }

    @Override // cal.gl
    public void setSupportActionBar(Toolbar toolbar) {
        if (!(this.mHost instanceof Activity)) {
            return;
        }
        fr supportActionBar = getSupportActionBar();
        if (!(supportActionBar instanceof hz)) {
            this.mMenuInflater = null;
            if (supportActionBar != null) {
                supportActionBar.g();
            }
            this.mActionBar = null;
            if (toolbar != null) {
                hr hrVar = new hr(toolbar, getTitle(), this.mAppCompatWindowCallback);
                this.mActionBar = hrVar;
                this.mAppCompatWindowCallback.e = hrVar.d;
                if (!toolbar.y) {
                    toolbar.y = true;
                    toolbar.s();
                }
            } else {
                this.mAppCompatWindowCallback.e = null;
            }
            invalidateOptionsMenu();
            return;
        }
        throw new IllegalStateException("This Activity already has an action bar supplied by the window decor. Do not request Window.FEATURE_SUPPORT_ACTION_BAR and set windowActionBar to false in your theme to use a Toolbar instead.");
    }

    @Override // cal.gl
    public void setTheme(int i) {
        this.mThemeResId = i;
    }

    @Override // cal.gl
    public final void setTitle(CharSequence charSequence) {
        this.mTitle = charSequence;
        nx nxVar = this.mDecorContentParent;
        if (nxVar != null) {
            nxVar.l(charSequence);
            return;
        }
        if (peekSupportActionBar() != null) {
            peekSupportActionBar().q(charSequence);
            return;
        }
        TextView textView = this.mTitleView;
        if (textView != null) {
            textView.setText(charSequence);
        }
    }

    public final boolean shouldAnimateActionModeView() {
        ViewGroup viewGroup;
        if (this.mSubDecorInstalled && (viewGroup = this.mSubDecor) != null && viewGroup.isLaidOut()) {
            return true;
        }
        return false;
    }

    public boolean shouldRegisterBackInvokedCallback() {
        if (this.mDispatcher == null) {
            return false;
        }
        he panelState = getPanelState(0, false);
        if ((panelState == null || !panelState.o) && this.mActionMode == null) {
            return false;
        }
        return true;
    }

    @Override // cal.gl
    public je startSupportActionMode(jd jdVar) {
        if (jdVar != null) {
            je jeVar = this.mActionMode;
            if (jeVar != null) {
                jeVar.f();
            }
            gw gwVar = new gw(this, jdVar);
            fr supportActionBar = getSupportActionBar();
            if (supportActionBar != null) {
                this.mActionMode = supportActionBar.d(gwVar);
            }
            if (this.mActionMode == null) {
                this.mActionMode = startSupportActionModeFromWindow(gwVar);
            }
            updateBackInvokedCallbackState();
            return this.mActionMode;
        }
        throw new IllegalArgumentException("ActionMode callback can not be null.");
    }

    public je startSupportActionModeFromWindow(jd jdVar) {
        Context context;
        endOnGoingFadeAnimation();
        je jeVar = this.mActionMode;
        if (jeVar != null) {
            jeVar.f();
        }
        if (!(jdVar instanceof gw)) {
            jdVar = new gw(this, jdVar);
        }
        if (this.mActionModeView == null) {
            if (this.mIsFloating) {
                TypedValue typedValue = new TypedValue();
                Resources.Theme theme = this.mContext.getTheme();
                theme.resolveAttribute(com.google.android.calendar.R.attr.actionBarTheme, typedValue, true);
                if (typedValue.resourceId != 0) {
                    Resources.Theme newTheme = this.mContext.getResources().newTheme();
                    newTheme.setTo(theme);
                    newTheme.applyStyle(typedValue.resourceId, true);
                    context = new wa(this.mContext, 0);
                    context.getTheme().setTo(newTheme);
                } else {
                    context = this.mContext;
                }
                this.mActionModeView = new ActionBarContextView(context);
                PopupWindow popupWindow = new PopupWindow(context, (AttributeSet) null, com.google.android.calendar.R.attr.actionModePopupWindowStyle);
                this.mActionModePopup = popupWindow;
                popupWindow.setWindowLayoutType(2);
                this.mActionModePopup.setContentView(this.mActionModeView);
                this.mActionModePopup.setWidth(-1);
                context.getTheme().resolveAttribute(com.google.android.calendar.R.attr.actionBarSize, typedValue, true);
                this.mActionModeView.setContentHeight(TypedValue.complexToDimensionPixelSize(typedValue.data, context.getResources().getDisplayMetrics()));
                this.mActionModePopup.setHeight(-2);
                this.mShowActionModePopup = new gr(this);
            } else {
                ViewStubCompat viewStubCompat = (ViewStubCompat) this.mSubDecor.findViewById(com.google.android.calendar.R.id.action_mode_bar_stub);
                if (viewStubCompat != null) {
                    viewStubCompat.a = LayoutInflater.from(getActionBarThemedContext());
                    this.mActionModeView = (ActionBarContextView) viewStubCompat.a();
                }
            }
        }
        if (this.mActionModeView != null) {
            endOnGoingFadeAnimation();
            ActionBarContextView actionBarContextView = this.mActionModeView;
            actionBarContextView.removeAllViews();
            actionBarContextView.k = null;
            actionBarContextView.c = null;
            actionBarContextView.d = null;
            View view = actionBarContextView.j;
            if (view != null) {
                view.setOnClickListener(null);
            }
            jf jfVar = new jf(this.mActionModeView.getContext(), this.mActionModeView, jdVar);
            if (jdVar.c(jfVar, jfVar.b)) {
                jfVar.a.d(jfVar, jfVar.b);
                this.mActionModeView.d(jfVar);
                this.mActionMode = jfVar;
                if (shouldAnimateActionModeView()) {
                    this.mActionModeView.setAlpha(0.0f);
                    amq d = ame.d(this.mActionModeView);
                    View view2 = (View) d.a.get();
                    if (view2 != null) {
                        view2.animate().alpha(1.0f);
                    }
                    this.mFadeAnim = d;
                    gs gsVar = new gs(this);
                    View view3 = (View) d.a.get();
                    if (view3 != null) {
                        view3.animate().setListener(new amp(gsVar));
                    }
                } else {
                    this.mActionModeView.setAlpha(1.0f);
                    this.mActionModeView.setVisibility(0);
                    if (this.mActionModeView.getParent() instanceof View) {
                        als.c((View) this.mActionModeView.getParent());
                    }
                }
                if (this.mActionModePopup != null) {
                    this.mWindow.getDecorView().post(this.mShowActionModePopup);
                }
            } else {
                this.mActionMode = null;
            }
        }
        updateBackInvokedCallbackState();
        return this.mActionMode;
    }

    public void updateBackInvokedCallbackState() {
        if (Build.VERSION.SDK_INT >= 33) {
            if (shouldRegisterBackInvokedCallback()) {
                if (this.mBackCallback == null) {
                    OnBackInvokedDispatcher onBackInvokedDispatcher = this.mDispatcher;
                    OnBackInvokedCallback onBackInvokedCallback = new OnBackInvokedCallback() { // from class: cal.gx
                        public final void onBackInvoked() {
                            AppCompatDelegateImpl.this.onBackPressed();
                        }
                    };
                    onBackInvokedDispatcher.registerOnBackInvokedCallback(1000000, onBackInvokedCallback);
                    this.mBackCallback = onBackInvokedCallback;
                    return;
                }
                return;
            }
            OnBackInvokedCallback onBackInvokedCallback2 = this.mBackCallback;
            if (onBackInvokedCallback2 != null) {
                this.mDispatcher.unregisterOnBackInvokedCallback(onBackInvokedCallback2);
                this.mBackCallback = null;
            }
        }
    }

    public final int updateStatusGuard(anq anqVar, Rect rect) {
        int i;
        boolean z;
        boolean z2;
        int i2;
        int i3;
        Insets of;
        WindowInsets.Builder systemWindowInsets;
        WindowInsets build;
        Insets systemWindowInsets2;
        int i4;
        int i5;
        int i6;
        int i7;
        int i8 = 0;
        if (anqVar != null) {
            i = anqVar.b.c().c;
        } else if (rect != null) {
            i = rect.top;
        } else {
            i = 0;
        }
        ActionBarContextView actionBarContextView = this.mActionModeView;
        if (actionBarContextView != null && (actionBarContextView.getLayoutParams() instanceof ViewGroup.MarginLayoutParams)) {
            ViewGroup.MarginLayoutParams marginLayoutParams = (ViewGroup.MarginLayoutParams) this.mActionModeView.getLayoutParams();
            if (this.mActionModeView.isShown()) {
                if (this.mTempRect1 == null) {
                    this.mTempRect1 = new Rect();
                    this.mTempRect2 = new Rect();
                }
                Rect rect2 = this.mTempRect1;
                Rect rect3 = this.mTempRect2;
                if (anqVar == null) {
                    rect2.set(rect);
                } else {
                    rect2.set(anqVar.b.c().b, anqVar.b.c().c, anqVar.b.c().d, anqVar.b.c().e);
                }
                ViewGroup viewGroup = this.mSubDecor;
                if (Build.VERSION.SDK_INT >= 29) {
                    WindowInsets.Builder builder = new WindowInsets.Builder();
                    of = Insets.of(rect2);
                    systemWindowInsets = builder.setSystemWindowInsets(of);
                    build = systemWindowInsets.build();
                    systemWindowInsets2 = viewGroup.computeSystemWindowInsets(build, rect3).getSystemWindowInsets();
                    i4 = systemWindowInsets2.left;
                    i5 = systemWindowInsets2.top;
                    i6 = systemWindowInsets2.right;
                    i7 = systemWindowInsets2.bottom;
                    rect2.set(i4, i5, i6, i7);
                } else {
                    if (!tr.a) {
                        tr.a = true;
                        try {
                            tr.b = View.class.getDeclaredMethod("computeFitSystemWindows", Rect.class, Rect.class);
                            if (!tr.b.isAccessible()) {
                                tr.b.setAccessible(true);
                            }
                        } catch (NoSuchMethodException unused) {
                        }
                    }
                    Method method = tr.b;
                    if (method != null) {
                        try {
                            method.invoke(viewGroup, rect2, rect3);
                        } catch (Exception unused2) {
                        }
                    }
                }
                int i9 = rect2.top;
                int i10 = rect2.left;
                int i11 = rect2.right;
                anq a = alv.a(this.mSubDecor);
                if (a == null) {
                    i2 = 0;
                } else {
                    i2 = a.b.c().b;
                }
                if (a == null) {
                    i3 = 0;
                } else {
                    i3 = a.b.c().d;
                }
                if (marginLayoutParams.topMargin == i9 && marginLayoutParams.leftMargin == i10 && marginLayoutParams.rightMargin == i11) {
                    z2 = false;
                } else {
                    marginLayoutParams.topMargin = i9;
                    marginLayoutParams.leftMargin = i10;
                    marginLayoutParams.rightMargin = i11;
                    z2 = true;
                }
                if (i9 > 0 && this.mStatusGuard == null) {
                    View view = new View(this.mContext);
                    this.mStatusGuard = view;
                    view.setVisibility(8);
                    FrameLayout.LayoutParams layoutParams = new FrameLayout.LayoutParams(-1, marginLayoutParams.topMargin, 51);
                    layoutParams.leftMargin = i2;
                    layoutParams.rightMargin = i3;
                    this.mSubDecor.addView(this.mStatusGuard, -1, layoutParams);
                } else {
                    View view2 = this.mStatusGuard;
                    if (view2 != null) {
                        ViewGroup.MarginLayoutParams marginLayoutParams2 = (ViewGroup.MarginLayoutParams) view2.getLayoutParams();
                        if (marginLayoutParams2.height != marginLayoutParams.topMargin || marginLayoutParams2.leftMargin != i2 || marginLayoutParams2.rightMargin != i3) {
                            marginLayoutParams2.height = marginLayoutParams.topMargin;
                            marginLayoutParams2.leftMargin = i2;
                            marginLayoutParams2.rightMargin = i3;
                            this.mStatusGuard.setLayoutParams(marginLayoutParams2);
                        }
                    }
                }
                View view3 = this.mStatusGuard;
                if (view3 != null) {
                    z = true;
                } else {
                    z = false;
                }
                if (z && view3.getVisibility() != 0) {
                    updateStatusGuardColor(this.mStatusGuard);
                }
                if (!this.mOverlayActionMode && z) {
                    i = 0;
                }
            } else if (marginLayoutParams.topMargin != 0) {
                marginLayoutParams.topMargin = 0;
                z = false;
                z2 = true;
            } else {
                z2 = false;
                z = false;
            }
            if (z2) {
                this.mActionModeView.setLayoutParams(marginLayoutParams);
            }
        } else {
            z = false;
        }
        View view4 = this.mStatusGuard;
        if (view4 != null) {
            if (true != z) {
                i8 = 8;
            }
            view4.setVisibility(i8);
        }
        return i;
    }

    public AppCompatDelegateImpl(Dialog dialog, gg ggVar) {
        this(dialog.getContext(), dialog.getWindow(), ggVar, dialog);
    }

    private boolean applyApplicationSpecificConfig(boolean z, boolean z2) {
        BroadcastReceiver broadcastReceiver;
        BroadcastReceiver broadcastReceiver2;
        if (this.mDestroyed) {
            return false;
        }
        int calculateNightMode = calculateNightMode();
        int mapNightMode = mapNightMode(this.mContext, calculateNightMode);
        aiu calculateApplicationLocales = Build.VERSION.SDK_INT < 33 ? calculateApplicationLocales(this.mContext) : null;
        if (!z2 && calculateApplicationLocales != null) {
            calculateApplicationLocales = getConfigurationLocales(this.mContext.getResources().getConfiguration());
        }
        boolean updateAppConfiguration = updateAppConfiguration(mapNightMode, calculateApplicationLocales, z);
        if (calculateNightMode == 0) {
            getAutoTimeNightModeManager(this.mContext).d();
        } else {
            hb hbVar = this.mAutoTimeNightModeManager;
            if (hbVar != null && (broadcastReceiver = hbVar.b) != null) {
                try {
                    hbVar.c.mContext.unregisterReceiver(broadcastReceiver);
                } catch (IllegalArgumentException unused) {
                }
                hbVar.b = null;
            }
            if (calculateNightMode == 3) {
                getAutoBatteryNightModeManager(this.mContext).d();
                return updateAppConfiguration;
            }
        }
        hb hbVar2 = this.mAutoBatteryNightModeManager;
        if (hbVar2 != null && (broadcastReceiver2 = hbVar2.b) != null) {
            try {
                hbVar2.c.mContext.unregisterReceiver(broadcastReceiver2);
            } catch (IllegalArgumentException unused2) {
            }
            hbVar2.b = null;
        }
        return updateAppConfiguration;
    }

    private hb getAutoTimeNightModeManager(Context context) {
        if (this.mAutoTimeNightModeManager == null) {
            if (hu.a == null) {
                Context applicationContext = context.getApplicationContext();
                hu.a = new hu(applicationContext, (LocationManager) applicationContext.getSystemService("location"));
            }
            this.mAutoTimeNightModeManager = new hc(this, hu.a);
        }
        return this.mAutoTimeNightModeManager;
    }

    public void closePanel(he heVar, boolean z) {
        ViewGroup viewGroup;
        nx nxVar;
        if (z && heVar.a == 0 && (nxVar = this.mDecorContentParent) != null && nxVar.p()) {
            checkCloseActionMenu(heVar.j);
            return;
        }
        WindowManager windowManager = (WindowManager) this.mContext.getSystemService("window");
        if (windowManager != null && heVar.o && (viewGroup = heVar.g) != null) {
            windowManager.removeView(viewGroup);
            if (z) {
                callOnPanelClosed(heVar.a, heVar, null);
            }
        }
        heVar.m = false;
        heVar.n = false;
        heVar.o = false;
        heVar.h = null;
        heVar.q = true;
        if (this.mPreparedPanel == heVar) {
            this.mPreparedPanel = null;
        }
        if (heVar.a == 0) {
            updateBackInvokedCallbackState();
        }
    }

    @Override // android.view.LayoutInflater.Factory
    public View onCreateView(String str, Context context, AttributeSet attributeSet) {
        return onCreateView(null, str, context, attributeSet);
    }

    public AppCompatDelegateImpl(Context context, Activity activity, gg ggVar) {
        this(context, null, ggVar, activity);
    }

    public AppCompatDelegateImpl(Context context, Window window, gg ggVar) {
        this(context, window, ggVar, context);
    }

    private AppCompatDelegateImpl(Context context, Window window, gg ggVar, Object obj) {
        gf tryUnwrapContext;
        this.mFadeAnim = null;
        this.mHandleNativeActionModes = true;
        this.mLocalNightMode = -100;
        this.mInvalidatePanelMenuRunnable = new gn(this);
        this.mContext = context;
        this.mAppCompatCallback = ggVar;
        this.mHost = obj;
        if ((obj instanceof Dialog) && (tryUnwrapContext = tryUnwrapContext()) != null) {
            if (tryUnwrapContext.g == null) {
                tryUnwrapContext.g = gl.create(tryUnwrapContext, tryUnwrapContext);
            }
            this.mLocalNightMode = tryUnwrapContext.g.getLocalNightMode();
        }
        if (this.mLocalNightMode == -100) {
            abh<String, Integer> abhVar = sLocalNightModes;
            Integer num = (Integer) abhVar.get(obj.getClass().getName());
            if (num != null) {
                this.mLocalNightMode = num.intValue();
                abhVar.remove(obj.getClass().getName());
            }
        }
        if (window != null) {
            attachToWindow(window);
        }
        mi.f();
    }

    @Override // cal.gl
    public void setContentView(View view) {
        ensureSubDecor();
        ViewGroup viewGroup = (ViewGroup) this.mSubDecor.findViewById(R.id.content);
        viewGroup.removeAllViews();
        viewGroup.addView(view);
        gy gyVar = this.mAppCompatWindowCallback;
        Window.Callback callback = this.mWindow.getCallback();
        try {
            gyVar.a = true;
            callback.onContentChanged();
        } finally {
            gyVar.a = false;
        }
    }

    @Override // cal.gl
    public void setContentView(View view, ViewGroup.LayoutParams layoutParams) {
        ensureSubDecor();
        ViewGroup viewGroup = (ViewGroup) this.mSubDecor.findViewById(R.id.content);
        viewGroup.removeAllViews();
        viewGroup.addView(view, layoutParams);
        gy gyVar = this.mAppCompatWindowCallback;
        Window.Callback callback = this.mWindow.getCallback();
        try {
            gyVar.a = true;
            callback.onContentChanged();
        } finally {
            gyVar.a = false;
        }
    }

    @Override // cal.gl
    public void onSaveInstanceState(Bundle bundle) {
    }

    public void onSubDecorInstalled(ViewGroup viewGroup) {
    }
}
