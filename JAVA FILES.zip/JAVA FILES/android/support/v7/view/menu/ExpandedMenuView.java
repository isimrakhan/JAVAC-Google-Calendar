package android.support.v7.view.menu;

import android.R;
import android.content.Context;
import android.util.AttributeSet;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ListView;
import cal.kd;
import cal.ke;
import cal.kh;
import cal.kt;
import cal.sv;

/* compiled from: PG */
/* loaded from: classes.dex */
public final class ExpandedMenuView extends ListView implements AdapterView.OnItemClickListener, kd, kt {
    private static final int[] a = {R.attr.background, R.attr.divider};
    private ke b;

    public ExpandedMenuView(Context context, AttributeSet attributeSet) {
        this(context, attributeSet, R.attr.listViewStyle);
    }

    @Override // cal.kt
    public final void a(ke keVar) {
        this.b = keVar;
    }

    @Override // cal.kd
    public final boolean b(kh khVar) {
        throw null;
    }

    @Override // android.widget.ListView, android.widget.AbsListView, android.widget.AdapterView, android.view.ViewGroup, android.view.View
    protected final void onDetachedFromWindow() {
        super.onDetachedFromWindow();
        setChildrenDrawingCacheEnabled(false);
    }

    @Override // android.widget.AdapterView.OnItemClickListener
    public final void onItemClick(AdapterView adapterView, View view, int i, long j) {
        this.b.x((kh) getAdapter().getItem(i), null, 0);
    }

    public ExpandedMenuView(Context context, AttributeSet attributeSet, int i) {
        super(context, attributeSet);
        setOnItemClickListener(this);
        sv svVar = new sv(context, context.obtainStyledAttributes(attributeSet, a, i, 0));
        if (svVar.b.hasValue(0)) {
            setBackgroundDrawable(svVar.b(0));
        }
        if (svVar.b.hasValue(1)) {
            setDivider(svVar.b(1));
        }
        svVar.b.recycle();
    }
}
