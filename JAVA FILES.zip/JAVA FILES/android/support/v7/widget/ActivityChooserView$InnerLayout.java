package android.support.v7.widget;

import android.R;
import android.content.Context;
import android.util.AttributeSet;
import android.widget.LinearLayout;
import cal.sv;

/* compiled from: PG */
/* loaded from: classes.dex */
public class ActivityChooserView$InnerLayout extends LinearLayout {
    private static final int[] a = {R.attr.background};

    public ActivityChooserView$InnerLayout(Context context, AttributeSet attributeSet) {
        super(context, attributeSet);
        sv svVar = new sv(context, context.obtainStyledAttributes(attributeSet, a));
        setBackgroundDrawable(svVar.b(0));
        svVar.b.recycle();
    }
}
