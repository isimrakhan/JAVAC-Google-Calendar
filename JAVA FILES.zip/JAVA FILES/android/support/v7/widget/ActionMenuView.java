package android.support.v7.widget;

import android.content.Context;
import android.content.res.Configuration;
import android.support.v7.view.menu.ActionMenuItemView;
import android.text.TextUtils;
import android.util.AttributeSet;
import android.view.ContextThemeWrapper;
import android.view.KeyEvent;
import android.view.Menu;
import android.view.View;
import android.view.ViewGroup;
import android.view.accessibility.AccessibilityEvent;
import cal.kc;
import cal.kd;
import cal.ke;
import cal.kh;
import cal.kn;
import cal.kq;
import cal.kt;
import cal.ll;
import cal.lq;
import cal.lu;
import cal.lv;
import cal.lw;
import cal.lx;
import cal.ly;
import cal.ph;
import cal.pi;
import cal.sy;
import java.lang.ref.WeakReference;

/* compiled from: PG */
/* loaded from: classes.dex */
public class ActionMenuView extends pi implements kd, kt {
    public ke a;
    public boolean b;
    public lu c;
    public kq d;
    public kc e;
    public sy f;
    private Context l;
    private int m;
    private boolean n;
    private int o;
    private int p;
    private int q;

    public ActionMenuView(Context context) {
        this(context, null);
    }

    public static final lx h(ViewGroup.LayoutParams layoutParams) {
        lx lxVar;
        if (layoutParams != null) {
            if (layoutParams instanceof lx) {
                lxVar = new lx((lx) layoutParams);
            } else {
                lxVar = new lx(layoutParams);
            }
            if (lxVar.gravity <= 0) {
                lxVar.gravity = 16;
            }
            return lxVar;
        }
        lx lxVar2 = new lx();
        lxVar2.gravity = 16;
        return lxVar2;
    }

    @Override // cal.kt
    public final void a(ke keVar) {
        this.a = keVar;
    }

    @Override // cal.kd
    public final boolean b(kh khVar) {
        return this.a.x(khVar, null, 0);
    }

    /* JADX INFO: Access modifiers changed from: protected */
    @Override // cal.pi
    /* renamed from: c */
    public final /* synthetic */ ph generateDefaultLayoutParams() {
        lx lxVar = new lx();
        lxVar.gravity = 16;
        return lxVar;
    }

    @Override // cal.pi, android.view.ViewGroup
    protected final boolean checkLayoutParams(ViewGroup.LayoutParams layoutParams) {
        return layoutParams instanceof lx;
    }

    @Override // cal.pi
    /* renamed from: di */
    public final /* synthetic */ ph generateLayoutParams(AttributeSet attributeSet) {
        return new lx(getContext(), attributeSet);
    }

    @Override // android.view.View
    public final boolean dispatchPopulateAccessibilityEvent(AccessibilityEvent accessibilityEvent) {
        return false;
    }

    /* JADX INFO: Access modifiers changed from: protected */
    @Override // cal.pi
    /* renamed from: dj */
    public final /* bridge */ /* synthetic */ ph generateLayoutParams(ViewGroup.LayoutParams layoutParams) {
        return h(layoutParams);
    }

    public final Menu f() {
        if (this.a == null) {
            Context context = getContext();
            ke keVar = new ke(context);
            this.a = keVar;
            keVar.d = new ly(this);
            lu luVar = new lu(context);
            this.c = luVar;
            luVar.k = true;
            luVar.l = true;
            kq kqVar = this.d;
            if (kqVar == null) {
                kqVar = new lw();
            }
            luVar.e = kqVar;
            ke keVar2 = this.a;
            lu luVar2 = this.c;
            Context context2 = this.l;
            keVar2.r.add(new WeakReference(luVar2));
            luVar2.c(context2, keVar2);
            keVar2.i = true;
            lu luVar3 = this.c;
            luVar3.f = this;
            this.a = luVar3.c;
        }
        return this.a;
    }

    protected final boolean g(int i) {
        boolean z = false;
        if (i == 0) {
            return false;
        }
        KeyEvent.Callback childAt = getChildAt(i - 1);
        KeyEvent.Callback childAt2 = getChildAt(i);
        if (i < getChildCount() && (childAt instanceof lv)) {
            z = ((lv) childAt).b();
        }
        if (i > 0 && (childAt2 instanceof lv)) {
            return ((lv) childAt2).c() | z;
        }
        return z;
    }

    @Override // cal.pi, android.view.ViewGroup
    protected final /* synthetic */ ViewGroup.LayoutParams generateDefaultLayoutParams() {
        lx lxVar = new lx();
        lxVar.gravity = 16;
        return lxVar;
    }

    @Override // cal.pi, android.view.ViewGroup
    public final /* synthetic */ ViewGroup.LayoutParams generateLayoutParams(AttributeSet attributeSet) {
        return new lx(getContext(), attributeSet);
    }

    @Override // android.view.View
    public final void onConfigurationChanged(Configuration configuration) {
        kn knVar;
        super.onConfigurationChanged(configuration);
        lu luVar = this.c;
        if (luVar != null) {
            luVar.j();
            lq lqVar = this.c.o;
            if (lqVar != null && (knVar = lqVar.f) != null && knVar.x()) {
                this.c.k();
                this.c.l();
            }
        }
    }

    @Override // android.view.ViewGroup, android.view.View
    public final void onDetachedFromWindow() {
        kn knVar;
        super.onDetachedFromWindow();
        lu luVar = this.c;
        if (luVar != null) {
            luVar.k();
            ll llVar = luVar.p;
            if (llVar != null && (knVar = llVar.f) != null && knVar.x()) {
                llVar.f.m();
            }
        }
    }

    @Override // cal.pi, android.view.ViewGroup, android.view.View
    protected final void onLayout(boolean z, int i, int i2, int i3, int i4) {
        int i5;
        int i6;
        int i7;
        int width;
        int i8;
        if (!this.n) {
            if (this.h == 1) {
                l(i, i2, i3, i4);
                return;
            } else {
                k(i, i2, i3, i4);
                return;
            }
        }
        int childCount = getChildCount();
        int i9 = i4 - i2;
        int i10 = this.k;
        int i11 = i3 - i;
        int paddingRight = (i11 - getPaddingRight()) - getPaddingLeft();
        int layoutDirection = getLayoutDirection();
        int i12 = 0;
        int i13 = 0;
        int i14 = 0;
        while (true) {
            i5 = i9 / 2;
            if (i12 >= childCount) {
                break;
            }
            View childAt = getChildAt(i12);
            if (childAt.getVisibility() != 8) {
                lx lxVar = (lx) childAt.getLayoutParams();
                if (lxVar.a) {
                    int measuredWidth = childAt.getMeasuredWidth();
                    if (g(i12)) {
                        measuredWidth += i10;
                    }
                    int measuredHeight = childAt.getMeasuredHeight();
                    if (layoutDirection == 1) {
                        i8 = getPaddingLeft() + lxVar.leftMargin;
                        width = i8 + measuredWidth;
                    } else {
                        width = (getWidth() - getPaddingRight()) - lxVar.rightMargin;
                        i8 = width - measuredWidth;
                    }
                    int i15 = i5 - (measuredHeight / 2);
                    childAt.layout(i8, i15, width, measuredHeight + i15);
                    paddingRight -= measuredWidth;
                    i13 = 1;
                } else {
                    paddingRight -= (childAt.getMeasuredWidth() + lxVar.leftMargin) + lxVar.rightMargin;
                    g(i12);
                    i14++;
                }
            }
            i12++;
        }
        if (childCount == 1) {
            if (i13 != 0) {
                childCount = 1;
            } else {
                View childAt2 = getChildAt(0);
                int measuredWidth2 = childAt2.getMeasuredWidth();
                int measuredHeight2 = childAt2.getMeasuredHeight();
                int i16 = i5 - (measuredHeight2 / 2);
                int i17 = (i11 / 2) - (measuredWidth2 / 2);
                childAt2.layout(i17, i16, measuredWidth2 + i17, measuredHeight2 + i16);
                return;
            }
        }
        int i18 = i14 - (i13 ^ 1);
        if (i18 > 0) {
            i7 = paddingRight / i18;
            i6 = 0;
        } else {
            i6 = 0;
            i7 = 0;
        }
        int max = Math.max(i6, i7);
        if (layoutDirection == 1) {
            int width2 = getWidth() - getPaddingRight();
            for (int i19 = i6; i19 < childCount; i19++) {
                View childAt3 = getChildAt(i19);
                lx lxVar2 = (lx) childAt3.getLayoutParams();
                if (childAt3.getVisibility() != 8 && !lxVar2.a) {
                    int i20 = width2 - lxVar2.rightMargin;
                    int measuredWidth3 = childAt3.getMeasuredWidth();
                    int measuredHeight3 = childAt3.getMeasuredHeight();
                    int i21 = i5 - (measuredHeight3 / 2);
                    childAt3.layout(i20 - measuredWidth3, i21, i20, measuredHeight3 + i21);
                    width2 = i20 - ((measuredWidth3 + lxVar2.leftMargin) + max);
                }
            }
            return;
        }
        int paddingLeft = getPaddingLeft();
        for (int i22 = i6; i22 < childCount; i22++) {
            View childAt4 = getChildAt(i22);
            lx lxVar3 = (lx) childAt4.getLayoutParams();
            if (childAt4.getVisibility() != 8 && !lxVar3.a) {
                int i23 = paddingLeft + lxVar3.leftMargin;
                int measuredWidth4 = childAt4.getMeasuredWidth();
                int measuredHeight4 = childAt4.getMeasuredHeight();
                int i24 = i5 - (measuredHeight4 / 2);
                childAt4.layout(i23, i24, i23 + measuredWidth4, measuredHeight4 + i24);
                paddingLeft = i23 + measuredWidth4 + lxVar3.rightMargin + max;
            }
        }
    }

    /* JADX WARN: Type inference failed for: r6v18 */
    /* JADX WARN: Type inference failed for: r6v19, types: [int, boolean] */
    /* JADX WARN: Type inference failed for: r6v23 */
    @Override // cal.pi, android.view.View
    protected final void onMeasure(int i, int i2) {
        boolean z;
        boolean z2;
        int i3;
        boolean z3;
        int i4;
        boolean z4;
        int i5;
        int i6;
        int i7;
        int i8;
        int i9;
        ?? r6;
        boolean z5;
        boolean z6;
        int i10;
        int i11;
        int i12;
        ActionMenuItemView actionMenuItemView;
        boolean z7;
        int i13;
        boolean z8;
        ke keVar;
        boolean z9 = this.n;
        if (View.MeasureSpec.getMode(i) == 1073741824) {
            z = true;
        } else {
            z = false;
        }
        this.n = z;
        if (z9 != z) {
            this.o = 0;
        }
        int size = View.MeasureSpec.getSize(i);
        if (this.n && (keVar = this.a) != null && size != this.o) {
            this.o = size;
            keVar.k(true);
        }
        int childCount = getChildCount();
        if (this.n && childCount > 0) {
            int mode = View.MeasureSpec.getMode(i2);
            int size2 = View.MeasureSpec.getSize(i);
            int size3 = View.MeasureSpec.getSize(i2);
            int paddingLeft = getPaddingLeft() + getPaddingRight();
            int paddingTop = getPaddingTop() + getPaddingBottom();
            int childMeasureSpec = getChildMeasureSpec(i2, paddingTop, -2);
            int i14 = size2 - paddingLeft;
            int i15 = this.p;
            int i16 = i14 / i15;
            int i17 = i14 % i15;
            if (i16 == 0) {
                setMeasuredDimension(i14, 0);
                return;
            }
            int i18 = i15 + (i17 / i16);
            int childCount2 = getChildCount();
            int i19 = 0;
            int i20 = 0;
            int i21 = 0;
            boolean z10 = false;
            int i22 = 0;
            int i23 = 0;
            long j = 0;
            while (i21 < childCount2) {
                View childAt = getChildAt(i21);
                if (childAt.getVisibility() == 8) {
                    i11 = i14;
                    i9 = size3;
                    i12 = paddingTop;
                } else {
                    boolean z11 = childAt instanceof ActionMenuItemView;
                    int i24 = i19 + 1;
                    if (z11) {
                        int i25 = this.q;
                        i9 = size3;
                        r6 = 0;
                        childAt.setPadding(i25, 0, i25, 0);
                        z5 = true;
                    } else {
                        i9 = size3;
                        r6 = 0;
                        z5 = false;
                    }
                    lx lxVar = (lx) childAt.getLayoutParams();
                    lxVar.f = r6;
                    lxVar.c = r6;
                    lxVar.b = r6;
                    lxVar.d = r6;
                    lxVar.leftMargin = r6;
                    lxVar.rightMargin = r6;
                    if (z5 && !TextUtils.isEmpty(((ActionMenuItemView) childAt).getText())) {
                        z6 = true;
                    } else {
                        z6 = false;
                    }
                    lxVar.e = z6;
                    if (true != lxVar.a) {
                        i10 = i16;
                    } else {
                        i10 = 1;
                    }
                    lx lxVar2 = (lx) childAt.getLayoutParams();
                    i11 = i14;
                    i12 = paddingTop;
                    int makeMeasureSpec = View.MeasureSpec.makeMeasureSpec(View.MeasureSpec.getSize(childMeasureSpec) - paddingTop, View.MeasureSpec.getMode(childMeasureSpec));
                    if (z11) {
                        actionMenuItemView = (ActionMenuItemView) childAt;
                    } else {
                        actionMenuItemView = null;
                    }
                    if (actionMenuItemView != null && !TextUtils.isEmpty(actionMenuItemView.getText())) {
                        z7 = true;
                    } else {
                        z7 = false;
                    }
                    if (i10 > 0 && (!z7 || i10 >= 2)) {
                        childAt.measure(View.MeasureSpec.makeMeasureSpec(i10 * i18, Integer.MIN_VALUE), makeMeasureSpec);
                        int measuredWidth = childAt.getMeasuredWidth();
                        i13 = measuredWidth / i18;
                        if (measuredWidth % i18 != 0) {
                            i13++;
                        }
                        if (z7 && i13 < 2) {
                            i13 = 2;
                        }
                    } else {
                        i13 = 0;
                    }
                    if (!lxVar2.a && z7) {
                        z8 = true;
                    } else {
                        z8 = false;
                    }
                    lxVar2.d = z8;
                    lxVar2.b = i13;
                    childAt.measure(View.MeasureSpec.makeMeasureSpec(i13 * i18, 1073741824), makeMeasureSpec);
                    i22 = Math.max(i22, i13);
                    if (lxVar.d) {
                        i20++;
                    }
                    z10 |= lxVar.a;
                    i16 -= i13;
                    i23 = Math.max(i23, childAt.getMeasuredHeight());
                    if (i13 == 1) {
                        j |= 1 << i21;
                    }
                    i19 = i24;
                }
                i21++;
                size3 = i9;
                paddingTop = i12;
                i14 = i11;
            }
            int i26 = i14;
            int i27 = size3;
            int i28 = i22;
            int i29 = i23;
            if (z10 && i19 == 2) {
                z2 = true;
                i19 = 2;
            } else {
                z2 = false;
            }
            boolean z12 = false;
            while (i20 > 0 && i16 > 0) {
                int i30 = Integer.MAX_VALUE;
                int i31 = 0;
                int i32 = 0;
                long j2 = 0;
                while (i32 < childCount2) {
                    int i33 = i29;
                    lx lxVar3 = (lx) getChildAt(i32).getLayoutParams();
                    boolean z13 = z12;
                    if (lxVar3.d) {
                        int i34 = lxVar3.b;
                        if (i34 < i30) {
                            j2 = 1 << i32;
                            i31 = 1;
                            i30 = i34;
                        } else if (i34 == i30) {
                            j2 |= 1 << i32;
                            i31++;
                        }
                    }
                    i32++;
                    z12 = z13;
                    i29 = i33;
                }
                i3 = i29;
                z3 = z12;
                j |= j2;
                if (i31 > i16) {
                    break;
                }
                int i35 = i30 + 1;
                int i36 = 0;
                while (i36 < childCount2) {
                    View childAt2 = getChildAt(i36);
                    lx lxVar4 = (lx) childAt2.getLayoutParams();
                    int i37 = i20;
                    long j3 = 1 << i36;
                    if ((j2 & j3) == 0) {
                        if (lxVar4.b == i35) {
                            j |= j3;
                        }
                    } else {
                        if (z2 && lxVar4.e && i16 == 1) {
                            int i38 = this.q;
                            childAt2.setPadding(i38 + i18, 0, i38, 0);
                            i16 = 1;
                        }
                        lxVar4.b++;
                        lxVar4.f = true;
                        i16--;
                    }
                    i36++;
                    i20 = i37;
                }
                z12 = true;
                i29 = i3;
                i20 = i20;
            }
            i3 = i29;
            z3 = z12;
            if (!z10 && i19 == 1) {
                z4 = true;
                i4 = 1;
            } else {
                i4 = i19;
                z4 = false;
            }
            if (i16 > 0 && j != 0 && (i16 < i4 - 1 || z4 || i28 > 1)) {
                float bitCount = Long.bitCount(j);
                if (!z4) {
                    int i39 = childCount2 - 1;
                    if ((j & 1) != 0 && !((lx) getChildAt(0).getLayoutParams()).e) {
                        bitCount -= 0.5f;
                    }
                    if ((j & (1 << i39)) != 0 && !((lx) getChildAt(i39).getLayoutParams()).e) {
                        bitCount -= 0.5f;
                    }
                }
                if (bitCount > 0.0f) {
                    i7 = (int) ((i16 * i18) / bitCount);
                } else {
                    i7 = 0;
                }
                int i40 = 0;
                while (i40 < childCount2) {
                    if ((j & (1 << i40)) != 0) {
                        View childAt3 = getChildAt(i40);
                        lx lxVar5 = (lx) childAt3.getLayoutParams();
                        if (childAt3 instanceof ActionMenuItemView) {
                            lxVar5.c = i7;
                            lxVar5.f = true;
                            if (i40 == 0) {
                                if (!lxVar5.e) {
                                    lxVar5.leftMargin = (-i7) / 2;
                                }
                                i40 = 0;
                            }
                        } else if (lxVar5.a) {
                            lxVar5.c = i7;
                            lxVar5.f = true;
                            lxVar5.rightMargin = (-i7) / 2;
                        } else {
                            int i41 = childCount2 - 1;
                            if (i40 != 0) {
                                lxVar5.leftMargin = i7 / 2;
                            }
                            if (i40 != i41) {
                                lxVar5.rightMargin = i7 / 2;
                            }
                        }
                        i8 = 1;
                        z3 = true;
                        i40 += i8;
                    }
                    i8 = 1;
                    i40 += i8;
                }
            }
            if (z3) {
                for (int i42 = 0; i42 < childCount2; i42++) {
                    View childAt4 = getChildAt(i42);
                    lx lxVar6 = (lx) childAt4.getLayoutParams();
                    if (lxVar6.f) {
                        childAt4.measure(View.MeasureSpec.makeMeasureSpec((lxVar6.b * i18) + lxVar6.c, 1073741824), childMeasureSpec);
                    }
                }
            }
            if (mode == 1073741824) {
                i6 = i27;
                i5 = i26;
            } else {
                i5 = i26;
                i6 = i3;
            }
            setMeasuredDimension(i5, i6);
            return;
        }
        for (int i43 = 0; i43 < childCount; i43++) {
            lx lxVar7 = (lx) getChildAt(i43).getLayoutParams();
            lxVar7.rightMargin = 0;
            lxVar7.leftMargin = 0;
        }
        if (this.h == 1) {
            n(i, i2);
        } else {
            m(i, i2);
        }
    }

    public void setPopupTheme(int i) {
        if (this.m != i) {
            this.m = i;
            if (i == 0) {
                this.l = getContext();
            } else {
                this.l = new ContextThemeWrapper(getContext(), i);
            }
        }
    }

    public ActionMenuView(Context context, AttributeSet attributeSet) {
        super(context, attributeSet);
        this.g = false;
        float f = context.getResources().getDisplayMetrics().density;
        this.p = (int) (56.0f * f);
        this.q = (int) (f * 4.0f);
        this.l = context;
        this.m = 0;
    }

    @Override // cal.pi, android.view.ViewGroup
    protected final /* bridge */ /* synthetic */ ViewGroup.LayoutParams generateLayoutParams(ViewGroup.LayoutParams layoutParams) {
        return h(layoutParams);
    }
}
