package android.support.v7.widget;

import android.content.Context;
import android.graphics.Rect;
import android.util.AttributeSet;
import android.util.Log;
import android.util.SparseIntArray;
import android.view.View;
import android.view.ViewGroup;
import android.view.accessibility.AccessibilityNodeInfo;
import android.widget.GridView;
import cal.a;
import cal.aoa;
import cal.aob;
import cal.nw;
import cal.pa;
import cal.pd;
import cal.pe;
import cal.pf;
import cal.pj;
import cal.pl;
import cal.qq;
import cal.rd;
import cal.rj;
import cal.rr;
import cal.rt;
import j$.util.DesugarCollections;
import java.util.Arrays;
import java.util.HashSet;
import java.util.Set;

/* compiled from: PG */
/* loaded from: classes.dex */
public class GridLayoutManager extends LinearLayoutManager {
    private static final Set J = DesugarCollections.unmodifiableSet(new HashSet(Arrays.asList(17, 66, 33, 130)));
    private int K;
    boolean a;
    public int b;
    int[] c;
    View[] d;
    final SparseIntArray e;
    final SparseIntArray f;
    final pf g;
    final Rect h;
    int i;
    int j;

    public GridLayoutManager(int i) {
        super(1);
        this.a = false;
        this.b = -1;
        this.e = new SparseIntArray();
        this.f = new SparseIntArray();
        this.g = new pd();
        this.h = new Rect();
        this.K = -1;
        this.i = -1;
        this.j = -1;
        q(i);
    }

    private final int aH(int i) {
        if (this.k == 0) {
            RecyclerView recyclerView = this.u;
            return aJ(recyclerView.d, recyclerView.R, i);
        }
        RecyclerView recyclerView2 = this.u;
        return aK(recyclerView2.d, recyclerView2.R, i);
    }

    private final int aI(int i) {
        if (this.k == 1) {
            RecyclerView recyclerView = this.u;
            return aJ(recyclerView.d, recyclerView.R, i);
        }
        RecyclerView recyclerView2 = this.u;
        return aK(recyclerView2.d, recyclerView2.R, i);
    }

    private final int aJ(rj rjVar, rr rrVar, int i) {
        if (rrVar.g) {
            int a = rjVar.a(i);
            if (a != -1) {
                i = a;
            } else {
                Log.w("GridLayoutManager", a.f(i, "Cannot find span size for pre layout position. "));
                return 0;
            }
        }
        int i2 = this.b;
        int i3 = 0;
        int i4 = 0;
        int i5 = 0;
        while (true) {
            i3++;
            if (i4 >= i) {
                break;
            }
            if (i3 == i2) {
                i5++;
                i3 = 0;
            } else if (i3 > i2) {
                i5++;
                i3 = 1;
            }
            i4++;
        }
        if (i3 > i2) {
            return i5 + 1;
        }
        return i5;
    }

    private final int aK(rj rjVar, rr rrVar, int i) {
        if (!rrVar.g) {
            return i % this.b;
        }
        int i2 = this.f.get(i, -1);
        if (i2 != -1) {
            return i2;
        }
        int a = rjVar.a(i);
        if (a == -1) {
            Log.w("GridLayoutManager", a.f(i, "Cannot find span size for pre layout position. It is not cached, not in the adapter. Pos:"));
            return 0;
        }
        return a % this.b;
    }

    private final int aL(rj rjVar, rr rrVar, int i) {
        if (!rrVar.g) {
            return 1;
        }
        int i2 = this.e.get(i, -1);
        if (i2 != -1) {
            return i2;
        }
        if (rjVar.a(i) == -1) {
            Log.w("GridLayoutManager", a.f(i, "Cannot find span size for pre layout position. It is not cached, not in the adapter. Pos:"));
        }
        return 1;
    }

    private final Set aM(int i, int i2) {
        HashSet hashSet = new HashSet();
        RecyclerView recyclerView = this.u;
        int aL = aL(recyclerView.d, recyclerView.R, i2);
        for (int i3 = i; i3 < i + aL; i3++) {
            hashSet.add(Integer.valueOf(i3));
        }
        return hashSet;
    }

    private final void aN(View view, int i, boolean z) {
        int i2;
        int i3;
        boolean ay;
        pe peVar = (pe) view.getLayoutParams();
        Rect rect = peVar.d;
        int i4 = rect.top + rect.bottom + peVar.topMargin + peVar.bottomMargin;
        int i5 = rect.left + rect.right + peVar.leftMargin + peVar.rightMargin;
        int c = c(peVar.a, peVar.b);
        if (this.k == 1) {
            i3 = ah(c, i, i5, peVar.width, false);
            i2 = ah(this.m.k(), this.G, i4, peVar.height, true);
        } else {
            int ah = ah(c, i, i4, peVar.height, false);
            int ah2 = ah(this.m.k(), this.F, i5, peVar.width, true);
            i2 = ah;
            i3 = ah2;
        }
        rd rdVar = (rd) view.getLayoutParams();
        if (z) {
            ay = az(view, i3, i2, rdVar);
        } else {
            ay = ay(view, i3, i2, rdVar);
        }
        if (ay) {
            view.measure(i3, i2);
        }
    }

    private final void aO() {
        int i;
        int i2;
        int i3;
        int i4 = 0;
        if (this.k == 1) {
            int i5 = this.H;
            RecyclerView recyclerView = this.u;
            if (recyclerView != null) {
                i3 = recyclerView.getPaddingRight();
            } else {
                i3 = 0;
            }
            i2 = i5 - i3;
            RecyclerView recyclerView2 = this.u;
            if (recyclerView2 != null) {
                i4 = recyclerView2.getPaddingLeft();
            }
        } else {
            int i6 = this.I;
            RecyclerView recyclerView3 = this.u;
            if (recyclerView3 != null) {
                i = recyclerView3.getPaddingBottom();
            } else {
                i = 0;
            }
            i2 = i6 - i;
            RecyclerView recyclerView4 = this.u;
            if (recyclerView4 != null) {
                i4 = recyclerView4.getPaddingTop();
            }
        }
        this.c = v(this.c, this.b, i2 - i4);
    }

    static int[] v(int[] iArr, int i, int i2) {
        int i3;
        int length;
        int i4 = i + 1;
        if (iArr == null || (length = iArr.length) != i4 || iArr[length - 1] != i2) {
            iArr = new int[i4];
        }
        int i5 = 0;
        iArr[0] = 0;
        int i6 = i2 / i;
        int i7 = i2 % i;
        int i8 = 0;
        for (int i9 = 1; i9 <= i; i9++) {
            i5 += i7;
            if (i5 > 0 && i - i5 < i7) {
                i3 = i6 + 1;
                i5 -= i;
            } else {
                i3 = i6;
            }
            i8 += i3;
            iArr[i9] = i8;
        }
        return iArr;
    }

    @Override // cal.rc
    public final void A(int i, int i2) {
        this.g.a.clear();
        this.g.b.clear();
    }

    @Override // android.support.v7.widget.LinearLayoutManager, cal.rc
    public final void B() {
        View P;
        this.r = null;
        this.p = -1;
        this.q = Integer.MIN_VALUE;
        pj pjVar = this.s;
        pjVar.b = -1;
        pjVar.c = Integer.MIN_VALUE;
        pjVar.d = false;
        pjVar.e = false;
        this.a = false;
        int i = this.K;
        if (i != -1 && (P = P(i)) != null) {
            P.sendAccessibilityEvent(67108864);
            this.K = -1;
        }
    }

    @Override // cal.rc
    public final void C(int i, int i2) {
        this.g.a.clear();
        this.g.b.clear();
    }

    @Override // cal.rc
    public final int bG(rj rjVar, rr rrVar) {
        int i;
        int i2;
        qq qqVar;
        int i3 = 0;
        if (this.k == 1) {
            int i4 = this.b;
            RecyclerView recyclerView = this.u;
            if (recyclerView != null) {
                qqVar = recyclerView.m;
            } else {
                qqVar = null;
            }
            if (qqVar != null) {
                i3 = qqVar.a();
            }
            return Math.min(i4, i3);
        }
        boolean z = rrVar.g;
        if (z) {
            i = rrVar.b - rrVar.c;
        } else {
            i = rrVar.e;
        }
        if (i <= 0) {
            return 0;
        }
        if (z) {
            i2 = rrVar.b - rrVar.c;
        } else {
            i2 = rrVar.e;
        }
        return aJ(rjVar, rrVar, i2 - 1) + 1;
    }

    @Override // cal.rc
    public final int bH(rj rjVar, rr rrVar) {
        int i;
        int i2;
        qq qqVar;
        int i3 = 0;
        if (this.k == 0) {
            int i4 = this.b;
            RecyclerView recyclerView = this.u;
            if (recyclerView != null) {
                qqVar = recyclerView.m;
            } else {
                qqVar = null;
            }
            if (qqVar != null) {
                i3 = qqVar.a();
            }
            return Math.min(i4, i3);
        }
        boolean z = rrVar.g;
        if (z) {
            i = rrVar.b - rrVar.c;
        } else {
            i = rrVar.e;
        }
        if (i <= 0) {
            return 0;
        }
        if (z) {
            i2 = rrVar.b - rrVar.c;
        } else {
            i2 = rrVar.e;
        }
        return aJ(rjVar, rrVar, i2 - 1) + 1;
    }

    final int c(int i, int i2) {
        if (this.k == 1 && this.u.getLayoutDirection() == 1) {
            int[] iArr = this.c;
            int i3 = this.b - i;
            return iArr[i3] - iArr[i3 - i2];
        }
        int[] iArr2 = this.c;
        return iArr2[i2 + i] - iArr2[i];
    }

    @Override // cal.rc
    public final rd cN(ViewGroup.LayoutParams layoutParams) {
        if (layoutParams instanceof ViewGroup.MarginLayoutParams) {
            return new pe((ViewGroup.MarginLayoutParams) layoutParams);
        }
        return new pe(layoutParams);
    }

    /* JADX WARN: Code restructure failed: missing block: B:67:0x00ff, code lost:
    
        if (r13 == r7) goto L62;
     */
    /* JADX WARN: Code restructure failed: missing block: B:79:0x011f, code lost:
    
        if (r13 == r4) goto L80;
     */
    @Override // android.support.v7.widget.LinearLayoutManager, cal.rc
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct code enable 'Show inconsistent code' option in preferences
    */
    public final android.view.View cO(android.view.View r23, int r24, cal.rj r25, cal.rr r26) {
        /*
            Method dump skipped, instructions count: 346
            To view this dump change 'Code comments level' option to 'DEBUG'
        */
        throw new UnsupportedOperationException("Method not decompiled: android.support.v7.widget.GridLayoutManager.cO(android.view.View, int, cal.rj, cal.rr):android.view.View");
    }

    @Override // android.support.v7.widget.LinearLayoutManager, cal.rc
    public final void cP(rj rjVar, rr rrVar, aob aobVar) {
        super.cP(rjVar, rrVar, aobVar);
        aobVar.a.setClassName(GridView.class.getName());
        qq qqVar = this.u.m;
        if (qqVar != null && qqVar.a() > 1) {
            aobVar.a.addAction((AccessibilityNodeInfo.AccessibilityAction) aoa.n.o);
        }
    }

    @Override // cal.rc
    public final void cQ(rj rjVar, rr rrVar, View view, aob aobVar) {
        ViewGroup.LayoutParams layoutParams = view.getLayoutParams();
        if (!(layoutParams instanceof pe)) {
            super.ap(view, aobVar);
            return;
        }
        pe peVar = (pe) layoutParams;
        rt rtVar = peVar.c;
        int i = rtVar.g;
        if (i == -1) {
            i = rtVar.c;
        }
        int aJ = aJ(rjVar, rrVar, i);
        if (this.k == 0) {
            aobVar.a.setCollectionItemInfo(AccessibilityNodeInfo.CollectionItemInfo.obtain(peVar.a, peVar.b, aJ, 1, false, false));
        } else {
            aobVar.a.setCollectionItemInfo(AccessibilityNodeInfo.CollectionItemInfo.obtain(aJ, 1, peVar.a, peVar.b, false, false));
        }
    }

    /* JADX WARN: Removed duplicated region for block: B:38:0x00c6  */
    /* JADX WARN: Removed duplicated region for block: B:40:0x00cd  */
    @Override // cal.rc
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct code enable 'Show inconsistent code' option in preferences
    */
    public final void cR(android.graphics.Rect r7, int r8, int r9) {
        /*
            r6 = this;
            int[] r0 = r6.c
            if (r0 != 0) goto L7
            super.cR(r7, r8, r9)
        L7:
            android.support.v7.widget.RecyclerView r0 = r6.u
            r1 = 0
            if (r0 == 0) goto L11
            int r0 = r0.getPaddingLeft()
            goto L12
        L11:
            r0 = r1
        L12:
            android.support.v7.widget.RecyclerView r2 = r6.u
            if (r2 == 0) goto L1b
            int r2 = r2.getPaddingRight()
            goto L1c
        L1b:
            r2 = r1
        L1c:
            int r0 = r0 + r2
            android.support.v7.widget.RecyclerView r2 = r6.u
            if (r2 == 0) goto L26
            int r2 = r2.getPaddingTop()
            goto L27
        L26:
            r2 = r1
        L27:
            android.support.v7.widget.RecyclerView r3 = r6.u
            if (r3 == 0) goto L2f
            int r1 = r3.getPaddingBottom()
        L2f:
            int r2 = r2 + r1
            int r1 = r6.k
            r3 = 1
            r4 = 1073741824(0x40000000, float:2.0)
            r5 = -2147483648(0xffffffff80000000, float:-0.0)
            if (r1 != r3) goto L87
            int r7 = r7.height()
            int r7 = r7 + r2
            android.support.v7.widget.RecyclerView r1 = r6.u
            int[] r2 = cal.ame.a
            int r1 = r1.getMinimumHeight()
            int r2 = android.view.View.MeasureSpec.getMode(r9)
            int r9 = android.view.View.MeasureSpec.getSize(r9)
            if (r2 == r5) goto L57
            if (r2 == r4) goto L5f
            int r9 = java.lang.Math.max(r7, r1)
            goto L5f
        L57:
            int r7 = java.lang.Math.max(r7, r1)
            int r9 = java.lang.Math.min(r9, r7)
        L5f:
            int[] r7 = r6.c
            int r1 = r7.length
            int r1 = r1 + (-1)
            r7 = r7[r1]
            int r7 = r7 + r0
            android.support.v7.widget.RecyclerView r0 = r6.u
            int r0 = r0.getMinimumWidth()
            int r1 = android.view.View.MeasureSpec.getMode(r8)
            int r8 = android.view.View.MeasureSpec.getSize(r8)
            if (r1 == r5) goto L7e
            if (r1 == r4) goto Ld5
            int r8 = java.lang.Math.max(r7, r0)
            goto Ld5
        L7e:
            int r7 = java.lang.Math.max(r7, r0)
            int r8 = java.lang.Math.min(r8, r7)
            goto Ld5
        L87:
            int r7 = r7.width()
            int r7 = r7 + r0
            android.support.v7.widget.RecyclerView r0 = r6.u
            int[] r1 = cal.ame.a
            int r0 = r0.getMinimumWidth()
            int r1 = android.view.View.MeasureSpec.getMode(r8)
            int r8 = android.view.View.MeasureSpec.getSize(r8)
            if (r1 == r5) goto La5
            if (r1 == r4) goto Lae
            int r7 = java.lang.Math.max(r7, r0)
            goto Lad
        La5:
            int r7 = java.lang.Math.max(r7, r0)
            int r7 = java.lang.Math.min(r8, r7)
        Lad:
            r8 = r7
        Lae:
            int[] r7 = r6.c
            int r0 = r7.length
            int r0 = r0 + (-1)
            r7 = r7[r0]
            int r7 = r7 + r2
            android.support.v7.widget.RecyclerView r0 = r6.u
            int r0 = r0.getMinimumHeight()
            int r1 = android.view.View.MeasureSpec.getMode(r9)
            int r9 = android.view.View.MeasureSpec.getSize(r9)
            if (r1 == r5) goto Lcd
            if (r1 == r4) goto Ld5
            int r9 = java.lang.Math.max(r7, r0)
            goto Ld5
        Lcd:
            int r7 = java.lang.Math.max(r7, r0)
            int r9 = java.lang.Math.min(r9, r7)
        Ld5:
            android.support.v7.widget.RecyclerView r7 = r6.u
            android.support.v7.widget.RecyclerView.m(r7, r8, r9)
            return
        */
        throw new UnsupportedOperationException("Method not decompiled: android.support.v7.widget.GridLayoutManager.cR(android.graphics.Rect, int, int):void");
    }

    /* JADX WARN: Code restructure failed: missing block: B:181:0x0154, code lost:
    
        r12.i = r9;
        r12.j = r10;
     */
    /* JADX WARN: Code restructure failed: missing block: B:72:0x0116, code lost:
    
        r12.i = r9;
     */
    /* JADX WARN: Removed duplicated region for block: B:142:0x02ea  */
    /* JADX WARN: Removed duplicated region for block: B:74:0x01f9  */
    @Override // android.support.v7.widget.LinearLayoutManager, cal.rc
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct code enable 'Show inconsistent code' option in preferences
    */
    public final boolean cS(int r13, android.os.Bundle r14) {
        /*
            Method dump skipped, instructions count: 870
            To view this dump change 'Code comments level' option to 'DEBUG'
        */
        throw new UnsupportedOperationException("Method not decompiled: android.support.v7.widget.GridLayoutManager.cS(int, android.os.Bundle):boolean");
    }

    @Override // android.support.v7.widget.LinearLayoutManager, cal.rc
    public final boolean cT() {
        if (this.r == null && !this.a) {
            return true;
        }
        return false;
    }

    @Override // cal.rc
    public final void cU() {
        this.g.a.clear();
        this.g.b.clear();
    }

    /* JADX WARN: Code restructure failed: missing block: B:4:0x000a, code lost:
    
        if (r0.length != r2.b) goto L6;
     */
    @Override // android.support.v7.widget.LinearLayoutManager, cal.rc
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct code enable 'Show inconsistent code' option in preferences
    */
    public final int d(int r3, cal.rj r4, cal.rr r5) {
        /*
            r2 = this;
            r2.aO()
            android.view.View[] r0 = r2.d
            if (r0 == 0) goto Lc
            int r1 = r2.b
            int r0 = r0.length
            if (r0 == r1) goto L12
        Lc:
            int r0 = r2.b
            android.view.View[] r0 = new android.view.View[r0]
            r2.d = r0
        L12:
            int r0 = r2.k
            r1 = 1
            if (r0 != r1) goto L19
            r3 = 0
            return r3
        L19:
            int r3 = r2.L(r3, r4, r5)
            return r3
        */
        throw new UnsupportedOperationException("Method not decompiled: android.support.v7.widget.GridLayoutManager.d(int, cal.rj, cal.rr):int");
    }

    /* JADX WARN: Code restructure failed: missing block: B:4:0x000a, code lost:
    
        if (r0.length != r2.b) goto L6;
     */
    @Override // android.support.v7.widget.LinearLayoutManager, cal.rc
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct code enable 'Show inconsistent code' option in preferences
    */
    public final int e(int r3, cal.rj r4, cal.rr r5) {
        /*
            r2 = this;
            r2.aO()
            android.view.View[] r0 = r2.d
            if (r0 == 0) goto Lc
            int r1 = r2.b
            int r0 = r0.length
            if (r0 == r1) goto L12
        Lc:
            int r0 = r2.b
            android.view.View[] r0 = new android.view.View[r0]
            r2.d = r0
        L12:
            int r0 = r2.k
            if (r0 != 0) goto L18
            r3 = 0
            return r3
        L18:
            int r3 = r2.L(r3, r4, r5)
            return r3
        */
        throw new UnsupportedOperationException("Method not decompiled: android.support.v7.widget.GridLayoutManager.e(int, cal.rj, cal.rr):int");
    }

    @Override // android.support.v7.widget.LinearLayoutManager, cal.rc
    public final rd f() {
        if (this.k == 0) {
            return new pe(-2, -1);
        }
        return new pe(-1, -2);
    }

    @Override // cal.rc
    public final rd h(Context context, AttributeSet attributeSet) {
        return new pe(context, attributeSet);
    }

    @Override // android.support.v7.widget.LinearLayoutManager
    public final View i(rj rjVar, rr rrVar, boolean z, boolean z2) {
        int i;
        int i2;
        int i3;
        View view;
        nw nwVar = this.t;
        int i4 = 0;
        if (nwVar != null) {
            i = nwVar.e.a.getChildCount() - nwVar.b.size();
        } else {
            i = 0;
        }
        if (z2) {
            nw nwVar2 = this.t;
            if (nwVar2 != null) {
                i4 = nwVar2.e.a.getChildCount() - nwVar2.b.size();
            }
            i4--;
            i2 = -1;
            i = -1;
        } else {
            i2 = 1;
        }
        if (rrVar.g) {
            i3 = rrVar.b - rrVar.c;
        } else {
            i3 = rrVar.e;
        }
        if (this.l == null) {
            this.l = new pl();
        }
        int j = this.m.j();
        int f = this.m.f();
        View view2 = null;
        View view3 = null;
        while (i4 != i) {
            nw nwVar3 = this.t;
            if (nwVar3 != null) {
                view = nwVar3.e.a.getChildAt(nwVar3.a(i4));
            } else {
                view = null;
            }
            rt rtVar = ((rd) view.getLayoutParams()).c;
            int i5 = rtVar.g;
            if (i5 == -1) {
                i5 = rtVar.c;
            }
            if (i5 >= 0 && i5 < i3 && aK(rjVar, rrVar, i5) == 0) {
                if ((((rd) view.getLayoutParams()).c.j & 8) != 0) {
                    if (view3 == null) {
                        view3 = view;
                    }
                } else {
                    if (this.m.d(view) < f && this.m.a(view) >= j) {
                        return view;
                    }
                    if (view2 == null) {
                        view2 = view;
                    }
                }
            }
            i4 += i2;
        }
        if (view2 != null) {
            return view2;
        }
        return view3;
    }

    /* JADX WARN: Multi-variable type inference failed */
    /* JADX WARN: Removed duplicated region for block: B:10:0x0037  */
    /* JADX WARN: Removed duplicated region for block: B:13:0x0040  */
    /* JADX WARN: Removed duplicated region for block: B:145:0x02d3  */
    /* JADX WARN: Removed duplicated region for block: B:149:0x009a A[SYNTHETIC] */
    /* JADX WARN: Removed duplicated region for block: B:154:0x0060  */
    /* JADX WARN: Removed duplicated region for block: B:157:0x0034  */
    /* JADX WARN: Removed duplicated region for block: B:21:0x005a  */
    /* JADX WARN: Removed duplicated region for block: B:26:0x006e  */
    /* JADX WARN: Removed duplicated region for block: B:35:0x00c7  */
    /* JADX WARN: Removed duplicated region for block: B:8:0x0032  */
    /* JADX WARN: Type inference failed for: r12v22 */
    /* JADX WARN: Type inference failed for: r12v23, types: [int, boolean] */
    /* JADX WARN: Type inference failed for: r12v24 */
    /* JADX WARN: Type inference failed for: r12v25 */
    /* JADX WARN: Type inference failed for: r12v32 */
    @Override // android.support.v7.widget.LinearLayoutManager
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct code enable 'Show inconsistent code' option in preferences
    */
    public final void k(cal.rj r19, cal.rr r20, cal.pl r21, cal.pk r22) {
        /*
            Method dump skipped, instructions count: 728
            To view this dump change 'Code comments level' option to 'DEBUG'
        */
        throw new UnsupportedOperationException("Method not decompiled: android.support.v7.widget.GridLayoutManager.k(cal.rj, cal.rr, cal.pl, cal.pk):void");
    }

    @Override // android.support.v7.widget.LinearLayoutManager
    public final void l(rj rjVar, rr rrVar, pj pjVar, int i) {
        int i2;
        int i3;
        aO();
        boolean z = rrVar.g;
        if (z) {
            i2 = rrVar.b - rrVar.c;
        } else {
            i2 = rrVar.e;
        }
        if (i2 > 0 && !z) {
            int aK = aK(rjVar, rrVar, pjVar.b);
            if (i == 1) {
                while (aK > 0) {
                    int i4 = pjVar.b;
                    if (i4 <= 0) {
                        break;
                    }
                    int i5 = i4 - 1;
                    pjVar.b = i5;
                    aK = aK(rjVar, rrVar, i5);
                }
            } else {
                if (rrVar.g) {
                    i3 = rrVar.b - rrVar.c;
                } else {
                    i3 = rrVar.e;
                }
                int i6 = i3 - 1;
                int i7 = pjVar.b;
                while (i7 < i6) {
                    int i8 = i7 + 1;
                    int aK2 = aK(rjVar, rrVar, i8);
                    if (aK2 <= aK) {
                        break;
                    }
                    i7 = i8;
                    aK = aK2;
                }
                pjVar.b = i7;
            }
        }
        View[] viewArr = this.d;
        if (viewArr != null) {
            if (viewArr.length == this.b) {
                return;
            }
        }
        this.d = new View[this.b];
    }

    @Override // android.support.v7.widget.LinearLayoutManager, cal.rc
    public final void o(rj rjVar, rr rrVar) {
        int i;
        View view;
        if (rrVar.g) {
            nw nwVar = this.t;
            if (nwVar != null) {
                i = nwVar.e.a.getChildCount() - nwVar.b.size();
            } else {
                i = 0;
            }
            for (int i2 = 0; i2 < i; i2++) {
                nw nwVar2 = this.t;
                if (nwVar2 != null) {
                    view = nwVar2.e.a.getChildAt(nwVar2.a(i2));
                } else {
                    view = null;
                }
                pe peVar = (pe) view.getLayoutParams();
                rt rtVar = peVar.c;
                int i3 = rtVar.g;
                if (i3 == -1) {
                    i3 = rtVar.c;
                }
                this.e.put(i3, peVar.b);
                this.f.put(i3, peVar.a);
            }
        }
        super.o(rjVar, rrVar);
        this.e.clear();
        this.f.clear();
    }

    public final void q(int i) {
        if (i != this.b) {
            this.a = true;
            if (i > 0) {
                this.b = i;
                this.g.a.clear();
                RecyclerView recyclerView = this.u;
                if (recyclerView != null) {
                    recyclerView.requestLayout();
                    return;
                }
                return;
            }
            throw new IllegalArgumentException(a.f(i, "Span count should be at least 1. Provided "));
        }
    }

    @Override // android.support.v7.widget.LinearLayoutManager
    public final void r(boolean z) {
        RecyclerView recyclerView;
        if (!z) {
            if (this.r == null && (recyclerView = this.u) != null) {
                recyclerView.o(null);
            }
            if (this.o) {
                this.o = false;
                RecyclerView recyclerView2 = this.u;
                if (recyclerView2 != null) {
                    recyclerView2.requestLayout();
                    return;
                }
                return;
            }
            return;
        }
        throw new UnsupportedOperationException("GridLayoutManager does not support stack from end. Consider using reverse layout");
    }

    @Override // cal.rc
    public final boolean s(rd rdVar) {
        return rdVar instanceof pe;
    }

    @Override // android.support.v7.widget.LinearLayoutManager
    public final void w(rr rrVar, pl plVar, pa paVar) {
        int i;
        int i2;
        int i3 = this.b;
        for (int i4 = 0; i4 < this.b && (i = plVar.d) >= 0; i4++) {
            if (rrVar.g) {
                i2 = rrVar.b - rrVar.c;
            } else {
                i2 = rrVar.e;
            }
            if (i < i2 && i3 > 0) {
                paVar.a(i, Math.max(0, plVar.g));
                i3--;
                plVar.d += plVar.e;
            } else {
                return;
            }
        }
    }

    @Override // cal.rc
    public final void x(int i, int i2) {
        this.g.a.clear();
        this.g.b.clear();
    }

    @Override // cal.rc
    public final void z(int i, int i2) {
        this.g.a.clear();
        this.g.b.clear();
    }

    public GridLayoutManager(Context context, AttributeSet attributeSet, int i, int i2) {
        super(context, attributeSet, i, i2);
        this.a = false;
        this.b = -1;
        this.e = new SparseIntArray();
        this.f = new SparseIntArray();
        this.g = new pd();
        this.h = new Rect();
        this.K = -1;
        this.i = -1;
        this.j = -1;
        q(ai(context, attributeSet, i, i2).b);
    }
}
