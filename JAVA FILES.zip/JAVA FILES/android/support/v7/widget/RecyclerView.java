package android.support.v7.widget;

import android.R;
import android.animation.LayoutTransition;
import android.content.Context;
import android.content.res.Resources;
import android.content.res.TypedArray;
import android.graphics.Canvas;
import android.graphics.Rect;
import android.graphics.RectF;
import android.graphics.drawable.Drawable;
import android.graphics.drawable.StateListDrawable;
import android.os.Build;
import android.os.Parcelable;
import android.os.SystemClock;
import android.os.Trace;
import android.util.AttributeSet;
import android.util.Log;
import android.util.SparseArray;
import android.view.Display;
import android.view.KeyEvent;
import android.view.MotionEvent;
import android.view.VelocityTracker;
import android.view.View;
import android.view.ViewConfiguration;
import android.view.ViewGroup;
import android.view.ViewParent;
import android.view.accessibility.AccessibilityEvent;
import android.view.accessibility.AccessibilityManager;
import android.view.animation.Interpolator;
import android.widget.EdgeEffect;
import android.widget.OverScroller;
import cal.a;
import cal.aimm;
import cal.akf;
import cal.akt;
import cal.aku;
import cal.alc;
import cal.alu;
import cal.alx;
import cal.alz;
import cal.ame;
import cal.ami;
import cal.amk;
import cal.amn;
import cal.aow;
import cal.aox;
import cal.api;
import cal.apk;
import cal.clf;
import cal.hka;
import cal.hkb;
import cal.hkh;
import cal.hki;
import cal.ic;
import cal.lz;
import cal.ma;
import cal.nv;
import cal.nw;
import cal.oj;
import cal.ov;
import cal.pa;
import cal.pc;
import cal.qj;
import cal.qk;
import cal.ql;
import cal.qm;
import cal.qn;
import cal.qo;
import cal.qp;
import cal.qq;
import cal.qv;
import cal.qw;
import cal.qx;
import cal.qy;
import cal.rc;
import cal.rd;
import cal.re;
import cal.rf;
import cal.rg;
import cal.rh;
import cal.ri;
import cal.rj;
import cal.rk;
import cal.rm;
import cal.rq;
import cal.rr;
import cal.rs;
import cal.rt;
import cal.rv;
import cal.tp;
import cal.tq;
import cal.tuw;
import j$.util.DesugarCollections;
import java.lang.ref.WeakReference;
import java.lang.reflect.Constructor;
import java.lang.reflect.InvocationTargetException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Comparator;
import java.util.List;
import java.util.Objects;

/* compiled from: PG */
/* loaded from: classes.dex */
public class RecyclerView extends ViewGroup {
    public static final /* synthetic */ int ah = 0;
    private static final Class[] ak;
    public static final Interpolator c;
    public boolean A;
    public boolean B;
    public int C;
    public EdgeEffect D;
    public EdgeEffect E;
    public EdgeEffect F;
    public EdgeEffect G;
    public qw H;
    public int I;
    public re J;
    public final int K;
    public final int L;
    public float M;
    public float N;
    public final rs O;
    public pc P;
    public pa Q;
    public final rr R;
    public rg S;
    public List T;
    public boolean U;
    public boolean V;
    public boolean W;
    private final int[] aA;
    private final int[] aB;
    private Runnable aC;
    private boolean aD;
    private int aE;
    private int aF;
    private final aku aG;
    private qx aH;
    private hka aI;
    private final qm aJ;
    public rv aa;
    public alc ab;
    public final int[] ac;
    public final List ad;
    boolean ae;
    akt af;
    public hkb ag;
    private final float al;
    private final rk am;
    private final Rect an;
    private boolean ao;
    private int ap;
    private int aq;
    private int ar;
    private VelocityTracker as;
    private int at;
    private int au;
    private int av;
    private int aw;
    private int ax;
    private boolean ay;
    private final int[] az;
    public final rj d;
    rm e;
    public ma f;
    public nw g;
    public final tq h;
    boolean i;
    public final Runnable j;
    public final Rect k;
    public final RectF l;
    public qq m;
    public rc n;
    public final List o;
    public final ArrayList p;
    public final ArrayList q;
    public rf r;
    public boolean s;
    public boolean t;
    public boolean u;
    public int v;
    public boolean w;
    public boolean x;
    public boolean y;
    public final AccessibilityManager z;
    private static final int[] ai = {R.attr.nestedScrollingEnabled};
    private static final float aj = (float) (Math.log(0.78d) / Math.log(0.9d));
    public static final boolean a = true;
    public static final boolean b = true;

    static {
        Class cls = Integer.TYPE;
        ak = new Class[]{Context.class, AttributeSet.class, cls, cls};
        c = new ql();
    }

    public RecyclerView(Context context) {
        this(context, null);
    }

    public static void C(View view, Rect rect) {
        rd rdVar = (rd) view.getLayoutParams();
        Rect rect2 = rdVar.d;
        rect.set((view.getLeft() - rect2.left) - rdVar.leftMargin, (view.getTop() - rect2.top) - rdVar.topMargin, view.getRight() + rect2.right + rdVar.rightMargin, view.getBottom() + rect2.bottom + rdVar.bottomMargin);
    }

    private final float a(int i) {
        double log = Math.log((Math.abs(i) * 0.35f) / (this.al * 0.015f));
        double d = aj;
        return (float) (this.al * 0.015f * Math.exp((d / ((-1.0d) + d)) * log));
    }

    public static final int ag(int i, EdgeEffect edgeEffect, EdgeEffect edgeEffect2, int i2) {
        float f;
        float f2;
        if (i > 0 && edgeEffect != null) {
            if (Build.VERSION.SDK_INT >= 31) {
                f2 = aox.a(edgeEffect);
            } else {
                f2 = 0.0f;
            }
            if (f2 != 0.0f) {
                float f3 = i2;
                float f4 = (-i2) / 4.0f;
                float f5 = ((-i) * 4.0f) / f3;
                if (Build.VERSION.SDK_INT >= 31) {
                    f5 = aox.b(edgeEffect, f5, 0.5f);
                } else {
                    aow.a(edgeEffect, f5, 0.5f);
                }
                int round = Math.round(f4 * f5);
                if (round != i) {
                    edgeEffect.finish();
                }
                return i - round;
            }
        }
        if (i < 0 && edgeEffect2 != null) {
            if (Build.VERSION.SDK_INT >= 31) {
                f = aox.a(edgeEffect2);
            } else {
                f = 0.0f;
            }
            if (f != 0.0f) {
                float f6 = i2;
                float f7 = f6 / 4.0f;
                float f8 = (i * 4.0f) / f6;
                if (Build.VERSION.SDK_INT >= 31) {
                    f8 = aox.b(edgeEffect2, f8, 0.5f);
                } else {
                    aow.a(edgeEffect2, f8, 0.5f);
                }
                int round2 = Math.round(f7 * f8);
                if (round2 != i) {
                    edgeEffect2.finish();
                }
                return i - round2;
            }
            return i;
        }
        return i;
    }

    private final int aj(int i, float f) {
        float f2;
        float f3;
        float f4;
        float f5;
        float width = i / getWidth();
        float height = f / getHeight();
        EdgeEffect edgeEffect = this.D;
        float f6 = 0.0f;
        if (edgeEffect != null) {
            if (Build.VERSION.SDK_INT >= 31) {
                f4 = aox.a(edgeEffect);
            } else {
                f4 = 0.0f;
            }
            if (f4 != 0.0f) {
                if (canScrollHorizontally(-1)) {
                    this.D.onRelease();
                } else {
                    EdgeEffect edgeEffect2 = this.D;
                    float f7 = -width;
                    float f8 = 1.0f - height;
                    if (Build.VERSION.SDK_INT >= 31) {
                        f7 = aox.b(edgeEffect2, f7, f8);
                    } else {
                        aow.a(edgeEffect2, f7, f8);
                    }
                    EdgeEffect edgeEffect3 = this.D;
                    if (Build.VERSION.SDK_INT >= 31) {
                        f5 = aox.a(edgeEffect3);
                    } else {
                        f5 = 0.0f;
                    }
                    float f9 = -f7;
                    if (f5 == 0.0f) {
                        this.D.onRelease();
                    }
                    f6 = f9;
                }
                invalidate();
                return Math.round(f6 * getWidth());
            }
        }
        EdgeEffect edgeEffect4 = this.F;
        if (edgeEffect4 != null) {
            if (Build.VERSION.SDK_INT >= 31) {
                f2 = aox.a(edgeEffect4);
            } else {
                f2 = 0.0f;
            }
            if (f2 != 0.0f) {
                if (canScrollHorizontally(1)) {
                    this.F.onRelease();
                } else {
                    EdgeEffect edgeEffect5 = this.F;
                    if (Build.VERSION.SDK_INT >= 31) {
                        width = aox.b(edgeEffect5, width, height);
                    } else {
                        aow.a(edgeEffect5, width, height);
                    }
                    EdgeEffect edgeEffect6 = this.F;
                    if (Build.VERSION.SDK_INT >= 31) {
                        f3 = aox.a(edgeEffect6);
                    } else {
                        f3 = 0.0f;
                    }
                    if (f3 == 0.0f) {
                        this.F.onRelease();
                    }
                    f6 = width;
                }
                invalidate();
            }
        }
        return Math.round(f6 * getWidth());
    }

    private final int ak(int i, float f) {
        float f2;
        float f3;
        float f4;
        float f5;
        float height = i / getHeight();
        float width = f / getWidth();
        EdgeEffect edgeEffect = this.E;
        float f6 = 0.0f;
        if (edgeEffect != null) {
            if (Build.VERSION.SDK_INT >= 31) {
                f4 = aox.a(edgeEffect);
            } else {
                f4 = 0.0f;
            }
            if (f4 != 0.0f) {
                if (canScrollVertically(-1)) {
                    this.E.onRelease();
                } else {
                    EdgeEffect edgeEffect2 = this.E;
                    float f7 = -height;
                    if (Build.VERSION.SDK_INT >= 31) {
                        f7 = aox.b(edgeEffect2, f7, width);
                    } else {
                        aow.a(edgeEffect2, f7, width);
                    }
                    EdgeEffect edgeEffect3 = this.E;
                    if (Build.VERSION.SDK_INT >= 31) {
                        f5 = aox.a(edgeEffect3);
                    } else {
                        f5 = 0.0f;
                    }
                    float f8 = -f7;
                    if (f5 == 0.0f) {
                        this.E.onRelease();
                    }
                    f6 = f8;
                }
                invalidate();
                return Math.round(f6 * getHeight());
            }
        }
        EdgeEffect edgeEffect4 = this.G;
        if (edgeEffect4 != null) {
            if (Build.VERSION.SDK_INT >= 31) {
                f2 = aox.a(edgeEffect4);
            } else {
                f2 = 0.0f;
            }
            if (f2 != 0.0f) {
                if (canScrollVertically(1)) {
                    this.G.onRelease();
                } else {
                    EdgeEffect edgeEffect5 = this.G;
                    float f9 = 1.0f - width;
                    if (Build.VERSION.SDK_INT >= 31) {
                        height = aox.b(edgeEffect5, height, f9);
                    } else {
                        aow.a(edgeEffect5, height, f9);
                    }
                    EdgeEffect edgeEffect6 = this.G;
                    if (Build.VERSION.SDK_INT >= 31) {
                        f3 = aox.a(edgeEffect6);
                    } else {
                        f3 = 0.0f;
                    }
                    if (f3 == 0.0f) {
                        this.G.onRelease();
                    }
                    f6 = height;
                }
                invalidate();
            }
        }
        return Math.round(f6 * getHeight());
    }

    /* JADX WARN: Removed duplicated region for block: B:164:0x00b8 A[SYNTHETIC] */
    /* JADX WARN: Removed duplicated region for block: B:168:0x009c A[SYNTHETIC] */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct code enable 'Show inconsistent code' option in preferences
    */
    private final void al() {
        /*
            Method dump skipped, instructions count: 720
            To view this dump change 'Code comments level' option to 'DEBUG'
        */
        throw new UnsupportedOperationException("Method not decompiled: android.support.v7.widget.RecyclerView.al():void");
    }

    private final void am() {
        boolean z;
        int i = this.v + 1;
        this.v = i;
        if (i == 1 && !this.x) {
            this.w = false;
        }
        this.C++;
        this.R.a(6);
        this.f.d();
        this.R.e = this.m.a();
        this.R.c = 0;
        rm rmVar = this.e;
        if (rmVar != null) {
            int i2 = this.m.d;
            Parcelable parcelable = rmVar.a;
            if (parcelable != null) {
                this.n.T(parcelable);
            }
            this.e = null;
        }
        rr rrVar = this.R;
        rrVar.g = false;
        this.n.o(this.d, rrVar);
        rr rrVar2 = this.R;
        rrVar2.f = false;
        if (rrVar2.j && this.H != null) {
            z = true;
        } else {
            z = false;
        }
        rrVar2.j = z;
        rrVar2.d = 4;
        M(true);
        W(false);
    }

    private final void an(int[] iArr) {
        rt rtVar;
        nw nwVar = this.g;
        int childCount = nwVar.e.a.getChildCount() - nwVar.b.size();
        if (childCount != 0) {
            int i = Integer.MIN_VALUE;
            int i2 = Integer.MAX_VALUE;
            for (int i3 = 0; i3 < childCount; i3++) {
                nw nwVar2 = this.g;
                View childAt = nwVar2.e.a.getChildAt(nwVar2.a(i3));
                if (childAt == null) {
                    rtVar = null;
                } else {
                    rtVar = ((rd) childAt.getLayoutParams()).c;
                }
                if ((rtVar.j & 128) == 0) {
                    int i4 = rtVar.g;
                    if (i4 == -1) {
                        i4 = rtVar.c;
                    }
                    if (i4 < i2) {
                        i2 = i4;
                    }
                    if (i4 > i) {
                        i = i4;
                    }
                }
            }
            iArr[0] = i2;
            iArr[1] = i;
            return;
        }
        iArr[0] = -1;
        iArr[1] = -1;
    }

    private final void ao(MotionEvent motionEvent) {
        int i;
        int actionIndex = motionEvent.getActionIndex();
        if (motionEvent.getPointerId(actionIndex) == this.ar) {
            if (actionIndex == 0) {
                i = 1;
            } else {
                i = 0;
            }
            this.ar = motionEvent.getPointerId(i);
            int x = (int) (motionEvent.getX(i) + 0.5f);
            this.av = x;
            this.at = x;
            int y = (int) (motionEvent.getY(i) + 0.5f);
            this.aw = y;
            this.au = y;
        }
    }

    private final void ap() {
        boolean z;
        boolean z2;
        boolean z3;
        boolean z4 = false;
        if (this.A) {
            ma maVar = this.f;
            maVar.g(maVar.b);
            maVar.g(maVar.c);
            maVar.e = 0;
            if (this.B) {
                this.n.cU();
            }
        }
        if (this.H != null && this.n.cT()) {
            this.f.f();
        } else {
            this.f.d();
        }
        if (!this.U && !this.V) {
            z = false;
        } else {
            z = true;
        }
        rr rrVar = this.R;
        if (this.u && this.H != null && (((z3 = this.A) || z || this.n.y) && (!z3 || this.m.c))) {
            z2 = true;
        } else {
            z2 = false;
        }
        rrVar.j = z2;
        if (z2 && z && !this.A && this.H != null && this.n.cT()) {
            z4 = true;
        }
        rrVar.k = z4;
    }

    private final void aq() {
        boolean z;
        EdgeEffect edgeEffect = this.D;
        if (edgeEffect != null) {
            edgeEffect.onRelease();
            z = this.D.isFinished();
        } else {
            z = false;
        }
        EdgeEffect edgeEffect2 = this.E;
        if (edgeEffect2 != null) {
            edgeEffect2.onRelease();
            z |= this.E.isFinished();
        }
        EdgeEffect edgeEffect3 = this.F;
        if (edgeEffect3 != null) {
            edgeEffect3.onRelease();
            z |= this.F.isFinished();
        }
        EdgeEffect edgeEffect4 = this.G;
        if (edgeEffect4 != null) {
            edgeEffect4.onRelease();
            z |= this.G.isFinished();
        }
        if (z) {
            postInvalidateOnAnimation();
        }
    }

    private final void ar(View view, View view2) {
        View view3;
        boolean z;
        if (view2 != null) {
            view3 = view2;
        } else {
            view3 = view;
        }
        this.k.set(0, 0, view3.getWidth(), view3.getHeight());
        ViewGroup.LayoutParams layoutParams = view3.getLayoutParams();
        if (layoutParams instanceof rd) {
            rd rdVar = (rd) layoutParams;
            if (!rdVar.e) {
                Rect rect = rdVar.d;
                this.k.left -= rect.left;
                this.k.right += rect.right;
                this.k.top -= rect.top;
                this.k.bottom += rect.bottom;
            }
        }
        if (view2 != null) {
            offsetDescendantRectToMyCoords(view2, this.k);
            offsetRectIntoDescendantCoords(view, this.k);
        } else {
            view2 = null;
        }
        rc rcVar = this.n;
        Rect rect2 = this.k;
        boolean z2 = !this.u;
        if (view2 == null) {
            z = true;
        } else {
            z = false;
        }
        rcVar.ax(this, view, rect2, z2, z);
    }

    /* JADX WARN: Multi-variable type inference failed */
    private final void as(int i) {
        boolean W = this.n.W();
        int i2 = W;
        if (this.n.X()) {
            i2 = (W ? 1 : 0) | 2;
        }
        if (this.ab == null) {
            this.ab = new alc(this);
        }
        this.ab.c(i2, i);
    }

    private final boolean at(MotionEvent motionEvent) {
        ArrayList arrayList = this.q;
        int action = motionEvent.getAction();
        int size = arrayList.size();
        for (int i = 0; i < size; i++) {
            rf rfVar = (rf) this.q.get(i);
            if (rfVar.f(motionEvent) && action != 3) {
                this.r = rfVar;
                return true;
            }
        }
        return false;
    }

    private final void au(Context context, String str, AttributeSet attributeSet, int i) {
        ClassLoader classLoader;
        Object[] objArr;
        Constructor constructor;
        if (str != null) {
            String trim = str.trim();
            if (!trim.isEmpty()) {
                if (trim.charAt(0) == '.') {
                    trim = String.valueOf(context.getPackageName()).concat(String.valueOf(trim));
                } else if (!trim.contains(".")) {
                    trim = RecyclerView.class.getPackage().getName() + '.' + trim;
                }
                try {
                    if (isInEditMode()) {
                        classLoader = getClass().getClassLoader();
                    } else {
                        classLoader = context.getClassLoader();
                    }
                    Class<? extends U> asSubclass = Class.forName(trim, false, classLoader).asSubclass(rc.class);
                    try {
                        constructor = asSubclass.getConstructor(ak);
                        objArr = new Object[]{context, attributeSet, Integer.valueOf(i), 0};
                    } catch (NoSuchMethodException e) {
                        objArr = null;
                        try {
                            constructor = asSubclass.getConstructor(null);
                        } catch (NoSuchMethodException e2) {
                            e2.initCause(e);
                            throw new IllegalStateException(a.g(trim, attributeSet, ": Error creating LayoutManager "), e2);
                        }
                    }
                    constructor.setAccessible(true);
                    U((rc) constructor.newInstance(objArr));
                } catch (ClassCastException e3) {
                    throw new IllegalStateException(a.g(trim, attributeSet, ": Class is not a LayoutManager "), e3);
                } catch (ClassNotFoundException e4) {
                    throw new IllegalStateException(a.g(trim, attributeSet, ": Unable to find LayoutManager "), e4);
                } catch (IllegalAccessException e5) {
                    throw new IllegalStateException(a.g(trim, attributeSet, ": Cannot access non-public constructor "), e5);
                } catch (InstantiationException e6) {
                    throw new IllegalStateException(a.g(trim, attributeSet, ": Could not instantiate the LayoutManager: "), e6);
                } catch (InvocationTargetException e7) {
                    throw new IllegalStateException(a.g(trim, attributeSet, ": Could not instantiate the LayoutManager: "), e7);
                }
            }
        }
    }

    public static RecyclerView bD(View view) {
        if (view instanceof ViewGroup) {
            if (view instanceof RecyclerView) {
                return (RecyclerView) view;
            }
            ViewGroup viewGroup = (ViewGroup) view;
            int childCount = viewGroup.getChildCount();
            for (int i = 0; i < childCount; i++) {
                RecyclerView bD = bD(viewGroup.getChildAt(i));
                if (bD != null) {
                    return bD;
                }
            }
            return null;
        }
        return null;
    }

    public static void p(rt rtVar) {
        WeakReference weakReference = rtVar.b;
        if (weakReference != null) {
            View view = (View) weakReference.get();
            while (view != null) {
                if (view != rtVar.a) {
                    Object parent = view.getParent();
                    if (parent instanceof View) {
                        view = (View) parent;
                    } else {
                        view = null;
                    }
                } else {
                    return;
                }
            }
            rtVar.b = null;
        }
    }

    public final void A() {
        if (this.E != null) {
            return;
        }
        EdgeEffect edgeEffect = new EdgeEffect(getContext());
        this.E = edgeEffect;
        if (this.i) {
            edgeEffect.setSize((getMeasuredWidth() - getPaddingLeft()) - getPaddingRight(), (getMeasuredHeight() - getPaddingTop()) - getPaddingBottom());
        } else {
            edgeEffect.setSize(getMeasuredWidth(), getMeasuredHeight());
        }
    }

    final void B(rr rrVar) {
        if (this.I == 2) {
            OverScroller overScroller = this.O.a;
            rrVar.o = overScroller.getFinalX() - overScroller.getCurrX();
            rrVar.p = overScroller.getFinalY() - overScroller.getCurrY();
        } else {
            rrVar.o = 0;
            rrVar.p = 0;
        }
    }

    public final void D() {
        if (this.p.size() == 0) {
            return;
        }
        rc rcVar = this.n;
        if (rcVar != null) {
            rcVar.Q("Cannot invalidate item decorations during a scroll or layout");
        }
        F();
        requestLayout();
    }

    public final void E(int i) {
        if (this.n != null) {
            if (this.I != 2) {
                this.I = 2;
                v(2);
            }
            this.n.U(i);
            awakenScrollBars();
        }
    }

    final void F() {
        int childCount = this.g.e.a.getChildCount();
        for (int i = 0; i < childCount; i++) {
            ((rd) this.g.e.a.getChildAt(i).getLayoutParams()).e = true;
        }
        rj rjVar = this.d;
        int size = rjVar.c.size();
        for (int i2 = 0; i2 < size; i2++) {
            rd rdVar = (rd) ((rt) rjVar.c.get(i2)).a.getLayoutParams();
            if (rdVar != null) {
                rdVar.e = true;
            }
        }
    }

    public final void G() {
        rt rtVar;
        int childCount = this.g.e.a.getChildCount();
        for (int i = 0; i < childCount; i++) {
            View childAt = this.g.e.a.getChildAt(i);
            if (childAt == null) {
                rtVar = null;
            } else {
                rtVar = ((rd) childAt.getLayoutParams()).c;
            }
            if (rtVar != null) {
                int i2 = rtVar.j;
                if ((i2 & 128) == 0) {
                    rtVar.j = i2 | 6;
                }
            }
        }
        F();
        rj rjVar = this.d;
        int size = rjVar.c.size();
        for (int i3 = 0; i3 < size; i3++) {
            rt rtVar2 = (rt) rjVar.c.get(i3);
            if (rtVar2 != null) {
                rtVar2.j |= 1030;
            }
        }
        qq qqVar = rjVar.h.m;
        if (qqVar != null && qqVar.c) {
            return;
        }
        rjVar.d();
    }

    public final void H(int i) {
        nw nwVar = this.g;
        int childCount = nwVar.e.a.getChildCount() - nwVar.b.size();
        for (int i2 = 0; i2 < childCount; i2++) {
            nw nwVar2 = this.g;
            nwVar2.e.a.getChildAt(nwVar2.a(i2)).offsetLeftAndRight(i);
        }
    }

    public final void I(int i) {
        nw nwVar = this.g;
        int childCount = nwVar.e.a.getChildCount() - nwVar.b.size();
        for (int i2 = 0; i2 < childCount; i2++) {
            nw nwVar2 = this.g;
            nwVar2.e.a.getChildAt(nwVar2.a(i2)).offsetTopAndBottom(i);
        }
    }

    public final void J(int i, int i2) {
        rt rtVar;
        int childCount = this.g.e.a.getChildCount();
        for (int i3 = 0; i3 < childCount; i3++) {
            View childAt = this.g.e.a.getChildAt(i3);
            if (childAt == null) {
                rtVar = null;
            } else {
                rtVar = ((rd) childAt.getLayoutParams()).c;
            }
            if (rtVar != null && (rtVar.j & 128) == 0 && rtVar.c >= i) {
                rtVar.c(i2, false);
                this.R.f = true;
            }
        }
        rj rjVar = this.d;
        int size = rjVar.c.size();
        for (int i4 = 0; i4 < size; i4++) {
            rt rtVar2 = (rt) rjVar.c.get(i4);
            if (rtVar2 != null && rtVar2.c >= i) {
                rtVar2.c(i2, false);
            }
        }
        requestLayout();
    }

    public final void K(int i, int i2) {
        int i3;
        int i4;
        int i5;
        int i6;
        rt rtVar;
        int i7;
        int i8;
        int childCount = this.g.e.a.getChildCount();
        int i9 = 0;
        while (true) {
            int i10 = -1;
            if (i9 >= childCount) {
                break;
            }
            View childAt = this.g.e.a.getChildAt(i9);
            if (childAt == null) {
                rtVar = null;
            } else {
                rtVar = ((rd) childAt.getLayoutParams()).c;
            }
            if (rtVar != null) {
                if (i < i2) {
                    i7 = i;
                } else {
                    i7 = i2;
                }
                int i11 = rtVar.c;
                if (i11 >= i7) {
                    if (i < i2) {
                        i8 = i2;
                    } else {
                        i8 = i;
                    }
                    if (i11 <= i8) {
                        if (i11 == i) {
                            rtVar.c(i2 - i, false);
                        } else {
                            if (i >= i2) {
                                i10 = 1;
                            }
                            rtVar.c(i10, false);
                        }
                        this.R.f = true;
                    }
                }
            }
            i9++;
        }
        rj rjVar = this.d;
        if (i < i2) {
            i3 = i2;
        } else {
            i3 = i;
        }
        if (i < i2) {
            i4 = i;
        } else {
            i4 = i2;
        }
        int size = rjVar.c.size();
        for (int i12 = 0; i12 < size; i12++) {
            rt rtVar2 = (rt) rjVar.c.get(i12);
            if (rtVar2 != null && (i5 = rtVar2.c) >= i4 && i5 <= i3) {
                if (i5 == i) {
                    rtVar2.c(i2 - i, false);
                } else {
                    if (i < i2) {
                        i6 = -1;
                    } else {
                        i6 = 1;
                    }
                    rtVar2.c(i6, false);
                }
            }
        }
        requestLayout();
    }

    public final void L(int i, int i2, boolean z) {
        int i3;
        rt rtVar;
        int childCount = this.g.e.a.getChildCount();
        int i4 = 0;
        while (true) {
            i3 = i + i2;
            if (i4 >= childCount) {
                break;
            }
            View childAt = this.g.e.a.getChildAt(i4);
            if (childAt == null) {
                rtVar = null;
            } else {
                rtVar = ((rd) childAt.getLayoutParams()).c;
            }
            if (rtVar != null) {
                int i5 = rtVar.j;
                if ((i5 & 128) == 0) {
                    int i6 = rtVar.c;
                    if (i6 >= i3) {
                        rtVar.c(-i2, z);
                        this.R.f = true;
                    } else if (i6 >= i) {
                        rtVar.j = i5 | 8;
                        rtVar.c(-i2, z);
                        rtVar.c = i - 1;
                        this.R.f = true;
                    }
                }
            }
            i4++;
        }
        rj rjVar = this.d;
        int size = rjVar.c.size();
        while (true) {
            size--;
            if (size >= 0) {
                rt rtVar2 = (rt) rjVar.c.get(size);
                if (rtVar2 != null) {
                    int i7 = rtVar2.c;
                    if (i7 >= i3) {
                        rtVar2.c(-i2, z);
                    } else if (i7 >= i) {
                        rtVar2.j |= 8;
                        rjVar.b((rt) rjVar.c.get(size), true);
                        rjVar.c.remove(size);
                    }
                }
            } else {
                requestLayout();
                return;
            }
        }
    }

    public final void M(boolean z) {
        int i;
        AccessibilityManager accessibilityManager;
        int i2 = this.C - 1;
        this.C = i2;
        if (i2 <= 0) {
            this.C = 0;
            if (z) {
                int i3 = this.ap;
                this.ap = 0;
                if (i3 != 0 && (accessibilityManager = this.z) != null && accessibilityManager.isEnabled()) {
                    AccessibilityEvent obtain = AccessibilityEvent.obtain();
                    obtain.setEventType(2048);
                    obtain.setContentChangeTypes(i3);
                    if (!ad(obtain)) {
                        super.sendAccessibilityEventUnchecked(obtain);
                    }
                }
                for (int size = this.ad.size() - 1; size >= 0; size--) {
                    rt rtVar = (rt) this.ad.get(size);
                    if (rtVar.a.getParent() == this && (rtVar.j & 128) == 0 && (i = rtVar.p) != -1) {
                        rtVar.a.setImportantForAccessibility(i);
                        rtVar.p = -1;
                    }
                }
                this.ad.clear();
            }
        }
    }

    final void N() {
        if (!this.W && this.s) {
            Runnable runnable = this.aC;
            int[] iArr = ame.a;
            postOnAnimation(runnable);
            this.W = true;
        }
    }

    public final void O(rt rtVar, qv qvVar) {
        long j;
        int i = rtVar.j;
        rtVar.j = i & (-8193);
        if (this.R.h && (i & 2) != 0 && (i & 8) == 0 && (i & 128) == 0) {
            if (this.m.c) {
                j = rtVar.e;
            } else {
                j = rtVar.c;
            }
            this.h.b.f(j, rtVar);
        }
        this.h.d(rtVar, qvVar);
    }

    public final void P() {
        qw qwVar = this.H;
        if (qwVar != null) {
            qwVar.b();
        }
        rc rcVar = this.n;
        if (rcVar != null) {
            rcVar.ar(this.d);
            this.n.as(this.d);
        }
        rj rjVar = this.d;
        rjVar.a.clear();
        rjVar.d();
    }

    public final void Q(qy qyVar) {
        boolean z;
        rc rcVar = this.n;
        if (rcVar != null) {
            rcVar.Q("Cannot remove item decoration during a scroll  or layout");
        }
        this.p.remove(qyVar);
        if (this.p.isEmpty()) {
            if (getOverScrollMode() == 2) {
                z = true;
            } else {
                z = false;
            }
            setWillNotDraw(z);
        }
        F();
        requestLayout();
    }

    public final void R(int i, int i2, int[] iArr) {
        int i3;
        int i4;
        rt rtVar;
        int i5 = this.v + 1;
        this.v = i5;
        if (i5 == 1 && !this.x) {
            this.w = false;
        }
        this.C++;
        Trace.beginSection("RV Scroll");
        B(this.R);
        if (i != 0) {
            i3 = this.n.d(i, this.d, this.R);
        } else {
            i3 = 0;
        }
        if (i2 != 0) {
            i4 = this.n.e(i2, this.d, this.R);
        } else {
            i4 = 0;
        }
        Trace.endSection();
        nw nwVar = this.g;
        int childCount = nwVar.e.a.getChildCount() - nwVar.b.size();
        for (int i6 = 0; i6 < childCount; i6++) {
            nw nwVar2 = this.g;
            View childAt = nwVar2.e.a.getChildAt(nwVar2.a(i6));
            rt bC = bC(childAt);
            if (bC != null && (rtVar = bC.i) != null) {
                int left = childAt.getLeft();
                int top = childAt.getTop();
                View view = rtVar.a;
                if (left != view.getLeft() || top != view.getTop()) {
                    view.layout(left, top, view.getWidth() + left, view.getHeight() + top);
                }
            }
        }
        M(true);
        W(false);
        if (iArr != null) {
            iArr[0] = i3;
            iArr[1] = i4;
        }
    }

    public final void S(int i) {
        rq rqVar;
        rq rqVar2;
        if (!this.x) {
            if (this.I != 0) {
                this.I = 0;
                rs rsVar = this.O;
                rsVar.e.removeCallbacks(rsVar);
                rsVar.a.abortAnimation();
                rc rcVar = this.n;
                if (rcVar != null && (rqVar2 = rcVar.x) != null) {
                    rqVar2.h();
                }
                v(0);
            }
            rs rsVar2 = this.O;
            rsVar2.e.removeCallbacks(rsVar2);
            rsVar2.a.abortAnimation();
            rc rcVar2 = this.n;
            if (rcVar2 != null && (rqVar = rcVar2.x) != null) {
                rqVar.h();
            }
            rc rcVar3 = this.n;
            if (rcVar3 == null) {
                Log.e("RecyclerView", "Cannot scroll to position a LayoutManager set. Call setLayoutManager with a non-null argument.");
            } else {
                rcVar3.U(i);
                awakenScrollBars();
            }
        }
    }

    public final void T(qw qwVar) {
        qw qwVar2 = this.H;
        if (qwVar2 != null) {
            qwVar2.b();
            this.H.m = null;
        }
        this.H = qwVar;
        if (qwVar != null) {
            qwVar.m = this.aH;
        }
    }

    public final void U(rc rcVar) {
        rt rtVar;
        rq rqVar;
        rq rqVar2;
        if (rcVar != this.n) {
            if (this.I != 0) {
                this.I = 0;
                rs rsVar = this.O;
                rsVar.e.removeCallbacks(rsVar);
                rsVar.a.abortAnimation();
                rc rcVar2 = this.n;
                if (rcVar2 != null && (rqVar2 = rcVar2.x) != null) {
                    rqVar2.h();
                }
                v(0);
            }
            rs rsVar2 = this.O;
            rsVar2.e.removeCallbacks(rsVar2);
            rsVar2.a.abortAnimation();
            rc rcVar3 = this.n;
            if (rcVar3 != null && (rqVar = rcVar3.x) != null) {
                rqVar.h();
            }
            if (this.n != null) {
                qw qwVar = this.H;
                if (qwVar != null) {
                    qwVar.b();
                }
                this.n.ar(this.d);
                this.n.as(this.d);
                rj rjVar = this.d;
                rjVar.a.clear();
                rjVar.d();
                if (this.s) {
                    rc rcVar4 = this.n;
                    rcVar4.z = false;
                    rcVar4.ae(this);
                }
                rc rcVar5 = this.n;
                rcVar5.u = null;
                rcVar5.t = null;
                rcVar5.H = 0;
                rcVar5.I = 0;
                rcVar5.F = 1073741824;
                rcVar5.G = 1073741824;
                this.n = null;
            } else {
                rj rjVar2 = this.d;
                rjVar2.a.clear();
                rjVar2.d();
            }
            nw nwVar = this.g;
            nv nvVar = nwVar.a;
            nvVar.a = 0L;
            nv nvVar2 = nvVar.b;
            if (nvVar2 != null) {
                nvVar2.d();
            }
            int size = nwVar.b.size();
            while (true) {
                size--;
                if (size < 0) {
                    break;
                }
                qo qoVar = nwVar.e;
                View view = (View) nwVar.b.get(size);
                if (view == null) {
                    rtVar = null;
                } else {
                    rtVar = ((rd) view.getLayoutParams()).c;
                }
                if (rtVar != null) {
                    RecyclerView recyclerView = qoVar.a;
                    int i = rtVar.o;
                    if (recyclerView.C > 0) {
                        rtVar.p = i;
                        recyclerView.ad.add(rtVar);
                    } else {
                        rtVar.a.setImportantForAccessibility(i);
                    }
                    rtVar.o = 0;
                }
                nwVar.b.remove(size);
            }
            qo qoVar2 = nwVar.e;
            int childCount = qoVar2.a.getChildCount();
            for (int i2 = 0; i2 < childCount; i2++) {
                View childAt = qoVar2.a.getChildAt(i2);
                if (childAt != null) {
                    rt rtVar2 = ((rd) childAt.getLayoutParams()).c;
                }
                childAt.clearAnimation();
            }
            qoVar2.a.removeAllViews();
            this.n = rcVar;
            if (rcVar != null) {
                if (rcVar.u == null) {
                    rc rcVar6 = this.n;
                    rcVar6.u = this;
                    rcVar6.t = this.g;
                    rcVar6.H = getWidth();
                    rcVar6.I = getHeight();
                    rcVar6.F = 1073741824;
                    rcVar6.G = 1073741824;
                    if (this.s) {
                        rc rcVar7 = this.n;
                        rcVar7.z = true;
                        rcVar7.ao(this);
                    }
                } else {
                    throw new IllegalArgumentException("LayoutManager " + rcVar + " is already attached to a RecyclerView:" + rcVar.u.h());
                }
            }
            this.d.i();
            requestLayout();
        }
    }

    public final void V(int i) {
        if (this.x) {
            return;
        }
        rc rcVar = this.n;
        if (rcVar == null) {
            Log.e("RecyclerView", "Cannot smooth scroll without a LayoutManager set. Call setLayoutManager with a non-null argument.");
        } else {
            rcVar.af(this, i);
        }
    }

    public final void W(boolean z) {
        int i = this.v;
        if (i <= 0) {
            this.v = 1;
            i = 1;
        }
        if (!z && !this.x) {
            this.w = false;
        }
        if (i == 1) {
            if (z && this.w && !this.x && this.n != null && this.m != null) {
                u();
            }
            if (!this.x) {
                this.w = false;
            }
        }
        this.v--;
    }

    public final void X() {
        rq rqVar;
        rq rqVar2;
        if (this.I != 0) {
            this.I = 0;
            rs rsVar = this.O;
            rsVar.e.removeCallbacks(rsVar);
            rsVar.a.abortAnimation();
            rc rcVar = this.n;
            if (rcVar != null && (rqVar2 = rcVar.x) != null) {
                rqVar2.h();
            }
            v(0);
        }
        rs rsVar2 = this.O;
        rsVar2.e.removeCallbacks(rsVar2);
        rsVar2.a.abortAnimation();
        rc rcVar2 = this.n;
        if (rcVar2 != null && (rqVar = rcVar2.x) != null) {
            rqVar.h();
        }
    }

    public final void Y(int i, int i2, Object obj) {
        int i3;
        int i4;
        rt rtVar;
        int i5;
        int childCount = this.g.e.a.getChildCount();
        int i6 = 0;
        while (true) {
            i3 = i + i2;
            if (i6 >= childCount) {
                break;
            }
            View childAt = this.g.e.a.getChildAt(i6);
            if (childAt == null) {
                rtVar = null;
            } else {
                rtVar = ((rd) childAt.getLayoutParams()).c;
            }
            if (rtVar != null) {
                int i7 = rtVar.j;
                if ((i7 & 128) == 0 && (i5 = rtVar.c) >= i && i5 < i3) {
                    int i8 = i7 | 2;
                    rtVar.j = i8;
                    if (obj == null) {
                        rtVar.j = i7 | 1026;
                    } else if ((i8 & 1024) == 0) {
                        if (rtVar.k == null) {
                            rtVar.k = new ArrayList();
                            rtVar.l = DesugarCollections.unmodifiableList(rtVar.k);
                        }
                        rtVar.k.add(obj);
                    }
                    ((rd) childAt.getLayoutParams()).e = true;
                }
            }
            i6++;
        }
        rj rjVar = this.d;
        int size = rjVar.c.size();
        while (true) {
            size--;
            if (size >= 0) {
                rt rtVar2 = (rt) rjVar.c.get(size);
                if (rtVar2 != null && (i4 = rtVar2.c) >= i && i4 < i3) {
                    rtVar2.j |= 2;
                    rjVar.b((rt) rjVar.c.get(size), true);
                    rjVar.c.remove(size);
                }
            } else {
                return;
            }
        }
    }

    public boolean aa(int i, int i2) {
        return ab(i, i2, this.K, this.L);
    }

    /* JADX WARN: Code restructure failed: missing block: B:112:0x0111, code lost:
    
        if (a(-r11) >= (r3 * r6)) goto L232;
     */
    /* JADX WARN: Code restructure failed: missing block: B:133:0x00a2, code lost:
    
        if (a(-r10) >= (r4 * r5)) goto L192;
     */
    /* JADX WARN: Code restructure failed: missing block: B:35:0x0069, code lost:
    
        if (a(-r5) < (r4 * r6)) goto L190;
     */
    /* JADX WARN: Code restructure failed: missing block: B:51:0x00db, code lost:
    
        if (a(-r6) < (r3 * r7)) goto L230;
     */
    /* JADX WARN: Removed duplicated region for block: B:38:0x00ae  */
    /* JADX WARN: Removed duplicated region for block: B:55:0x011f  */
    /* JADX WARN: Removed duplicated region for block: B:59:0x0141  */
    /* JADX WARN: Removed duplicated region for block: B:67:0x014f  */
    /* JADX WARN: Removed duplicated region for block: B:70:0x015e  */
    /* JADX WARN: Removed duplicated region for block: B:76:0x016c A[ADDED_TO_REGION] */
    /* JADX WARN: Removed duplicated region for block: B:80:0x0176  */
    /* JADX WARN: Removed duplicated region for block: B:83:0x0183  */
    /* JADX WARN: Removed duplicated region for block: B:88:0x0190  */
    /* JADX WARN: Removed duplicated region for block: B:92:0x019a  */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct code enable 'Show inconsistent code' option in preferences
    */
    public final boolean ab(int r10, int r11, int r12, int r13) {
        /*
            Method dump skipped, instructions count: 437
            To view this dump change 'Code comments level' option to 'DEBUG'
        */
        throw new UnsupportedOperationException("Method not decompiled: android.support.v7.widget.RecyclerView.ab(int, int, int, int):boolean");
    }

    /* JADX WARN: Code restructure failed: missing block: B:46:0x0137, code lost:
    
        if (r8 == 0.0f) goto L134;
     */
    /* JADX WARN: Removed duplicated region for block: B:27:0x00ef  */
    /* JADX WARN: Removed duplicated region for block: B:37:0x010d  */
    /* JADX WARN: Removed duplicated region for block: B:62:0x0161  */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct code enable 'Show inconsistent code' option in preferences
    */
    final boolean ac(int r18, int r19, android.view.MotionEvent r20, int r21) {
        /*
            Method dump skipped, instructions count: 367
            To view this dump change 'Code comments level' option to 'DEBUG'
        */
        throw new UnsupportedOperationException("Method not decompiled: android.support.v7.widget.RecyclerView.ac(int, int, android.view.MotionEvent, int):boolean");
    }

    final boolean ad(AccessibilityEvent accessibilityEvent) {
        int i;
        int i2 = 0;
        if (this.C <= 0) {
            return false;
        }
        if (accessibilityEvent != null) {
            i = accessibilityEvent.getContentChangeTypes();
        } else {
            i = 0;
        }
        if (i != 0) {
            i2 = i;
        }
        this.ap |= i2;
        return true;
    }

    public final void ae(hka hkaVar) {
        boolean z;
        if (hkaVar == this.aI) {
            return;
        }
        this.aI = hkaVar;
        if (hkaVar != null) {
            z = true;
        } else {
            z = false;
        }
        setChildrenDrawingOrderEnabled(z);
    }

    public final void af(qy qyVar) {
        rc rcVar = this.n;
        if (rcVar != null) {
            rcVar.Q("Cannot add item decoration during a scroll  or layout");
        }
        if (this.p.isEmpty()) {
            setWillNotDraw(false);
        }
        this.p.add(qyVar);
        F();
        requestLayout();
    }

    public final void ah(qq qqVar) {
        qq qqVar2 = this.m;
        if (qqVar2 != null) {
            qqVar2.b.unregisterObserver(this.am);
            this.m.bn(this);
        }
        P();
        ma maVar = this.f;
        maVar.g(maVar.b);
        maVar.g(maVar.c);
        maVar.e = 0;
        qq qqVar3 = this.m;
        this.m = qqVar;
        if (qqVar != null) {
            qqVar.b.registerObserver(this.am);
            qqVar.bm(this);
        }
        rc rcVar = this.n;
        if (rcVar != null) {
            rcVar.aD();
        }
        rj rjVar = this.d;
        qq qqVar4 = this.m;
        rjVar.a.clear();
        rjVar.d();
        ri riVar = rjVar.g;
        if (riVar != null) {
            riVar.a(qqVar3, true);
        }
        if (rjVar.g == null) {
            rjVar.g = new ri();
            rjVar.c();
        }
        ri riVar2 = rjVar.g;
        if (qqVar3 != null) {
            riVar2.b--;
        }
        if (riVar2.b == 0) {
            for (int i = 0; i < riVar2.a.size(); i++) {
                rh rhVar = (rh) riVar2.a.valueAt(i);
                ArrayList arrayList = rhVar.a;
                int size = arrayList.size();
                for (int i2 = 0; i2 < size; i2++) {
                    api.a(((rt) arrayList.get(i2)).a);
                }
                rhVar.a.clear();
            }
        }
        if (qqVar4 != null) {
            riVar2.b++;
        }
        rjVar.c();
        this.R.f = true;
    }

    public final void ai(int i, int i2, boolean z) {
        rc rcVar = this.n;
        if (rcVar == null) {
            Log.e("RecyclerView", "Cannot smooth scroll without a LayoutManager set. Call setLayoutManager with a non-null argument.");
            return;
        }
        if (!this.x) {
            int i3 = 0;
            if (true != rcVar.W()) {
                i = 0;
            }
            if (true != this.n.X()) {
                i2 = 0;
            }
            if (i == 0) {
                if (i2 != 0) {
                    i = 0;
                } else {
                    return;
                }
            }
            if (z) {
                if (i != 0) {
                    i3 = 1;
                }
                if (i2 != 0) {
                    i3 |= 2;
                }
                if (this.ab == null) {
                    this.ab = new alc(this);
                }
                this.ab.c(i3, 1);
            }
            this.O.b(i, i2, Integer.MIN_VALUE, null);
        }
    }

    public final Rect bA(View view) {
        rd rdVar = (rd) view.getLayoutParams();
        if (!rdVar.e) {
            return rdVar.d;
        }
        if (this.R.g) {
            int i = rdVar.c.j;
            if ((i & 2) != 0 || (i & 4) != 0) {
                return rdVar.d;
            }
        }
        Rect rect = rdVar.d;
        rect.set(0, 0, 0, 0);
        int size = this.p.size();
        for (int i2 = 0; i2 < size; i2++) {
            this.k.set(0, 0, 0, 0);
            ((qy) this.p.get(i2)).i(this.k, view, this, this.R);
            rect.left += this.k.left;
            rect.top += this.k.top;
            rect.right += this.k.right;
            rect.bottom += this.k.bottom;
        }
        rdVar.e = false;
        return rect;
    }

    public final rt bB(int i) {
        rt rtVar;
        if (this.A) {
            return null;
        }
        int childCount = this.g.e.a.getChildCount();
        rt rtVar2 = null;
        for (int i2 = 0; i2 < childCount; i2++) {
            View childAt = this.g.e.a.getChildAt(i2);
            if (childAt == null) {
                rtVar = null;
            } else {
                rtVar = ((rd) childAt.getLayoutParams()).c;
            }
            if (rtVar != null && (rtVar.j & 8) == 0 && bz(rtVar) == i) {
                if (this.g.b.contains(rtVar.a)) {
                    rtVar2 = rtVar;
                } else {
                    return rtVar;
                }
            }
        }
        return rtVar2;
    }

    public final rt bC(View view) {
        ViewParent parent = view.getParent();
        if (parent != null && parent != this) {
            throw new IllegalArgumentException(a.h(this, view, "View ", " is not a direct child of "));
        }
        if (view == null) {
            return null;
        }
        return ((rd) view.getLayoutParams()).c;
    }

    /* JADX WARN: Code restructure failed: missing block: B:9:0x0016, code lost:
    
        return r3;
     */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct code enable 'Show inconsistent code' option in preferences
    */
    public final android.view.View bE(android.view.View r3) {
        /*
            r2 = this;
            android.view.ViewParent r0 = r3.getParent()
        L4:
            if (r0 == 0) goto L14
            if (r0 == r2) goto L14
            boolean r1 = r0 instanceof android.view.View
            if (r1 == 0) goto L14
            r3 = r0
            android.view.View r3 = (android.view.View) r3
            android.view.ViewParent r0 = r3.getParent()
            goto L4
        L14:
            if (r0 != r2) goto L17
            return r3
        L17:
            r3 = 0
            return r3
        */
        throw new UnsupportedOperationException("Method not decompiled: android.support.v7.widget.RecyclerView.bE(android.view.View):android.view.View");
    }

    public final int bz(rt rtVar) {
        int i = rtVar.j;
        if ((i & 524) != 0 || (i & 1) == 0) {
            return -1;
        }
        ma maVar = this.f;
        int i2 = rtVar.c;
        int size = maVar.b.size();
        for (int i3 = 0; i3 < size; i3++) {
            lz lzVar = (lz) maVar.b.get(i3);
            int i4 = lzVar.a;
            if (i4 != 1) {
                if (i4 != 2) {
                    if (i4 == 8) {
                        int i5 = lzVar.b;
                        if (i5 == i2) {
                            i2 = lzVar.d;
                        } else {
                            if (i5 < i2) {
                                i2--;
                            }
                            if (lzVar.d <= i2) {
                                i2++;
                            }
                        }
                    }
                } else {
                    int i6 = lzVar.b;
                    if (i6 <= i2) {
                        int i7 = lzVar.d;
                        if (i6 + i7 > i2) {
                            return -1;
                        }
                        i2 -= i7;
                    } else {
                        continue;
                    }
                }
            } else if (lzVar.b <= i2) {
                i2 += lzVar.d;
            }
        }
        return i2;
    }

    @Override // android.view.ViewGroup
    protected final boolean checkLayoutParams(ViewGroup.LayoutParams layoutParams) {
        if ((layoutParams instanceof rd) && this.n.s((rd) layoutParams)) {
            return true;
        }
        return false;
    }

    @Override // android.view.View
    public final int computeHorizontalScrollExtent() {
        rc rcVar = this.n;
        if (rcVar != null && rcVar.W()) {
            return this.n.D(this.R);
        }
        return 0;
    }

    @Override // android.view.View
    public final int computeHorizontalScrollOffset() {
        rc rcVar = this.n;
        if (rcVar != null && rcVar.W()) {
            return this.n.E(this.R);
        }
        return 0;
    }

    @Override // android.view.View
    public final int computeHorizontalScrollRange() {
        rc rcVar = this.n;
        if (rcVar != null && rcVar.W()) {
            return this.n.F(this.R);
        }
        return 0;
    }

    @Override // android.view.View
    public final int computeVerticalScrollExtent() {
        rc rcVar = this.n;
        if (rcVar != null && rcVar.X()) {
            return this.n.G(this.R);
        }
        return 0;
    }

    @Override // android.view.View
    public final int computeVerticalScrollOffset() {
        rc rcVar = this.n;
        if (rcVar != null && rcVar.X()) {
            return this.n.H(this.R);
        }
        return 0;
    }

    @Override // android.view.View
    public final int computeVerticalScrollRange() {
        rc rcVar = this.n;
        if (rcVar != null && rcVar.X()) {
            return this.n.I(this.R);
        }
        return 0;
    }

    @Override // android.view.ViewGroup, android.view.View
    public final boolean dispatchKeyEvent(KeyEvent keyEvent) {
        if (super.dispatchKeyEvent(keyEvent)) {
            return true;
        }
        rc rcVar = this.n;
        int i = 0;
        if (rcVar == null) {
            return false;
        }
        if (rcVar.X()) {
            int keyCode = keyEvent.getKeyCode();
            if (keyCode != 92 && keyCode != 93) {
                if (keyCode == 122 || keyCode == 123) {
                    boolean Z = rcVar.Z();
                    if (keyCode == 122) {
                        if (Z) {
                            i = this.m.a();
                        }
                    } else if (!Z) {
                        i = this.m.a();
                    }
                    V(i);
                    return true;
                }
            } else {
                int measuredHeight = getMeasuredHeight();
                if (keyCode == 93) {
                    ai(0, measuredHeight, false);
                } else {
                    ai(0, -measuredHeight, false);
                }
                return true;
            }
        } else if (rcVar.W()) {
            int keyCode2 = keyEvent.getKeyCode();
            if (keyCode2 != 92 && keyCode2 != 93) {
                if (keyCode2 == 122 || keyCode2 == 123) {
                    boolean Z2 = rcVar.Z();
                    if (keyCode2 == 122) {
                        if (Z2) {
                            i = this.m.a();
                        }
                    } else if (!Z2) {
                        i = this.m.a();
                    }
                    V(i);
                    return true;
                }
            } else {
                int measuredWidth = getMeasuredWidth();
                if (keyCode2 == 93) {
                    ai(measuredWidth, 0, false);
                } else {
                    ai(-measuredWidth, 0, false);
                }
                return true;
            }
        }
        return false;
    }

    @Override // android.view.View
    public final boolean dispatchNestedFling(float f, float f2, boolean z) {
        ViewParent viewParent;
        if (this.ab == null) {
            this.ab = new alc(this);
        }
        alc alcVar = this.ab;
        if (alcVar.d && (viewParent = alcVar.a) != null) {
            return amn.e(viewParent, alcVar.c, f, f2, z);
        }
        return false;
    }

    @Override // android.view.View
    public final boolean dispatchNestedPreFling(float f, float f2) {
        ViewParent viewParent;
        if (this.ab == null) {
            this.ab = new alc(this);
        }
        alc alcVar = this.ab;
        if (alcVar.d && (viewParent = alcVar.a) != null) {
            return amn.f(viewParent, alcVar.c, f, f2);
        }
        return false;
    }

    @Override // android.view.View
    public final boolean dispatchNestedPreScroll(int i, int i2, int[] iArr, int[] iArr2) {
        if (this.ab == null) {
            this.ab = new alc(this);
        }
        return this.ab.a(i, i2, iArr, iArr2, 0);
    }

    @Override // android.view.View
    public final boolean dispatchNestedScroll(int i, int i2, int i3, int i4, int[] iArr) {
        if (this.ab == null) {
            this.ab = new alc(this);
        }
        return this.ab.b(i, i2, i3, i4, iArr, 0, null);
    }

    @Override // android.view.View
    public final boolean dispatchPopulateAccessibilityEvent(AccessibilityEvent accessibilityEvent) {
        onPopulateAccessibilityEvent(accessibilityEvent);
        return true;
    }

    @Override // android.view.ViewGroup, android.view.View
    protected final void dispatchRestoreInstanceState(SparseArray sparseArray) {
        dispatchThawSelfOnly(sparseArray);
    }

    @Override // android.view.ViewGroup, android.view.View
    protected final void dispatchSaveInstanceState(SparseArray sparseArray) {
        dispatchFreezeSelfOnly(sparseArray);
    }

    @Override // android.view.View
    public final void draw(Canvas canvas) {
        boolean z;
        int i;
        boolean z2;
        boolean z3;
        int i2;
        super.draw(canvas);
        int size = this.p.size();
        boolean z4 = false;
        for (int i3 = 0; i3 < size; i3++) {
            ((qy) this.p.get(i3)).e(canvas, this);
        }
        EdgeEffect edgeEffect = this.D;
        if (edgeEffect != null && !edgeEffect.isFinished()) {
            int save = canvas.save();
            if (this.i) {
                i2 = getPaddingBottom();
            } else {
                i2 = 0;
            }
            canvas.rotate(270.0f);
            canvas.translate((-getHeight()) + i2, 0.0f);
            EdgeEffect edgeEffect2 = this.D;
            if (edgeEffect2 != null && edgeEffect2.draw(canvas)) {
                z = true;
            } else {
                z = false;
            }
            canvas.restoreToCount(save);
        } else {
            z = false;
        }
        EdgeEffect edgeEffect3 = this.E;
        if (edgeEffect3 != null && !edgeEffect3.isFinished()) {
            int save2 = canvas.save();
            if (this.i) {
                canvas.translate(getPaddingLeft(), getPaddingTop());
            }
            EdgeEffect edgeEffect4 = this.E;
            if (edgeEffect4 != null && edgeEffect4.draw(canvas)) {
                z3 = true;
            } else {
                z3 = false;
            }
            z |= z3;
            canvas.restoreToCount(save2);
        }
        EdgeEffect edgeEffect5 = this.F;
        if (edgeEffect5 != null && !edgeEffect5.isFinished()) {
            int save3 = canvas.save();
            int width = getWidth();
            if (this.i) {
                i = getPaddingTop();
            } else {
                i = 0;
            }
            canvas.rotate(90.0f);
            canvas.translate(i, -width);
            EdgeEffect edgeEffect6 = this.F;
            if (edgeEffect6 != null && edgeEffect6.draw(canvas)) {
                z2 = true;
            } else {
                z2 = false;
            }
            z |= z2;
            canvas.restoreToCount(save3);
        }
        EdgeEffect edgeEffect7 = this.G;
        if (edgeEffect7 != null && !edgeEffect7.isFinished()) {
            int save4 = canvas.save();
            canvas.rotate(180.0f);
            if (this.i) {
                canvas.translate((-getWidth()) + getPaddingRight(), (-getHeight()) + getPaddingBottom());
            } else {
                canvas.translate(-getWidth(), -getHeight());
            }
            EdgeEffect edgeEffect8 = this.G;
            if (edgeEffect8 != null && edgeEffect8.draw(canvas)) {
                z4 = true;
            }
            z |= z4;
            canvas.restoreToCount(save4);
        }
        if (!z && (this.H == null || this.p.size() <= 0 || !this.H.g())) {
            return;
        }
        postInvalidateOnAnimation();
    }

    @Override // android.view.ViewGroup
    public boolean drawChild(Canvas canvas, View view, long j) {
        return super.drawChild(canvas, view, j);
    }

    /* JADX WARN: Code restructure failed: missing block: B:104:0x0087, code lost:
    
        return null;
     */
    /* JADX WARN: Code restructure failed: missing block: B:117:0x0062, code lost:
    
        if (r3.findNextFocus(r13, r14, r0) == null) goto L183;
     */
    /* JADX WARN: Code restructure failed: missing block: B:20:0x003c, code lost:
    
        if (r3.findNextFocus(r13, r14, r0) != null) goto L168;
     */
    /* JADX WARN: Code restructure failed: missing block: B:21:0x0064, code lost:
    
        s();
     */
    /* JADX WARN: Code restructure failed: missing block: B:22:0x006b, code lost:
    
        if (bE(r14) == null) goto L191;
     */
    /* JADX WARN: Code restructure failed: missing block: B:23:0x006d, code lost:
    
        r0 = r13.v + 1;
        r13.v = r0;
     */
    /* JADX WARN: Code restructure failed: missing block: B:24:0x0072, code lost:
    
        if (r0 != 1) goto L190;
     */
    /* JADX WARN: Code restructure failed: missing block: B:26:0x0076, code lost:
    
        if (r13.x != false) goto L190;
     */
    /* JADX WARN: Code restructure failed: missing block: B:27:0x0078, code lost:
    
        r13.w = false;
     */
    /* JADX WARN: Code restructure failed: missing block: B:28:0x007a, code lost:
    
        r13.n.cO(r14, r15, r13.d, r13.R);
        W(false);
     */
    /* JADX WARN: Code restructure failed: missing block: B:54:0x012e, code lost:
    
        if (r13.k.right <= r13.an.left) goto L233;
     */
    /* JADX WARN: Code restructure failed: missing block: B:58:0x014e, code lost:
    
        if (r13.k.left >= r13.an.right) goto L240;
     */
    /* JADX WARN: Code restructure failed: missing block: B:63:0x016f, code lost:
    
        if (r13.k.bottom <= r13.an.top) goto L248;
     */
    /* JADX WARN: Code restructure failed: missing block: B:67:0x018f, code lost:
    
        if (r13.k.top >= r13.an.bottom) goto L255;
     */
    /* JADX WARN: Code restructure failed: missing block: B:74:0x01a8, code lost:
    
        if (r2 > 0) goto L283;
     */
    /* JADX WARN: Code restructure failed: missing block: B:77:0x01c6, code lost:
    
        if (r10 > 0) goto L283;
     */
    /* JADX WARN: Code restructure failed: missing block: B:78:0x01c9, code lost:
    
        if (r2 < 0) goto L283;
     */
    /* JADX WARN: Code restructure failed: missing block: B:79:0x01cc, code lost:
    
        if (r10 < 0) goto L283;
     */
    /* JADX WARN: Code restructure failed: missing block: B:83:0x01d4, code lost:
    
        if ((r10 * r3) <= 0) goto L284;
     */
    /* JADX WARN: Code restructure failed: missing block: B:87:0x01dc, code lost:
    
        if ((r10 * r3) >= 0) goto L284;
     */
    /* JADX WARN: Removed duplicated region for block: B:100:0x011b  */
    /* JADX WARN: Removed duplicated region for block: B:50:0x0119  */
    /* JADX WARN: Removed duplicated region for block: B:53:0x0126  */
    /* JADX WARN: Removed duplicated region for block: B:57:0x0146  */
    /* JADX WARN: Removed duplicated region for block: B:62:0x0167  */
    /* JADX WARN: Removed duplicated region for block: B:66:0x0187  */
    /* JADX WARN: Removed duplicated region for block: B:69:0x019e  */
    /* JADX WARN: Removed duplicated region for block: B:84:0x01d7  */
    /* JADX WARN: Removed duplicated region for block: B:90:0x019b  */
    /* JADX WARN: Removed duplicated region for block: B:93:0x017b  */
    /* JADX WARN: Removed duplicated region for block: B:96:0x015a  */
    /* JADX WARN: Removed duplicated region for block: B:99:0x013a  */
    @Override // android.view.ViewGroup, android.view.ViewParent
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct code enable 'Show inconsistent code' option in preferences
    */
    public android.view.View focusSearch(android.view.View r14, int r15) {
        /*
            Method dump skipped, instructions count: 484
            To view this dump change 'Code comments level' option to 'DEBUG'
        */
        throw new UnsupportedOperationException("Method not decompiled: android.support.v7.widget.RecyclerView.focusSearch(android.view.View, int):android.view.View");
    }

    @Override // android.view.ViewGroup
    protected final ViewGroup.LayoutParams generateDefaultLayoutParams() {
        rc rcVar = this.n;
        if (rcVar != null) {
            return rcVar.f();
        }
        throw new IllegalStateException("RecyclerView has no LayoutManager".concat(h()));
    }

    @Override // android.view.ViewGroup
    public final ViewGroup.LayoutParams generateLayoutParams(AttributeSet attributeSet) {
        rc rcVar = this.n;
        if (rcVar != null) {
            return rcVar.h(getContext(), attributeSet);
        }
        throw new IllegalStateException("RecyclerView has no LayoutManager".concat(h()));
    }

    @Override // android.view.ViewGroup, android.view.View
    public final CharSequence getAccessibilityClassName() {
        return "android.support.v7.widget.RecyclerView";
    }

    @Override // android.view.View
    public final int getBaseline() {
        if (this.n != null) {
            return -1;
        }
        return super.getBaseline();
    }

    @Override // android.view.ViewGroup
    protected final int getChildDrawingOrder(int i, int i2) {
        View view;
        hka hkaVar = this.aI;
        if (hkaVar == null) {
            return super.getChildDrawingOrder(i, i2);
        }
        hki hkiVar = hkaVar.a;
        int i3 = hkiVar.e;
        if (i != i3) {
            clf.b("LayoutUpdaterImpl", "Unexpected child count %d, %d", Integer.valueOf(i3), Integer.valueOf(i));
            hkiVar.d = false;
        }
        if (!hkiVar.d) {
            if (hkiVar.f.length < i) {
                hkiVar.f = new hkh[i];
            }
            rc rcVar = hkiVar.a.n;
            for (int i4 = 0; i4 < i; i4++) {
                hkh[] hkhVarArr = hkiVar.f;
                nw nwVar = rcVar.t;
                if (nwVar != null) {
                    view = nwVar.e.a.getChildAt(nwVar.a(i4));
                } else {
                    view = null;
                }
                hkhVarArr[i4] = (hkh) view.getLayoutParams();
                hkiVar.f[i4].b = i4;
            }
            Arrays.sort(hkiVar.f, 0, i, new Comparator() { // from class: cal.hkd
                @Override // java.util.Comparator
                public final int compare(Object obj, Object obj2) {
                    int i5 = ((hkh) obj).a;
                    int i6 = ((hkh) obj2).a;
                    if (i5 > i6) {
                        return 1;
                    }
                    if (i5 >= i6) {
                        return 0;
                    }
                    return -1;
                }
            });
            hkiVar.d = true;
        }
        hkh[] hkhVarArr2 = hkiVar.f;
        if (i2 >= hkhVarArr2.length) {
            clf.g(aimm.h("LayoutUpdaterImpl"), "Child index out of bounds %d, %d", Integer.valueOf(i2), Integer.valueOf(hkiVar.f.length));
            return 0;
        }
        int i5 = hkhVarArr2[i2].b;
        if (i5 >= 0 && i5 < i) {
            return i5;
        }
        clf.g(aimm.h("LayoutUpdaterImpl"), "Index out of bounds %d, %d", Integer.valueOf(i5), Integer.valueOf(i));
        return Math.min(Math.max(0, i5), i - 1);
    }

    @Override // android.view.ViewGroup
    public final boolean getClipToPadding() {
        return this.i;
    }

    public final String h() {
        return " " + super.toString() + ", adapter:" + this.m + ", layout:" + this.n + ", context:" + getContext();
    }

    @Override // android.view.View
    public final boolean hasNestedScrollingParent() {
        if (this.ab == null) {
            this.ab = new alc(this);
        }
        if (this.ab.a != null) {
            return true;
        }
        return false;
    }

    @Override // android.view.View
    public final boolean isAttachedToWindow() {
        return this.s;
    }

    @Override // android.view.ViewGroup
    public final boolean isLayoutSuppressed() {
        return this.x;
    }

    @Override // android.view.View
    public final boolean isNestedScrollingEnabled() {
        if (this.ab == null) {
            this.ab = new alc(this);
        }
        return this.ab.d;
    }

    public final void n(rt rtVar) {
        View view = rtVar.a;
        ViewParent parent = view.getParent();
        this.d.h(bC(view));
        if ((rtVar.j & 256) == 0) {
            if (parent != this) {
                this.g.c(view, -1, true);
                return;
            }
            nw nwVar = this.g;
            int indexOfChild = nwVar.e.a.indexOfChild(view);
            if (indexOfChild >= 0) {
                nwVar.a.e(indexOfChild);
                nwVar.b.add(view);
                qo qoVar = nwVar.e;
                rt rtVar2 = ((rd) view.getLayoutParams()).c;
                if (rtVar2 != null) {
                    rtVar2.d(qoVar.a);
                    return;
                }
                return;
            }
            Objects.toString(view);
            throw new IllegalArgumentException("view is not a child, cannot hide ".concat(view.toString()));
        }
        this.g.d(view, -1, view.getLayoutParams(), true);
    }

    public final void o(String str) {
        if (this.C > 0) {
            if (str == null) {
                throw new IllegalStateException("Cannot call this method while RecyclerView is computing a layout or scrolling".concat(h()));
            }
            throw new IllegalStateException(str);
        }
        if (this.aq > 0) {
            Log.w("RecyclerView", "Cannot call this method in a scroll callback. Scroll callbacks mightbe run during a measure & layout pass where you cannot change theRecyclerView data. Any method call that might change the structureof the RecyclerView or the adapter contents should be postponed tothe next frame.", new IllegalStateException("".concat(h())));
        }
    }

    @Override // android.view.ViewGroup, android.view.View
    protected final void onAttachedToWindow() {
        boolean z;
        super.onAttachedToWindow();
        this.C = 0;
        this.s = true;
        if (this.u && !isLayoutRequested()) {
            z = true;
        } else {
            z = false;
        }
        this.u = z;
        this.d.c();
        rc rcVar = this.n;
        if (rcVar != null) {
            rcVar.z = true;
            rcVar.ao(this);
        }
        this.W = false;
        if (b) {
            pc pcVar = (pc) pc.a.get();
            this.P = pcVar;
            if (pcVar == null) {
                this.P = new pc();
                int[] iArr = ame.a;
                Display display = getDisplay();
                float f = 60.0f;
                if (!isInEditMode() && display != null) {
                    float refreshRate = display.getRefreshRate();
                    if (refreshRate >= 30.0f) {
                        f = refreshRate;
                    }
                }
                pc pcVar2 = this.P;
                pcVar2.e = 1.0E9f / f;
                pc.a.set(pcVar2);
            }
            this.P.c.add(this);
        }
    }

    @Override // android.view.ViewGroup, android.view.View
    protected final void onDetachedFromWindow() {
        Object obj;
        pc pcVar;
        rq rqVar;
        rq rqVar2;
        super.onDetachedFromWindow();
        qw qwVar = this.H;
        if (qwVar != null) {
            qwVar.b();
        }
        if (this.I != 0) {
            this.I = 0;
            rs rsVar = this.O;
            rsVar.e.removeCallbacks(rsVar);
            rsVar.a.abortAnimation();
            rc rcVar = this.n;
            if (rcVar != null && (rqVar2 = rcVar.x) != null) {
                rqVar2.h();
            }
            v(0);
        }
        rs rsVar2 = this.O;
        rsVar2.e.removeCallbacks(rsVar2);
        rsVar2.a.abortAnimation();
        rc rcVar2 = this.n;
        if (rcVar2 != null && (rqVar = rcVar2.x) != null) {
            rqVar.h();
        }
        this.s = false;
        rc rcVar3 = this.n;
        if (rcVar3 != null) {
            rcVar3.z = false;
            rcVar3.ae(this);
        }
        this.ad.clear();
        removeCallbacks(this.aC);
        do {
            akf akfVar = (akf) tp.a;
            int i = akfVar.b;
            if (i > 0) {
                int i2 = i - 1;
                Object[] objArr = akfVar.a;
                obj = objArr[i2];
                obj.getClass();
                objArr[i2] = null;
                akfVar.b = i2;
            } else {
                obj = null;
            }
        } while (obj != null);
        rj rjVar = this.d;
        for (int i3 = 0; i3 < rjVar.c.size(); i3++) {
            api.a(((rt) rjVar.c.get(i3)).a);
        }
        qq qqVar = rjVar.h.m;
        ri riVar = rjVar.g;
        if (riVar != null) {
            riVar.a(qqVar, false);
        }
        amk amkVar = new amk(new ami(this).a);
        while (amkVar.a < amkVar.b.getChildCount()) {
            int i4 = amkVar.a;
            amkVar.a = i4 + 1;
            View childAt = amkVar.b.getChildAt(i4);
            if (childAt != null) {
                apk apkVar = (apk) childAt.getTag(com.google.android.calendar.R.id.pooling_container_listener_holder_tag);
                if (apkVar == null) {
                    apkVar = new apk();
                    childAt.setTag(com.google.android.calendar.R.id.pooling_container_listener_holder_tag, apkVar);
                }
                apkVar.a();
            } else {
                throw new IndexOutOfBoundsException();
            }
        }
        if (b && (pcVar = this.P) != null) {
            pcVar.c.remove(this);
            this.P = null;
        }
    }

    @Override // android.view.View
    public final void onDraw(Canvas canvas) {
        super.onDraw(canvas);
        int size = this.p.size();
        for (int i = 0; i < size; i++) {
            ((qy) this.p.get(i)).j(canvas, this);
        }
    }

    /* JADX WARN: Removed duplicated region for block: B:19:0x0081  */
    /* JADX WARN: Removed duplicated region for block: B:23:0x009e  */
    @Override // android.view.View
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct code enable 'Show inconsistent code' option in preferences
    */
    public final boolean onGenericMotionEvent(android.view.MotionEvent r21) {
        /*
            Method dump skipped, instructions count: 358
            To view this dump change 'Code comments level' option to 'DEBUG'
        */
        throw new UnsupportedOperationException("Method not decompiled: android.support.v7.widget.RecyclerView.onGenericMotionEvent(android.view.MotionEvent):boolean");
    }

    /* JADX WARN: Code restructure failed: missing block: B:172:0x027c, code lost:
    
        if (r11.I != 2) goto L353;
     */
    /* JADX WARN: Code restructure failed: missing block: B:87:0x014a, code lost:
    
        if (r0 != false) goto L258;
     */
    /* JADX WARN: Removed duplicated region for block: B:113:0x01eb  */
    /* JADX WARN: Removed duplicated region for block: B:128:0x021b  */
    /* JADX WARN: Removed duplicated region for block: B:143:0x024b  */
    /* JADX WARN: Removed duplicated region for block: B:155:0x028a  */
    /* JADX WARN: Removed duplicated region for block: B:163:0x02aa  */
    /* JADX WARN: Removed duplicated region for block: B:166:0x02b7  */
    /* JADX WARN: Removed duplicated region for block: B:171:0x027a  */
    @Override // android.view.ViewGroup
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct code enable 'Show inconsistent code' option in preferences
    */
    public final boolean onInterceptTouchEvent(android.view.MotionEvent r12) {
        /*
            Method dump skipped, instructions count: 717
            To view this dump change 'Code comments level' option to 'DEBUG'
        */
        throw new UnsupportedOperationException("Method not decompiled: android.support.v7.widget.RecyclerView.onInterceptTouchEvent(android.view.MotionEvent):boolean");
    }

    @Override // android.view.ViewGroup, android.view.View
    protected final void onLayout(boolean z, int i, int i2, int i3, int i4) {
        Trace.beginSection("RV OnLayout");
        u();
        Trace.endSection();
        this.u = true;
    }

    @Override // android.view.View
    public void onMeasure(int i, int i2) {
        rc rcVar = this.n;
        if (rcVar == null) {
            int paddingLeft = getPaddingLeft() + getPaddingRight();
            int[] iArr = ame.a;
            int minimumWidth = getMinimumWidth();
            int mode = View.MeasureSpec.getMode(i);
            int size = View.MeasureSpec.getSize(i);
            if (mode != Integer.MIN_VALUE) {
                if (mode != 1073741824) {
                    size = Math.max(paddingLeft, minimumWidth);
                }
            } else {
                size = Math.min(size, Math.max(paddingLeft, minimumWidth));
            }
            int paddingTop = getPaddingTop() + getPaddingBottom();
            int minimumHeight = getMinimumHeight();
            int mode2 = View.MeasureSpec.getMode(i2);
            int size2 = View.MeasureSpec.getSize(i2);
            if (mode2 != Integer.MIN_VALUE) {
                if (mode2 != 1073741824) {
                    size2 = Math.max(paddingTop, minimumHeight);
                }
            } else {
                size2 = Math.min(size2, Math.max(paddingTop, minimumHeight));
            }
            setMeasuredDimension(size, size2);
            return;
        }
        boolean z = false;
        if (rcVar.Y()) {
            int mode3 = View.MeasureSpec.getMode(i);
            int mode4 = View.MeasureSpec.getMode(i2);
            RecyclerView recyclerView = this.n.u;
            int paddingLeft2 = recyclerView.getPaddingLeft() + recyclerView.getPaddingRight();
            int[] iArr2 = ame.a;
            int minimumWidth2 = recyclerView.getMinimumWidth();
            int mode5 = View.MeasureSpec.getMode(i);
            int size3 = View.MeasureSpec.getSize(i);
            if (mode5 != Integer.MIN_VALUE) {
                if (mode5 != 1073741824) {
                    size3 = Math.max(paddingLeft2, minimumWidth2);
                }
            } else {
                size3 = Math.min(size3, Math.max(paddingLeft2, minimumWidth2));
            }
            int paddingTop2 = recyclerView.getPaddingTop() + recyclerView.getPaddingBottom();
            int minimumHeight2 = recyclerView.getMinimumHeight();
            int mode6 = View.MeasureSpec.getMode(i2);
            int size4 = View.MeasureSpec.getSize(i2);
            if (mode6 != Integer.MIN_VALUE) {
                if (mode6 != 1073741824) {
                    size4 = Math.max(paddingTop2, minimumHeight2);
                }
            } else {
                size4 = Math.min(size4, Math.max(paddingTop2, minimumHeight2));
            }
            recyclerView.setMeasuredDimension(size3, size4);
            if (mode3 == 1073741824 && mode4 == 1073741824) {
                z = true;
            }
            this.aD = z;
            if (!z && this.m != null) {
                if (this.R.d == 1) {
                    al();
                }
                this.n.au(i, i2);
                this.R.i = true;
                am();
                this.n.av(i, i2);
                if (this.n.aa()) {
                    this.n.au(View.MeasureSpec.makeMeasureSpec(getMeasuredWidth(), 1073741824), View.MeasureSpec.makeMeasureSpec(getMeasuredHeight(), 1073741824));
                    this.R.i = true;
                    am();
                    this.n.av(i, i2);
                }
                this.aE = getMeasuredWidth();
                this.aF = getMeasuredHeight();
                return;
            }
            return;
        }
        if (this.t) {
            RecyclerView recyclerView2 = rcVar.u;
            int paddingLeft3 = recyclerView2.getPaddingLeft() + recyclerView2.getPaddingRight();
            int[] iArr3 = ame.a;
            int minimumWidth3 = recyclerView2.getMinimumWidth();
            int mode7 = View.MeasureSpec.getMode(i);
            int size5 = View.MeasureSpec.getSize(i);
            if (mode7 != Integer.MIN_VALUE) {
                if (mode7 != 1073741824) {
                    size5 = Math.max(paddingLeft3, minimumWidth3);
                }
            } else {
                size5 = Math.min(size5, Math.max(paddingLeft3, minimumWidth3));
            }
            int paddingTop3 = recyclerView2.getPaddingTop() + recyclerView2.getPaddingBottom();
            int minimumHeight3 = recyclerView2.getMinimumHeight();
            int mode8 = View.MeasureSpec.getMode(i2);
            int size6 = View.MeasureSpec.getSize(i2);
            if (mode8 != Integer.MIN_VALUE) {
                if (mode8 != 1073741824) {
                    size6 = Math.max(paddingTop3, minimumHeight3);
                }
            } else {
                size6 = Math.min(size6, Math.max(paddingTop3, minimumHeight3));
            }
            recyclerView2.setMeasuredDimension(size5, size6);
            return;
        }
        if (this.y) {
            int i3 = this.v + 1;
            this.v = i3;
            if (i3 == 1 && !this.x) {
                this.w = false;
            }
            this.C++;
            ap();
            M(true);
            rr rrVar = this.R;
            if (rrVar.k) {
                rrVar.g = true;
            } else {
                this.f.d();
                this.R.g = false;
            }
            this.y = false;
            W(false);
        } else if (this.R.k) {
            setMeasuredDimension(getMeasuredWidth(), getMeasuredHeight());
            return;
        }
        qq qqVar = this.m;
        if (qqVar != null) {
            this.R.e = qqVar.a();
        } else {
            this.R.e = 0;
        }
        int i4 = this.v + 1;
        this.v = i4;
        if (i4 == 1 && !this.x) {
            this.w = false;
        }
        RecyclerView recyclerView3 = this.n.u;
        int paddingLeft4 = recyclerView3.getPaddingLeft() + recyclerView3.getPaddingRight();
        int[] iArr4 = ame.a;
        int minimumWidth4 = recyclerView3.getMinimumWidth();
        int mode9 = View.MeasureSpec.getMode(i);
        int size7 = View.MeasureSpec.getSize(i);
        if (mode9 != Integer.MIN_VALUE) {
            if (mode9 != 1073741824) {
                size7 = Math.max(paddingLeft4, minimumWidth4);
            }
        } else {
            size7 = Math.min(size7, Math.max(paddingLeft4, minimumWidth4));
        }
        int paddingTop4 = recyclerView3.getPaddingTop() + recyclerView3.getPaddingBottom();
        int minimumHeight4 = recyclerView3.getMinimumHeight();
        int mode10 = View.MeasureSpec.getMode(i2);
        int size8 = View.MeasureSpec.getSize(i2);
        if (mode10 != Integer.MIN_VALUE) {
            if (mode10 != 1073741824) {
                size8 = Math.max(paddingTop4, minimumHeight4);
            }
        } else {
            size8 = Math.min(size8, Math.max(paddingTop4, minimumHeight4));
        }
        recyclerView3.setMeasuredDimension(size7, size8);
        W(false);
        this.R.g = false;
    }

    @Override // android.view.ViewGroup
    protected final boolean onRequestFocusInDescendants(int i, Rect rect) {
        if (this.C > 0) {
            return false;
        }
        return super.onRequestFocusInDescendants(i, rect);
    }

    @Override // android.view.View
    protected final void onRestoreInstanceState(Parcelable parcelable) {
        if (!(parcelable instanceof rm)) {
            super.onRestoreInstanceState(parcelable);
            return;
        }
        rm rmVar = (rm) parcelable;
        this.e = rmVar;
        super.onRestoreInstanceState(rmVar.d);
        requestLayout();
    }

    @Override // android.view.View
    protected final Parcelable onSaveInstanceState() {
        Parcelable parcelable;
        rm rmVar = new rm(super.onSaveInstanceState());
        rm rmVar2 = this.e;
        if (rmVar2 != null) {
            rmVar.a = rmVar2.a;
        } else {
            rc rcVar = this.n;
            if (rcVar != null) {
                parcelable = rcVar.N();
            } else {
                parcelable = null;
            }
            rmVar.a = parcelable;
        }
        return rmVar;
    }

    @Override // android.view.View
    public void onSizeChanged(int i, int i2, int i3, int i4) {
        super.onSizeChanged(i, i2, i3, i4);
        if (i == i3 && i2 == i4) {
            return;
        }
        this.G = null;
        this.E = null;
        this.F = null;
        this.D = null;
    }

    /* JADX WARN: Code restructure failed: missing block: B:129:0x01f3, code lost:
    
        if (r9 != 0) goto L299;
     */
    /* JADX WARN: Removed duplicated region for block: B:101:0x0147  */
    /* JADX WARN: Removed duplicated region for block: B:85:0x012e  */
    @Override // android.view.View
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct code enable 'Show inconsistent code' option in preferences
    */
    public boolean onTouchEvent(android.view.MotionEvent r18) {
        /*
            Method dump skipped, instructions count: 754
            To view this dump change 'Code comments level' option to 'DEBUG'
        */
        throw new UnsupportedOperationException("Method not decompiled: android.support.v7.widget.RecyclerView.onTouchEvent(android.view.MotionEvent):boolean");
    }

    final void q() {
        rt rtVar;
        int childCount = this.g.e.a.getChildCount();
        for (int i = 0; i < childCount; i++) {
            View childAt = this.g.e.a.getChildAt(i);
            if (childAt == null) {
                rtVar = null;
            } else {
                rtVar = ((rd) childAt.getLayoutParams()).c;
            }
            if ((rtVar.j & 128) == 0) {
                rtVar.d = -1;
                rtVar.g = -1;
            }
        }
        rj rjVar = this.d;
        int size = rjVar.c.size();
        for (int i2 = 0; i2 < size; i2++) {
            rt rtVar2 = (rt) rjVar.c.get(i2);
            rtVar2.d = -1;
            rtVar2.g = -1;
        }
        int size2 = rjVar.a.size();
        for (int i3 = 0; i3 < size2; i3++) {
            rt rtVar3 = (rt) rjVar.a.get(i3);
            rtVar3.d = -1;
            rtVar3.g = -1;
        }
        ArrayList arrayList = rjVar.b;
        if (arrayList != null) {
            int size3 = arrayList.size();
            for (int i4 = 0; i4 < size3; i4++) {
                rt rtVar4 = (rt) rjVar.b.get(i4);
                rtVar4.d = -1;
                rtVar4.g = -1;
            }
        }
    }

    public final void r(int i, int i2) {
        EdgeEffect edgeEffect = this.D;
        boolean z = false;
        if (edgeEffect != null && !edgeEffect.isFinished() && i > 0) {
            this.D.onRelease();
            z = this.D.isFinished();
        }
        EdgeEffect edgeEffect2 = this.F;
        if (edgeEffect2 != null && !edgeEffect2.isFinished() && i < 0) {
            this.F.onRelease();
            z |= this.F.isFinished();
        }
        EdgeEffect edgeEffect3 = this.E;
        if (edgeEffect3 != null && !edgeEffect3.isFinished() && i2 > 0) {
            this.E.onRelease();
            z |= this.E.isFinished();
        }
        EdgeEffect edgeEffect4 = this.G;
        if (edgeEffect4 != null && !edgeEffect4.isFinished() && i2 < 0) {
            this.G.onRelease();
            z |= this.G.isFinished();
        }
        if (z) {
            postInvalidateOnAnimation();
        }
    }

    @Override // android.view.ViewGroup
    public final void removeDetachedView(View view, boolean z) {
        rt rtVar;
        if (view == null) {
            rtVar = null;
        } else {
            rtVar = ((rd) view.getLayoutParams()).c;
        }
        if (rtVar != null) {
            int i = rtVar.j;
            if ((i & 256) != 0) {
                rtVar.j = i & (-257);
            } else if ((i & 128) == 0) {
                throw new IllegalArgumentException("Called removeDetachedView with a view which is not flagged as tmp detached." + rtVar + h());
            }
        }
        view.clearAnimation();
        if (view != null) {
            rt rtVar2 = ((rd) view.getLayoutParams()).c;
        }
        super.removeDetachedView(view, z);
    }

    @Override // android.view.ViewGroup, android.view.ViewParent
    public final void requestChildFocus(View view, View view2) {
        rq rqVar = this.n.x;
        if ((rqVar == null || !rqVar.n) && this.C <= 0 && view2 != null) {
            ar(view, view2);
        }
        super.requestChildFocus(view, view2);
    }

    @Override // android.view.ViewGroup, android.view.ViewParent
    public final boolean requestChildRectangleOnScreen(View view, Rect rect, boolean z) {
        return this.n.ax(this, view, rect, z, false);
    }

    @Override // android.view.ViewGroup, android.view.ViewParent
    public final void requestDisallowInterceptTouchEvent(boolean z) {
        int size = this.q.size();
        for (int i = 0; i < size; i++) {
            ((rf) this.q.get(i)).g();
        }
        super.requestDisallowInterceptTouchEvent(z);
    }

    @Override // android.view.View, android.view.ViewParent
    public final void requestLayout() {
        if (this.v == 0 && !this.x) {
            super.requestLayout();
        } else {
            this.w = true;
        }
    }

    public final void s() {
        rt rtVar;
        if (this.u && !this.A) {
            if (this.f.b.size() > 0) {
                ma maVar = this.f;
                int i = maVar.e;
                if ((i & 4) != 0 && (i & 11) == 0) {
                    Trace.beginSection("RV PartialInvalidate");
                    int i2 = this.v + 1;
                    this.v = i2;
                    int i3 = 0;
                    if (i2 == 1 && !this.x) {
                        this.w = false;
                    }
                    this.C++;
                    this.f.f();
                    if (!this.w) {
                        nw nwVar = this.g;
                        int childCount = nwVar.e.a.getChildCount() - nwVar.b.size();
                        while (true) {
                            if (i3 < childCount) {
                                nw nwVar2 = this.g;
                                View childAt = nwVar2.e.a.getChildAt(nwVar2.a(i3));
                                if (childAt == null) {
                                    rtVar = null;
                                } else {
                                    rtVar = ((rd) childAt.getLayoutParams()).c;
                                }
                                if (rtVar != null) {
                                    int i4 = rtVar.j;
                                    if ((i4 & 128) == 0 && (i4 & 2) != 0) {
                                        u();
                                        break;
                                    }
                                }
                                i3++;
                            } else {
                                this.f.c();
                                break;
                            }
                        }
                    }
                    W(true);
                    M(true);
                    Trace.endSection();
                    return;
                }
                if (maVar.b.size() > 0) {
                    Trace.beginSection("RV FullInvalidate");
                    u();
                    Trace.endSection();
                    return;
                }
                return;
            }
            return;
        }
        Trace.beginSection("RV FullInvalidate");
        u();
        Trace.endSection();
    }

    @Override // android.view.View
    public final void scrollBy(int i, int i2) {
        rc rcVar = this.n;
        if (rcVar == null) {
            Log.e("RecyclerView", "Cannot scroll without a LayoutManager set. Call setLayoutManager with a non-null argument.");
            return;
        }
        if (!this.x) {
            boolean W = rcVar.W();
            boolean X = this.n.X();
            if (!W) {
                if (X) {
                    X = true;
                } else {
                    return;
                }
            }
            if (true != W) {
                i = 0;
            }
            if (true != X) {
                i2 = 0;
            }
            ac(i, i2, null, 0);
        }
    }

    @Override // android.view.View
    public final void scrollTo(int i, int i2) {
        Log.w("RecyclerView", "RecyclerView does not support scrolling to an absolute position. Use scrollToPosition instead");
    }

    @Override // android.view.View, android.view.accessibility.AccessibilityEventSource
    public final void sendAccessibilityEventUnchecked(AccessibilityEvent accessibilityEvent) {
        if (ad(accessibilityEvent)) {
            return;
        }
        super.sendAccessibilityEventUnchecked(accessibilityEvent);
    }

    @Override // android.view.ViewGroup
    public final void setClipToPadding(boolean z) {
        if (z != this.i) {
            this.G = null;
            this.E = null;
            this.F = null;
            this.D = null;
        }
        this.i = z;
        super.setClipToPadding(z);
        if (this.u) {
            requestLayout();
        }
    }

    public void setItemViewCacheSize(int i) {
        rj rjVar = this.d;
        rjVar.e = i;
        rjVar.i();
    }

    @Override // android.view.ViewGroup
    @Deprecated
    public final void setLayoutTransition(LayoutTransition layoutTransition) {
        if (layoutTransition == null) {
            super.setLayoutTransition(null);
            return;
        }
        throw new IllegalArgumentException("Providing a LayoutTransition into RecyclerView is not supported. Please use setItemAnimator() instead for animating changes to the items in this RecyclerView");
    }

    @Override // android.view.View
    public final void setNestedScrollingEnabled(boolean z) {
        if (this.ab == null) {
            this.ab = new alc(this);
        }
        alc alcVar = this.ab;
        if (alcVar.d) {
            alu.n(alcVar.c);
        }
        alcVar.d = z;
    }

    public void setScrollingTouchSlop(int i) {
        ViewConfiguration viewConfiguration = ViewConfiguration.get(getContext());
        if (i != 0) {
            if (i != 1) {
                Log.w("RecyclerView", a.i(i, "setScrollingTouchSlop(): bad argument constant ", "; using default value"));
            } else {
                this.ax = viewConfiguration.getScaledPagingTouchSlop();
                return;
            }
        }
        this.ax = viewConfiguration.getScaledTouchSlop();
    }

    @Override // android.view.View
    public final boolean startNestedScroll(int i) {
        if (this.ab == null) {
            this.ab = new alc(this);
        }
        return this.ab.c(i, 0);
    }

    @Override // android.view.View
    public final void stopNestedScroll() {
        if (this.ab == null) {
            this.ab = new alc(this);
        }
        alc alcVar = this.ab;
        ViewParent viewParent = alcVar.a;
        if (viewParent != null) {
            amn.d(viewParent, alcVar.c, 0);
            alcVar.a = null;
        }
    }

    @Override // android.view.ViewGroup
    public final void suppressLayout(boolean z) {
        rq rqVar;
        rq rqVar2;
        if (z != this.x) {
            o("Do not suppressLayout in layout or scroll");
            if (!z) {
                this.x = false;
                if (this.w && this.n != null && this.m != null) {
                    requestLayout();
                }
                this.w = false;
                return;
            }
            long uptimeMillis = SystemClock.uptimeMillis();
            onTouchEvent(MotionEvent.obtain(uptimeMillis, uptimeMillis, 3, 0.0f, 0.0f, 0));
            this.x = true;
            this.ao = true;
            if (this.I != 0) {
                this.I = 0;
                rs rsVar = this.O;
                rsVar.e.removeCallbacks(rsVar);
                rsVar.a.abortAnimation();
                rc rcVar = this.n;
                if (rcVar != null && (rqVar2 = rcVar.x) != null) {
                    rqVar2.h();
                }
                v(0);
            }
            rs rsVar2 = this.O;
            rsVar2.e.removeCallbacks(rsVar2);
            rsVar2.a.abortAnimation();
            rc rcVar2 = this.n;
            if (rcVar2 != null && (rqVar = rcVar2.x) != null) {
                rqVar.h();
            }
        }
    }

    public final void t(int i, int i2) {
        int paddingLeft = getPaddingLeft() + getPaddingRight();
        int[] iArr = ame.a;
        int minimumWidth = getMinimumWidth();
        int mode = View.MeasureSpec.getMode(i);
        int size = View.MeasureSpec.getSize(i);
        if (mode != Integer.MIN_VALUE) {
            if (mode != 1073741824) {
                size = Math.max(paddingLeft, minimumWidth);
            }
        } else {
            size = Math.min(size, Math.max(paddingLeft, minimumWidth));
        }
        int paddingTop = getPaddingTop() + getPaddingBottom();
        int minimumHeight = getMinimumHeight();
        int mode2 = View.MeasureSpec.getMode(i2);
        int size2 = View.MeasureSpec.getSize(i2);
        if (mode2 != Integer.MIN_VALUE) {
            if (mode2 != 1073741824) {
                size2 = Math.max(paddingTop, minimumHeight);
            }
        } else {
            size2 = Math.min(size2, Math.max(paddingTop, minimumHeight));
        }
        setMeasuredDimension(size, size2);
    }

    /* JADX WARN: Code restructure failed: missing block: B:204:0x044c, code lost:
    
        if (r17.g.b.contains(getFocusedChild()) != false) goto L499;
     */
    /* JADX WARN: Removed duplicated region for block: B:234:0x0522  */
    /* JADX WARN: Removed duplicated region for block: B:244:0x04d5  */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct code enable 'Show inconsistent code' option in preferences
    */
    final void u() {
        /*
            Method dump skipped, instructions count: 1349
            To view this dump change 'Code comments level' option to 'DEBUG'
        */
        throw new UnsupportedOperationException("Method not decompiled: android.support.v7.widget.RecyclerView.u():void");
    }

    public final void v(int i) {
        rc rcVar = this.n;
        if (rcVar != null) {
            rcVar.aq(i);
        }
        List list = this.T;
        if (list != null) {
            int size = list.size();
            while (true) {
                size--;
                if (size >= 0) {
                    ((rg) this.T.get(size)).b(this, i);
                } else {
                    return;
                }
            }
        }
    }

    public final void w(int i, int i2) {
        this.aq++;
        int scrollX = getScrollX();
        int scrollY = getScrollY();
        onScrollChanged(scrollX, scrollY, scrollX - i, scrollY - i2);
        rg rgVar = this.S;
        if (rgVar != null) {
            ((tuw) rgVar).a.h();
        }
        List list = this.T;
        if (list != null) {
            int size = list.size();
            while (true) {
                size--;
                if (size < 0) {
                    break;
                } else {
                    ((rg) this.T.get(size)).a(this, i, i2);
                }
            }
        }
        this.aq--;
    }

    public final void x() {
        if (this.G != null) {
            return;
        }
        EdgeEffect edgeEffect = new EdgeEffect(getContext());
        this.G = edgeEffect;
        if (this.i) {
            edgeEffect.setSize((getMeasuredWidth() - getPaddingLeft()) - getPaddingRight(), (getMeasuredHeight() - getPaddingTop()) - getPaddingBottom());
        } else {
            edgeEffect.setSize(getMeasuredWidth(), getMeasuredHeight());
        }
    }

    public final void y() {
        if (this.D != null) {
            return;
        }
        EdgeEffect edgeEffect = new EdgeEffect(getContext());
        this.D = edgeEffect;
        if (this.i) {
            edgeEffect.setSize((getMeasuredHeight() - getPaddingTop()) - getPaddingBottom(), (getMeasuredWidth() - getPaddingLeft()) - getPaddingRight());
        } else {
            edgeEffect.setSize(getMeasuredHeight(), getMeasuredWidth());
        }
    }

    public final void z() {
        if (this.F != null) {
            return;
        }
        EdgeEffect edgeEffect = new EdgeEffect(getContext());
        this.F = edgeEffect;
        if (this.i) {
            edgeEffect.setSize((getMeasuredHeight() - getPaddingTop()) - getPaddingBottom(), (getMeasuredWidth() - getPaddingLeft()) - getPaddingRight());
        } else {
            edgeEffect.setSize(getMeasuredHeight(), getMeasuredWidth());
        }
    }

    public RecyclerView(Context context, AttributeSet attributeSet) {
        this(context, attributeSet, com.google.android.calendar.R.attr.recyclerViewStyle);
    }

    public RecyclerView(Context context, AttributeSet attributeSet, int i) {
        super(context, attributeSet, i);
        float scaledHorizontalScrollFactor;
        float scaledVerticalScrollFactor;
        TypedArray typedArray;
        this.am = new rk(this);
        this.d = new rj(this);
        this.h = new tq();
        this.j = new qj(this);
        this.k = new Rect();
        this.an = new Rect();
        this.l = new RectF();
        this.o = new ArrayList();
        this.p = new ArrayList();
        this.q = new ArrayList();
        this.v = 0;
        this.A = false;
        this.B = false;
        this.C = 0;
        this.aq = 0;
        this.H = new oj();
        this.I = 0;
        this.ar = -1;
        this.M = Float.MIN_VALUE;
        this.N = Float.MIN_VALUE;
        this.ay = true;
        this.O = new rs(this);
        this.Q = b ? new pa() : null;
        this.R = new rr();
        this.U = false;
        this.V = false;
        this.aH = new qx(this);
        this.W = false;
        this.az = new int[2];
        this.aA = new int[2];
        this.aB = new int[2];
        this.ac = new int[2];
        this.ad = new ArrayList();
        this.aC = new qk(this);
        this.aE = 0;
        this.aF = 0;
        this.aJ = new qm(this);
        qn qnVar = new qn(this);
        this.aG = qnVar;
        this.af = new akt(getContext(), qnVar);
        setScrollContainer(true);
        setFocusableInTouchMode(true);
        ViewConfiguration viewConfiguration = ViewConfiguration.get(context);
        this.ax = viewConfiguration.getScaledTouchSlop();
        scaledHorizontalScrollFactor = viewConfiguration.getScaledHorizontalScrollFactor();
        this.M = scaledHorizontalScrollFactor;
        scaledVerticalScrollFactor = viewConfiguration.getScaledVerticalScrollFactor();
        this.N = scaledVerticalScrollFactor;
        this.K = viewConfiguration.getScaledMinimumFlingVelocity();
        this.L = viewConfiguration.getScaledMaximumFlingVelocity();
        this.al = context.getResources().getDisplayMetrics().density * 160.0f * 386.0878f * 0.84f;
        setWillNotDraw(getOverScrollMode() == 2);
        this.H.m = this.aH;
        this.f = new ma(new qp(this));
        this.g = new nw(new qo(this));
        if (alx.a(this) == 0) {
            alx.b(this, 8);
        }
        if (getImportantForAccessibility() == 0) {
            setImportantForAccessibility(1);
        }
        this.z = (AccessibilityManager) getContext().getSystemService("accessibility");
        rv rvVar = new rv(this);
        this.aa = rvVar;
        ame.g(this, rvVar);
        TypedArray obtainStyledAttributes = context.obtainStyledAttributes(attributeSet, ic.a, i, 0);
        int i2 = Build.VERSION.SDK_INT;
        int[] iArr = ic.a;
        if (i2 >= 29) {
            typedArray = obtainStyledAttributes;
            alz.b(this, context, iArr, attributeSet, obtainStyledAttributes, i, 0);
        } else {
            typedArray = obtainStyledAttributes;
        }
        String string = typedArray.getString(8);
        if (typedArray.getInt(2, -1) == -1) {
            setDescendantFocusability(262144);
        }
        this.i = typedArray.getBoolean(1, true);
        if (typedArray.getBoolean(3, false)) {
            StateListDrawable stateListDrawable = (StateListDrawable) typedArray.getDrawable(6);
            Drawable drawable = typedArray.getDrawable(7);
            StateListDrawable stateListDrawable2 = (StateListDrawable) typedArray.getDrawable(4);
            Drawable drawable2 = typedArray.getDrawable(5);
            if (stateListDrawable != null && drawable != null && stateListDrawable2 != null && drawable2 != null) {
                Resources resources = getContext().getResources();
                new ov(this, stateListDrawable, drawable, stateListDrawable2, drawable2, resources.getDimensionPixelSize(com.google.android.calendar.R.dimen.fastscroll_default_thickness), resources.getDimensionPixelSize(com.google.android.calendar.R.dimen.fastscroll_minimum_range), resources.getDimensionPixelOffset(com.google.android.calendar.R.dimen.fastscroll_margin));
            } else {
                throw new IllegalArgumentException("Trying to set fast scroller without both required drawables.".concat(h()));
            }
        }
        typedArray.recycle();
        this.ae = context.getPackageManager().hasSystemFeature("android.hardware.rotaryencoder.lowres");
        au(context, string, attributeSet, i);
        int[] iArr2 = ai;
        TypedArray obtainStyledAttributes2 = context.obtainStyledAttributes(attributeSet, iArr2, i, 0);
        if (Build.VERSION.SDK_INT >= 29) {
            alz.b(this, context, iArr2, attributeSet, obtainStyledAttributes2, i, 0);
        }
        boolean z = obtainStyledAttributes2.getBoolean(0, true);
        obtainStyledAttributes2.recycle();
        if (this.ab == null) {
            this.ab = new alc(this);
        }
        alc alcVar = this.ab;
        if (alcVar.d) {
            alu.n(alcVar.c);
        }
        alcVar.d = z;
        setTag(com.google.android.calendar.R.id.is_pooling_container_tag, true);
    }

    @Override // android.view.ViewGroup
    protected final ViewGroup.LayoutParams generateLayoutParams(ViewGroup.LayoutParams layoutParams) {
        rc rcVar = this.n;
        if (rcVar != null) {
            return rcVar.cN(layoutParams);
        }
        throw new IllegalStateException("RecyclerView has no LayoutManager".concat(h()));
    }
}
