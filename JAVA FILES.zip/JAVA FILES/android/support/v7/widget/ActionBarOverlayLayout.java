package android.support.v7.widget;

import android.animation.AnimatorListenerAdapter;
import android.content.Context;
import android.content.res.Configuration;
import android.content.res.TypedArray;
import android.graphics.Canvas;
import android.graphics.Rect;
import android.graphics.drawable.Drawable;
import android.os.Build;
import android.util.AttributeSet;
import android.view.KeyEvent;
import android.view.Menu;
import android.view.View;
import android.view.ViewGroup;
import android.view.ViewPropertyAnimator;
import android.view.Window;
import android.widget.OverScroller;
import cal.ahr;
import cal.ald;
import cal.ale;
import cal.alf;
import cal.als;
import cal.anf;
import cal.ang;
import cal.anh;
import cal.ani;
import cal.anq;
import cal.hz;
import cal.jm;
import cal.kq;
import cal.lf;
import cal.lg;
import cal.lh;
import cal.li;
import cal.lj;
import cal.lk;
import cal.nx;
import cal.ny;
import cal.tk;
import com.google.android.calendar.R;

/* compiled from: PG */
/* loaded from: classes.dex */
public class ActionBarOverlayLayout extends ViewGroup implements nx, ald, ale {
    private static final anq o;
    private static final Rect p;
    private boolean A;
    private boolean B;
    private anq C;
    private anq D;
    private anq E;
    private anq F;
    private OverScroller G;
    private final alf H;
    private final lk I;
    public int b;
    public ActionBarContainer c;
    public boolean d;
    public boolean e;
    public boolean f;
    public boolean g;
    public int h;
    public li i;
    public ViewPropertyAnimator j;
    public final AnimatorListenerAdapter k;
    public final Runnable l;
    public final Runnable m;
    private int q;
    private ContentFrameLayout r;
    private ny s;
    private Drawable t;
    private int u;
    private final Rect v;
    private final Rect w;
    private final Rect x;
    private final Rect y;
    private final Rect z;
    private static final Rect n = new Rect();
    static final int[] a = {R.attr.actionBarSize, android.R.attr.windowContentOverlay};

    static {
        ani anfVar;
        if (Build.VERSION.SDK_INT >= 30) {
            anfVar = new anh();
        } else if (Build.VERSION.SDK_INT >= 29) {
            anfVar = new ang();
        } else {
            anfVar = new anf();
        }
        anfVar.c(new ahr(0, 1, 0, 1));
        o = anfVar.a();
        p = new Rect();
    }

    public ActionBarOverlayLayout(Context context) {
        this(context, null);
    }

    private final void s(Context context) {
        TypedArray obtainStyledAttributes = getContext().getTheme().obtainStyledAttributes(a);
        boolean z = false;
        this.q = obtainStyledAttributes.getDimensionPixelSize(0, 0);
        Drawable drawable = obtainStyledAttributes.getDrawable(1);
        this.t = drawable;
        if (drawable == null) {
            z = true;
        }
        setWillNotDraw(z);
        obtainStyledAttributes.recycle();
        this.G = new OverScroller(context);
    }

    private static final boolean t(View view, Rect rect, boolean z) {
        boolean z2;
        lj ljVar = (lj) view.getLayoutParams();
        if (ljVar.leftMargin != rect.left) {
            ljVar.leftMargin = rect.left;
            z2 = true;
        } else {
            z2 = false;
        }
        if (ljVar.topMargin != rect.top) {
            ljVar.topMargin = rect.top;
            z2 = true;
        }
        if (ljVar.rightMargin != rect.right) {
            ljVar.rightMargin = rect.right;
            z2 = true;
        }
        if (z && ljVar.bottomMargin != rect.bottom) {
            ljVar.bottomMargin = rect.bottom;
            return true;
        }
        return z2;
    }

    private static final boolean u(View view, Rect rect) {
        if (view.getPaddingLeft() == rect.left && view.getPaddingTop() == rect.top && view.getPaddingRight() == rect.right) {
            return false;
        }
        view.setPadding(rect.left, rect.top, rect.right, view.getPaddingBottom());
        return true;
    }

    @Override // cal.nx
    public final void a() {
        h();
        this.s.e();
    }

    @Override // cal.nx
    public final void b(int i) {
        h();
        if (i != 2) {
            if (i != 5) {
                if (i != 109) {
                    return;
                }
                this.d = true;
                return;
            }
            this.s.f();
            return;
        }
        this.s.g();
    }

    @Override // android.view.ViewGroup
    protected final boolean checkLayoutParams(ViewGroup.LayoutParams layoutParams) {
        return layoutParams instanceof lj;
    }

    @Override // cal.ald
    public final void d(View view, int i, int i2, int i3, int i4, int i5) {
        if (i5 == 0) {
            int i6 = this.u + i2;
            this.u = i6;
            setActionBarHideOffset(i6);
        }
    }

    @Override // android.view.View
    public final void draw(Canvas canvas) {
        int i;
        super.draw(canvas);
        if (this.t != null) {
            if (this.c.getVisibility() == 0) {
                i = (int) (this.c.getBottom() + this.c.getTranslationY() + 0.5f);
            } else {
                i = 0;
            }
            this.t.setBounds(0, i, getWidth(), this.t.getIntrinsicHeight() + i);
            this.t.draw(canvas);
        }
    }

    @Override // cal.ale
    public final void e(View view, int i, int i2, int i3, int i4, int i5, int[] iArr) {
        if (i5 == 0) {
            int i6 = this.u + i2;
            this.u = i6;
            setActionBarHideOffset(i6);
        }
    }

    @Override // cal.ald
    public final void f(View view, View view2, int i, int i2) {
        if (i2 == 0) {
            onNestedScrollAccepted(view, view2, i);
        }
    }

    @Override // cal.ald
    public final void g(View view, int i) {
        if (i == 0) {
            onStopNestedScroll(view);
        }
    }

    @Override // android.view.ViewGroup
    protected final /* synthetic */ ViewGroup.LayoutParams generateDefaultLayoutParams() {
        return new lj();
    }

    @Override // android.view.ViewGroup
    public final /* synthetic */ ViewGroup.LayoutParams generateLayoutParams(AttributeSet attributeSet) {
        return new lj(getContext(), attributeSet);
    }

    @Override // android.view.ViewGroup
    public final int getNestedScrollAxes() {
        alf alfVar = this.H;
        return alfVar.b | alfVar.a;
    }

    final void h() {
        ny nyVar;
        if (this.r == null) {
            this.r = (ContentFrameLayout) findViewById(R.id.action_bar_activity_content);
            this.c = (ActionBarContainer) findViewById(R.id.action_bar_container);
            KeyEvent.Callback findViewById = findViewById(R.id.action_bar);
            if (findViewById instanceof ny) {
                nyVar = (ny) findViewById;
            } else if (findViewById instanceof Toolbar) {
                Toolbar toolbar = (Toolbar) findViewById;
                if (toolbar.t == null) {
                    toolbar.t = new tk(toolbar, true);
                }
                nyVar = toolbar.t;
            } else {
                throw new IllegalStateException("Can't make a decor toolbar out of ".concat(String.valueOf(findViewById.getClass().getSimpleName())));
            }
            this.s = nyVar;
        }
    }

    @Override // cal.nx
    public final void i(Menu menu, kq kqVar) {
        h();
        this.s.m(menu, kqVar);
    }

    @Override // cal.nx
    public final void j() {
        h();
        this.s.n();
    }

    @Override // cal.nx
    public final void k(Window.Callback callback) {
        h();
        this.s.s(callback);
    }

    @Override // cal.nx
    public final void l(CharSequence charSequence) {
        h();
        this.s.t(charSequence);
    }

    @Override // cal.nx
    public final boolean m() {
        h();
        return this.s.u();
    }

    @Override // cal.nx
    public final boolean n() {
        h();
        return this.s.w();
    }

    @Override // cal.nx
    public final boolean o() {
        h();
        return this.s.x();
    }

    /* JADX WARN: Code restructure failed: missing block: B:35:0x00cc, code lost:
    
        if (r4 != false) goto L37;
     */
    @Override // android.view.View
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct code enable 'Show inconsistent code' option in preferences
    */
    public final android.view.WindowInsets onApplyWindowInsets(android.view.WindowInsets r8) {
        /*
            Method dump skipped, instructions count: 240
            To view this dump change 'Code comments level' option to 'DEBUG'
        */
        throw new UnsupportedOperationException("Method not decompiled: android.support.v7.widget.ActionBarOverlayLayout.onApplyWindowInsets(android.view.WindowInsets):android.view.WindowInsets");
    }

    @Override // android.view.View
    protected final void onConfigurationChanged(Configuration configuration) {
        super.onConfigurationChanged(configuration);
        s(getContext());
        als.c(this);
    }

    @Override // android.view.ViewGroup, android.view.View
    protected final void onDetachedFromWindow() {
        super.onDetachedFromWindow();
        removeCallbacks(this.l);
        removeCallbacks(this.m);
        ViewPropertyAnimator viewPropertyAnimator = this.j;
        if (viewPropertyAnimator != null) {
            viewPropertyAnimator.cancel();
        }
    }

    @Override // android.view.ViewGroup, android.view.View
    protected final void onLayout(boolean z, int i, int i2, int i3, int i4) {
        int childCount = getChildCount();
        int paddingLeft = getPaddingLeft();
        int paddingTop = getPaddingTop();
        for (int i5 = 0; i5 < childCount; i5++) {
            View childAt = getChildAt(i5);
            if (childAt.getVisibility() != 8) {
                lj ljVar = (lj) childAt.getLayoutParams();
                int measuredWidth = childAt.getMeasuredWidth();
                int measuredHeight = childAt.getMeasuredHeight();
                int i6 = ljVar.leftMargin + paddingLeft;
                int i7 = ljVar.topMargin + paddingTop;
                childAt.layout(i6, i7, measuredWidth + i6, measuredHeight + i7);
            }
        }
    }

    /* JADX WARN: Removed duplicated region for block: B:45:0x0144  */
    /* JADX WARN: Removed duplicated region for block: B:47:0x014a  */
    @Override // android.view.View
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct code enable 'Show inconsistent code' option in preferences
    */
    protected final void onMeasure(int r13, int r14) {
        /*
            Method dump skipped, instructions count: 528
            To view this dump change 'Code comments level' option to 'DEBUG'
        */
        throw new UnsupportedOperationException("Method not decompiled: android.support.v7.widget.ActionBarOverlayLayout.onMeasure(int, int):void");
    }

    @Override // android.view.ViewGroup, android.view.ViewParent
    public final boolean onNestedFling(View view, float f, float f2, boolean z) {
        if (this.f && z) {
            this.G.fling(0, 0, 0, (int) f2, 0, 0, Integer.MIN_VALUE, Integer.MAX_VALUE);
            if (this.G.getFinalY() > this.c.getHeight()) {
                removeCallbacks(this.l);
                removeCallbacks(this.m);
                ViewPropertyAnimator viewPropertyAnimator = this.j;
                if (viewPropertyAnimator != null) {
                    viewPropertyAnimator.cancel();
                }
                this.m.run();
            } else {
                removeCallbacks(this.l);
                removeCallbacks(this.m);
                ViewPropertyAnimator viewPropertyAnimator2 = this.j;
                if (viewPropertyAnimator2 != null) {
                    viewPropertyAnimator2.cancel();
                }
                this.l.run();
            }
            this.g = true;
            return true;
        }
        return false;
    }

    @Override // android.view.ViewGroup, android.view.ViewParent
    public final boolean onNestedPreFling(View view, float f, float f2) {
        return false;
    }

    @Override // android.view.ViewGroup, android.view.ViewParent
    public final void onNestedScroll(View view, int i, int i2, int i3, int i4) {
        int i5 = this.u + i2;
        this.u = i5;
        setActionBarHideOffset(i5);
    }

    @Override // android.view.ViewGroup, android.view.ViewParent
    public final void onNestedScrollAccepted(View view, View view2, int i) {
        int i2;
        hz hzVar;
        jm jmVar;
        this.H.a = i;
        ActionBarContainer actionBarContainer = this.c;
        if (actionBarContainer != null) {
            i2 = -((int) actionBarContainer.getTranslationY());
        } else {
            i2 = 0;
        }
        this.u = i2;
        removeCallbacks(this.l);
        removeCallbacks(this.m);
        ViewPropertyAnimator viewPropertyAnimator = this.j;
        if (viewPropertyAnimator != null) {
            viewPropertyAnimator.cancel();
        }
        li liVar = this.i;
        if (liVar != null && (jmVar = (hzVar = (hz) liVar).n) != null) {
            jmVar.a();
            hzVar.n = null;
        }
    }

    @Override // android.view.ViewGroup, android.view.ViewParent
    public final boolean onStartNestedScroll(View view, View view2, int i) {
        if ((i & 2) != 0 && this.c.getVisibility() == 0) {
            return this.f;
        }
        return false;
    }

    @Override // android.view.ViewGroup, android.view.ViewParent
    public final void onStopNestedScroll(View view) {
        if (this.f && !this.g) {
            if (this.u <= this.c.getHeight()) {
                removeCallbacks(this.l);
                removeCallbacks(this.m);
                ViewPropertyAnimator viewPropertyAnimator = this.j;
                if (viewPropertyAnimator != null) {
                    viewPropertyAnimator.cancel();
                }
                postDelayed(this.l, 600L);
                return;
            }
            removeCallbacks(this.l);
            removeCallbacks(this.m);
            ViewPropertyAnimator viewPropertyAnimator2 = this.j;
            if (viewPropertyAnimator2 != null) {
                viewPropertyAnimator2.cancel();
            }
            postDelayed(this.m, 600L);
        }
    }

    @Override // android.view.View
    @Deprecated
    public final void onWindowSystemUiVisibilityChanged(int i) {
        boolean z;
        boolean z2;
        super.onWindowSystemUiVisibilityChanged(i);
        h();
        int i2 = this.h ^ i;
        this.h = i;
        li liVar = this.i;
        if (liVar != null) {
            if ((i & 256) != 0) {
                z = true;
            } else {
                z = false;
            }
            if (!z && !this.B) {
                z2 = true;
            } else {
                z2 = false;
            }
            int i3 = i & 4;
            hz hzVar = (hz) liVar;
            hzVar.k = z2;
            if (i3 != 0 && z) {
                if (!hzVar.m) {
                    hzVar.m = true;
                    hzVar.H(true);
                }
            } else if (hzVar.m) {
                hzVar.m = false;
                hzVar.H(true);
            }
        }
        if ((i2 & 256) != 0 && this.i != null) {
            als.c(this);
        }
    }

    @Override // android.view.View
    protected final void onWindowVisibilityChanged(int i) {
        super.onWindowVisibilityChanged(i);
        this.b = i;
        li liVar = this.i;
        if (liVar != null) {
            ((hz) liVar).j = i;
        }
    }

    @Override // cal.nx
    public final boolean p() {
        h();
        return this.s.y();
    }

    @Override // cal.ald
    public final boolean q(View view, View view2, int i, int i2) {
        if (i2 == 0 && (i & 2) != 0 && this.c.getVisibility() == 0 && this.f) {
            return true;
        }
        return false;
    }

    @Override // cal.nx
    public final boolean r() {
        h();
        return this.s.z();
    }

    public void setActionBarHideOffset(int i) {
        removeCallbacks(this.l);
        removeCallbacks(this.m);
        ViewPropertyAnimator viewPropertyAnimator = this.j;
        if (viewPropertyAnimator != null) {
            viewPropertyAnimator.cancel();
        }
        this.c.setTranslationY(-Math.max(0, Math.min(i, this.c.getHeight())));
    }

    public void setIcon(int i) {
        h();
        this.s.j(i);
    }

    public void setLogo(int i) {
        h();
        this.s.l(i);
    }

    @Override // android.view.ViewGroup
    public final boolean shouldDelayChildPressedState() {
        return false;
    }

    public ActionBarOverlayLayout(Context context, AttributeSet attributeSet) {
        super(context, attributeSet);
        this.b = 0;
        this.v = new Rect();
        this.w = new Rect();
        this.x = new Rect();
        this.y = new Rect();
        this.z = new Rect();
        this.A = true;
        this.B = false;
        new Rect();
        new Rect();
        new Rect();
        new Rect();
        this.C = anq.a;
        anq anqVar = anq.a;
        this.D = anqVar;
        this.E = anqVar;
        this.F = anqVar;
        this.k = new lf(this);
        this.l = new lg(this);
        this.m = new lh(this);
        s(context);
        this.H = new alf();
        lk lkVar = new lk(context);
        this.I = lkVar;
        addView(lkVar);
    }

    @Override // android.view.ViewGroup
    protected final ViewGroup.LayoutParams generateLayoutParams(ViewGroup.LayoutParams layoutParams) {
        return new lj(layoutParams);
    }

    public void setUiOptions(int i) {
    }

    @Override // android.view.ViewGroup, android.view.ViewParent
    public final void onNestedPreScroll(View view, int i, int i2, int[] iArr) {
    }

    @Override // cal.ald
    public final void c(View view, int i, int i2, int[] iArr, int i3) {
    }
}
