package android.support.v7.widget;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.drawable.Drawable;
import android.graphics.drawable.RippleDrawable;
import android.net.Uri;
import android.util.AttributeSet;
import android.widget.ImageView;
import cal.mc;
import cal.mo;
import cal.ol;
import cal.sq;
import cal.ss;
import cal.su;

/* compiled from: PG */
/* loaded from: classes.dex */
public class AppCompatImageView extends ImageView {
    private final mc a;
    private final mo b;
    private boolean c;

    public AppCompatImageView(Context context) {
        this(context, null);
    }

    /* JADX INFO: Access modifiers changed from: protected */
    @Override // android.widget.ImageView, android.view.View
    public void drawableStateChanged() {
        Drawable drawable;
        super.drawableStateChanged();
        mc mcVar = this.a;
        if (mcVar != null) {
            mcVar.a();
        }
        mo moVar = this.b;
        if (moVar != null && (drawable = moVar.a.getDrawable()) != null) {
            ol.c(drawable);
        }
    }

    @Override // android.widget.ImageView, android.view.View
    public final boolean hasOverlappingRendering() {
        if (!(this.b.a.getBackground() instanceof RippleDrawable) && super.hasOverlappingRendering()) {
            return true;
        }
        return false;
    }

    @Override // android.view.View
    public final void setBackgroundDrawable(Drawable drawable) {
        super.setBackgroundDrawable(drawable);
        mc mcVar = this.a;
        if (mcVar != null) {
            mcVar.a = -1;
            mcVar.b = null;
            mcVar.a();
            mcVar.a();
        }
    }

    @Override // android.view.View
    public void setBackgroundResource(int i) {
        super.setBackgroundResource(i);
        mc mcVar = this.a;
        if (mcVar != null) {
            mcVar.c(i);
        }
    }

    @Override // android.widget.ImageView
    public void setImageBitmap(Bitmap bitmap) {
        Drawable drawable;
        super.setImageBitmap(bitmap);
        mo moVar = this.b;
        if (moVar != null && (drawable = moVar.a.getDrawable()) != null) {
            ol.c(drawable);
        }
    }

    @Override // android.widget.ImageView
    public void setImageDrawable(Drawable drawable) {
        mo moVar = this.b;
        if (moVar != null && drawable != null && !this.c) {
            moVar.b = drawable.getLevel();
        }
        super.setImageDrawable(drawable);
        mo moVar2 = this.b;
        if (moVar2 != null) {
            Drawable drawable2 = moVar2.a.getDrawable();
            if (drawable2 != null) {
                ol.c(drawable2);
            }
            if (!this.c) {
                mo moVar3 = this.b;
                if (moVar3.a.getDrawable() != null) {
                    moVar3.a.getDrawable().setLevel(moVar3.b);
                }
            }
        }
    }

    @Override // android.widget.ImageView
    public void setImageLevel(int i) {
        super.setImageLevel(i);
        this.c = true;
    }

    @Override // android.widget.ImageView
    public void setImageResource(int i) {
        mo moVar = this.b;
        if (moVar != null) {
            moVar.b(i);
        }
    }

    @Override // android.widget.ImageView
    public void setImageURI(Uri uri) {
        Drawable drawable;
        super.setImageURI(uri);
        mo moVar = this.b;
        if (moVar != null && (drawable = moVar.a.getDrawable()) != null) {
            ol.c(drawable);
        }
    }

    public AppCompatImageView(Context context, AttributeSet attributeSet) {
        this(context, attributeSet, 0);
    }

    /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
    public AppCompatImageView(Context context, AttributeSet attributeSet, int i) {
        super(context, attributeSet, i);
        if (!(context instanceof ss) && !(context.getResources() instanceof su)) {
            context.getResources();
        }
        this.c = false;
        sq.b(this, getContext());
        mc mcVar = new mc(this);
        this.a = mcVar;
        mcVar.b(attributeSet, i);
        mo moVar = new mo(this);
        this.b = moVar;
        moVar.a(attributeSet, i);
    }
}
