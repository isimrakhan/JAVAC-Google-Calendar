package android.support.v7.widget;

import android.content.Context;
import android.text.TextUtils;
import android.util.AttributeSet;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup;
import android.widget.LinearLayout;
import android.widget.TextView;
import cal.ia;
import cal.je;
import cal.ke;
import cal.kn;
import cal.kt;
import cal.lc;
import cal.le;
import cal.ll;
import cal.lu;
import cal.sv;
import com.google.android.calendar.R;
import java.lang.ref.WeakReference;

/* compiled from: PG */
/* loaded from: classes.dex */
public class ActionBarContextView extends lc {
    public CharSequence g;
    public CharSequence h;
    public View i;
    public View j;
    public View k;
    public boolean l;
    private LinearLayout m;
    private TextView n;
    private TextView o;
    private int p;
    private int q;
    private int r;

    public ActionBarContextView(Context context) {
        this(context, null);
    }

    public final void d(je jeVar) {
        kn knVar;
        View view = this.i;
        if (view == null) {
            View inflate = LayoutInflater.from(getContext()).inflate(this.r, (ViewGroup) this, false);
            this.i = inflate;
            addView(inflate);
        } else if (view.getParent() == null) {
            addView(this.i);
        }
        View findViewById = this.i.findViewById(R.id.action_mode_close_button);
        this.j = findViewById;
        findViewById.setOnClickListener(new le(jeVar));
        Menu a = jeVar.a();
        lu luVar = this.d;
        if (luVar != null) {
            luVar.k();
            ll llVar = luVar.p;
            if (llVar != null && (knVar = llVar.f) != null && knVar.x()) {
                llVar.f.m();
            }
        }
        this.d = new lu(getContext());
        lu luVar2 = this.d;
        luVar2.k = true;
        luVar2.l = true;
        ViewGroup.LayoutParams layoutParams = new ViewGroup.LayoutParams(-2, -1);
        lu luVar3 = this.d;
        Context context = this.b;
        ke keVar = (ke) a;
        keVar.r.add(new WeakReference(luVar3));
        luVar3.c(context, keVar);
        keVar.i = true;
        lu luVar4 = this.d;
        kt ktVar = luVar4.f;
        if (luVar4.f == null) {
            luVar4.f = (kt) luVar4.d.inflate(R.layout.abc_action_menu_layout, (ViewGroup) this, false);
            luVar4.f.a(luVar4.c);
            luVar4.j();
        }
        kt ktVar2 = luVar4.f;
        if (ktVar != ktVar2) {
            ActionMenuView actionMenuView = (ActionMenuView) ktVar2;
            actionMenuView.c = luVar4;
            lu luVar5 = actionMenuView.c;
            luVar5.f = actionMenuView;
            actionMenuView.a = luVar5.c;
        }
        this.c = (ActionMenuView) ktVar2;
        this.c.setBackground(null);
        addView(this.c, layoutParams);
    }

    public final void e() {
        int i;
        if (this.m == null) {
            LayoutInflater.from(getContext()).inflate(R.layout.abc_action_bar_title_item, this);
            LinearLayout linearLayout = (LinearLayout) getChildAt(getChildCount() - 1);
            this.m = linearLayout;
            this.n = (TextView) linearLayout.findViewById(R.id.action_bar_title);
            this.o = (TextView) this.m.findViewById(R.id.action_bar_subtitle);
            if (this.p != 0) {
                this.n.setTextAppearance(getContext(), this.p);
            }
            if (this.q != 0) {
                this.o.setTextAppearance(getContext(), this.q);
            }
        }
        this.n.setText(this.g);
        this.o.setText(this.h);
        boolean isEmpty = TextUtils.isEmpty(this.g);
        boolean isEmpty2 = TextUtils.isEmpty(this.h);
        TextView textView = this.o;
        int i2 = 8;
        if (true != isEmpty2) {
            i = 0;
        } else {
            i = 8;
        }
        textView.setVisibility(i);
        LinearLayout linearLayout2 = this.m;
        if (!isEmpty || !isEmpty2) {
            i2 = 0;
        }
        linearLayout2.setVisibility(i2);
        if (this.m.getParent() == null) {
            addView(this.m);
        }
    }

    public final void f(View view) {
        LinearLayout linearLayout;
        View view2 = this.k;
        if (view2 != null) {
            removeView(view2);
        }
        this.k = view;
        if (view != null && (linearLayout = this.m) != null) {
            removeView(linearLayout);
            this.m = null;
        }
        if (view != null) {
            addView(view);
        }
        requestLayout();
    }

    @Override // android.view.ViewGroup
    protected final ViewGroup.LayoutParams generateDefaultLayoutParams() {
        return new ViewGroup.MarginLayoutParams(-1, -2);
    }

    @Override // android.view.ViewGroup
    public final ViewGroup.LayoutParams generateLayoutParams(AttributeSet attributeSet) {
        return new ViewGroup.MarginLayoutParams(getContext(), attributeSet);
    }

    @Override // android.view.ViewGroup, android.view.View
    public final void onDetachedFromWindow() {
        kn knVar;
        super.onDetachedFromWindow();
        lu luVar = this.d;
        if (luVar != null) {
            luVar.k();
            ll llVar = this.d.p;
            if (llVar != null && (knVar = llVar.f) != null && knVar.x()) {
                llVar.f.m();
            }
        }
    }

    @Override // cal.lc, android.view.View
    public final /* bridge */ /* synthetic */ boolean onHoverEvent(MotionEvent motionEvent) {
        super.onHoverEvent(motionEvent);
        return true;
    }

    @Override // android.view.ViewGroup, android.view.View
    protected final void onLayout(boolean z, int i, int i2, int i3, int i4) {
        int paddingLeft;
        int paddingRight;
        int i5;
        int i6;
        int i7;
        boolean z2 = true;
        if (getLayoutDirection() != 1) {
            z2 = false;
        }
        if (z2) {
            paddingLeft = (i3 - i) - getPaddingRight();
        } else {
            paddingLeft = getPaddingLeft();
        }
        int paddingTop = getPaddingTop();
        int paddingTop2 = ((i4 - i2) - getPaddingTop()) - getPaddingBottom();
        View view = this.i;
        if (view != null && view.getVisibility() != 8) {
            ViewGroup.MarginLayoutParams marginLayoutParams = (ViewGroup.MarginLayoutParams) this.i.getLayoutParams();
            if (z2) {
                i5 = marginLayoutParams.rightMargin;
            } else {
                i5 = marginLayoutParams.leftMargin;
            }
            if (z2) {
                i6 = marginLayoutParams.leftMargin;
            } else {
                i6 = marginLayoutParams.rightMargin;
            }
            if (z2) {
                i7 = paddingLeft - i5;
            } else {
                i7 = paddingLeft + i5;
            }
            View view2 = this.i;
            int measuredWidth = view2.getMeasuredWidth();
            int measuredHeight = view2.getMeasuredHeight();
            int i8 = ((paddingTop2 - measuredHeight) / 2) + paddingTop;
            int i9 = measuredHeight + i8;
            if (z2) {
                view2.layout(i7 - measuredWidth, i8, i7, i9);
                measuredWidth = -measuredWidth;
            } else {
                view2.layout(i7, i8, i7 + measuredWidth, i9);
            }
            int i10 = i7 + measuredWidth;
            if (z2) {
                paddingLeft = i10 - i6;
            } else {
                paddingLeft = i10 + i6;
            }
        }
        LinearLayout linearLayout = this.m;
        if (linearLayout != null && this.k == null && linearLayout.getVisibility() != 8) {
            LinearLayout linearLayout2 = this.m;
            int measuredWidth2 = linearLayout2.getMeasuredWidth();
            int measuredHeight2 = linearLayout2.getMeasuredHeight();
            int i11 = ((paddingTop2 - measuredHeight2) / 2) + paddingTop;
            int i12 = measuredHeight2 + i11;
            if (z2) {
                linearLayout2.layout(paddingLeft - measuredWidth2, i11, paddingLeft, i12);
                measuredWidth2 = -measuredWidth2;
            } else {
                linearLayout2.layout(paddingLeft, i11, paddingLeft + measuredWidth2, i12);
            }
            paddingLeft += measuredWidth2;
        }
        View view3 = this.k;
        if (view3 != null) {
            int measuredWidth3 = view3.getMeasuredWidth();
            int measuredHeight3 = view3.getMeasuredHeight();
            int i13 = ((paddingTop2 - measuredHeight3) / 2) + paddingTop;
            int i14 = measuredHeight3 + i13;
            if (z2) {
                view3.layout(paddingLeft - measuredWidth3, i13, paddingLeft, i14);
            } else {
                view3.layout(paddingLeft, i13, measuredWidth3 + paddingLeft, i14);
            }
        }
        if (z2) {
            paddingRight = getPaddingLeft();
        } else {
            paddingRight = (i3 - i) - getPaddingRight();
        }
        ActionMenuView actionMenuView = this.c;
        if (actionMenuView != null) {
            int measuredWidth4 = actionMenuView.getMeasuredWidth();
            int measuredHeight4 = actionMenuView.getMeasuredHeight();
            int i15 = paddingTop + ((paddingTop2 - measuredHeight4) / 2);
            int i16 = measuredHeight4 + i15;
            if (!z2) {
                actionMenuView.layout(paddingRight - measuredWidth4, i15, paddingRight, i16);
            } else {
                actionMenuView.layout(paddingRight, i15, measuredWidth4 + paddingRight, i16);
            }
        }
    }

    @Override // android.view.View
    protected final void onMeasure(int i, int i2) {
        int i3;
        boolean z;
        int i4;
        int i5 = 1073741824;
        if (View.MeasureSpec.getMode(i) == 1073741824) {
            if (View.MeasureSpec.getMode(i2) != 0) {
                int size = View.MeasureSpec.getSize(i);
                int i6 = this.e;
                if (i6 <= 0) {
                    i6 = View.MeasureSpec.getSize(i2);
                }
                int paddingTop = getPaddingTop() + getPaddingBottom();
                int paddingLeft = (size - getPaddingLeft()) - getPaddingRight();
                int i7 = i6 - paddingTop;
                int makeMeasureSpec = View.MeasureSpec.makeMeasureSpec(i7, Integer.MIN_VALUE);
                View view = this.i;
                if (view != null) {
                    view.measure(View.MeasureSpec.makeMeasureSpec(paddingLeft, Integer.MIN_VALUE), makeMeasureSpec);
                    int max = Math.max(0, paddingLeft - view.getMeasuredWidth());
                    ViewGroup.MarginLayoutParams marginLayoutParams = (ViewGroup.MarginLayoutParams) this.i.getLayoutParams();
                    paddingLeft = max - (marginLayoutParams.leftMargin + marginLayoutParams.rightMargin);
                }
                ActionMenuView actionMenuView = this.c;
                if (actionMenuView != null && actionMenuView.getParent() == this) {
                    ActionMenuView actionMenuView2 = this.c;
                    actionMenuView2.measure(View.MeasureSpec.makeMeasureSpec(paddingLeft, Integer.MIN_VALUE), makeMeasureSpec);
                    paddingLeft = Math.max(0, paddingLeft - actionMenuView2.getMeasuredWidth());
                }
                LinearLayout linearLayout = this.m;
                if (linearLayout != null && this.k == null) {
                    if (this.l) {
                        this.m.measure(View.MeasureSpec.makeMeasureSpec(0, 0), makeMeasureSpec);
                        int measuredWidth = this.m.getMeasuredWidth();
                        if (measuredWidth <= paddingLeft) {
                            z = true;
                        } else {
                            z = false;
                        }
                        if (z) {
                            paddingLeft -= measuredWidth;
                        }
                        LinearLayout linearLayout2 = this.m;
                        if (true != z) {
                            i4 = 8;
                        } else {
                            i4 = 0;
                        }
                        linearLayout2.setVisibility(i4);
                    } else {
                        linearLayout.measure(View.MeasureSpec.makeMeasureSpec(paddingLeft, Integer.MIN_VALUE), makeMeasureSpec);
                        paddingLeft = Math.max(0, paddingLeft - linearLayout.getMeasuredWidth());
                    }
                }
                View view2 = this.k;
                if (view2 != null) {
                    ViewGroup.LayoutParams layoutParams = view2.getLayoutParams();
                    if (layoutParams.width != -2) {
                        i3 = 1073741824;
                    } else {
                        i3 = Integer.MIN_VALUE;
                    }
                    if (layoutParams.width >= 0) {
                        paddingLeft = Math.min(layoutParams.width, paddingLeft);
                    }
                    if (layoutParams.height == -2) {
                        i5 = Integer.MIN_VALUE;
                    }
                    if (layoutParams.height >= 0) {
                        i7 = Math.min(layoutParams.height, i7);
                    }
                    this.k.measure(View.MeasureSpec.makeMeasureSpec(paddingLeft, i3), View.MeasureSpec.makeMeasureSpec(i7, i5));
                }
                if (this.e <= 0) {
                    int childCount = getChildCount();
                    int i8 = 0;
                    for (int i9 = 0; i9 < childCount; i9++) {
                        int measuredHeight = getChildAt(i9).getMeasuredHeight() + paddingTop;
                        if (measuredHeight > i8) {
                            i8 = measuredHeight;
                        }
                    }
                    setMeasuredDimension(size, i8);
                    return;
                }
                setMeasuredDimension(size, i6);
                return;
            }
            throw new IllegalStateException(String.valueOf(getClass().getSimpleName()).concat(" can only be used with android:layout_height=\"wrap_content\""));
        }
        throw new IllegalStateException(String.valueOf(getClass().getSimpleName()).concat(" can only be used with android:layout_width=\"match_parent\" (or fill_parent)"));
    }

    @Override // cal.lc, android.view.View
    public final /* bridge */ /* synthetic */ boolean onTouchEvent(MotionEvent motionEvent) {
        super.onTouchEvent(motionEvent);
        return true;
    }

    @Override // cal.lc
    public void setContentHeight(int i) {
        this.e = i;
    }

    @Override // cal.lc, android.view.View
    public /* bridge */ /* synthetic */ void setVisibility(int i) {
        super.setVisibility(i);
    }

    @Override // android.view.ViewGroup
    public final boolean shouldDelayChildPressedState() {
        return false;
    }

    public ActionBarContextView(Context context, AttributeSet attributeSet) {
        this(context, attributeSet, R.attr.actionModeStyle);
    }

    public ActionBarContextView(Context context, AttributeSet attributeSet, int i) {
        super(context, attributeSet, i);
        sv svVar = new sv(context, context.obtainStyledAttributes(attributeSet, ia.d, i, 0));
        setBackground(svVar.b(0));
        this.p = svVar.b.getResourceId(5, 0);
        this.q = svVar.b.getResourceId(4, 0);
        this.e = svVar.b.getLayoutDimension(3, 0);
        this.r = svVar.b.getResourceId(2, R.layout.abc_action_mode_close_item_material);
        svVar.b.recycle();
    }
}
