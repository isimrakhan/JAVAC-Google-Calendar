package android.support.v7.widget;

import android.content.Context;
import android.content.res.ColorStateList;
import android.content.res.TypedArray;
import android.graphics.drawable.Drawable;
import android.os.Build;
import android.os.Parcelable;
import android.support.v7.widget.Toolbar;
import android.text.TextUtils;
import android.util.AttributeSet;
import android.view.ContextThemeWrapper;
import android.view.Gravity;
import android.view.Menu;
import android.view.MenuItem;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.TextView;
import android.window.OnBackInvokedCallback;
import android.window.OnBackInvokedDispatcher;
import cal.akz;
import cal.ala;
import cal.alb;
import cal.alz;
import cal.di;
import cal.fp;
import cal.ia;
import cal.jk;
import cal.kc;
import cal.ke;
import cal.kh;
import cal.kn;
import cal.kq;
import cal.lq;
import cal.lu;
import cal.ry;
import cal.sa;
import cal.sv;
import cal.sw;
import cal.sy;
import cal.sz;
import cal.ta;
import cal.tb;
import cal.td;
import cal.te;
import cal.tf;
import cal.th;
import cal.tk;
import com.google.android.calendar.R;
import java.lang.ref.WeakReference;
import java.util.ArrayList;
import java.util.List;

/* compiled from: PG */
/* loaded from: classes.dex */
public class Toolbar extends ViewGroup implements akz {
    private CharSequence A;
    private int B;
    private int C;
    private int D;
    private int E;
    private int F;
    private int G;
    private int H;
    private int I;
    private ColorStateList J;
    private ColorStateList K;
    private boolean L;
    private boolean M;
    private final ArrayList N;
    private final int[] O;
    private OnBackInvokedCallback P;
    private OnBackInvokedDispatcher Q;
    private final Runnable R;
    private final sy S;
    public ActionMenuView a;
    public TextView b;
    public TextView c;
    public ImageButton d;
    public ImageView e;
    public ImageButton f;
    public View g;
    public Context h;
    public int i;
    public int j;
    public int k;
    public int l;
    public sa m;
    public CharSequence n;
    public CharSequence o;
    public final ArrayList p;
    public final alb q;
    public ArrayList r;
    public tf s;
    public tk t;
    public lu u;
    public td v;
    public kq w;
    public kc x;
    public boolean y;
    private Drawable z;

    public Toolbar(Context context) {
        this(context, null);
    }

    private final void A(View view, int i, int i2, int i3, int i4) {
        ViewGroup.MarginLayoutParams marginLayoutParams = (ViewGroup.MarginLayoutParams) view.getLayoutParams();
        int childMeasureSpec = getChildMeasureSpec(i, getPaddingLeft() + getPaddingRight() + marginLayoutParams.leftMargin + marginLayoutParams.rightMargin + i2, marginLayoutParams.width);
        int childMeasureSpec2 = getChildMeasureSpec(i3, getPaddingTop() + getPaddingBottom() + marginLayoutParams.topMargin + marginLayoutParams.bottomMargin, marginLayoutParams.height);
        int mode = View.MeasureSpec.getMode(childMeasureSpec2);
        if (mode != 1073741824 && i4 >= 0) {
            if (mode != 0) {
                i4 = Math.min(View.MeasureSpec.getSize(childMeasureSpec2), i4);
            }
            childMeasureSpec2 = View.MeasureSpec.makeMeasureSpec(i4, 1073741824);
        }
        view.measure(childMeasureSpec, childMeasureSpec2);
    }

    private final int a(int i) {
        int layoutDirection = getLayoutDirection();
        int absoluteGravity = Gravity.getAbsoluteGravity(i, layoutDirection) & 7;
        if (absoluteGravity != 1 && absoluteGravity != 3 && absoluteGravity != 5) {
            if (layoutDirection != 1) {
                return 3;
            }
            return 5;
        }
        return absoluteGravity;
    }

    protected static final te t(ViewGroup.LayoutParams layoutParams) {
        if (layoutParams instanceof te) {
            return new te((te) layoutParams);
        }
        if (layoutParams instanceof fp) {
            return new te((fp) layoutParams);
        }
        if (layoutParams instanceof ViewGroup.MarginLayoutParams) {
            return new te((ViewGroup.MarginLayoutParams) layoutParams);
        }
        return new te(layoutParams);
    }

    private final int u(View view, int i) {
        int i2;
        te teVar = (te) view.getLayoutParams();
        int measuredHeight = view.getMeasuredHeight();
        if (i > 0) {
            i2 = (measuredHeight - i) / 2;
        } else {
            i2 = 0;
        }
        int i3 = teVar.a & 112;
        if (i3 != 16 && i3 != 48 && i3 != 80) {
            i3 = this.I & 112;
        }
        if (i3 != 48) {
            if (i3 != 80) {
                int paddingTop = getPaddingTop();
                int paddingBottom = getPaddingBottom();
                int height = getHeight();
                int i4 = (((height - paddingTop) - paddingBottom) - measuredHeight) / 2;
                if (i4 < teVar.topMargin) {
                    i4 = teVar.topMargin;
                } else {
                    int i5 = (((height - paddingBottom) - measuredHeight) - i4) - paddingTop;
                    if (i5 < teVar.bottomMargin) {
                        i4 = Math.max(0, i4 - (teVar.bottomMargin - i5));
                    }
                }
                return paddingTop + i4;
            }
            return (((getHeight() - getPaddingBottom()) - measuredHeight) - teVar.bottomMargin) - i2;
        }
        return getPaddingTop() - i2;
    }

    private final int v(View view, int i, int[] iArr, int i2) {
        te teVar = (te) view.getLayoutParams();
        int i3 = teVar.leftMargin - iArr[0];
        int max = i + Math.max(0, i3);
        iArr[0] = Math.max(0, -i3);
        int u = u(view, i2);
        int measuredWidth = view.getMeasuredWidth();
        view.layout(max, u, max + measuredWidth, view.getMeasuredHeight() + u);
        return max + measuredWidth + teVar.rightMargin;
    }

    private final int w(View view, int i, int[] iArr, int i2) {
        te teVar = (te) view.getLayoutParams();
        int i3 = teVar.rightMargin - iArr[1];
        int max = i - Math.max(0, i3);
        iArr[1] = Math.max(0, -i3);
        int u = u(view, i2);
        int measuredWidth = view.getMeasuredWidth();
        view.layout(max - measuredWidth, u, max, view.getMeasuredHeight() + u);
        return max - (measuredWidth + teVar.leftMargin);
    }

    private final int x(View view, int i, int i2, int i3, int i4, int[] iArr) {
        ViewGroup.MarginLayoutParams marginLayoutParams = (ViewGroup.MarginLayoutParams) view.getLayoutParams();
        int i5 = marginLayoutParams.leftMargin - iArr[0];
        int i6 = marginLayoutParams.rightMargin - iArr[1];
        int max = Math.max(0, i5) + Math.max(0, i6);
        iArr[0] = Math.max(0, -i5);
        iArr[1] = Math.max(0, -i6);
        view.measure(getChildMeasureSpec(i, getPaddingLeft() + getPaddingRight() + max + i2, marginLayoutParams.width), getChildMeasureSpec(i3, getPaddingTop() + getPaddingBottom() + marginLayoutParams.topMargin + marginLayoutParams.bottomMargin + i4, marginLayoutParams.height));
        return view.getMeasuredWidth() + max;
    }

    private final void y(List list, int i) {
        int layoutDirection = getLayoutDirection();
        int childCount = getChildCount();
        int absoluteGravity = Gravity.getAbsoluteGravity(i, getLayoutDirection());
        list.clear();
        if (layoutDirection != 1) {
            for (int i2 = 0; i2 < childCount; i2++) {
                View childAt = getChildAt(i2);
                te teVar = (te) childAt.getLayoutParams();
                if (teVar.b == 0 && childAt != null && childAt.getParent() == this && childAt.getVisibility() != 8 && a(teVar.a) == absoluteGravity) {
                    list.add(childAt);
                }
            }
            return;
        }
        while (true) {
            childCount--;
            if (childCount >= 0) {
                View childAt2 = getChildAt(childCount);
                te teVar2 = (te) childAt2.getLayoutParams();
                if (teVar2.b == 0 && childAt2 != null && childAt2.getParent() == this && childAt2.getVisibility() != 8 && a(teVar2.a) == absoluteGravity) {
                    list.add(childAt2);
                }
            } else {
                return;
            }
        }
    }

    private final void z(View view, boolean z) {
        te t;
        ViewGroup.LayoutParams layoutParams = view.getLayoutParams();
        if (layoutParams == null) {
            t = new te();
        } else if (super.checkLayoutParams(layoutParams) && (layoutParams instanceof te)) {
            t = (te) layoutParams;
        } else {
            t = t(layoutParams);
        }
        t.b = 1;
        if (z && this.g != null) {
            view.setLayoutParams(t);
            this.p.add(view);
        } else {
            addView(view, t);
        }
    }

    public final int cc() {
        ke keVar;
        int i;
        ActionMenuView actionMenuView = this.a;
        if (actionMenuView != null && (keVar = actionMenuView.a) != null && keVar.hasVisibleItems()) {
            sa saVar = this.m;
            if (saVar != null) {
                if (saVar.g) {
                    i = saVar.a;
                } else {
                    i = saVar.b;
                }
            } else {
                i = 0;
            }
            return Math.max(i, Math.max(this.H, 0));
        }
        sa saVar2 = this.m;
        if (saVar2 == null) {
            return 0;
        }
        if (saVar2.g) {
            return saVar2.a;
        }
        return saVar2.b;
    }

    public final int cd() {
        Drawable drawable;
        int i;
        ImageButton imageButton = this.d;
        if (imageButton != null) {
            drawable = imageButton.getDrawable();
        } else {
            drawable = null;
        }
        if (drawable != null) {
            sa saVar = this.m;
            if (saVar != null) {
                if (saVar.g) {
                    i = saVar.b;
                } else {
                    i = saVar.a;
                }
            } else {
                i = 0;
            }
            return Math.max(i, Math.max(this.G, 0));
        }
        sa saVar2 = this.m;
        if (saVar2 == null) {
            return 0;
        }
        if (saVar2.g) {
            return saVar2.b;
        }
        return saVar2.a;
    }

    @Override // android.view.ViewGroup
    protected final boolean checkLayoutParams(ViewGroup.LayoutParams layoutParams) {
        if (super.checkLayoutParams(layoutParams) && (layoutParams instanceof te)) {
            return true;
        }
        return false;
    }

    public final Menu d() {
        g();
        return this.a.f();
    }

    public final ArrayList e() {
        ArrayList arrayList = new ArrayList();
        g();
        Menu f = this.a.f();
        int i = 0;
        while (true) {
            ke keVar = (ke) f;
            if (i < keVar.e.size()) {
                arrayList.add((MenuItem) keVar.e.get(i));
                i++;
            } else {
                return arrayList;
            }
        }
    }

    public final void f() {
        if (this.f == null) {
            AppCompatImageButton appCompatImageButton = new AppCompatImageButton(getContext(), null, R.attr.toolbarNavigationButtonStyle);
            this.f = appCompatImageButton;
            appCompatImageButton.setImageDrawable(this.z);
            this.f.setContentDescription(this.A);
            te teVar = new te();
            teVar.a = (this.l & 112) | 8388611;
            teVar.b = 2;
            this.f.setLayoutParams(teVar);
            this.f.setOnClickListener(new tb(this));
        }
    }

    public final void g() {
        kh khVar;
        h();
        ActionMenuView actionMenuView = this.a;
        if (actionMenuView.a == null) {
            Menu f = actionMenuView.f();
            if (this.v == null) {
                this.v = new td(this);
            }
            this.a.c.n = true;
            td tdVar = this.v;
            ke keVar = (ke) f;
            keVar.r.add(new WeakReference(tdVar));
            ke keVar2 = tdVar.a;
            if (keVar2 != null && (khVar = tdVar.b) != null) {
                keVar2.r(khVar);
            }
            tdVar.a = keVar;
            keVar.i = true;
            s();
        }
    }

    @Override // android.view.ViewGroup
    protected final /* synthetic */ ViewGroup.LayoutParams generateDefaultLayoutParams() {
        return new te();
    }

    @Override // android.view.ViewGroup
    public final /* synthetic */ ViewGroup.LayoutParams generateLayoutParams(AttributeSet attributeSet) {
        return new te(getContext(), attributeSet);
    }

    public final void h() {
        if (this.a == null) {
            ActionMenuView actionMenuView = new ActionMenuView(getContext());
            this.a = actionMenuView;
            actionMenuView.setPopupTheme(this.i);
            ActionMenuView actionMenuView2 = this.a;
            actionMenuView2.f = this.S;
            kq kqVar = this.w;
            ta taVar = new ta(this);
            actionMenuView2.d = kqVar;
            actionMenuView2.e = taVar;
            te teVar = new te();
            teVar.a = (this.l & 112) | 8388613;
            this.a.setLayoutParams(teVar);
            z(this.a, false);
        }
    }

    public final void i() {
        if (this.d == null) {
            this.d = new AppCompatImageButton(getContext(), null, R.attr.toolbarNavigationButtonStyle);
            te teVar = new te();
            teVar.a = (this.l & 112) | 8388611;
            this.d.setLayoutParams(teVar);
        }
    }

    public void j(int i) {
        jk jkVar = new jk(getContext());
        g();
        jkVar.inflate(i, this.a.f());
    }

    public final void k(Drawable drawable) {
        if (drawable != null) {
            if (this.e == null) {
                this.e = new AppCompatImageView(getContext());
            }
            ImageView imageView = this.e;
            if (imageView.getParent() != this && !this.p.contains(imageView)) {
                z(this.e, true);
            }
        } else {
            ImageView imageView2 = this.e;
            if (imageView2 != null && (imageView2.getParent() == this || this.p.contains(imageView2))) {
                removeView(this.e);
                this.p.remove(this.e);
            }
        }
        ImageView imageView3 = this.e;
        if (imageView3 != null) {
            imageView3.setImageDrawable(drawable);
        }
    }

    public final void l(CharSequence charSequence) {
        if (!TextUtils.isEmpty(charSequence) && this.e == null) {
            this.e = new AppCompatImageView(getContext());
        }
        ImageView imageView = this.e;
        if (imageView != null) {
            imageView.setContentDescription(charSequence);
        }
    }

    public final void m(CharSequence charSequence) {
        if (!TextUtils.isEmpty(charSequence)) {
            i();
        }
        ImageButton imageButton = this.d;
        if (imageButton != null) {
            imageButton.setContentDescription(charSequence);
            this.d.setTooltipText(charSequence);
        }
    }

    public void n(Drawable drawable) {
        if (drawable != null) {
            i();
            ImageButton imageButton = this.d;
            if (imageButton.getParent() != this && !this.p.contains(imageButton)) {
                z(this.d, true);
            }
        } else {
            ImageButton imageButton2 = this.d;
            if (imageButton2 != null && (imageButton2.getParent() == this || this.p.contains(imageButton2))) {
                removeView(this.d);
                this.p.remove(this.d);
            }
        }
        ImageButton imageButton3 = this.d;
        if (imageButton3 != null) {
            imageButton3.setImageDrawable(drawable);
        }
    }

    public void o(CharSequence charSequence) {
        if (!TextUtils.isEmpty(charSequence)) {
            if (this.c == null) {
                Context context = getContext();
                AppCompatTextView appCompatTextView = new AppCompatTextView(context);
                this.c = appCompatTextView;
                appCompatTextView.setSingleLine();
                this.c.setEllipsize(TextUtils.TruncateAt.END);
                int i = this.k;
                if (i != 0) {
                    this.c.setTextAppearance(context, i);
                }
                ColorStateList colorStateList = this.K;
                if (colorStateList != null) {
                    this.c.setTextColor(colorStateList);
                }
            }
            TextView textView = this.c;
            if (textView.getParent() != this && !this.p.contains(textView)) {
                z(this.c, true);
            }
        } else {
            TextView textView2 = this.c;
            if (textView2 != null && (textView2.getParent() == this || this.p.contains(textView2))) {
                removeView(this.c);
                this.p.remove(this.c);
            }
        }
        TextView textView3 = this.c;
        if (textView3 != null) {
            textView3.setText(charSequence);
        }
        this.o = charSequence;
    }

    /* JADX INFO: Access modifiers changed from: protected */
    @Override // android.view.ViewGroup, android.view.View
    public void onAttachedToWindow() {
        super.onAttachedToWindow();
        s();
    }

    @Override // android.view.ViewGroup, android.view.View
    protected final void onDetachedFromWindow() {
        super.onDetachedFromWindow();
        removeCallbacks(this.R);
        s();
    }

    @Override // android.view.View
    public final boolean onHoverEvent(MotionEvent motionEvent) {
        int actionMasked = motionEvent.getActionMasked();
        int i = 9;
        if (actionMasked == 9) {
            this.M = false;
            actionMasked = 9;
        }
        if (!this.M) {
            boolean onHoverEvent = super.onHoverEvent(motionEvent);
            if (actionMasked == 9) {
                if (!onHoverEvent) {
                    this.M = true;
                }
                if (i != 10 || i == 3) {
                    this.M = false;
                }
                return true;
            }
        }
        i = actionMasked;
        if (i != 10) {
        }
        this.M = false;
        return true;
    }

    /* JADX INFO: Access modifiers changed from: protected */
    /* JADX WARN: Removed duplicated region for block: B:102:0x018c  */
    /* JADX WARN: Removed duplicated region for block: B:104:0x0193  */
    /* JADX WARN: Removed duplicated region for block: B:107:0x01a6  */
    /* JADX WARN: Removed duplicated region for block: B:112:0x01cb  */
    /* JADX WARN: Removed duplicated region for block: B:119:0x0219  */
    /* JADX WARN: Removed duplicated region for block: B:132:0x028c  */
    /* JADX WARN: Removed duplicated region for block: B:148:0x020a  */
    /* JADX WARN: Removed duplicated region for block: B:153:0x0196  */
    /* JADX WARN: Removed duplicated region for block: B:154:0x018f  */
    /* JADX WARN: Removed duplicated region for block: B:155:0x017d  */
    /* JADX WARN: Removed duplicated region for block: B:156:0x0162  */
    /* JADX WARN: Removed duplicated region for block: B:160:0x00bc  */
    /* JADX WARN: Removed duplicated region for block: B:161:0x00ad  */
    /* JADX WARN: Removed duplicated region for block: B:21:0x0075  */
    /* JADX WARN: Removed duplicated region for block: B:22:0x007c  */
    /* JADX WARN: Removed duplicated region for block: B:30:0x0094  */
    /* JADX WARN: Removed duplicated region for block: B:31:0x009b  */
    /* JADX WARN: Removed duplicated region for block: B:34:0x00a8  */
    /* JADX WARN: Removed duplicated region for block: B:37:0x00b7  */
    /* JADX WARN: Removed duplicated region for block: B:45:0x00f3  */
    /* JADX WARN: Removed duplicated region for block: B:46:0x00fa  */
    /* JADX WARN: Removed duplicated region for block: B:54:0x0114  */
    /* JADX WARN: Removed duplicated region for block: B:55:0x011b  */
    /* JADX WARN: Removed duplicated region for block: B:65:0x013c  */
    /* JADX WARN: Removed duplicated region for block: B:71:0x014d  */
    /* JADX WARN: Removed duplicated region for block: B:73:0x0165  */
    /* JADX WARN: Removed duplicated region for block: B:75:0x0181 A[ADDED_TO_REGION] */
    /* JADX WARN: Removed duplicated region for block: B:79:0x0307 A[LOOP:0: B:78:0x0305->B:79:0x0307, LOOP_END] */
    /* JADX WARN: Removed duplicated region for block: B:83:0x0329 A[LOOP:1: B:82:0x0327->B:83:0x0329, LOOP_END] */
    /* JADX WARN: Removed duplicated region for block: B:87:0x034d A[LOOP:2: B:86:0x034b->B:87:0x034d, LOOP_END] */
    /* JADX WARN: Removed duplicated region for block: B:91:0x038e  */
    /* JADX WARN: Removed duplicated region for block: B:96:0x039d A[LOOP:3: B:95:0x039b->B:96:0x039d, LOOP_END] */
    @Override // android.view.ViewGroup, android.view.View
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct code enable 'Show inconsistent code' option in preferences
    */
    public void onLayout(boolean r19, int r20, int r21, int r22, int r23) {
        /*
            Method dump skipped, instructions count: 946
            To view this dump change 'Code comments level' option to 'DEBUG'
        */
        throw new UnsupportedOperationException("Method not decompiled: android.support.v7.widget.Toolbar.onLayout(boolean, int, int, int, int):void");
    }

    @Override // android.view.View
    protected final void onMeasure(int i, int i2) {
        int i3;
        int i4;
        int i5;
        char c;
        int i6;
        int i7;
        int i8;
        int i9;
        int layoutDirection = getLayoutDirection();
        ImageButton imageButton = this.d;
        int i10 = 0;
        if (imageButton != null && imageButton.getParent() == this && imageButton.getVisibility() != 8) {
            A(this.d, i, 0, i2, this.B);
            int measuredWidth = this.d.getMeasuredWidth();
            ViewGroup.MarginLayoutParams marginLayoutParams = (ViewGroup.MarginLayoutParams) this.d.getLayoutParams();
            i3 = measuredWidth + marginLayoutParams.getMarginStart() + marginLayoutParams.getMarginEnd();
            int measuredHeight = this.d.getMeasuredHeight();
            ViewGroup.MarginLayoutParams marginLayoutParams2 = (ViewGroup.MarginLayoutParams) this.d.getLayoutParams();
            i4 = Math.max(0, measuredHeight + marginLayoutParams2.topMargin + marginLayoutParams2.bottomMargin);
            i5 = View.combineMeasuredStates(0, this.d.getMeasuredState());
        } else {
            i3 = 0;
            i4 = 0;
            i5 = 0;
        }
        ImageButton imageButton2 = this.f;
        if (imageButton2 != null && imageButton2.getParent() == this && imageButton2.getVisibility() != 8) {
            A(this.f, i, 0, i2, this.B);
            int measuredWidth2 = this.f.getMeasuredWidth();
            ViewGroup.MarginLayoutParams marginLayoutParams3 = (ViewGroup.MarginLayoutParams) this.f.getLayoutParams();
            i3 = measuredWidth2 + marginLayoutParams3.getMarginStart() + marginLayoutParams3.getMarginEnd();
            int measuredHeight2 = this.f.getMeasuredHeight();
            ViewGroup.MarginLayoutParams marginLayoutParams4 = (ViewGroup.MarginLayoutParams) this.f.getLayoutParams();
            i4 = Math.max(i4, measuredHeight2 + marginLayoutParams4.topMargin + marginLayoutParams4.bottomMargin);
            i5 = View.combineMeasuredStates(i5, this.f.getMeasuredState());
        }
        if (layoutDirection == 1) {
            c = 1;
        } else {
            c = 0;
        }
        int[] iArr = this.O;
        int cd = cd();
        int max = Math.max(cd, i3);
        iArr[c] = Math.max(0, cd - i3);
        ActionMenuView actionMenuView = this.a;
        if (actionMenuView != null && actionMenuView.getParent() == this && actionMenuView.getVisibility() != 8) {
            A(this.a, i, max, i2, this.B);
            int measuredWidth3 = this.a.getMeasuredWidth();
            ViewGroup.MarginLayoutParams marginLayoutParams5 = (ViewGroup.MarginLayoutParams) this.a.getLayoutParams();
            i6 = measuredWidth3 + marginLayoutParams5.getMarginStart() + marginLayoutParams5.getMarginEnd();
            int measuredHeight3 = this.a.getMeasuredHeight();
            ViewGroup.MarginLayoutParams marginLayoutParams6 = (ViewGroup.MarginLayoutParams) this.a.getLayoutParams();
            i4 = Math.max(i4, measuredHeight3 + marginLayoutParams6.topMargin + marginLayoutParams6.bottomMargin);
            i5 = View.combineMeasuredStates(i5, this.a.getMeasuredState());
        } else {
            i6 = 0;
        }
        int cc = cc();
        int max2 = max + Math.max(cc, i6);
        iArr[c ^ 1] = Math.max(0, cc - i6);
        View view = this.g;
        if (view != null && view.getParent() == this && view.getVisibility() != 8) {
            max2 += x(this.g, i, max2, i2, 0, iArr);
            int measuredHeight4 = this.g.getMeasuredHeight();
            ViewGroup.MarginLayoutParams marginLayoutParams7 = (ViewGroup.MarginLayoutParams) this.g.getLayoutParams();
            i4 = Math.max(i4, measuredHeight4 + marginLayoutParams7.topMargin + marginLayoutParams7.bottomMargin);
            i5 = View.combineMeasuredStates(i5, this.g.getMeasuredState());
        }
        ImageView imageView = this.e;
        if (imageView != null && imageView.getParent() == this && imageView.getVisibility() != 8) {
            max2 += x(this.e, i, max2, i2, 0, iArr);
            int measuredHeight5 = this.e.getMeasuredHeight();
            ViewGroup.MarginLayoutParams marginLayoutParams8 = (ViewGroup.MarginLayoutParams) this.e.getLayoutParams();
            i4 = Math.max(i4, measuredHeight5 + marginLayoutParams8.topMargin + marginLayoutParams8.bottomMargin);
            i5 = View.combineMeasuredStates(i5, this.e.getMeasuredState());
        }
        int childCount = getChildCount();
        for (int i11 = 0; i11 < childCount; i11++) {
            View childAt = getChildAt(i11);
            if (((te) childAt.getLayoutParams()).b == 0 && childAt != null && childAt.getParent() == this && childAt.getVisibility() != 8) {
                max2 += x(childAt, i, max2, i2, 0, iArr);
                int measuredHeight6 = childAt.getMeasuredHeight();
                ViewGroup.MarginLayoutParams marginLayoutParams9 = (ViewGroup.MarginLayoutParams) childAt.getLayoutParams();
                i4 = Math.max(i4, measuredHeight6 + marginLayoutParams9.topMargin + marginLayoutParams9.bottomMargin);
                i5 = View.combineMeasuredStates(i5, childAt.getMeasuredState());
            }
        }
        int i12 = this.E + this.F;
        int i13 = this.C + this.D;
        TextView textView = this.b;
        if (textView != null && textView.getParent() == this && textView.getVisibility() != 8) {
            x(this.b, i, max2 + i13, i2, i12, iArr);
            int measuredWidth4 = this.b.getMeasuredWidth();
            ViewGroup.MarginLayoutParams marginLayoutParams10 = (ViewGroup.MarginLayoutParams) this.b.getLayoutParams();
            i10 = measuredWidth4 + marginLayoutParams10.getMarginStart() + marginLayoutParams10.getMarginEnd();
            int measuredHeight7 = this.b.getMeasuredHeight();
            ViewGroup.MarginLayoutParams marginLayoutParams11 = (ViewGroup.MarginLayoutParams) this.b.getLayoutParams();
            int i14 = measuredHeight7 + marginLayoutParams11.topMargin + marginLayoutParams11.bottomMargin;
            i7 = View.combineMeasuredStates(i5, this.b.getMeasuredState());
            i8 = i14;
        } else {
            i7 = i5;
            i8 = 0;
        }
        TextView textView2 = this.c;
        if (textView2 != null && textView2.getParent() == this && textView2.getVisibility() != 8) {
            i10 = Math.max(i10, x(this.c, i, max2 + i13, i2, i8 + i12, iArr));
            int measuredHeight8 = this.c.getMeasuredHeight();
            ViewGroup.MarginLayoutParams marginLayoutParams12 = (ViewGroup.MarginLayoutParams) this.c.getLayoutParams();
            i8 += measuredHeight8 + marginLayoutParams12.topMargin + marginLayoutParams12.bottomMargin;
            i9 = View.combineMeasuredStates(i7, this.c.getMeasuredState());
        } else {
            i9 = i7;
        }
        int max3 = Math.max(i4, i8);
        setMeasuredDimension(View.resolveSizeAndState(Math.max(max2 + i10 + getPaddingLeft() + getPaddingRight(), getSuggestedMinimumWidth()), i, (-16777216) & i9), View.resolveSizeAndState(Math.max(max3 + getPaddingTop() + getPaddingBottom(), getSuggestedMinimumHeight()), i2, i9 << 16));
    }

    @Override // android.view.View
    protected void onRestoreInstanceState(Parcelable parcelable) {
        ke keVar;
        MenuItem findItem;
        if (!(parcelable instanceof th)) {
            super.onRestoreInstanceState(parcelable);
            return;
        }
        th thVar = (th) parcelable;
        super.onRestoreInstanceState(thVar.d);
        ActionMenuView actionMenuView = this.a;
        if (actionMenuView != null) {
            keVar = actionMenuView.a;
        } else {
            keVar = null;
        }
        int i = thVar.a;
        if (i != 0 && this.v != null && keVar != null && (findItem = keVar.findItem(i)) != null) {
            findItem.expandActionView();
        }
        if (thVar.b) {
            removeCallbacks(this.R);
            post(this.R);
        }
    }

    @Override // android.view.View
    public final void onRtlPropertiesChanged(int i) {
        super.onRtlPropertiesChanged(i);
        if (this.m == null) {
            this.m = new sa();
        }
        sa saVar = this.m;
        boolean z = true;
        if (i != 1) {
            z = false;
        }
        if (z == saVar.g) {
            return;
        }
        saVar.g = z;
        if (saVar.h) {
            if (z) {
                int i2 = saVar.d;
                if (i2 == Integer.MIN_VALUE) {
                    i2 = saVar.e;
                }
                saVar.a = i2;
                int i3 = saVar.c;
                if (i3 == Integer.MIN_VALUE) {
                    i3 = saVar.f;
                }
                saVar.b = i3;
                return;
            }
            int i4 = saVar.c;
            if (i4 == Integer.MIN_VALUE) {
                i4 = saVar.e;
            }
            saVar.a = i4;
            int i5 = saVar.d;
            if (i5 == Integer.MIN_VALUE) {
                i5 = saVar.f;
            }
            saVar.b = i5;
            return;
        }
        saVar.a = saVar.e;
        saVar.b = saVar.f;
    }

    @Override // android.view.View
    protected Parcelable onSaveInstanceState() {
        lu luVar;
        lq lqVar;
        kn knVar;
        kh khVar;
        th thVar = new th(super.onSaveInstanceState());
        td tdVar = this.v;
        if (tdVar != null && (khVar = tdVar.b) != null) {
            thVar.a = khVar.a;
        }
        ActionMenuView actionMenuView = this.a;
        boolean z = false;
        if (actionMenuView != null && (luVar = actionMenuView.c) != null && (lqVar = luVar.o) != null && (knVar = lqVar.f) != null && knVar.x()) {
            z = true;
        }
        thVar.b = z;
        return thVar;
    }

    @Override // android.view.View
    public final boolean onTouchEvent(MotionEvent motionEvent) {
        int actionMasked = motionEvent.getActionMasked();
        if (actionMasked == 0) {
            this.L = false;
            actionMasked = 0;
        }
        if (!this.L) {
            boolean onTouchEvent = super.onTouchEvent(motionEvent);
            if (actionMasked == 0) {
                if (!onTouchEvent) {
                    this.L = true;
                }
                actionMasked = 0;
            }
        }
        if (actionMasked == 1 || actionMasked == 3) {
            this.L = false;
        }
        return true;
    }

    public void p(CharSequence charSequence) {
        if (!TextUtils.isEmpty(charSequence)) {
            if (this.b == null) {
                Context context = getContext();
                AppCompatTextView appCompatTextView = new AppCompatTextView(context);
                this.b = appCompatTextView;
                appCompatTextView.setSingleLine();
                this.b.setEllipsize(TextUtils.TruncateAt.END);
                int i = this.j;
                if (i != 0) {
                    this.b.setTextAppearance(context, i);
                }
                ColorStateList colorStateList = this.J;
                if (colorStateList != null) {
                    this.b.setTextColor(colorStateList);
                }
            }
            TextView textView = this.b;
            if (textView.getParent() != this && !this.p.contains(textView)) {
                z(this.b, true);
            }
        } else {
            TextView textView2 = this.b;
            if (textView2 != null && (textView2.getParent() == this || this.p.contains(textView2))) {
                removeView(this.b);
                this.p.remove(this.b);
            }
        }
        TextView textView3 = this.b;
        if (textView3 != null) {
            textView3.setText(charSequence);
        }
        this.n = charSequence;
    }

    @Override // cal.akz
    public final void q(di diVar) {
        alb albVar = this.q;
        albVar.b.add(diVar);
        albVar.a.run();
    }

    @Override // cal.akz
    public final void r(di diVar) {
        alb albVar = this.q;
        albVar.b.remove(diVar);
        if (((ala) albVar.c.remove(diVar)) == null) {
            albVar.a.run();
            return;
        }
        throw null;
    }

    public final void s() {
        OnBackInvokedDispatcher findOnBackInvokedDispatcher;
        if (Build.VERSION.SDK_INT >= 33) {
            findOnBackInvokedDispatcher = findOnBackInvokedDispatcher();
            td tdVar = this.v;
            if (tdVar != null && tdVar.b != null && findOnBackInvokedDispatcher != null && isAttachedToWindow() && this.y) {
                if (this.Q == null) {
                    if (this.P == null) {
                        final sw swVar = new sw(this);
                        this.P = new OnBackInvokedCallback() { // from class: cal.tc
                            public final void onBackInvoked() {
                                kh khVar;
                                td tdVar2 = ((sw) swVar).a.v;
                                if (tdVar2 == null) {
                                    khVar = null;
                                } else {
                                    khVar = tdVar2.b;
                                }
                                if (khVar != null) {
                                    khVar.collapseActionView();
                                }
                            }
                        };
                    }
                    findOnBackInvokedDispatcher.registerOnBackInvokedCallback(1000000, this.P);
                    this.Q = findOnBackInvokedDispatcher;
                    return;
                }
                return;
            }
            OnBackInvokedDispatcher onBackInvokedDispatcher = this.Q;
            if (onBackInvokedDispatcher != null) {
                onBackInvokedDispatcher.unregisterOnBackInvokedCallback(this.P);
                this.Q = null;
            }
        }
    }

    public void setCollapseContentDescription(int i) {
        CharSequence charSequence;
        if (i != 0) {
            charSequence = getContext().getText(i);
        } else {
            charSequence = null;
        }
        if (!TextUtils.isEmpty(charSequence)) {
            f();
        }
        ImageButton imageButton = this.f;
        if (imageButton != null) {
            imageButton.setContentDescription(charSequence);
        }
    }

    public void setCollapseIcon(int i) {
        Drawable c = ry.e().c(getContext(), i);
        if (c != null) {
            f();
            this.f.setImageDrawable(c);
        } else {
            ImageButton imageButton = this.f;
            if (imageButton != null) {
                imageButton.setImageDrawable(this.z);
            }
        }
    }

    public void setContentInsetEndWithActions(int i) {
        Drawable drawable;
        if (i < 0) {
            i = Integer.MIN_VALUE;
        }
        if (i != this.H) {
            this.H = i;
            ImageButton imageButton = this.d;
            if (imageButton != null) {
                drawable = imageButton.getDrawable();
            } else {
                drawable = null;
            }
            if (drawable != null) {
                requestLayout();
            }
        }
    }

    public void setContentInsetStartWithNavigation(int i) {
        Drawable drawable;
        if (i < 0) {
            i = Integer.MIN_VALUE;
        }
        if (i != this.G) {
            this.G = i;
            ImageButton imageButton = this.d;
            if (imageButton != null) {
                drawable = imageButton.getDrawable();
            } else {
                drawable = null;
            }
            if (drawable != null) {
                requestLayout();
            }
        }
    }

    public void setLogo(int i) {
        k(ry.e().c(getContext(), i));
    }

    public void setLogoDescription(int i) {
        l(getContext().getText(i));
    }

    public void setNavigationContentDescription(int i) {
        CharSequence charSequence;
        if (i != 0) {
            charSequence = getContext().getText(i);
        } else {
            charSequence = null;
        }
        m(charSequence);
    }

    public void setNavigationIcon(int i) {
        n(ry.e().c(getContext(), i));
    }

    public void setPopupTheme(int i) {
        if (this.i != i) {
            this.i = i;
            if (i == 0) {
                this.h = getContext();
            } else {
                this.h = new ContextThemeWrapper(getContext(), i);
            }
        }
    }

    public void setSubtitle(int i) {
        o(getContext().getText(i));
    }

    public void setSubtitleTextColor(int i) {
        ColorStateList valueOf = ColorStateList.valueOf(i);
        this.K = valueOf;
        TextView textView = this.c;
        if (textView != null) {
            textView.setTextColor(valueOf);
        }
    }

    public void setTitle(int i) {
        p(getContext().getText(i));
    }

    public void setTitleMarginBottom(int i) {
        this.F = i;
        requestLayout();
    }

    public void setTitleMarginEnd(int i) {
        this.D = i;
        requestLayout();
    }

    public void setTitleMarginStart(int i) {
        this.C = i;
        requestLayout();
    }

    public void setTitleMarginTop(int i) {
        this.E = i;
        requestLayout();
    }

    public void setTitleTextColor(int i) {
        ColorStateList valueOf = ColorStateList.valueOf(i);
        this.J = valueOf;
        TextView textView = this.b;
        if (textView != null) {
            textView.setTextColor(valueOf);
        }
    }

    public Toolbar(Context context, AttributeSet attributeSet) {
        this(context, attributeSet, R.attr.toolbarStyle);
    }

    @Override // android.view.ViewGroup
    protected final /* bridge */ /* synthetic */ ViewGroup.LayoutParams generateLayoutParams(ViewGroup.LayoutParams layoutParams) {
        return t(layoutParams);
    }

    public Toolbar(Context context, AttributeSet attributeSet, int i) {
        super(context, attributeSet, i);
        this.I = 8388627;
        this.N = new ArrayList();
        this.p = new ArrayList();
        this.O = new int[2];
        this.q = new alb(new Runnable() { // from class: cal.sx
            @Override // java.lang.Runnable
            public final void run() {
                Toolbar toolbar = Toolbar.this;
                ArrayList arrayList = toolbar.r;
                int size = arrayList.size();
                for (int i2 = 0; i2 < size; i2++) {
                    MenuItem menuItem = (MenuItem) arrayList.get(i2);
                    toolbar.g();
                    ke keVar = (ke) toolbar.a.f();
                    keVar.l(keVar.b(menuItem.getItemId()), true);
                }
                toolbar.g();
                Menu f = toolbar.a.f();
                ArrayList e = toolbar.e();
                toolbar.q.a(f, new jk(toolbar.getContext()));
                ArrayList e2 = toolbar.e();
                e2.removeAll(e);
                toolbar.r = e2;
            }
        });
        this.r = new ArrayList();
        this.S = new sy(this);
        this.R = new sz(this);
        Context context2 = getContext();
        sv svVar = new sv(context2, context2.obtainStyledAttributes(attributeSet, ia.x, i, 0));
        int[] iArr = ia.x;
        TypedArray typedArray = svVar.b;
        if (Build.VERSION.SDK_INT >= 29) {
            alz.b(this, context, iArr, attributeSet, typedArray, i, 0);
        }
        this.j = svVar.b.getResourceId(28, 0);
        this.k = svVar.b.getResourceId(19, 0);
        this.I = svVar.b.getInteger(0, this.I);
        this.l = svVar.b.getInteger(2, 48);
        int dimensionPixelOffset = svVar.b.getDimensionPixelOffset(22, 0);
        dimensionPixelOffset = svVar.b.hasValue(27) ? svVar.b.getDimensionPixelOffset(27, dimensionPixelOffset) : dimensionPixelOffset;
        this.F = dimensionPixelOffset;
        this.E = dimensionPixelOffset;
        this.D = dimensionPixelOffset;
        this.C = dimensionPixelOffset;
        int dimensionPixelOffset2 = svVar.b.getDimensionPixelOffset(25, -1);
        if (dimensionPixelOffset2 >= 0) {
            this.C = dimensionPixelOffset2;
        }
        int dimensionPixelOffset3 = svVar.b.getDimensionPixelOffset(24, -1);
        if (dimensionPixelOffset3 >= 0) {
            this.D = dimensionPixelOffset3;
        }
        int dimensionPixelOffset4 = svVar.b.getDimensionPixelOffset(26, -1);
        if (dimensionPixelOffset4 >= 0) {
            this.E = dimensionPixelOffset4;
        }
        int dimensionPixelOffset5 = svVar.b.getDimensionPixelOffset(23, -1);
        if (dimensionPixelOffset5 >= 0) {
            this.F = dimensionPixelOffset5;
        }
        this.B = svVar.b.getDimensionPixelSize(13, -1);
        int dimensionPixelOffset6 = svVar.b.getDimensionPixelOffset(9, Integer.MIN_VALUE);
        int dimensionPixelOffset7 = svVar.b.getDimensionPixelOffset(5, Integer.MIN_VALUE);
        int dimensionPixelSize = svVar.b.getDimensionPixelSize(7, 0);
        int dimensionPixelSize2 = svVar.b.getDimensionPixelSize(8, 0);
        if (this.m == null) {
            this.m = new sa();
        }
        sa saVar = this.m;
        saVar.h = false;
        if (dimensionPixelSize != Integer.MIN_VALUE) {
            saVar.e = dimensionPixelSize;
            saVar.a = dimensionPixelSize;
        }
        if (dimensionPixelSize2 != Integer.MIN_VALUE) {
            saVar.f = dimensionPixelSize2;
            saVar.b = dimensionPixelSize2;
        }
        if (dimensionPixelOffset6 != Integer.MIN_VALUE || dimensionPixelOffset7 != Integer.MIN_VALUE) {
            saVar.a(dimensionPixelOffset6, dimensionPixelOffset7);
        }
        this.G = svVar.b.getDimensionPixelOffset(10, Integer.MIN_VALUE);
        this.H = svVar.b.getDimensionPixelOffset(6, Integer.MIN_VALUE);
        this.z = svVar.b(4);
        this.A = svVar.b.getText(3);
        CharSequence text = svVar.b.getText(21);
        if (!TextUtils.isEmpty(text)) {
            p(text);
        }
        CharSequence text2 = svVar.b.getText(18);
        if (!TextUtils.isEmpty(text2)) {
            o(text2);
        }
        this.h = getContext();
        setPopupTheme(svVar.b.getResourceId(17, 0));
        Drawable b = svVar.b(16);
        if (b != null) {
            n(b);
        }
        CharSequence text3 = svVar.b.getText(15);
        if (!TextUtils.isEmpty(text3)) {
            m(text3);
        }
        Drawable b2 = svVar.b(11);
        if (b2 != null) {
            k(b2);
        }
        CharSequence text4 = svVar.b.getText(12);
        if (!TextUtils.isEmpty(text4)) {
            l(text4);
        }
        if (svVar.b.hasValue(29)) {
            ColorStateList a = svVar.a(29);
            this.J = a;
            TextView textView = this.b;
            if (textView != null) {
                textView.setTextColor(a);
            }
        }
        if (svVar.b.hasValue(20)) {
            ColorStateList a2 = svVar.a(20);
            this.K = a2;
            TextView textView2 = this.c;
            if (textView2 != null) {
                textView2.setTextColor(a2);
            }
        }
        if (svVar.b.hasValue(14)) {
            j(svVar.b.getResourceId(14, 0));
        }
        svVar.b.recycle();
    }
}
