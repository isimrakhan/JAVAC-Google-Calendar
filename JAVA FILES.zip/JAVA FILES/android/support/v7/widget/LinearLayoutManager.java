package android.support.v7.widget;

import android.content.Context;
import android.graphics.PointF;
import android.os.Bundle;
import android.os.Parcelable;
import android.util.AttributeSet;
import android.view.View;
import android.view.ViewGroup;
import android.view.accessibility.AccessibilityEvent;
import android.view.accessibility.AccessibilityNodeInfo;
import cal.a;
import cal.aoa;
import cal.aob;
import cal.nw;
import cal.pa;
import cal.pj;
import cal.pk;
import cal.pl;
import cal.pn;
import cal.po;
import cal.qa;
import cal.qb;
import cal.qc;
import cal.qq;
import cal.rb;
import cal.rc;
import cal.rd;
import cal.rj;
import cal.rp;
import cal.rr;
import cal.rt;
import cal.sb;
import java.util.List;

/* compiled from: PG */
/* loaded from: classes.dex */
public class LinearLayoutManager extends rc implements rp {
    private boolean a;
    private boolean b;
    private final boolean c;
    private final pk d;
    private final int e;
    private final int[] f;
    public int k;
    public pl l;
    qc m;
    boolean n;
    public boolean o;
    public int p;
    public int q;
    public pn r;
    final pj s;

    public LinearLayoutManager(int i) {
        RecyclerView recyclerView;
        this.k = 1;
        this.b = false;
        this.n = false;
        this.o = false;
        this.c = true;
        this.p = -1;
        this.q = Integer.MIN_VALUE;
        this.r = null;
        this.s = new pj();
        this.d = new pk();
        this.e = 2;
        this.f = new int[2];
        V(i);
        if (this.r == null && (recyclerView = this.u) != null) {
            recyclerView.o(null);
        }
        if (this.b) {
            this.b = false;
            RecyclerView recyclerView2 = this.u;
            if (recyclerView2 != null) {
                recyclerView2.requestLayout();
            }
        }
    }

    private final int aH(int i, rj rjVar, rr rrVar, boolean z) {
        int f;
        int f2 = this.m.f() - i;
        if (f2 > 0) {
            int i2 = -L(-f2, rjVar, rrVar);
            int i3 = i + i2;
            if (z && (f = this.m.f() - i3) > 0) {
                this.m.n(f);
                return f + i2;
            }
            return i2;
        }
        return 0;
    }

    private final int aI(int i, rj rjVar, rr rrVar, boolean z) {
        int j;
        int j2 = i - this.m.j();
        if (j2 > 0) {
            int i2 = -L(j2, rjVar, rrVar);
            int i3 = i + i2;
            if (z && (j = i3 - this.m.j()) > 0) {
                this.m.n(-j);
                return i2 - j;
            }
            return i2;
        }
        return 0;
    }

    private final void aJ(rj rjVar, pl plVar) {
        int i;
        View view;
        View view2;
        int i2;
        View view3;
        View view4;
        if (plVar.a && !plVar.m) {
            int i3 = plVar.g;
            int i4 = plVar.i;
            if (plVar.f == -1) {
                nw nwVar = this.t;
                if (nwVar != null) {
                    i2 = nwVar.e.a.getChildCount() - nwVar.b.size();
                } else {
                    i2 = 0;
                }
                if (i3 >= 0) {
                    int e = (this.m.e() - i3) + i4;
                    if (this.n) {
                        for (int i5 = 0; i5 < i2; i5++) {
                            nw nwVar2 = this.t;
                            if (nwVar2 != null) {
                                view4 = nwVar2.e.a.getChildAt(nwVar2.a(i5));
                            } else {
                                view4 = null;
                            }
                            if (this.m.d(view4) < e || this.m.m(view4) < e) {
                                aK(rjVar, 0, i5);
                                return;
                            }
                        }
                        return;
                    }
                    int i6 = i2 - 1;
                    for (int i7 = i6; i7 >= 0; i7--) {
                        nw nwVar3 = this.t;
                        if (nwVar3 != null) {
                            view3 = nwVar3.e.a.getChildAt(nwVar3.a(i7));
                        } else {
                            view3 = null;
                        }
                        if (this.m.d(view3) < e || this.m.m(view3) < e) {
                            aK(rjVar, i6, i7);
                            return;
                        }
                    }
                    return;
                }
                return;
            }
            if (i3 >= 0) {
                int i8 = i3 - i4;
                nw nwVar4 = this.t;
                if (nwVar4 != null) {
                    i = nwVar4.e.a.getChildCount() - nwVar4.b.size();
                } else {
                    i = 0;
                }
                if (this.n) {
                    int i9 = i - 1;
                    for (int i10 = i9; i10 >= 0; i10--) {
                        nw nwVar5 = this.t;
                        if (nwVar5 != null) {
                            view2 = nwVar5.e.a.getChildAt(nwVar5.a(i10));
                        } else {
                            view2 = null;
                        }
                        if (this.m.a(view2) > i8 || this.m.l(view2) > i8) {
                            aK(rjVar, i9, i10);
                            return;
                        }
                    }
                    return;
                }
                for (int i11 = 0; i11 < i; i11++) {
                    nw nwVar6 = this.t;
                    if (nwVar6 != null) {
                        view = nwVar6.e.a.getChildAt(nwVar6.a(i11));
                    } else {
                        view = null;
                    }
                    if (this.m.a(view) > i8 || this.m.l(view) > i8) {
                        aK(rjVar, 0, i11);
                        return;
                    }
                }
            }
        }
    }

    private final void aK(rj rjVar, int i, int i2) {
        View view;
        View view2;
        View view3;
        View view4;
        if (i != i2) {
            if (i2 <= i) {
                while (i > i2) {
                    nw nwVar = this.t;
                    if (nwVar != null) {
                        view = nwVar.e.a.getChildAt(nwVar.a(i));
                    } else {
                        view = null;
                    }
                    nw nwVar2 = this.t;
                    if (nwVar2 != null) {
                        view2 = nwVar2.e.a.getChildAt(nwVar2.a(i));
                    } else {
                        view2 = null;
                    }
                    if (view2 != null) {
                        this.t.f(i);
                    }
                    rjVar.e(view);
                    i--;
                }
                return;
            }
            while (true) {
                i2--;
                if (i2 >= i) {
                    nw nwVar3 = this.t;
                    if (nwVar3 != null) {
                        view3 = nwVar3.e.a.getChildAt(nwVar3.a(i2));
                    } else {
                        view3 = null;
                    }
                    nw nwVar4 = this.t;
                    if (nwVar4 != null) {
                        view4 = nwVar4.e.a.getChildAt(nwVar4.a(i2));
                    } else {
                        view4 = null;
                    }
                    if (view4 != null) {
                        this.t.f(i2);
                    }
                    rjVar.e(view3);
                } else {
                    return;
                }
            }
        }
    }

    private final void aL() {
        boolean z;
        if (this.k != 1 && this.u.getLayoutDirection() == 1) {
            z = !this.b;
        } else {
            z = this.b;
        }
        this.n = z;
    }

    private final void aM(int i, int i2, boolean z, rr rrVar) {
        boolean z2;
        int i3;
        int j;
        pl plVar = this.l;
        int i4 = 1;
        int i5 = 0;
        if (this.m.h() == 0 && this.m.e() == 0) {
            z2 = true;
        } else {
            z2 = false;
        }
        plVar.m = z2;
        this.l.f = i;
        int[] iArr = this.f;
        iArr[0] = 0;
        iArr[1] = 0;
        R(rrVar, iArr);
        int max = Math.max(0, this.f[0]);
        int max2 = Math.max(0, this.f[1]);
        pl plVar2 = this.l;
        if (i == 1) {
            i3 = max2;
        } else {
            i3 = max;
        }
        plVar2.h = i3;
        if (i != 1) {
            max = max2;
        }
        plVar2.i = max;
        View view = null;
        if (i == 1) {
            plVar2.h = i3 + this.m.g();
            if (!this.n) {
                nw nwVar = this.t;
                if (nwVar != null) {
                    i5 = nwVar.e.a.getChildCount() - nwVar.b.size();
                }
                i5--;
            }
            nw nwVar2 = this.t;
            if (nwVar2 != null) {
                view = nwVar2.e.a.getChildAt(nwVar2.a(i5));
            }
            pl plVar3 = this.l;
            if (true == this.n) {
                i4 = -1;
            }
            plVar3.e = i4;
            rt rtVar = ((rd) view.getLayoutParams()).c;
            int i6 = rtVar.g;
            if (i6 == -1) {
                i6 = rtVar.c;
            }
            pl plVar4 = this.l;
            plVar3.d = i6 + plVar4.e;
            plVar4.b = this.m.a(view);
            j = this.m.a(view) - this.m.f();
        } else {
            if (this.n) {
                nw nwVar3 = this.t;
                if (nwVar3 != null) {
                    i5 = nwVar3.e.a.getChildCount() - nwVar3.b.size();
                }
                i5--;
            }
            nw nwVar4 = this.t;
            if (nwVar4 != null) {
                view = nwVar4.e.a.getChildAt(nwVar4.a(i5));
            }
            this.l.h += this.m.j();
            pl plVar5 = this.l;
            if (true != this.n) {
                i4 = -1;
            }
            plVar5.e = i4;
            rt rtVar2 = ((rd) view.getLayoutParams()).c;
            int i7 = rtVar2.g;
            if (i7 == -1) {
                i7 = rtVar2.c;
            }
            pl plVar6 = this.l;
            plVar5.d = i7 + plVar6.e;
            plVar6.b = this.m.d(view);
            j = (-this.m.d(view)) + this.m.j();
        }
        pl plVar7 = this.l;
        plVar7.c = i2;
        if (z) {
            plVar7.c = i2 - j;
        }
        plVar7.g = j;
    }

    private final void aN(int i, int i2) {
        int i3;
        this.l.c = this.m.f() - i2;
        pl plVar = this.l;
        if (true != this.n) {
            i3 = 1;
        } else {
            i3 = -1;
        }
        plVar.e = i3;
        plVar.d = i;
        plVar.f = 1;
        plVar.b = i2;
        plVar.g = Integer.MIN_VALUE;
    }

    private final void aO(int i, int i2) {
        this.l.c = i2 - this.m.j();
        pl plVar = this.l;
        plVar.d = i;
        int i3 = 1;
        if (true != this.n) {
            i3 = -1;
        }
        plVar.e = i3;
        plVar.f = -1;
        plVar.b = i2;
        plVar.g = Integer.MIN_VALUE;
    }

    private final int c(rr rrVar) {
        int i;
        View ad;
        View ad2;
        int i2;
        int i3;
        nw nwVar = this.t;
        int i4 = 0;
        if (nwVar != null) {
            if (nwVar.e.a.getChildCount() - nwVar.b.size() != 0) {
                if (this.l == null) {
                    this.l = new pl();
                }
                qc qcVar = this.m;
                boolean z = !this.c;
                if (this.n) {
                    nw nwVar2 = this.t;
                    if (nwVar2 != null) {
                        i3 = nwVar2.e.a.getChildCount() - nwVar2.b.size();
                    } else {
                        i3 = 0;
                    }
                    ad = ad(i3 - 1, -1, z);
                } else {
                    nw nwVar3 = this.t;
                    if (nwVar3 != null) {
                        i = nwVar3.e.a.getChildCount() - nwVar3.b.size();
                    } else {
                        i = 0;
                    }
                    ad = ad(0, i, z);
                }
                boolean z2 = !this.c;
                if (this.n) {
                    nw nwVar4 = this.t;
                    if (nwVar4 != null) {
                        i2 = nwVar4.e.a.getChildCount() - nwVar4.b.size();
                    } else {
                        i2 = 0;
                    }
                    ad2 = ad(0, i2, z2);
                } else {
                    nw nwVar5 = this.t;
                    if (nwVar5 != null) {
                        i4 = nwVar5.e.a.getChildCount() - nwVar5.b.size();
                    }
                    ad2 = ad(i4 - 1, -1, z2);
                }
                return sb.a(rrVar, qcVar, ad, ad2, this, this.c);
            }
        }
        return 0;
    }

    private final int q(rr rrVar) {
        int i;
        View ad;
        View ad2;
        int i2;
        int i3;
        nw nwVar = this.t;
        int i4 = 0;
        if (nwVar != null) {
            if (nwVar.e.a.getChildCount() - nwVar.b.size() != 0) {
                if (this.l == null) {
                    this.l = new pl();
                }
                qc qcVar = this.m;
                boolean z = !this.c;
                if (this.n) {
                    nw nwVar2 = this.t;
                    if (nwVar2 != null) {
                        i3 = nwVar2.e.a.getChildCount() - nwVar2.b.size();
                    } else {
                        i3 = 0;
                    }
                    ad = ad(i3 - 1, -1, z);
                } else {
                    nw nwVar3 = this.t;
                    if (nwVar3 != null) {
                        i = nwVar3.e.a.getChildCount() - nwVar3.b.size();
                    } else {
                        i = 0;
                    }
                    ad = ad(0, i, z);
                }
                boolean z2 = !this.c;
                if (this.n) {
                    nw nwVar4 = this.t;
                    if (nwVar4 != null) {
                        i2 = nwVar4.e.a.getChildCount() - nwVar4.b.size();
                    } else {
                        i2 = 0;
                    }
                    ad2 = ad(0, i2, z2);
                } else {
                    nw nwVar5 = this.t;
                    if (nwVar5 != null) {
                        i4 = nwVar5.e.a.getChildCount() - nwVar5.b.size();
                    }
                    ad2 = ad(i4 - 1, -1, z2);
                }
                return sb.b(rrVar, qcVar, ad, ad2, this, this.c, this.n);
            }
        }
        return 0;
    }

    private final int v(rr rrVar) {
        int i;
        View ad;
        View ad2;
        int i2;
        int i3;
        nw nwVar = this.t;
        int i4 = 0;
        if (nwVar != null) {
            if (nwVar.e.a.getChildCount() - nwVar.b.size() != 0) {
                if (this.l == null) {
                    this.l = new pl();
                }
                qc qcVar = this.m;
                boolean z = !this.c;
                if (this.n) {
                    nw nwVar2 = this.t;
                    if (nwVar2 != null) {
                        i3 = nwVar2.e.a.getChildCount() - nwVar2.b.size();
                    } else {
                        i3 = 0;
                    }
                    ad = ad(i3 - 1, -1, z);
                } else {
                    nw nwVar3 = this.t;
                    if (nwVar3 != null) {
                        i = nwVar3.e.a.getChildCount() - nwVar3.b.size();
                    } else {
                        i = 0;
                    }
                    ad = ad(0, i, z);
                }
                boolean z2 = !this.c;
                if (this.n) {
                    nw nwVar4 = this.t;
                    if (nwVar4 != null) {
                        i2 = nwVar4.e.a.getChildCount() - nwVar4.b.size();
                    } else {
                        i2 = 0;
                    }
                    ad2 = ad(0, i2, z2);
                } else {
                    nw nwVar5 = this.t;
                    if (nwVar5 != null) {
                        i4 = nwVar5.e.a.getChildCount() - nwVar5.b.size();
                    }
                    ad2 = ad(i4 - 1, -1, z2);
                }
                return sb.c(rrVar, qcVar, ad, ad2, this, this.c);
            }
        }
        return 0;
    }

    @Override // cal.rc
    public void B() {
        this.r = null;
        this.p = -1;
        this.q = Integer.MIN_VALUE;
        pj pjVar = this.s;
        pjVar.b = -1;
        pjVar.c = Integer.MIN_VALUE;
        pjVar.d = false;
        pjVar.e = false;
    }

    @Override // cal.rc
    public final int D(rr rrVar) {
        return c(rrVar);
    }

    @Override // cal.rc
    public final int E(rr rrVar) {
        return q(rrVar);
    }

    @Override // cal.rc
    public final int F(rr rrVar) {
        return v(rrVar);
    }

    @Override // cal.rc
    public final int G(rr rrVar) {
        return c(rrVar);
    }

    @Override // cal.rc
    public final int H(rr rrVar) {
        return q(rrVar);
    }

    @Override // cal.rc
    public final int I(rr rrVar) {
        return v(rrVar);
    }

    /* JADX INFO: Access modifiers changed from: package-private */
    /* JADX WARN: Removed duplicated region for block: B:22:0x0027 A[RETURN] */
    /* JADX WARN: Removed duplicated region for block: B:23:0x0028 A[RETURN] */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct code enable 'Show inconsistent code' option in preferences
    */
    public final int J(int r6) {
        /*
            r5 = this;
            r0 = -1
            r1 = 1
            if (r6 == r1) goto L37
            r2 = 2
            if (r6 == r2) goto L29
            r2 = 17
            r3 = 0
            r4 = -2147483648(0xffffffff80000000, float:-0.0)
            if (r6 == r2) goto L22
            r2 = 33
            if (r6 == r2) goto L23
            r0 = 66
            if (r6 == r0) goto L21
            r0 = 130(0x82, float:1.82E-43)
            if (r6 == r0) goto L1b
            return r4
        L1b:
            int r6 = r5.k
            if (r6 != r1) goto L20
            return r1
        L20:
            return r4
        L21:
            r0 = r1
        L22:
            r1 = r3
        L23:
            int r6 = r5.k
            if (r6 != r1) goto L28
            return r0
        L28:
            return r4
        L29:
            int r6 = r5.k
            if (r6 == r1) goto L36
            android.support.v7.widget.RecyclerView r6 = r5.u
            int r6 = r6.getLayoutDirection()
            if (r6 != r1) goto L36
            return r0
        L36:
            return r1
        L37:
            int r6 = r5.k
            if (r6 == r1) goto L44
            android.support.v7.widget.RecyclerView r6 = r5.u
            int r6 = r6.getLayoutDirection()
            if (r6 != r1) goto L44
            return r1
        L44:
            return r0
        */
        throw new UnsupportedOperationException("Method not decompiled: android.support.v7.widget.LinearLayoutManager.J(int):int");
    }

    final int K(rj rjVar, pl plVar, rr rrVar, boolean z) {
        int i;
        int i2;
        int i3 = plVar.c;
        int i4 = plVar.g;
        if (i4 != Integer.MIN_VALUE) {
            if (i3 < 0) {
                plVar.g = i4 + i3;
            }
            aJ(rjVar, plVar);
        }
        int i5 = plVar.c + plVar.h;
        pk pkVar = this.d;
        while (true) {
            if ((!plVar.m && i5 <= 0) || (i = plVar.d) < 0) {
                break;
            }
            if (rrVar.g) {
                i2 = rrVar.b - rrVar.c;
            } else {
                i2 = rrVar.e;
            }
            if (i >= i2) {
                break;
            }
            pkVar.a = 0;
            pkVar.b = false;
            pkVar.c = false;
            pkVar.d = false;
            k(rjVar, rrVar, plVar, pkVar);
            if (!pkVar.b) {
                int i6 = plVar.b;
                int i7 = pkVar.a;
                plVar.b = i6 + (plVar.f * i7);
                if (!pkVar.c || plVar.l != null || !rrVar.g) {
                    plVar.c -= i7;
                    i5 -= i7;
                }
                int i8 = plVar.g;
                if (i8 != Integer.MIN_VALUE) {
                    int i9 = i8 + i7;
                    plVar.g = i9;
                    int i10 = plVar.c;
                    if (i10 < 0) {
                        plVar.g = i9 + i10;
                    }
                    aJ(rjVar, plVar);
                }
                if (z && pkVar.d) {
                    break;
                }
            } else {
                break;
            }
        }
        return i3 - plVar.c;
    }

    /* JADX INFO: Access modifiers changed from: package-private */
    public final int L(int i, rj rjVar, rr rrVar) {
        int i2;
        nw nwVar = this.t;
        if (nwVar != null) {
            if (nwVar.e.a.getChildCount() - nwVar.b.size() != 0 && i != 0) {
                if (this.l == null) {
                    this.l = new pl();
                }
                this.l.a = true;
                if (i > 0) {
                    i2 = 1;
                } else {
                    i2 = -1;
                }
                int abs = Math.abs(i);
                aM(i2, abs, true, rrVar);
                pl plVar = this.l;
                int K = plVar.g + K(rjVar, plVar, rrVar, false);
                if (K >= 0) {
                    if (abs > K) {
                        i = i2 * K;
                    }
                    this.m.n(-i);
                    this.l.k = i;
                    return i;
                }
            }
        }
        return 0;
    }

    @Override // cal.rp
    public final PointF M(int i) {
        nw nwVar = this.t;
        View view = null;
        if (nwVar != null) {
            if (nwVar.e.a.getChildCount() - nwVar.b.size() != 0) {
                nw nwVar2 = this.t;
                boolean z = false;
                if (nwVar2 != null) {
                    view = nwVar2.e.a.getChildAt(nwVar2.a(0));
                }
                rt rtVar = ((rd) view.getLayoutParams()).c;
                int i2 = rtVar.g;
                int i3 = -1;
                if (i2 == -1) {
                    i2 = rtVar.c;
                }
                if (i < i2) {
                    z = true;
                }
                if (z == this.n) {
                    i3 = 1;
                }
                float f = i3;
                if (this.k == 0) {
                    return new PointF(f, 0.0f);
                }
                return new PointF(0.0f, f);
            }
        }
        return null;
    }

    @Override // cal.rc
    public final Parcelable N() {
        pn pnVar = this.r;
        if (pnVar != null) {
            return new pn(pnVar);
        }
        pn pnVar2 = new pn();
        nw nwVar = this.t;
        if (nwVar != null) {
            if (nwVar.e.a.getChildCount() - nwVar.b.size() > 0) {
                if (this.l == null) {
                    this.l = new pl();
                }
                boolean z = this.a;
                boolean z2 = this.n;
                boolean z3 = z ^ z2;
                pnVar2.c = z3;
                View view = null;
                int i = 0;
                if (z3) {
                    if (!z2) {
                        nw nwVar2 = this.t;
                        if (nwVar2 != null) {
                            i = nwVar2.e.a.getChildCount() - nwVar2.b.size();
                        }
                        i--;
                    }
                    nw nwVar3 = this.t;
                    if (nwVar3 != null) {
                        view = nwVar3.e.a.getChildAt(nwVar3.a(i));
                    }
                    pnVar2.b = this.m.f() - this.m.a(view);
                    rt rtVar = ((rd) view.getLayoutParams()).c;
                    int i2 = rtVar.g;
                    if (i2 == -1) {
                        i2 = rtVar.c;
                    }
                    pnVar2.a = i2;
                } else {
                    if (z2) {
                        nw nwVar4 = this.t;
                        if (nwVar4 != null) {
                            i = nwVar4.e.a.getChildCount() - nwVar4.b.size();
                        }
                        i--;
                    }
                    nw nwVar5 = this.t;
                    if (nwVar5 != null) {
                        view = nwVar5.e.a.getChildAt(nwVar5.a(i));
                    }
                    rt rtVar2 = ((rd) view.getLayoutParams()).c;
                    int i3 = rtVar2.g;
                    if (i3 == -1) {
                        i3 = rtVar2.c;
                    }
                    pnVar2.a = i3;
                    pnVar2.b = this.m.d(view) - this.m.j();
                }
                return pnVar2;
            }
        }
        pnVar2.a = -1;
        return pnVar2;
    }

    final View O(int i, int i2) {
        int i3;
        int i4;
        if (this.l == null) {
            this.l = new pl();
        }
        View view = null;
        if (i2 <= i && i2 >= i) {
            nw nwVar = this.t;
            if (nwVar == null) {
                return null;
            }
            return nwVar.e.a.getChildAt(nwVar.a(i));
        }
        qc qcVar = this.m;
        nw nwVar2 = this.t;
        if (nwVar2 != null) {
            view = nwVar2.e.a.getChildAt(nwVar2.a(i));
        }
        int d = qcVar.d(view);
        int j = this.m.j();
        if (d < j) {
            i3 = 16388;
        } else {
            i3 = 4097;
        }
        if (d < j) {
            i4 = 16644;
        } else {
            i4 = 4161;
        }
        if (this.k == 0) {
            return this.v.a(i, i2, i4, i3);
        }
        return this.w.a(i, i2, i4, i3);
    }

    @Override // cal.rc
    public final View P(int i) {
        int i2;
        View view;
        nw nwVar = this.t;
        if (nwVar != null) {
            i2 = nwVar.e.a.getChildCount() - nwVar.b.size();
        } else {
            i2 = 0;
        }
        View view2 = null;
        if (i2 == 0) {
            return null;
        }
        nw nwVar2 = this.t;
        if (nwVar2 != null) {
            view = nwVar2.e.a.getChildAt(nwVar2.a(0));
        } else {
            view = null;
        }
        rt rtVar = ((rd) view.getLayoutParams()).c;
        int i3 = rtVar.g;
        if (i3 == -1) {
            i3 = rtVar.c;
        }
        int i4 = i - i3;
        if (i4 >= 0 && i4 < i2) {
            nw nwVar3 = this.t;
            if (nwVar3 != null) {
                view2 = nwVar3.e.a.getChildAt(nwVar3.a(i4));
            }
            rt rtVar2 = ((rd) view2.getLayoutParams()).c;
            int i5 = rtVar2.g;
            if (i5 == -1) {
                i5 = rtVar2.c;
            }
            if (i5 == i) {
                return view2;
            }
        }
        return super.P(i);
    }

    @Override // cal.rc
    public final void Q(String str) {
        RecyclerView recyclerView;
        if (this.r == null && (recyclerView = this.u) != null) {
            recyclerView.o(str);
        }
    }

    protected void R(rr rrVar, int[] iArr) {
        int i;
        int i2;
        if (rrVar.a != -1) {
            i = this.m.k();
        } else {
            i = 0;
        }
        int i3 = this.l.f;
        if (i3 == -1) {
            i2 = 0;
        } else {
            i2 = i;
        }
        if (i3 != -1) {
            i = 0;
        }
        iArr[0] = i;
        iArr[1] = i2;
    }

    @Override // cal.rc
    public final void S(AccessibilityEvent accessibilityEvent) {
        int i;
        int i2;
        int i3;
        RecyclerView recyclerView = this.u;
        rj rjVar = recyclerView.d;
        rr rrVar = recyclerView.R;
        aE(accessibilityEvent);
        nw nwVar = this.t;
        if (nwVar != null) {
            if (nwVar.e.a.getChildCount() - nwVar.b.size() > 0) {
                nw nwVar2 = this.t;
                if (nwVar2 != null) {
                    i = nwVar2.e.a.getChildCount() - nwVar2.b.size();
                } else {
                    i = 0;
                }
                View ad = ad(0, i, false);
                int i4 = -1;
                if (ad == null) {
                    i2 = -1;
                } else {
                    rt rtVar = ((rd) ad.getLayoutParams()).c;
                    i2 = rtVar.g;
                    if (i2 == -1) {
                        i2 = rtVar.c;
                    }
                }
                accessibilityEvent.setFromIndex(i2);
                nw nwVar3 = this.t;
                if (nwVar3 != null) {
                    i3 = nwVar3.e.a.getChildCount() - nwVar3.b.size();
                } else {
                    i3 = 0;
                }
                View ad2 = ad(i3 - 1, -1, false);
                if (ad2 != null) {
                    rt rtVar2 = ((rd) ad2.getLayoutParams()).c;
                    int i5 = rtVar2.g;
                    if (i5 == -1) {
                        i4 = rtVar2.c;
                    } else {
                        i4 = i5;
                    }
                }
                accessibilityEvent.setToIndex(i4);
            }
        }
    }

    @Override // cal.rc
    public final void T(Parcelable parcelable) {
        if (parcelable instanceof pn) {
            pn pnVar = (pn) parcelable;
            this.r = pnVar;
            if (this.p != -1) {
                pnVar.a = -1;
            }
            RecyclerView recyclerView = this.u;
            if (recyclerView != null) {
                recyclerView.requestLayout();
            }
        }
    }

    @Override // cal.rc
    public final void U(int i) {
        this.p = i;
        this.q = Integer.MIN_VALUE;
        pn pnVar = this.r;
        if (pnVar != null) {
            pnVar.a = -1;
        }
        RecyclerView recyclerView = this.u;
        if (recyclerView != null) {
            recyclerView.requestLayout();
        }
    }

    public final void V(int i) {
        qc qaVar;
        RecyclerView recyclerView;
        if (i != 0 && i != 1) {
            throw new IllegalArgumentException(a.f(i, "invalid orientation:"));
        }
        if (this.r == null && (recyclerView = this.u) != null) {
            recyclerView.o(null);
        }
        if (i != this.k || this.m == null) {
            if (i != 0) {
                qaVar = new qb(this);
            } else {
                qaVar = new qa(this);
            }
            this.m = qaVar;
            this.s.a = qaVar;
            this.k = i;
            RecyclerView recyclerView2 = this.u;
            if (recyclerView2 != null) {
                recyclerView2.requestLayout();
            }
        }
    }

    @Override // cal.rc
    public final boolean W() {
        if (this.k == 0) {
            return true;
        }
        return false;
    }

    @Override // cal.rc
    public final boolean X() {
        if (this.k == 1) {
            return true;
        }
        return false;
    }

    @Override // cal.rc
    public final boolean Y() {
        return true;
    }

    @Override // cal.rc
    public final boolean Z() {
        return this.b;
    }

    @Override // cal.rc
    public final boolean aa() {
        int i;
        View view;
        if (this.G != 1073741824 && this.F != 1073741824) {
            nw nwVar = this.t;
            if (nwVar != null) {
                i = nwVar.e.a.getChildCount() - nwVar.b.size();
            } else {
                i = 0;
            }
            for (int i2 = 0; i2 < i; i2++) {
                nw nwVar2 = this.t;
                if (nwVar2 != null) {
                    view = nwVar2.e.a.getChildAt(nwVar2.a(i2));
                } else {
                    view = null;
                }
                ViewGroup.LayoutParams layoutParams = view.getLayoutParams();
                if (layoutParams.width < 0 && layoutParams.height < 0) {
                    return true;
                }
            }
        }
        return false;
    }

    @Override // cal.rc
    public final void ab(int i, int i2, rr rrVar, pa paVar) {
        int i3;
        if (1 == this.k) {
            i = i2;
        }
        nw nwVar = this.t;
        if (nwVar != null) {
            if (nwVar.e.a.getChildCount() - nwVar.b.size() != 0 && i != 0) {
                if (this.l == null) {
                    this.l = new pl();
                }
                if (i > 0) {
                    i3 = 1;
                } else {
                    i3 = -1;
                }
                aM(i3, Math.abs(i), true, rrVar);
                w(rrVar, this.l, paVar);
            }
        }
    }

    @Override // cal.rc
    public final void ac(int i, pa paVar) {
        boolean z;
        int i2;
        pn pnVar = this.r;
        int i3 = -1;
        if (pnVar != null && (i2 = pnVar.a) >= 0) {
            z = pnVar.c;
        } else {
            aL();
            z = this.n;
            i2 = this.p;
            if (i2 == -1) {
                i2 = z ? i - 1 : 0;
            }
        }
        if (true != z) {
            i3 = 1;
        }
        for (int i4 = 0; i4 < this.e && i2 >= 0 && i2 < i; i4++) {
            paVar.a(i2, 0);
            i2 += i3;
        }
    }

    public final View ad(int i, int i2, boolean z) {
        int i3;
        if (this.l == null) {
            this.l = new pl();
        }
        if (true != z) {
            i3 = 320;
        } else {
            i3 = 24579;
        }
        if (this.k == 0) {
            return this.v.a(i, i2, i3, 320);
        }
        return this.w.a(i, i2, i3, 320);
    }

    @Override // cal.rc
    public void af(RecyclerView recyclerView, int i) {
        po poVar = new po(recyclerView.getContext());
        poVar.j = i;
        aw(poVar);
    }

    @Override // cal.rc
    public View cO(View view, int i, rj rjVar, rr rrVar) {
        int J;
        int i2;
        View O;
        int i3;
        View childAt;
        int i4;
        View O2;
        int i5;
        aL();
        nw nwVar = this.t;
        if (nwVar != null) {
            if (nwVar.e.a.getChildCount() - nwVar.b.size() == 0 || (J = J(i)) == Integer.MIN_VALUE) {
                return null;
            }
            if (this.l == null) {
                this.l = new pl();
            }
            int i6 = 0;
            aM(J, (int) (this.m.k() * 0.33333334f), false, rrVar);
            pl plVar = this.l;
            plVar.g = Integer.MIN_VALUE;
            plVar.a = false;
            K(rjVar, plVar, rrVar, true);
            if (J == -1) {
                if (this.n) {
                    nw nwVar2 = this.t;
                    if (nwVar2 != null) {
                        i5 = nwVar2.e.a.getChildCount() - nwVar2.b.size();
                    } else {
                        i5 = 0;
                    }
                    O2 = O(i5 - 1, -1);
                } else {
                    nw nwVar3 = this.t;
                    if (nwVar3 != null) {
                        i4 = nwVar3.e.a.getChildCount() - nwVar3.b.size();
                    } else {
                        i4 = 0;
                    }
                    O2 = O(0, i4);
                }
                O = O2;
                J = -1;
            } else if (this.n) {
                nw nwVar4 = this.t;
                if (nwVar4 != null) {
                    i3 = nwVar4.e.a.getChildCount() - nwVar4.b.size();
                } else {
                    i3 = 0;
                }
                O = O(0, i3);
            } else {
                nw nwVar5 = this.t;
                if (nwVar5 != null) {
                    i2 = nwVar5.e.a.getChildCount() - nwVar5.b.size();
                } else {
                    i2 = 0;
                }
                O = O(i2 - 1, -1);
            }
            if (J == -1) {
                if (this.n) {
                    nw nwVar6 = this.t;
                    if (nwVar6 != null) {
                        i6 = nwVar6.e.a.getChildCount() - nwVar6.b.size();
                    }
                    i6--;
                }
                nw nwVar7 = this.t;
                if (nwVar7 != null) {
                    childAt = nwVar7.e.a.getChildAt(nwVar7.a(i6));
                }
                childAt = null;
            } else {
                if (!this.n) {
                    nw nwVar8 = this.t;
                    if (nwVar8 != null) {
                        i6 = nwVar8.e.a.getChildCount() - nwVar8.b.size();
                    }
                    i6--;
                }
                nw nwVar9 = this.t;
                if (nwVar9 != null) {
                    childAt = nwVar9.e.a.getChildAt(nwVar9.a(i6));
                }
                childAt = null;
            }
            if (childAt.hasFocusable()) {
                if (O == null) {
                    return null;
                }
                return childAt;
            }
            return O;
        }
        return null;
    }

    @Override // cal.rc
    public void cP(rj rjVar, rr rrVar, aob aobVar) {
        super.cP(rjVar, rrVar, aobVar);
        qq qqVar = this.u.m;
        if (qqVar != null && qqVar.a() > 0) {
            aobVar.a.addAction((AccessibilityNodeInfo.AccessibilityAction) aoa.k.o);
        }
    }

    @Override // cal.rc
    public boolean cS(int i, Bundle bundle) {
        int min;
        RecyclerView recyclerView = this.u;
        rj rjVar = recyclerView.d;
        rr rrVar = recyclerView.R;
        if (aG(i, bundle)) {
            return true;
        }
        if (i == 16908343 && bundle != null) {
            if (this.k == 1) {
                int i2 = bundle.getInt("android.view.accessibility.action.ARGUMENT_ROW_INT", -1);
                if (i2 < 0) {
                    return false;
                }
                RecyclerView recyclerView2 = this.u;
                min = Math.min(i2, bH(recyclerView2.d, recyclerView2.R) - 1);
            } else {
                int i3 = bundle.getInt("android.view.accessibility.action.ARGUMENT_COLUMN_INT", -1);
                if (i3 < 0) {
                    return false;
                }
                RecyclerView recyclerView3 = this.u;
                min = Math.min(i3, bG(recyclerView3.d, recyclerView3.R) - 1);
            }
            if (min >= 0) {
                this.p = min;
                this.q = 0;
                pn pnVar = this.r;
                if (pnVar != null) {
                    pnVar.a = -1;
                }
                RecyclerView recyclerView4 = this.u;
                if (recyclerView4 != null) {
                    recyclerView4.requestLayout();
                }
                return true;
            }
        }
        return false;
    }

    @Override // cal.rc
    public boolean cT() {
        if (this.r == null && this.a == this.o) {
            return true;
        }
        return false;
    }

    @Override // cal.rc
    public int d(int i, rj rjVar, rr rrVar) {
        if (this.k == 1) {
            return 0;
        }
        return L(i, rjVar, rrVar);
    }

    @Override // cal.rc
    public int e(int i, rj rjVar, rr rrVar) {
        if (this.k == 0) {
            return 0;
        }
        return L(i, rjVar, rrVar);
    }

    @Override // cal.rc
    public rd f() {
        return new rd(-2, -2);
    }

    public View i(rj rjVar, rr rrVar, boolean z, boolean z2) {
        int i;
        int i2;
        int i3;
        int i4;
        View view;
        boolean z3;
        boolean z4;
        int i5;
        if (this.l == null) {
            this.l = new pl();
        }
        nw nwVar = this.t;
        if (nwVar != null) {
            i = nwVar.e.a.getChildCount() - nwVar.b.size();
        } else {
            i = 0;
        }
        if (z2) {
            nw nwVar2 = this.t;
            if (nwVar2 != null) {
                i5 = nwVar2.e.a.getChildCount() - nwVar2.b.size();
            } else {
                i5 = 0;
            }
            i2 = i5 - 1;
            i = -1;
            i3 = -1;
        } else {
            i2 = 0;
            i3 = 1;
        }
        if (rrVar.g) {
            i4 = rrVar.b - rrVar.c;
        } else {
            i4 = rrVar.e;
        }
        int j = this.m.j();
        int f = this.m.f();
        View view2 = null;
        View view3 = null;
        View view4 = null;
        while (i2 != i) {
            nw nwVar3 = this.t;
            if (nwVar3 != null) {
                view = nwVar3.e.a.getChildAt(nwVar3.a(i2));
            } else {
                view = null;
            }
            rt rtVar = ((rd) view.getLayoutParams()).c;
            int i6 = rtVar.g;
            if (i6 == -1) {
                i6 = rtVar.c;
            }
            int d = this.m.d(view);
            int a = this.m.a(view);
            if (i6 >= 0 && i6 < i4) {
                if ((((rd) view.getLayoutParams()).c.j & 8) != 0) {
                    if (view4 == null) {
                        view4 = view;
                    }
                } else {
                    if (a <= j && d < j) {
                        z3 = true;
                    } else {
                        z3 = false;
                    }
                    if (d >= f && a > f) {
                        z4 = true;
                    } else {
                        z4 = false;
                    }
                    if (!z3 && !z4) {
                        return view;
                    }
                    if (z) {
                        if (!z4) {
                            if (view2 != null) {
                            }
                            view2 = view;
                        }
                        view3 = view;
                    } else {
                        if (!z3) {
                            if (view2 != null) {
                            }
                            view2 = view;
                        }
                        view3 = view;
                    }
                }
            }
            i2 += i3;
        }
        if (view2 == null) {
            if (view3 != null) {
                return view3;
            }
            return view4;
        }
        return view2;
    }

    public void k(rj rjVar, rr rrVar, pl plVar, pk pkVar) {
        View view;
        boolean z;
        int i;
        int i2;
        int i3;
        boolean z2;
        if (plVar.l != null) {
            view = plVar.a();
        } else {
            view = rjVar.j(plVar.d, Long.MAX_VALUE).a;
            plVar.d += plVar.e;
        }
        if (view == null) {
            pkVar.b = true;
            return;
        }
        rd rdVar = (rd) view.getLayoutParams();
        int i4 = 0;
        if (plVar.l == null) {
            boolean z3 = this.n;
            if (plVar.f != -1) {
                z2 = false;
            } else {
                z2 = true;
            }
            if (z3 == z2) {
                super.al(view, -1, false);
            } else {
                super.al(view, 0, false);
            }
        } else {
            boolean z4 = this.n;
            if (plVar.f != -1) {
                z = false;
            } else {
                z = true;
            }
            if (z4 == z) {
                super.al(view, -1, true);
            } else {
                super.al(view, 0, true);
            }
        }
        aC(view);
        pkVar.a = this.m.b(view);
        if (this.k == 1) {
            if (this.u.getLayoutDirection() == 1) {
                int i5 = this.H;
                RecyclerView recyclerView = this.u;
                if (recyclerView != null) {
                    i4 = recyclerView.getPaddingRight();
                }
                i2 = i5 - i4;
                i4 = i2 - this.m.c(view);
            } else {
                RecyclerView recyclerView2 = this.u;
                if (recyclerView2 != null) {
                    i4 = recyclerView2.getPaddingLeft();
                }
                i2 = this.m.c(view) + i4;
            }
            if (plVar.f == -1) {
                i = plVar.b;
                i3 = i - pkVar.a;
            } else {
                i3 = plVar.b;
                i = pkVar.a + i3;
            }
        } else {
            RecyclerView recyclerView3 = this.u;
            if (recyclerView3 != null) {
                i4 = recyclerView3.getPaddingTop();
            }
            int c = this.m.c(view) + i4;
            if (plVar.f == -1) {
                int i6 = plVar.b;
                int i7 = i6 - pkVar.a;
                i2 = i6;
                i = c;
                int i8 = i4;
                i4 = i7;
                i3 = i8;
            } else {
                int i9 = plVar.b;
                int i10 = pkVar.a + i9;
                int i11 = i4;
                i4 = i9;
                i = c;
                i2 = i10;
                i3 = i11;
            }
        }
        aB(view, i4, i3, i2, i);
        int i12 = rdVar.c.j;
        if ((i12 & 8) != 0 || (i12 & 2) != 0) {
            pkVar.c = true;
        }
        pkVar.d = view.hasFocusable();
    }

    @Override // cal.rc
    public void o(rj rjVar, rr rrVar) {
        int i;
        int i2;
        int i3;
        View i4;
        boolean z;
        boolean z2;
        int i5;
        int i6;
        int i7;
        View view;
        boolean z3;
        boolean z4;
        int d;
        int k;
        int i8;
        int i9;
        int i10;
        boolean z5;
        int i11;
        int i12;
        nw nwVar;
        View view2;
        List list;
        int i13;
        int i14;
        View view3;
        int i15;
        View view4;
        int i16;
        boolean z6;
        int i17;
        int i18;
        int aH;
        View view5;
        int i19;
        View P;
        int d2;
        int i20;
        int i21;
        pn pnVar = this.r;
        if (pnVar != null || this.p != -1) {
            if (rrVar.g) {
                i = rrVar.b - rrVar.c;
            } else {
                i = rrVar.e;
            }
            if (i == 0) {
                ar(rjVar);
                return;
            }
        }
        if (pnVar != null && (i21 = pnVar.a) >= 0) {
            this.p = i21;
        }
        if (this.l == null) {
            this.l = new pl();
        }
        this.l.a = false;
        aL();
        View ak = ak();
        pj pjVar = this.s;
        if (pjVar.e && this.p == -1 && this.r == null) {
            if (ak != null && (this.m.d(ak) >= this.m.f() || this.m.a(ak) <= this.m.j())) {
                pj pjVar2 = this.s;
                rt rtVar = ((rd) ak.getLayoutParams()).c;
                int i22 = rtVar.g;
                if (i22 == -1) {
                    i22 = rtVar.c;
                }
                pjVar2.c(ak, i22);
            }
        } else {
            pjVar.b = -1;
            pjVar.c = Integer.MIN_VALUE;
            pjVar.d = false;
            pjVar.e = false;
            boolean z7 = this.n;
            pjVar.d = this.o ^ z7;
            if (!rrVar.g && (i7 = this.p) != -1) {
                if (i7 >= 0 && i7 < rrVar.e) {
                    pjVar.b = i7;
                    pn pnVar2 = this.r;
                    if (pnVar2 != null && pnVar2.a >= 0) {
                        boolean z8 = pnVar2.c;
                        pjVar.d = z8;
                        if (z8) {
                            pjVar.c = this.m.f() - this.r.b;
                        } else {
                            pjVar.c = this.m.j() + this.r.b;
                        }
                    } else if (this.q == Integer.MIN_VALUE) {
                        View P2 = P(i7);
                        if (P2 != null) {
                            if (this.m.b(P2) > this.m.k()) {
                                pjVar.a();
                            } else if (this.m.d(P2) - this.m.j() < 0) {
                                pjVar.c = this.m.j();
                                pjVar.d = false;
                            } else if (this.m.f() - this.m.a(P2) < 0) {
                                pjVar.c = this.m.f();
                                pjVar.d = true;
                            } else {
                                if (pjVar.d) {
                                    int a = this.m.a(P2);
                                    qc qcVar = this.m;
                                    if (qcVar.b == Integer.MIN_VALUE) {
                                        k = 0;
                                    } else {
                                        k = qcVar.k() - qcVar.b;
                                    }
                                    d = a + k;
                                } else {
                                    d = this.m.d(P2);
                                }
                                pjVar.c = d;
                            }
                        } else {
                            nw nwVar2 = this.t;
                            if (nwVar2 != null) {
                                if (nwVar2.e.a.getChildCount() - nwVar2.b.size() > 0) {
                                    nw nwVar3 = this.t;
                                    if (nwVar3 != null) {
                                        view = nwVar3.e.a.getChildAt(nwVar3.a(0));
                                    } else {
                                        view = null;
                                    }
                                    rt rtVar2 = ((rd) view.getLayoutParams()).c;
                                    int i23 = rtVar2.g;
                                    if (i23 == -1) {
                                        i23 = rtVar2.c;
                                    }
                                    if (this.p >= i23) {
                                        z3 = false;
                                    } else {
                                        z3 = true;
                                    }
                                    if (z3 == this.n) {
                                        z4 = true;
                                    } else {
                                        z4 = false;
                                    }
                                    pjVar.d = z4;
                                }
                            }
                            pjVar.a();
                        }
                    } else {
                        pjVar.d = z7;
                        if (z7) {
                            pjVar.c = this.m.f() - this.q;
                        } else {
                            pjVar.c = this.m.j() + this.q;
                        }
                    }
                    this.s.e = true;
                } else {
                    this.p = -1;
                    this.q = Integer.MIN_VALUE;
                }
            }
            nw nwVar4 = this.t;
            if (nwVar4 != null) {
                if (nwVar4.e.a.getChildCount() - nwVar4.b.size() != 0) {
                    View ak2 = ak();
                    if (ak2 != null) {
                        rt rtVar3 = ((rd) ak2.getLayoutParams()).c;
                        if ((rtVar3.j & 8) == 0) {
                            int i24 = rtVar3.g;
                            if (i24 == -1) {
                                i24 = rtVar3.c;
                                i5 = -1;
                            } else {
                                i5 = i24;
                            }
                            if (i24 >= 0) {
                                if (i5 == -1) {
                                    i5 = rtVar3.c;
                                }
                                if (rrVar.g) {
                                    i6 = rrVar.b - rrVar.c;
                                } else {
                                    i6 = rrVar.e;
                                }
                                if (i5 < i6) {
                                    rt rtVar4 = ((rd) ak2.getLayoutParams()).c;
                                    int i25 = rtVar4.g;
                                    if (i25 == -1) {
                                        i25 = rtVar4.c;
                                    }
                                    pjVar.c(ak2, i25);
                                    this.s.e = true;
                                }
                            }
                        }
                    }
                    boolean z9 = this.a;
                    boolean z10 = this.o;
                    if (z9 == z10 && (i4 = i(rjVar, rrVar, pjVar.d, z10)) != null) {
                        rt rtVar5 = ((rd) i4.getLayoutParams()).c;
                        int i26 = rtVar5.g;
                        if (i26 == -1) {
                            i26 = rtVar5.c;
                        }
                        pjVar.b(i4, i26);
                        if (!rrVar.g && cT()) {
                            int d3 = this.m.d(i4);
                            int a2 = this.m.a(i4);
                            int j = this.m.j();
                            int f = this.m.f();
                            if (a2 <= j && d3 < j) {
                                z = true;
                            } else {
                                z = false;
                            }
                            if (d3 >= f && a2 > f) {
                                z2 = true;
                            } else {
                                z2 = false;
                            }
                            if (z || z2) {
                                if (true == pjVar.d) {
                                    j = f;
                                }
                                pjVar.c = j;
                            }
                        }
                        this.s.e = true;
                    }
                }
            }
            pjVar.a();
            if (this.o) {
                if (rrVar.g) {
                    i3 = rrVar.b - rrVar.c;
                } else {
                    i3 = rrVar.e;
                }
                i2 = i3 - 1;
            } else {
                i2 = 0;
            }
            pjVar.b = i2;
            this.s.e = true;
        }
        pl plVar = this.l;
        if (plVar.k >= 0) {
            i8 = 1;
        } else {
            i8 = -1;
        }
        plVar.f = i8;
        int[] iArr = this.f;
        iArr[0] = 0;
        iArr[1] = 0;
        R(rrVar, iArr);
        int max = Math.max(0, this.f[0]) + this.m.j();
        int max2 = Math.max(0, this.f[1]) + this.m.g();
        if (rrVar.g && (i19 = this.p) != -1 && this.q != Integer.MIN_VALUE && (P = P(i19)) != null) {
            if (this.n) {
                i20 = this.m.f() - this.m.a(P);
                d2 = this.q;
            } else {
                d2 = this.m.d(P) - this.m.j();
                i20 = this.q;
            }
            int i27 = i20 - d2;
            if (i27 > 0) {
                max += i27;
            } else {
                max2 -= i27;
            }
        }
        pj pjVar3 = this.s;
        if (!pjVar3.d ? true != this.n : true == this.n) {
            i9 = 1;
        } else {
            i9 = -1;
        }
        l(rjVar, rrVar, pjVar3, i9);
        nw nwVar5 = this.t;
        if (nwVar5 != null) {
            i10 = nwVar5.e.a.getChildCount() - nwVar5.b.size();
        } else {
            i10 = 0;
        }
        for (int i28 = i10 - 1; i28 >= 0; i28--) {
            nw nwVar6 = this.t;
            if (nwVar6 != null) {
                view5 = nwVar6.e.a.getChildAt(nwVar6.a(i28));
            } else {
                view5 = null;
            }
            super.at(rjVar, i28, view5);
        }
        pl plVar2 = this.l;
        if (this.m.h() == 0 && this.m.e() == 0) {
            z5 = true;
        } else {
            z5 = false;
        }
        plVar2.m = z5;
        pl plVar3 = this.l;
        plVar3.j = rrVar.g;
        plVar3.i = 0;
        pj pjVar4 = this.s;
        if (pjVar4.d) {
            aO(pjVar4.b, pjVar4.c);
            pl plVar4 = this.l;
            plVar4.h = max;
            K(rjVar, plVar4, rrVar, false);
            pl plVar5 = this.l;
            i11 = plVar5.b;
            int i29 = plVar5.d;
            int i30 = plVar5.c;
            if (i30 > 0) {
                max2 += i30;
            }
            pj pjVar5 = this.s;
            aN(pjVar5.b, pjVar5.c);
            pl plVar6 = this.l;
            plVar6.h = max2;
            plVar6.d += plVar6.e;
            K(rjVar, plVar6, rrVar, false);
            pl plVar7 = this.l;
            i12 = plVar7.b;
            int i31 = plVar7.c;
            if (i31 > 0) {
                aO(i29, i11);
                pl plVar8 = this.l;
                plVar8.h = i31;
                K(rjVar, plVar8, rrVar, false);
                i11 = this.l.b;
            }
        } else {
            aN(pjVar4.b, pjVar4.c);
            pl plVar9 = this.l;
            plVar9.h = max2;
            K(rjVar, plVar9, rrVar, false);
            pl plVar10 = this.l;
            int i32 = plVar10.b;
            int i33 = plVar10.d;
            int i34 = plVar10.c;
            if (i34 > 0) {
                max += i34;
            }
            pj pjVar6 = this.s;
            aO(pjVar6.b, pjVar6.c);
            pl plVar11 = this.l;
            plVar11.h = max;
            plVar11.d += plVar11.e;
            K(rjVar, plVar11, rrVar, false);
            pl plVar12 = this.l;
            int i35 = plVar12.b;
            int i36 = plVar12.c;
            if (i36 > 0) {
                aN(i33, i32);
                pl plVar13 = this.l;
                plVar13.h = i36;
                K(rjVar, plVar13, rrVar, false);
                i11 = i35;
                i12 = this.l.b;
            } else {
                i11 = i35;
                i12 = i32;
            }
        }
        nw nwVar7 = this.t;
        if (nwVar7 != null) {
            if (nwVar7.e.a.getChildCount() - nwVar7.b.size() > 0) {
                if (this.n ^ this.o) {
                    int aH2 = aH(i12, rjVar, rrVar, true);
                    i17 = i11 + aH2;
                    i18 = i12 + aH2;
                    aH = aI(i17, rjVar, rrVar, false);
                } else {
                    int aI = aI(i11, rjVar, rrVar, true);
                    i17 = i11 + aI;
                    i18 = i12 + aI;
                    aH = aH(i18, rjVar, rrVar, false);
                }
                i11 = i17 + aH;
                i12 = i18 + aH;
            }
        }
        if (rrVar.k && (nwVar = this.t) != null) {
            if (nwVar.e.a.getChildCount() - nwVar.b.size() != 0 && !rrVar.g && cT()) {
                List list2 = rjVar.d;
                int size = list2.size();
                nw nwVar8 = this.t;
                if (nwVar8 != null) {
                    view2 = nwVar8.e.a.getChildAt(nwVar8.a(0));
                } else {
                    view2 = null;
                }
                rt rtVar6 = ((rd) view2.getLayoutParams()).c;
                int i37 = rtVar6.g;
                if (i37 == -1) {
                    i37 = rtVar6.c;
                }
                int i38 = 0;
                int i39 = 0;
                for (int i40 = 0; i40 < size; i40++) {
                    rt rtVar7 = (rt) list2.get(i40);
                    if ((rtVar7.j & 8) == 0) {
                        int i41 = rtVar7.g;
                        if (i41 == -1) {
                            i41 = rtVar7.c;
                        }
                        if (i41 >= i37) {
                            z6 = false;
                        } else {
                            z6 = true;
                        }
                        if (z6 != this.n) {
                            i38 += this.m.b(rtVar7.a);
                        } else {
                            i39 += this.m.b(rtVar7.a);
                        }
                    }
                }
                this.l.l = list2;
                if (i38 > 0) {
                    if (this.n) {
                        nw nwVar9 = this.t;
                        if (nwVar9 != null) {
                            i16 = nwVar9.e.a.getChildCount() - nwVar9.b.size();
                        } else {
                            i16 = 0;
                        }
                        i15 = i16 - 1;
                    } else {
                        i15 = 0;
                    }
                    nw nwVar10 = this.t;
                    if (nwVar10 != null) {
                        view4 = nwVar10.e.a.getChildAt(nwVar10.a(i15));
                    } else {
                        view4 = null;
                    }
                    rt rtVar8 = ((rd) view4.getLayoutParams()).c;
                    int i42 = rtVar8.g;
                    if (i42 == -1) {
                        i42 = rtVar8.c;
                    }
                    aO(i42, i11);
                    pl plVar14 = this.l;
                    plVar14.h = i38;
                    plVar14.c = 0;
                    plVar14.b(null);
                    K(rjVar, this.l, rrVar, false);
                }
                if (i39 > 0) {
                    if (this.n) {
                        i14 = 0;
                    } else {
                        nw nwVar11 = this.t;
                        if (nwVar11 != null) {
                            i13 = nwVar11.e.a.getChildCount() - nwVar11.b.size();
                        } else {
                            i13 = 0;
                        }
                        i14 = i13 - 1;
                    }
                    nw nwVar12 = this.t;
                    if (nwVar12 != null) {
                        view3 = nwVar12.e.a.getChildAt(nwVar12.a(i14));
                    } else {
                        view3 = null;
                    }
                    rt rtVar9 = ((rd) view3.getLayoutParams()).c;
                    int i43 = rtVar9.g;
                    if (i43 == -1) {
                        i43 = rtVar9.c;
                    }
                    aN(i43, i12);
                    pl plVar15 = this.l;
                    plVar15.h = i39;
                    plVar15.c = 0;
                    list = null;
                    plVar15.b(null);
                    K(rjVar, this.l, rrVar, false);
                } else {
                    list = null;
                }
                this.l.l = list;
            }
        }
        if (!rrVar.g) {
            qc qcVar2 = this.m;
            qcVar2.b = qcVar2.k();
        } else {
            pj pjVar7 = this.s;
            pjVar7.b = -1;
            pjVar7.c = Integer.MIN_VALUE;
            pjVar7.d = false;
            pjVar7.e = false;
        }
        this.a = this.o;
    }

    public void r(boolean z) {
        RecyclerView recyclerView;
        if (this.r == null && (recyclerView = this.u) != null) {
            recyclerView.o(null);
        }
        if (this.o != z) {
            this.o = z;
            RecyclerView recyclerView2 = this.u;
            if (recyclerView2 != null) {
                recyclerView2.requestLayout();
            }
        }
    }

    public void w(rr rrVar, pl plVar, pa paVar) {
        int i;
        int i2 = plVar.d;
        if (i2 >= 0) {
            if (rrVar.g) {
                i = rrVar.b - rrVar.c;
            } else {
                i = rrVar.e;
            }
            if (i2 < i) {
                paVar.a(i2, Math.max(0, plVar.g));
            }
        }
    }

    public LinearLayoutManager(Context context, AttributeSet attributeSet, int i, int i2) {
        RecyclerView recyclerView;
        this.k = 1;
        this.b = false;
        this.n = false;
        this.o = false;
        this.c = true;
        this.p = -1;
        this.q = Integer.MIN_VALUE;
        this.r = null;
        this.s = new pj();
        this.d = new pk();
        this.e = 2;
        this.f = new int[2];
        rb ai = ai(context, attributeSet, i, i2);
        V(ai.a);
        boolean z = ai.c;
        if (this.r == null && (recyclerView = this.u) != null) {
            recyclerView.o(null);
        }
        if (z != this.b) {
            this.b = z;
            RecyclerView recyclerView2 = this.u;
            if (recyclerView2 != null) {
                recyclerView2.requestLayout();
            }
        }
        r(ai.d);
    }

    @Override // cal.rc
    public final void ae(RecyclerView recyclerView) {
    }

    public void l(rj rjVar, rr rrVar, pj pjVar, int i) {
    }
}
