package android.support.v7.widget;

import android.content.Context;
import android.graphics.PointF;
import android.graphics.Rect;
import android.os.Parcelable;
import android.util.AttributeSet;
import android.view.View;
import android.view.ViewGroup;
import android.view.accessibility.AccessibilityEvent;
import android.view.accessibility.AccessibilityNodeInfo;
import cal.aob;
import cal.nw;
import cal.pg;
import cal.po;
import cal.qa;
import cal.qb;
import cal.qc;
import cal.rb;
import cal.rc;
import cal.rd;
import cal.rj;
import cal.rp;
import cal.rq;
import cal.rr;
import cal.rt;
import cal.sb;
import cal.sf;
import cal.sg;
import cal.sh;
import cal.sk;
import cal.sm;
import cal.sn;
import java.util.Arrays;
import java.util.BitSet;

/* compiled from: PG */
/* loaded from: classes.dex */
public class StaggeredGridLayoutManager extends rc implements rp {
    private int[] K;
    sn[] a;
    public qc b;
    qc c;
    private int i;
    private int j;
    private int k;
    private final pg l;
    private BitSet m;
    private boolean o;
    private boolean p;
    private sm q;
    public boolean d = false;
    boolean e = false;
    int f = -1;
    int g = Integer.MIN_VALUE;
    sk h = new sk();
    private int n = 2;
    private final Rect r = new Rect();
    private final sg s = new sg(this);
    private boolean J = true;
    private final Runnable L = new sf(this);

    public StaggeredGridLayoutManager(Context context, AttributeSet attributeSet, int i, int i2) {
        qc qaVar;
        qc qaVar2;
        RecyclerView recyclerView;
        RecyclerView recyclerView2;
        this.i = -1;
        rb ai = ai(context, attributeSet, i, i2);
        int i3 = ai.a;
        if (i3 != 0 && i3 != 1) {
            throw new IllegalArgumentException("invalid orientation.");
        }
        if (this.q == null && (recyclerView2 = this.u) != null) {
            recyclerView2.o(null);
        }
        if (i3 != this.j) {
            this.j = i3;
            qc qcVar = this.b;
            this.b = this.c;
            this.c = qcVar;
            RecyclerView recyclerView3 = this.u;
            if (recyclerView3 != null) {
                recyclerView3.requestLayout();
            }
        }
        int i4 = ai.b;
        if (this.q == null && (recyclerView = this.u) != null) {
            recyclerView.o(null);
        }
        if (i4 != this.i) {
            sk skVar = this.h;
            int[] iArr = skVar.a;
            if (iArr != null) {
                Arrays.fill(iArr, -1);
            }
            skVar.b = null;
            RecyclerView recyclerView4 = this.u;
            if (recyclerView4 != null) {
                recyclerView4.requestLayout();
            }
            this.i = i4;
            this.m = new BitSet(i4);
            this.a = new sn[this.i];
            for (int i5 = 0; i5 < this.i; i5++) {
                this.a[i5] = new sn(this, i5);
            }
            RecyclerView recyclerView5 = this.u;
            if (recyclerView5 != null) {
                recyclerView5.requestLayout();
            }
        }
        r(ai.c);
        this.l = new pg();
        if (this.j != 0) {
            qaVar = new qb(this);
        } else {
            qaVar = new qa(this);
        }
        this.b = qaVar;
        if (1 - this.j != 0) {
            qaVar2 = new qb(this);
        } else {
            qaVar2 = new qa(this);
        }
        this.c = qaVar2;
    }

    private final int J(rr rrVar) {
        nw nwVar = this.t;
        if (nwVar != null) {
            if (nwVar.e.a.getChildCount() - nwVar.b.size() != 0) {
                return sb.a(rrVar, this.b, k(!this.J), i(!this.J), this, this.J);
            }
            return 0;
        }
        return 0;
    }

    private final int K(rr rrVar) {
        nw nwVar = this.t;
        if (nwVar != null) {
            if (nwVar.e.a.getChildCount() - nwVar.b.size() != 0) {
                return sb.b(rrVar, this.b, k(!this.J), i(!this.J), this, this.J, this.e);
            }
            return 0;
        }
        return 0;
    }

    private final int L(rr rrVar) {
        nw nwVar = this.t;
        if (nwVar != null) {
            if (nwVar.e.a.getChildCount() - nwVar.b.size() != 0) {
                return sb.c(rrVar, this.b, k(!this.J), i(!this.J), this, this.J);
            }
            return 0;
        }
        return 0;
    }

    /* JADX WARN: Type inference failed for: r7v2 */
    /* JADX WARN: Type inference failed for: r7v3, types: [int, boolean] */
    /* JADX WARN: Type inference failed for: r7v34 */
    private final int O(rj rjVar, pg pgVar, rr rrVar) {
        int i;
        int j;
        int R;
        int i2;
        int i3;
        int i4;
        sn snVar;
        ?? r7;
        int i5;
        int i6;
        int i7;
        int c;
        int b;
        int j2;
        int b2;
        int i8;
        int i9;
        int i10;
        int i11;
        int i12;
        int i13;
        int i14;
        rr rrVar2 = rrVar;
        int i15 = 0;
        int i16 = 1;
        this.m.set(0, this.i, true);
        if (this.l.i) {
            if (pgVar.e == 1) {
                i = Integer.MAX_VALUE;
            } else {
                i = Integer.MIN_VALUE;
            }
        } else if (pgVar.e == 1) {
            i = pgVar.g + pgVar.b;
        } else {
            i = pgVar.f - pgVar.b;
        }
        int i17 = pgVar.e;
        for (int i18 = 0; i18 < this.i; i18++) {
            if (!this.a[i18].a.isEmpty()) {
                aP(this.a[i18], i17, i);
            }
        }
        if (this.e) {
            j = this.b.f();
        } else {
            j = this.b.j();
        }
        boolean z = false;
        while (true) {
            int i19 = pgVar.c;
            if (i19 < 0) {
                break;
            }
            if (rrVar2.g) {
                i2 = rrVar2.b - rrVar2.c;
            } else {
                i2 = rrVar2.e;
            }
            if (i19 >= i2 || (!this.l.i && this.m.isEmpty())) {
                break;
            }
            View view = rjVar.j(pgVar.c, Long.MAX_VALUE).a;
            pgVar.c += pgVar.d;
            sh shVar = (sh) view.getLayoutParams();
            rt rtVar = shVar.c;
            int i20 = rtVar.g;
            if (i20 == -1) {
                i20 = rtVar.c;
            }
            int[] iArr = this.h.a;
            if (iArr != null && i20 < iArr.length) {
                i3 = iArr[i20];
            } else {
                i3 = -1;
            }
            if (i3 == -1) {
                i4 = i16;
            } else {
                i4 = i15;
            }
            if (i4 != 0) {
                boolean z2 = shVar.b;
                if (aQ(pgVar.e)) {
                    i12 = this.i - 1;
                    i11 = -1;
                    i10 = -1;
                } else {
                    i10 = i16;
                    i11 = this.i;
                    i12 = i15;
                }
                sn snVar2 = null;
                if (pgVar.e == i16) {
                    int j3 = this.b.j();
                    int i21 = Integer.MAX_VALUE;
                    while (i12 != i11) {
                        sn snVar3 = this.a[i12];
                        int i22 = snVar3.c;
                        if (i22 == Integer.MIN_VALUE) {
                            if (snVar3.a.size() == 0) {
                                i22 = j3;
                            } else {
                                snVar3.e();
                                i22 = snVar3.c;
                            }
                        }
                        if (i22 < i21) {
                            i14 = i22;
                        } else {
                            i14 = i21;
                        }
                        if (i22 < i21) {
                            snVar2 = snVar3;
                        }
                        i12 += i10;
                        i21 = i14;
                    }
                } else {
                    int f = this.b.f();
                    int i23 = Integer.MIN_VALUE;
                    while (i12 != i11) {
                        sn snVar4 = this.a[i12];
                        int c2 = snVar4.c(f);
                        if (c2 > i23) {
                            i13 = c2;
                        } else {
                            i13 = i23;
                        }
                        if (c2 > i23) {
                            snVar2 = snVar4;
                        }
                        i12 += i10;
                        i23 = i13;
                    }
                }
                snVar = snVar2;
                sk skVar = this.h;
                skVar.a(i20);
                skVar.a[i20] = snVar.e;
            } else {
                snVar = this.a[i3];
            }
            shVar.a = snVar;
            if (pgVar.e == 1) {
                r7 = 0;
                super.al(view, -1, false);
            } else {
                r7 = 0;
                super.al(view, 0, false);
            }
            boolean z3 = shVar.b;
            if (this.j == 1) {
                int ah = ah(this.k, this.F, r7, shVar.width, r7);
                int i24 = this.I;
                int i25 = this.G;
                RecyclerView recyclerView = this.u;
                if (recyclerView != null) {
                    i8 = recyclerView.getPaddingTop();
                } else {
                    i8 = 0;
                }
                RecyclerView recyclerView2 = this.u;
                if (recyclerView2 != null) {
                    i9 = recyclerView2.getPaddingBottom();
                } else {
                    i9 = 0;
                }
                aR(view, ah, ah(i24, i25, i8 + i9, shVar.height, true));
                i7 = 1;
            } else {
                int i26 = this.H;
                int i27 = this.F;
                RecyclerView recyclerView3 = this.u;
                if (recyclerView3 != null) {
                    i5 = recyclerView3.getPaddingLeft();
                } else {
                    i5 = 0;
                }
                RecyclerView recyclerView4 = this.u;
                if (recyclerView4 != null) {
                    i6 = recyclerView4.getPaddingRight();
                } else {
                    i6 = 0;
                }
                i7 = 1;
                aR(view, ah(i26, i27, i5 + i6, shVar.width, true), ah(this.k, this.G, 0, shVar.height, false));
            }
            if (pgVar.e == i7) {
                boolean z4 = shVar.b;
                b = snVar.c;
                if (b == Integer.MIN_VALUE) {
                    if (snVar.a.size() == 0) {
                        b = j;
                    } else {
                        snVar.e();
                        b = snVar.c;
                    }
                }
                c = this.b.b(view) + b;
                if (i4 != 0) {
                    boolean z5 = shVar.b;
                }
            } else {
                boolean z6 = shVar.b;
                c = snVar.c(j);
                b = c - this.b.b(view);
                if (i4 != 0) {
                    boolean z7 = shVar.b;
                }
            }
            boolean z8 = shVar.b;
            if (pgVar.e == 1) {
                sn snVar5 = shVar.a;
                sh shVar2 = (sh) view.getLayoutParams();
                shVar2.a = snVar5;
                snVar5.a.add(view);
                snVar5.c = Integer.MIN_VALUE;
                if (snVar5.a.size() == 1) {
                    snVar5.b = Integer.MIN_VALUE;
                }
                int i28 = shVar2.c.j;
                if ((i28 & 8) != 0 || (i28 & 2) != 0) {
                    snVar5.d += snVar5.f.b.b(view);
                }
            } else {
                sn snVar6 = shVar.a;
                sh shVar3 = (sh) view.getLayoutParams();
                shVar3.a = snVar6;
                snVar6.a.add(0, view);
                snVar6.b = Integer.MIN_VALUE;
                if (snVar6.a.size() == 1) {
                    snVar6.c = Integer.MIN_VALUE;
                }
                int i29 = shVar3.c.j;
                if ((i29 & 8) != 0 || (i29 & 2) != 0) {
                    snVar6.d += snVar6.f.b.b(view);
                }
            }
            if (this.u.getLayoutDirection() == 1 && this.j == 1) {
                boolean z9 = shVar.b;
                b2 = this.c.f() - (((this.i - 1) - snVar.e) * this.k);
                j2 = b2 - this.c.b(view);
            } else {
                boolean z10 = shVar.b;
                j2 = this.c.j() + (snVar.e * this.k);
                b2 = this.c.b(view) + j2;
            }
            if (this.j == 1) {
                aB(view, j2, b, b2, c);
            } else {
                aB(view, b, j2, c, b2);
            }
            boolean z11 = shVar.b;
            aP(snVar, this.l.e, i);
            aK(rjVar, this.l);
            if (this.l.h && view.hasFocusable()) {
                boolean z12 = shVar.b;
                i15 = 0;
                this.m.set(snVar.e, false);
                rrVar2 = rrVar;
                i16 = 1;
                z = true;
            } else {
                rrVar2 = rrVar;
                i16 = 1;
                z = true;
                i15 = 0;
            }
        }
        if (!z) {
            aK(rjVar, this.l);
        }
        if (this.l.e == -1) {
            R = this.b.j() - V(this.b.j());
        } else {
            R = R(this.b.f()) - this.b.f();
        }
        if (R > 0) {
            return Math.min(pgVar.b, R);
        }
        return 0;
    }

    private final int R(int i) {
        sn snVar = this.a[0];
        int i2 = snVar.c;
        if (i2 == Integer.MIN_VALUE) {
            if (snVar.a.size() == 0) {
                i2 = i;
            } else {
                snVar.e();
                i2 = snVar.c;
            }
        }
        for (int i3 = 1; i3 < this.i; i3++) {
            sn snVar2 = this.a[i3];
            int i4 = snVar2.c;
            if (i4 == Integer.MIN_VALUE) {
                if (snVar2.a.size() == 0) {
                    i4 = i;
                } else {
                    snVar2.e();
                    i4 = snVar2.c;
                }
            }
            if (i4 > i2) {
                i2 = i4;
            }
        }
        return i2;
    }

    private final int V(int i) {
        int c = this.a[0].c(i);
        for (int i2 = 1; i2 < this.i; i2++) {
            int c2 = this.a[i2].c(i);
            if (c2 < c) {
                c = c2;
            }
        }
        return c;
    }

    private final void aH(rj rjVar, rr rrVar, boolean z) {
        int j;
        int V = V(Integer.MAX_VALUE);
        if (V != Integer.MAX_VALUE && (j = V - this.b.j()) > 0) {
            int c = j - c(j, rjVar, rrVar);
            if (z && c > 0) {
                this.b.n(-c);
            }
        }
    }

    /* JADX WARN: Removed duplicated region for block: B:26:0x00e7  */
    /* JADX WARN: Removed duplicated region for block: B:27:0x00f1  */
    /* JADX WARN: Removed duplicated region for block: B:28:0x009b  */
    /* JADX WARN: Removed duplicated region for block: B:49:0x0100  */
    /* JADX WARN: Removed duplicated region for block: B:54:0x0120  */
    /* JADX WARN: Removed duplicated region for block: B:85:? A[RETURN, SYNTHETIC] */
    /* JADX WARN: Removed duplicated region for block: B:87:0x0117  */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct code enable 'Show inconsistent code' option in preferences
    */
    private final void aI(int r13, int r14, int r15) {
        /*
            Method dump skipped, instructions count: 410
            To view this dump change 'Code comments level' option to 'DEBUG'
        */
        throw new UnsupportedOperationException("Method not decompiled: android.support.v7.widget.StaggeredGridLayoutManager.aI(int, int, int):void");
    }

    /* JADX WARN: Code restructure failed: missing block: B:183:0x02e3, code lost:
    
        if (r7 != r12.p) goto L189;
     */
    /* JADX WARN: Removed duplicated region for block: B:348:0x05ab  */
    /* JADX WARN: Removed duplicated region for block: B:351:0x05bd  */
    /* JADX WARN: Removed duplicated region for block: B:354:0x05c2  */
    /* JADX WARN: Removed duplicated region for block: B:357:? A[RETURN, SYNTHETIC] */
    /* JADX WARN: Removed duplicated region for block: B:71:0x0160  */
    /* JADX WARN: Removed duplicated region for block: B:75:0x018c  */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct code enable 'Show inconsistent code' option in preferences
    */
    private final void aJ(cal.rj r13, cal.rr r14, boolean r15) {
        /*
            Method dump skipped, instructions count: 1490
            To view this dump change 'Code comments level' option to 'DEBUG'
        */
        throw new UnsupportedOperationException("Method not decompiled: android.support.v7.widget.StaggeredGridLayoutManager.aJ(cal.rj, cal.rr, boolean):void");
    }

    private final void aK(rj rjVar, pg pgVar) {
        int min;
        int min2;
        if (pgVar.a && !pgVar.i) {
            if (pgVar.b == 0) {
                if (pgVar.e == -1) {
                    aL(rjVar, pgVar.g);
                    return;
                } else {
                    aM(rjVar, pgVar.f);
                    return;
                }
            }
            int i = 1;
            if (pgVar.e == -1) {
                int i2 = pgVar.f;
                int c = this.a[0].c(i2);
                while (i < this.i) {
                    int c2 = this.a[i].c(i2);
                    if (c2 > c) {
                        c = c2;
                    }
                    i++;
                }
                int i3 = i2 - c;
                if (i3 < 0) {
                    min2 = pgVar.g;
                } else {
                    min2 = pgVar.g - Math.min(i3, pgVar.b);
                }
                aL(rjVar, min2);
                return;
            }
            int i4 = pgVar.g;
            sn snVar = this.a[0];
            int i5 = snVar.c;
            if (i5 == Integer.MIN_VALUE) {
                if (snVar.a.size() == 0) {
                    i5 = i4;
                } else {
                    snVar.e();
                    i5 = snVar.c;
                }
            }
            while (i < this.i) {
                sn snVar2 = this.a[i];
                int i6 = snVar2.c;
                if (i6 == Integer.MIN_VALUE) {
                    if (snVar2.a.size() == 0) {
                        i6 = i4;
                    } else {
                        snVar2.e();
                        i6 = snVar2.c;
                    }
                }
                if (i6 < i5) {
                    i5 = i6;
                }
                i++;
            }
            int i7 = i5 - pgVar.g;
            if (i7 < 0) {
                min = pgVar.f;
            } else {
                min = Math.min(i7, pgVar.b) + pgVar.f;
            }
            aM(rjVar, min);
        }
    }

    private final void aL(rj rjVar, int i) {
        int i2;
        View view;
        nw nwVar = this.t;
        if (nwVar != null) {
            i2 = nwVar.e.a.getChildCount() - nwVar.b.size();
        } else {
            i2 = 0;
        }
        while (true) {
            i2--;
            if (i2 >= 0) {
                nw nwVar2 = this.t;
                if (nwVar2 != null) {
                    view = nwVar2.e.a.getChildAt(nwVar2.a(i2));
                } else {
                    view = null;
                }
                if (this.b.d(view) >= i && this.b.m(view) >= i) {
                    sh shVar = (sh) view.getLayoutParams();
                    boolean z = shVar.b;
                    if (shVar.a.a.size() != 1) {
                        sn snVar = shVar.a;
                        int size = snVar.a.size();
                        View view2 = (View) snVar.a.remove(size - 1);
                        sh shVar2 = (sh) view2.getLayoutParams();
                        shVar2.a = null;
                        int i3 = shVar2.c.j;
                        if ((i3 & 8) != 0 || (i3 & 2) != 0) {
                            snVar.d -= snVar.f.b.b(view2);
                        }
                        if (size == 1) {
                            snVar.b = Integer.MIN_VALUE;
                        }
                        snVar.c = Integer.MIN_VALUE;
                        this.t.e(view);
                        rjVar.e(view);
                    } else {
                        return;
                    }
                } else {
                    return;
                }
            } else {
                return;
            }
        }
    }

    private final void aM(rj rjVar, int i) {
        View view;
        while (true) {
            nw nwVar = this.t;
            if (nwVar != null) {
                if (nwVar.e.a.getChildCount() - nwVar.b.size() > 0) {
                    nw nwVar2 = this.t;
                    if (nwVar2 != null) {
                        view = nwVar2.e.a.getChildAt(nwVar2.a(0));
                    } else {
                        view = null;
                    }
                    if (this.b.a(view) <= i && this.b.l(view) <= i) {
                        sh shVar = (sh) view.getLayoutParams();
                        boolean z = shVar.b;
                        if (shVar.a.a.size() != 1) {
                            sn snVar = shVar.a;
                            View view2 = (View) snVar.a.remove(0);
                            sh shVar2 = (sh) view2.getLayoutParams();
                            shVar2.a = null;
                            if (snVar.a.size() == 0) {
                                snVar.c = Integer.MIN_VALUE;
                            }
                            int i2 = shVar2.c.j;
                            if ((i2 & 8) != 0 || (i2 & 2) != 0) {
                                snVar.d -= snVar.f.b.b(view2);
                            }
                            snVar.b = Integer.MIN_VALUE;
                            this.t.e(view);
                            rjVar.e(view);
                        } else {
                            return;
                        }
                    } else {
                        return;
                    }
                } else {
                    return;
                }
            } else {
                return;
            }
        }
    }

    private final void aN() {
        boolean z;
        if (this.j != 1 && this.u.getLayoutDirection() == 1) {
            z = !this.d;
        } else {
            z = this.d;
        }
        this.e = z;
    }

    private final void aO(int i, rr rrVar) {
        int i2;
        int i3;
        int i4;
        boolean z;
        pg pgVar = this.l;
        boolean z2 = false;
        pgVar.b = 0;
        pgVar.c = i;
        rq rqVar = this.x;
        if (rqVar != null && rqVar.n && (i4 = rrVar.a) != -1) {
            boolean z3 = this.e;
            if (i4 >= i) {
                z = false;
            } else {
                z = true;
            }
            if (z3 == z) {
                i2 = this.b.k();
                i3 = 0;
            } else {
                i3 = this.b.k();
                i2 = 0;
            }
        } else {
            i2 = 0;
            i3 = 0;
        }
        RecyclerView recyclerView = this.u;
        if (recyclerView != null && recyclerView.i) {
            this.l.f = this.b.j() - i3;
            this.l.g = this.b.f() + i2;
        } else {
            this.l.g = this.b.e() + i2;
            this.l.f = -i3;
        }
        pg pgVar2 = this.l;
        pgVar2.h = false;
        pgVar2.a = true;
        if (this.b.h() == 0 && this.b.e() == 0) {
            z2 = true;
        }
        pgVar2.i = z2;
    }

    private final void aP(sn snVar, int i, int i2) {
        int i3 = snVar.d;
        if (i == -1) {
            int i4 = snVar.b;
            if (i4 == Integer.MIN_VALUE) {
                View view = (View) snVar.a.get(0);
                sh shVar = (sh) view.getLayoutParams();
                i4 = snVar.f.b.d(view);
                snVar.b = i4;
                boolean z = shVar.b;
            }
            if (i4 + i3 <= i2) {
                this.m.set(snVar.e, false);
                return;
            }
            return;
        }
        int i5 = snVar.c;
        if (i5 == Integer.MIN_VALUE) {
            snVar.e();
            i5 = snVar.c;
        }
        if (i5 - i3 >= i2) {
            this.m.set(snVar.e, false);
        }
    }

    private final boolean aQ(int i) {
        boolean z;
        boolean z2;
        boolean z3;
        int i2 = this.j;
        if (i != -1) {
            z = false;
        } else {
            z = true;
        }
        if (i2 == 0) {
            if (z == this.e) {
                return false;
            }
            return true;
        }
        if (z != this.e) {
            z2 = false;
        } else {
            z2 = true;
        }
        if (this.u.getLayoutDirection() != 1) {
            z3 = false;
        } else {
            z3 = true;
        }
        if (z2 != z3) {
            return false;
        }
        return true;
    }

    private final void aR(View view, int i, int i2) {
        Rect rect = this.r;
        RecyclerView recyclerView = this.u;
        if (recyclerView == null) {
            rect.set(0, 0, 0, 0);
        } else {
            rect.set(recyclerView.bA(view));
        }
        sh shVar = (sh) view.getLayoutParams();
        int aS = aS(i, shVar.leftMargin + this.r.left, shVar.rightMargin + this.r.right);
        int aS2 = aS(i2, shVar.topMargin + this.r.top, shVar.bottomMargin + this.r.bottom);
        if (ay(view, aS, aS2, shVar)) {
            view.measure(aS, aS2);
        }
    }

    private static final int aS(int i, int i2, int i3) {
        if (i2 == 0) {
            if (i3 != 0) {
                i2 = 0;
            }
            return i;
        }
        int mode = View.MeasureSpec.getMode(i);
        if (mode != Integer.MIN_VALUE) {
            if (mode == 1073741824) {
                mode = 1073741824;
            }
            return i;
        }
        return View.MeasureSpec.makeMeasureSpec(Math.max(0, (View.MeasureSpec.getSize(i) - i2) - i3), mode);
    }

    private final void ad(rj rjVar, rr rrVar, boolean z) {
        int f;
        int i;
        int R = R(Integer.MIN_VALUE);
        if (R != Integer.MIN_VALUE && (f = this.b.f() - R) > 0) {
            int i2 = -c(-f, rjVar, rrVar);
            if (z && (i = f - i2) > 0) {
                this.b.n(i);
            }
        }
    }

    /* JADX WARN: Removed duplicated region for block: B:16:0x0054  */
    /* JADX WARN: Removed duplicated region for block: B:19:0x0059 A[RETURN] */
    /* JADX WARN: Removed duplicated region for block: B:21:0x005a A[RETURN] */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct code enable 'Show inconsistent code' option in preferences
    */
    private final int w(int r6) {
        /*
            r5 = this;
            cal.nw r0 = r5.t
            r1 = 1
            r2 = -1
            if (r0 == 0) goto L5b
            cal.qo r3 = r0.e
            java.util.List r0 = r0.b
            android.support.v7.widget.RecyclerView r3 = r3.a
            int r3 = r3.getChildCount()
            int r0 = r0.size()
            int r3 = r3 - r0
            if (r3 != 0) goto L18
            goto L5b
        L18:
            cal.nw r0 = r5.t
            r3 = 0
            if (r0 == 0) goto L50
            cal.qo r4 = r0.e
            java.util.List r0 = r0.b
            android.support.v7.widget.RecyclerView r4 = r4.a
            int r4 = r4.getChildCount()
            int r0 = r0.size()
            int r4 = r4 - r0
            if (r4 != 0) goto L2f
            goto L50
        L2f:
            cal.nw r0 = r5.t
            if (r0 == 0) goto L40
            int r4 = r0.a(r3)
            cal.qo r0 = r0.e
            android.support.v7.widget.RecyclerView r0 = r0.a
            android.view.View r0 = r0.getChildAt(r4)
            goto L41
        L40:
            r0 = 0
        L41:
            android.view.ViewGroup$LayoutParams r0 = r0.getLayoutParams()
            cal.rd r0 = (cal.rd) r0
            cal.rt r0 = r0.c
            int r4 = r0.g
            if (r4 != r2) goto L51
            int r4 = r0.c
            goto L51
        L50:
            r4 = r3
        L51:
            if (r6 < r4) goto L54
            goto L55
        L54:
            r3 = r1
        L55:
            boolean r6 = r5.e
            if (r3 == r6) goto L5a
            return r2
        L5a:
            return r1
        L5b:
            boolean r6 = r5.e
            if (r6 == 0) goto L60
            return r1
        L60:
            return r2
        */
        throw new UnsupportedOperationException("Method not decompiled: android.support.v7.widget.StaggeredGridLayoutManager.w(int):int");
    }

    @Override // cal.rc
    public final void A(int i, int i2) {
        aI(i, i2, 2);
    }

    @Override // cal.rc
    public final void B() {
        this.f = -1;
        this.g = Integer.MIN_VALUE;
        this.q = null;
        this.s.a();
    }

    @Override // cal.rc
    public final void C(int i, int i2) {
        aI(i, i2, 4);
    }

    @Override // cal.rc
    public final int D(rr rrVar) {
        return J(rrVar);
    }

    @Override // cal.rc
    public final int E(rr rrVar) {
        return K(rrVar);
    }

    @Override // cal.rc
    public final int F(rr rrVar) {
        return L(rrVar);
    }

    @Override // cal.rc
    public final int G(rr rrVar) {
        return J(rrVar);
    }

    @Override // cal.rc
    public final int H(rr rrVar) {
        return K(rrVar);
    }

    @Override // cal.rc
    public final int I(rr rrVar) {
        return L(rrVar);
    }

    @Override // cal.rp
    public final PointF M(int i) {
        int w = w(i);
        PointF pointF = new PointF();
        if (w == 0) {
            return null;
        }
        float f = w;
        if (this.j == 0) {
            pointF.x = f;
            pointF.y = 0.0f;
        } else {
            pointF.x = 0.0f;
            pointF.y = f;
        }
        return pointF;
    }

    /* JADX WARN: Removed duplicated region for block: B:29:0x00c2  */
    /* JADX WARN: Removed duplicated region for block: B:31:0x00ce  */
    /* JADX WARN: Removed duplicated region for block: B:38:0x00ec  */
    /* JADX WARN: Removed duplicated region for block: B:58:0x00c7  */
    @Override // cal.rc
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct code enable 'Show inconsistent code' option in preferences
    */
    public final android.os.Parcelable N() {
        /*
            Method dump skipped, instructions count: 306
            To view this dump change 'Code comments level' option to 'DEBUG'
        */
        throw new UnsupportedOperationException("Method not decompiled: android.support.v7.widget.StaggeredGridLayoutManager.N():android.os.Parcelable");
    }

    @Override // cal.rc
    public final void Q(String str) {
        RecyclerView recyclerView;
        if (this.q == null && (recyclerView = this.u) != null) {
            recyclerView.o(str);
        }
    }

    @Override // cal.rc
    public final void S(AccessibilityEvent accessibilityEvent) {
        RecyclerView recyclerView = this.u;
        rj rjVar = recyclerView.d;
        rr rrVar = recyclerView.R;
        aE(accessibilityEvent);
        nw nwVar = this.t;
        if (nwVar != null) {
            if (nwVar.e.a.getChildCount() - nwVar.b.size() > 0) {
                View k = k(false);
                View i = i(false);
                if (k != null && i != null) {
                    rt rtVar = ((rd) k.getLayoutParams()).c;
                    int i2 = rtVar.g;
                    if (i2 == -1) {
                        i2 = rtVar.c;
                    }
                    rt rtVar2 = ((rd) i.getLayoutParams()).c;
                    int i3 = rtVar2.g;
                    if (i3 == -1) {
                        i3 = rtVar2.c;
                    }
                    if (i2 < i3) {
                        accessibilityEvent.setFromIndex(i2);
                        accessibilityEvent.setToIndex(i3);
                    } else {
                        accessibilityEvent.setFromIndex(i3);
                        accessibilityEvent.setToIndex(i2);
                    }
                }
            }
        }
    }

    @Override // cal.rc
    public final void T(Parcelable parcelable) {
        if (parcelable instanceof sm) {
            sm smVar = (sm) parcelable;
            this.q = smVar;
            if (this.f != -1) {
                smVar.d = null;
                smVar.c = 0;
                smVar.a = -1;
                smVar.b = -1;
                smVar.e = 0;
                smVar.f = null;
                smVar.g = null;
            }
            RecyclerView recyclerView = this.u;
            if (recyclerView != null) {
                recyclerView.requestLayout();
            }
        }
    }

    @Override // cal.rc
    public final void U(int i) {
        sm smVar = this.q;
        if (smVar != null && smVar.a != i) {
            smVar.d = null;
            smVar.c = 0;
            smVar.a = -1;
            smVar.b = -1;
        }
        this.f = i;
        this.g = Integer.MIN_VALUE;
        RecyclerView recyclerView = this.u;
        if (recyclerView != null) {
            recyclerView.requestLayout();
        }
    }

    @Override // cal.rc
    public final boolean W() {
        if (this.j == 0) {
            return true;
        }
        return false;
    }

    @Override // cal.rc
    public final boolean X() {
        if (this.j == 1) {
            return true;
        }
        return false;
    }

    @Override // cal.rc
    public final boolean Y() {
        if (this.n != 0) {
            return true;
        }
        return false;
    }

    @Override // cal.rc
    public final boolean Z() {
        return this.d;
    }

    @Override // cal.rc
    public final void aD() {
        sk skVar = this.h;
        int[] iArr = skVar.a;
        if (iArr != null) {
            Arrays.fill(iArr, -1);
        }
        skVar.b = null;
        for (int i = 0; i < this.i; i++) {
            sn snVar = this.a[i];
            snVar.a.clear();
            snVar.b = Integer.MIN_VALUE;
            snVar.c = Integer.MIN_VALUE;
            snVar.d = 0;
        }
    }

    /* JADX WARN: Code restructure failed: missing block: B:12:0x002a, code lost:
    
        if (r6.length < r5.i) goto L15;
     */
    @Override // cal.rc
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct code enable 'Show inconsistent code' option in preferences
    */
    public final void ab(int r6, int r7, cal.rr r8, cal.pa r9) {
        /*
            r5 = this;
            r0 = 1
            int r1 = r5.j
            if (r0 != r1) goto L6
            r6 = r7
        L6:
            cal.nw r7 = r5.t
            if (r7 == 0) goto La4
            java.util.List r0 = r7.b
            cal.qo r7 = r7.e
            android.support.v7.widget.RecyclerView r7 = r7.a
            int r7 = r7.getChildCount()
            int r0 = r0.size()
            int r7 = r7 - r0
            if (r7 == 0) goto La4
            if (r6 != 0) goto L1f
            goto La4
        L1f:
            r5.q(r6, r8)
            int[] r6 = r5.K
            r7 = 0
            if (r6 == 0) goto L2c
            int r0 = r5.i
            int r6 = r6.length
            if (r6 >= r0) goto L32
        L2c:
            int r6 = r5.i
            int[] r6 = new int[r6]
            r5.K = r6
        L32:
            r6 = r7
            r0 = r6
        L34:
            int r1 = r5.i
            if (r6 >= r1) goto L76
            cal.pg r1 = r5.l
            int r2 = r1.d
            r3 = -1
            if (r2 != r3) goto L4b
            int r1 = r1.f
            cal.sn[] r2 = r5.a
            r2 = r2[r6]
            int r2 = r2.c(r1)
        L49:
            int r1 = r1 - r2
            goto L6b
        L4b:
            cal.sn[] r2 = r5.a
            r2 = r2[r6]
            int r1 = r1.g
            int r3 = r2.c
            r4 = -2147483648(0xffffffff80000000, float:-0.0)
            if (r3 == r4) goto L59
            r1 = r3
            goto L66
        L59:
            java.util.ArrayList r3 = r2.a
            int r3 = r3.size()
            if (r3 == 0) goto L66
            r2.e()
            int r1 = r2.c
        L66:
            cal.pg r2 = r5.l
            int r2 = r2.g
            goto L49
        L6b:
            if (r1 < 0) goto L73
            int[] r2 = r5.K
            r2[r0] = r1
            int r0 = r0 + 1
        L73:
            int r6 = r6 + 1
            goto L34
        L76:
            int[] r6 = r5.K
            java.util.Arrays.sort(r6, r7, r0)
        L7b:
            if (r7 >= r0) goto La4
            cal.pg r6 = r5.l
            int r6 = r6.c
            if (r6 < 0) goto La4
            boolean r1 = r8.g
            if (r1 == 0) goto L8d
            int r1 = r8.b
            int r2 = r8.c
            int r1 = r1 - r2
            goto L8f
        L8d:
            int r1 = r8.e
        L8f:
            if (r6 >= r1) goto La4
            int[] r1 = r5.K
            r1 = r1[r7]
            r9.a(r6, r1)
            cal.pg r6 = r5.l
            int r1 = r6.c
            int r2 = r6.d
            int r1 = r1 + r2
            r6.c = r1
            int r7 = r7 + 1
            goto L7b
        La4:
            return
        */
        throw new UnsupportedOperationException("Method not decompiled: android.support.v7.widget.StaggeredGridLayoutManager.ab(int, int, cal.rr, cal.pa):void");
    }

    @Override // cal.rc
    public final void ae(RecyclerView recyclerView) {
        RecyclerView recyclerView2 = this.u;
        if (recyclerView2 != null) {
            recyclerView2.removeCallbacks(this.L);
        }
        for (int i = 0; i < this.i; i++) {
            sn snVar = this.a[i];
            snVar.a.clear();
            snVar.b = Integer.MIN_VALUE;
            snVar.c = Integer.MIN_VALUE;
            snVar.d = 0;
        }
        recyclerView.requestLayout();
    }

    @Override // cal.rc
    public final void af(RecyclerView recyclerView, int i) {
        po poVar = new po(recyclerView.getContext());
        poVar.j = i;
        aw(poVar);
    }

    @Override // cal.rc
    public final void am(int i) {
        RecyclerView recyclerView = this.u;
        if (recyclerView != null) {
            recyclerView.H(i);
        }
        for (int i2 = 0; i2 < this.i; i2++) {
            sn snVar = this.a[i2];
            int i3 = snVar.b;
            if (i3 != Integer.MIN_VALUE) {
                snVar.b = i3 + i;
            }
            int i4 = snVar.c;
            if (i4 != Integer.MIN_VALUE) {
                snVar.c = i4 + i;
            }
        }
    }

    @Override // cal.rc
    public final void an(int i) {
        RecyclerView recyclerView = this.u;
        if (recyclerView != null) {
            recyclerView.I(i);
        }
        for (int i2 = 0; i2 < this.i; i2++) {
            sn snVar = this.a[i2];
            int i3 = snVar.b;
            if (i3 != Integer.MIN_VALUE) {
                snVar.b = i3 + i;
            }
            int i4 = snVar.c;
            if (i4 != Integer.MIN_VALUE) {
                snVar.c = i4 + i;
            }
        }
    }

    @Override // cal.rc
    public final void aq(int i) {
        if (i == 0) {
            v();
        }
    }

    @Override // cal.rc
    public final int bG(rj rjVar, rr rrVar) {
        int i;
        if (this.j == 1) {
            int i2 = this.i;
            if (rrVar.g) {
                i = rrVar.b - rrVar.c;
            } else {
                i = rrVar.e;
            }
            return Math.min(i2, i);
        }
        return -1;
    }

    @Override // cal.rc
    public final int bH(rj rjVar, rr rrVar) {
        int i;
        if (this.j == 0) {
            int i2 = this.i;
            if (rrVar.g) {
                i = rrVar.b - rrVar.c;
            } else {
                i = rrVar.e;
            }
            return Math.min(i2, i);
        }
        return -1;
    }

    final int c(int i, rj rjVar, rr rrVar) {
        nw nwVar = this.t;
        if (nwVar != null) {
            if (nwVar.e.a.getChildCount() - nwVar.b.size() != 0 && i != 0) {
                q(i, rrVar);
                int O = O(rjVar, this.l, rrVar);
                if (this.l.b >= O) {
                    if (i < 0) {
                        i = -O;
                    } else {
                        i = O;
                    }
                }
                this.b.n(-i);
                this.o = this.e;
                pg pgVar = this.l;
                pgVar.b = 0;
                aK(rjVar, pgVar);
                return i;
            }
        }
        return 0;
    }

    @Override // cal.rc
    public final rd cN(ViewGroup.LayoutParams layoutParams) {
        if (layoutParams instanceof ViewGroup.MarginLayoutParams) {
            return new sh((ViewGroup.MarginLayoutParams) layoutParams);
        }
        return new sh(layoutParams);
    }

    /* JADX WARN: Code restructure failed: missing block: B:136:0x0049, code lost:
    
        if (r10.j == 1) goto L43;
     */
    /* JADX WARN: Code restructure failed: missing block: B:139:0x004e, code lost:
    
        if (r10.j == 0) goto L43;
     */
    /* JADX WARN: Code restructure failed: missing block: B:143:0x005d, code lost:
    
        if (r10.u.getLayoutDirection() != 1) goto L37;
     */
    /* JADX WARN: Code restructure failed: missing block: B:147:0x006c, code lost:
    
        if (r10.u.getLayoutDirection() != 1) goto L43;
     */
    /* JADX WARN: Removed duplicated region for block: B:101:0x016e  */
    /* JADX WARN: Removed duplicated region for block: B:102:0x014a  */
    /* JADX WARN: Removed duplicated region for block: B:114:0x0103  */
    /* JADX WARN: Removed duplicated region for block: B:115:0x00f8  */
    /* JADX WARN: Removed duplicated region for block: B:38:0x00f6  */
    /* JADX WARN: Removed duplicated region for block: B:41:0x0101  */
    /* JADX WARN: Removed duplicated region for block: B:44:0x012a A[ADDED_TO_REGION] */
    /* JADX WARN: Removed duplicated region for block: B:48:0x0134  */
    /* JADX WARN: Removed duplicated region for block: B:61:0x0166  */
    /* JADX WARN: Removed duplicated region for block: B:63:0x0169  */
    /* JADX WARN: Removed duplicated region for block: B:66:0x0178 A[ADDED_TO_REGION] */
    /* JADX WARN: Removed duplicated region for block: B:70:0x0182  */
    /* JADX WARN: Removed duplicated region for block: B:87:0x01ab A[LOOP:2: B:87:0x01ab->B:97:0x01cc, LOOP_START, PHI: r4
  0x01ab: PHI (r4v2 int) = (r4v1 int), (r4v3 int) binds: [B:69:0x0180, B:97:0x01cc] A[DONT_GENERATE, DONT_INLINE]] */
    @Override // cal.rc
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct code enable 'Show inconsistent code' option in preferences
    */
    public final android.view.View cO(android.view.View r11, int r12, cal.rj r13, cal.rr r14) {
        /*
            Method dump skipped, instructions count: 464
            To view this dump change 'Code comments level' option to 'DEBUG'
        */
        throw new UnsupportedOperationException("Method not decompiled: android.support.v7.widget.StaggeredGridLayoutManager.cO(android.view.View, int, cal.rj, cal.rr):android.view.View");
    }

    @Override // cal.rc
    public final void cP(rj rjVar, rr rrVar, aob aobVar) {
        super.cP(rjVar, rrVar, aobVar);
        aobVar.a.setClassName("android.support.v7.widget.StaggeredGridLayoutManager");
    }

    @Override // cal.rc
    public final void cQ(rj rjVar, rr rrVar, View view, aob aobVar) {
        ViewGroup.LayoutParams layoutParams = view.getLayoutParams();
        if (!(layoutParams instanceof sh)) {
            super.ap(view, aobVar);
            return;
        }
        sh shVar = (sh) layoutParams;
        int i = -1;
        if (this.j == 0) {
            sn snVar = shVar.a;
            if (snVar != null) {
                i = snVar.e;
            }
            boolean z = shVar.b;
            aobVar.a.setCollectionItemInfo(AccessibilityNodeInfo.CollectionItemInfo.obtain(i, 1, -1, -1, false, false));
            return;
        }
        sn snVar2 = shVar.a;
        if (snVar2 != null) {
            i = snVar2.e;
        }
        boolean z2 = shVar.b;
        aobVar.a.setCollectionItemInfo(AccessibilityNodeInfo.CollectionItemInfo.obtain(-1, -1, i, 1, false, false));
    }

    /* JADX WARN: Removed duplicated region for block: B:35:0x00bb  */
    /* JADX WARN: Removed duplicated region for block: B:37:0x00c2  */
    @Override // cal.rc
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct code enable 'Show inconsistent code' option in preferences
    */
    public final void cR(android.graphics.Rect r7, int r8, int r9) {
        /*
            r6 = this;
            android.support.v7.widget.RecyclerView r0 = r6.u
            r1 = 0
            if (r0 == 0) goto La
            int r0 = r0.getPaddingLeft()
            goto Lb
        La:
            r0 = r1
        Lb:
            android.support.v7.widget.RecyclerView r2 = r6.u
            if (r2 == 0) goto L14
            int r2 = r2.getPaddingRight()
            goto L15
        L14:
            r2 = r1
        L15:
            int r0 = r0 + r2
            android.support.v7.widget.RecyclerView r2 = r6.u
            if (r2 == 0) goto L1f
            int r2 = r2.getPaddingTop()
            goto L20
        L1f:
            r2 = r1
        L20:
            android.support.v7.widget.RecyclerView r3 = r6.u
            if (r3 == 0) goto L28
            int r1 = r3.getPaddingBottom()
        L28:
            int r2 = r2 + r1
            int r1 = r6.j
            r3 = 1
            r4 = 1073741824(0x40000000, float:2.0)
            r5 = -2147483648(0xffffffff80000000, float:-0.0)
            if (r1 != r3) goto L7e
            int r7 = r7.height()
            int r7 = r7 + r2
            android.support.v7.widget.RecyclerView r1 = r6.u
            int[] r2 = cal.ame.a
            int r1 = r1.getMinimumHeight()
            int r2 = android.view.View.MeasureSpec.getMode(r9)
            int r9 = android.view.View.MeasureSpec.getSize(r9)
            if (r2 == r5) goto L50
            if (r2 == r4) goto L58
            int r9 = java.lang.Math.max(r7, r1)
            goto L58
        L50:
            int r7 = java.lang.Math.max(r7, r1)
            int r9 = java.lang.Math.min(r9, r7)
        L58:
            int r7 = r6.k
            int r1 = r6.i
            int r7 = r7 * r1
            int r7 = r7 + r0
            android.support.v7.widget.RecyclerView r0 = r6.u
            int r0 = r0.getMinimumWidth()
            int r1 = android.view.View.MeasureSpec.getMode(r8)
            int r8 = android.view.View.MeasureSpec.getSize(r8)
            if (r1 == r5) goto L75
            if (r1 == r4) goto Lca
            int r8 = java.lang.Math.max(r7, r0)
            goto Lca
        L75:
            int r7 = java.lang.Math.max(r7, r0)
            int r8 = java.lang.Math.min(r8, r7)
            goto Lca
        L7e:
            int r7 = r7.width()
            int r7 = r7 + r0
            android.support.v7.widget.RecyclerView r0 = r6.u
            int[] r1 = cal.ame.a
            int r0 = r0.getMinimumWidth()
            int r1 = android.view.View.MeasureSpec.getMode(r8)
            int r8 = android.view.View.MeasureSpec.getSize(r8)
            if (r1 == r5) goto L9c
            if (r1 == r4) goto La5
            int r7 = java.lang.Math.max(r7, r0)
            goto La4
        L9c:
            int r7 = java.lang.Math.max(r7, r0)
            int r7 = java.lang.Math.min(r8, r7)
        La4:
            r8 = r7
        La5:
            int r7 = r6.k
            int r0 = r6.i
            int r7 = r7 * r0
            int r7 = r7 + r2
            android.support.v7.widget.RecyclerView r0 = r6.u
            int r0 = r0.getMinimumHeight()
            int r1 = android.view.View.MeasureSpec.getMode(r9)
            int r9 = android.view.View.MeasureSpec.getSize(r9)
            if (r1 == r5) goto Lc2
            if (r1 == r4) goto Lca
            int r9 = java.lang.Math.max(r7, r0)
            goto Lca
        Lc2:
            int r7 = java.lang.Math.max(r7, r0)
            int r9 = java.lang.Math.min(r9, r7)
        Lca:
            android.support.v7.widget.RecyclerView r7 = r6.u
            android.support.v7.widget.RecyclerView.m(r7, r8, r9)
            return
        */
        throw new UnsupportedOperationException("Method not decompiled: android.support.v7.widget.StaggeredGridLayoutManager.cR(android.graphics.Rect, int, int):void");
    }

    @Override // cal.rc
    public final boolean cT() {
        if (this.q == null) {
            return true;
        }
        return false;
    }

    @Override // cal.rc
    public final void cU() {
        sk skVar = this.h;
        int[] iArr = skVar.a;
        if (iArr != null) {
            Arrays.fill(iArr, -1);
        }
        skVar.b = null;
        RecyclerView recyclerView = this.u;
        if (recyclerView != null) {
            recyclerView.requestLayout();
        }
    }

    @Override // cal.rc
    public final int d(int i, rj rjVar, rr rrVar) {
        return c(i, rjVar, rrVar);
    }

    @Override // cal.rc
    public final int e(int i, rj rjVar, rr rrVar) {
        return c(i, rjVar, rrVar);
    }

    @Override // cal.rc
    public final rd f() {
        if (this.j == 0) {
            return new sh(-2, -1);
        }
        return new sh(-1, -2);
    }

    @Override // cal.rc
    public final rd h(Context context, AttributeSet attributeSet) {
        return new sh(context, attributeSet);
    }

    final View i(boolean z) {
        int i;
        View view;
        int j = this.b.j();
        int f = this.b.f();
        nw nwVar = this.t;
        if (nwVar != null) {
            i = nwVar.e.a.getChildCount() - nwVar.b.size();
        } else {
            i = 0;
        }
        View view2 = null;
        for (int i2 = i - 1; i2 >= 0; i2--) {
            nw nwVar2 = this.t;
            if (nwVar2 != null) {
                view = nwVar2.e.a.getChildAt(nwVar2.a(i2));
            } else {
                view = null;
            }
            int d = this.b.d(view);
            int a = this.b.a(view);
            if (a > j && d < f) {
                if (a > f && z) {
                    if (view2 == null) {
                        view2 = view;
                    }
                } else {
                    return view;
                }
            }
        }
        return view2;
    }

    final View k(boolean z) {
        int i;
        View view;
        int j = this.b.j();
        int f = this.b.f();
        nw nwVar = this.t;
        if (nwVar != null) {
            i = nwVar.e.a.getChildCount() - nwVar.b.size();
        } else {
            i = 0;
        }
        View view2 = null;
        for (int i2 = 0; i2 < i; i2++) {
            nw nwVar2 = this.t;
            if (nwVar2 != null) {
                view = nwVar2.e.a.getChildAt(nwVar2.a(i2));
            } else {
                view = null;
            }
            int d = this.b.d(view);
            if (this.b.a(view) > j && d < f) {
                if (d < j && z) {
                    if (view2 == null) {
                        view2 = view;
                    }
                } else {
                    return view;
                }
            }
        }
        return view2;
    }

    /* JADX WARN: Removed duplicated region for block: B:56:0x0122  */
    /* JADX WARN: Removed duplicated region for block: B:58:0x0127  */
    /* JADX WARN: Removed duplicated region for block: B:60:0x012e A[SYNTHETIC] */
    /* JADX WARN: Removed duplicated region for block: B:62:0x0041 A[SYNTHETIC] */
    /* JADX WARN: Removed duplicated region for block: B:64:0x0129  */
    /* JADX WARN: Removed duplicated region for block: B:65:0x0124  */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct code enable 'Show inconsistent code' option in preferences
    */
    final android.view.View l() {
        /*
            Method dump skipped, instructions count: 304
            To view this dump change 'Code comments level' option to 'DEBUG'
        */
        throw new UnsupportedOperationException("Method not decompiled: android.support.v7.widget.StaggeredGridLayoutManager.l():android.view.View");
    }

    @Override // cal.rc
    public final void o(rj rjVar, rr rrVar) {
        aJ(rjVar, rrVar, true);
    }

    final void q(int i, rr rrVar) {
        int i2;
        int i3;
        int i4;
        View view = null;
        int i5 = 1;
        boolean z = false;
        if (i > 0) {
            nw nwVar = this.t;
            if (nwVar != null) {
                i4 = nwVar.e.a.getChildCount() - nwVar.b.size();
            } else {
                i4 = 0;
            }
            if (i4 == 0) {
                i2 = 0;
            } else {
                int i6 = i4 - 1;
                nw nwVar2 = this.t;
                if (nwVar2 != null) {
                    view = nwVar2.e.a.getChildAt(nwVar2.a(i6));
                }
                rt rtVar = ((rd) view.getLayoutParams()).c;
                i2 = rtVar.g;
                if (i2 == -1) {
                    i2 = rtVar.c;
                }
            }
            i3 = 1;
        } else {
            nw nwVar3 = this.t;
            if (nwVar3 != null) {
                if (nwVar3.e.a.getChildCount() - nwVar3.b.size() != 0) {
                    nw nwVar4 = this.t;
                    if (nwVar4 != null) {
                        view = nwVar4.e.a.getChildAt(nwVar4.a(0));
                    }
                    rt rtVar2 = ((rd) view.getLayoutParams()).c;
                    i2 = rtVar2.g;
                    if (i2 == -1) {
                        i2 = rtVar2.c;
                    }
                    i3 = -1;
                }
            }
            i2 = 0;
            i3 = -1;
        }
        this.l.a = true;
        aO(i2, rrVar);
        pg pgVar = this.l;
        pgVar.e = i3;
        boolean z2 = this.e;
        if (i3 == -1) {
            z = true;
        }
        if (z2 != z) {
            i5 = -1;
        }
        pgVar.d = i5;
        pgVar.c = i2 + i5;
        pgVar.b = Math.abs(i);
    }

    public final void r(boolean z) {
        RecyclerView recyclerView;
        if (this.q == null && (recyclerView = this.u) != null) {
            recyclerView.o(null);
        }
        sm smVar = this.q;
        if (smVar != null && smVar.h != z) {
            smVar.h = z;
        }
        this.d = z;
        RecyclerView recyclerView2 = this.u;
        if (recyclerView2 != null) {
            recyclerView2.requestLayout();
        }
    }

    @Override // cal.rc
    public final boolean s(rd rdVar) {
        return rdVar instanceof sh;
    }

    /* JADX WARN: Removed duplicated region for block: B:58:0x00d4  */
    /* JADX WARN: Removed duplicated region for block: B:60:0x00e7  */
    /* JADX WARN: Removed duplicated region for block: B:67:0x00e4  */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct code enable 'Show inconsistent code' option in preferences
    */
    public final boolean v() {
        /*
            Method dump skipped, instructions count: 295
            To view this dump change 'Code comments level' option to 'DEBUG'
        */
        throw new UnsupportedOperationException("Method not decompiled: android.support.v7.widget.StaggeredGridLayoutManager.v():boolean");
    }

    @Override // cal.rc
    public final void x(int i, int i2) {
        aI(i, i2, 1);
    }

    @Override // cal.rc
    public final void z(int i, int i2) {
        aI(i, i2, 8);
    }
}
