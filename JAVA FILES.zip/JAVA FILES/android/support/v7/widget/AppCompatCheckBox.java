package android.support.v7.widget;

import android.content.Context;
import android.graphics.drawable.Drawable;
import android.text.InputFilter;
import android.util.AttributeSet;
import android.widget.CheckBox;
import cal.mc;
import cal.mg;
import cal.mm;
import cal.nm;
import cal.ry;
import cal.sq;
import cal.ss;
import cal.su;
import com.google.android.calendar.R;

/* compiled from: PG */
/* loaded from: classes.dex */
public class AppCompatCheckBox extends CheckBox {
    public final mg a;
    private final mc b;
    private final nm c;
    private mm d;

    public AppCompatCheckBox(Context context) {
        this(context, null);
    }

    /* JADX INFO: Access modifiers changed from: protected */
    @Override // android.widget.CompoundButton, android.widget.TextView, android.view.View
    public void drawableStateChanged() {
        super.drawableStateChanged();
        mc mcVar = this.b;
        if (mcVar != null) {
            mcVar.a();
        }
        nm nmVar = this.c;
        if (nmVar != null) {
            nmVar.a();
        }
    }

    @Override // android.widget.TextView
    public final void setAllCaps(boolean z) {
        super.setAllCaps(z);
        if (this.d == null) {
            this.d = new mm(this);
        }
        this.d.a.a.c(z);
    }

    @Override // android.view.View
    public void setBackgroundDrawable(Drawable drawable) {
        super.setBackgroundDrawable(drawable);
        mc mcVar = this.b;
        if (mcVar != null) {
            mcVar.a = -1;
            mcVar.b = null;
            mcVar.a();
            mcVar.a();
        }
    }

    @Override // android.view.View
    public void setBackgroundResource(int i) {
        super.setBackgroundResource(i);
        mc mcVar = this.b;
        if (mcVar != null) {
            mcVar.c(i);
        }
    }

    @Override // android.widget.CompoundButton
    public void setButtonDrawable(int i) {
        setButtonDrawable(ry.e().c(getContext(), i));
    }

    @Override // android.widget.TextView
    public void setCompoundDrawables(Drawable drawable, Drawable drawable2, Drawable drawable3, Drawable drawable4) {
        super.setCompoundDrawables(drawable, drawable2, drawable3, drawable4);
        nm nmVar = this.c;
        if (nmVar != null) {
            nmVar.a();
        }
    }

    @Override // android.widget.TextView
    public void setCompoundDrawablesRelative(Drawable drawable, Drawable drawable2, Drawable drawable3, Drawable drawable4) {
        super.setCompoundDrawablesRelative(drawable, drawable2, drawable3, drawable4);
        nm nmVar = this.c;
        if (nmVar != null) {
            nmVar.a();
        }
    }

    @Override // android.widget.TextView
    public final void setFilters(InputFilter[] inputFilterArr) {
        if (this.d == null) {
            this.d = new mm(this);
        }
        super.setFilters(this.d.a.a.d(inputFilterArr));
    }

    public AppCompatCheckBox(Context context, AttributeSet attributeSet) {
        this(context, attributeSet, R.attr.checkboxStyle);
    }

    /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
    public AppCompatCheckBox(Context context, AttributeSet attributeSet, int i) {
        super(context, attributeSet, i);
        if (!(context instanceof ss) && !(context.getResources() instanceof su)) {
            context.getResources();
        }
        sq.b(this, getContext());
        mg mgVar = new mg(this);
        this.a = mgVar;
        mgVar.b(attributeSet, i);
        mc mcVar = new mc(this);
        this.b = mcVar;
        mcVar.b(attributeSet, i);
        nm nmVar = new nm(this);
        this.c = nmVar;
        nmVar.c(attributeSet, i);
        if (this.d == null) {
            this.d = new mm(this);
        }
        this.d.a(attributeSet, i);
    }

    @Override // android.widget.CompoundButton
    public void setButtonDrawable(Drawable drawable) {
        super.setButtonDrawable(drawable);
        mg mgVar = this.a;
        if (mgVar != null) {
            if (mgVar.d) {
                mgVar.d = false;
            } else {
                mgVar.d = true;
                mgVar.a();
            }
        }
    }
}
