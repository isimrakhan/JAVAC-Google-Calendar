package android.support.v7.widget;

import android.R;
import android.animation.ObjectAnimator;
import android.content.Context;
import android.content.res.ColorStateList;
import android.content.res.TypedArray;
import android.graphics.Canvas;
import android.graphics.PorterDuff;
import android.graphics.Rect;
import android.graphics.Region;
import android.graphics.Typeface;
import android.graphics.drawable.Drawable;
import android.os.Build;
import android.os.Handler;
import android.os.Looper;
import android.text.InputFilter;
import android.text.Layout;
import android.text.StaticLayout;
import android.text.TextPaint;
import android.text.TextUtils;
import android.text.method.TransformationMethod;
import android.util.AttributeSet;
import android.util.Property;
import android.view.ActionMode;
import android.view.VelocityTracker;
import android.view.ViewConfiguration;
import android.view.accessibility.AccessibilityEvent;
import android.view.accessibility.AccessibilityNodeInfo;
import android.widget.CompoundButton;
import cal.alo;
import cal.alz;
import cal.apf;
import cal.apg;
import cal.arh;
import cal.arv;
import cal.atf;
import cal.atg;
import cal.atk;
import cal.ia;
import cal.in;
import cal.mm;
import cal.nm;
import cal.ol;
import cal.ry;
import cal.so;
import cal.sp;
import cal.sq;
import cal.sv;

/* compiled from: PG */
/* loaded from: classes.dex */
public class SwitchCompat extends CompoundButton {
    private static final Property u = new so(Float.class);
    private static final int[] v = {R.attr.state_checked};
    private int A;
    private boolean B;
    private int C;
    private int D;
    private float E;
    private float F;
    private VelocityTracker G;
    private int H;
    private int I;
    private int J;
    private int K;
    private int L;
    private int M;
    private int N;
    private int O;
    private final TextPaint P;
    private ColorStateList Q;
    private final nm R;
    private sp S;
    private final Rect T;
    public Drawable a;
    public ColorStateList b;
    public PorterDuff.Mode c;
    public boolean d;
    public Drawable e;
    public ColorStateList f;
    public PorterDuff.Mode g;
    public boolean h;
    public CharSequence i;
    public CharSequence j;
    public CharSequence k;
    public CharSequence l;
    public boolean m;
    public float n;
    public boolean o;
    public Layout p;
    public Layout q;
    public TransformationMethod r;
    ObjectAnimator s;
    public mm t;
    private boolean w;
    private boolean x;
    private int y;
    private int z;

    public SwitchCompat(Context context) {
        this(context, null);
    }

    private final int i() {
        float f;
        if (getLayoutDirection() == 1) {
            f = 1.0f - this.n;
        } else {
            f = this.n;
        }
        return (int) ((f * j()) + 0.5f);
    }

    private final int j() {
        Rect rect;
        Drawable drawable = this.e;
        if (drawable != null) {
            Rect rect2 = this.T;
            drawable.getPadding(rect2);
            Drawable drawable2 = this.a;
            if (drawable2 != null) {
                rect = ol.b(drawable2);
            } else {
                rect = ol.a;
            }
            return ((((this.I - this.K) - rect2.left) - rect2.right) - rect.left) - rect.right;
        }
        return 0;
    }

    private final Layout k(CharSequence charSequence) {
        int i;
        if (charSequence != null) {
            i = (int) Math.ceil(Layout.getDesiredWidth(charSequence, this.P));
        } else {
            i = 0;
        }
        return new StaticLayout(charSequence, this.P, i, Layout.Alignment.ALIGN_NORMAL, 1.0f, 0.0f, true);
    }

    public final void a() {
        Drawable drawable = this.a;
        if (drawable != null) {
            if (this.d || this.w) {
                Drawable mutate = drawable.mutate();
                this.a = mutate;
                if (this.d) {
                    mutate.setTintList(this.b);
                }
                if (this.w) {
                    this.a.setTintMode(this.c);
                }
                if (this.a.isStateful()) {
                    this.a.setState(getDrawableState());
                }
            }
        }
    }

    public final void b() {
        Drawable drawable = this.e;
        if (drawable != null) {
            if (this.h || this.x) {
                Drawable mutate = drawable.mutate();
                this.e = mutate;
                if (this.h) {
                    mutate.setTintList(this.f);
                }
                if (this.x) {
                    this.e.setTintMode(this.g);
                }
                if (this.e.isStateful()) {
                    this.e.setState(getDrawableState());
                }
            }
        }
    }

    public final void c() {
        if (Build.VERSION.SDK_INT >= 30) {
            Object obj = this.k;
            if (obj == null) {
                obj = getResources().getString(com.google.android.calendar.R.string.abc_capital_off);
            }
            new alo(CharSequence.class).e(this, obj);
        }
    }

    public final void d() {
        if (Build.VERSION.SDK_INT >= 30) {
            Object obj = this.i;
            if (obj == null) {
                obj = getResources().getString(com.google.android.calendar.R.string.abc_capital_on);
            }
            new alo(CharSequence.class).e(this, obj);
        }
    }

    @Override // android.view.View
    public final void draw(Canvas canvas) {
        Rect rect;
        int i;
        int i2;
        int i3 = this.L;
        int i4 = this.M;
        int i5 = this.N;
        int i6 = this.O;
        int i7 = i() + i3;
        Drawable drawable = this.a;
        if (drawable != null) {
            rect = ol.b(drawable);
        } else {
            rect = ol.a;
        }
        Rect rect2 = this.T;
        Drawable drawable2 = this.e;
        if (drawable2 != null) {
            drawable2.getPadding(rect2);
            i7 += rect2.left;
            if (rect != null) {
                if (rect.left > rect2.left) {
                    i3 += rect.left - rect2.left;
                }
                if (rect.top > rect2.top) {
                    i = (rect.top - rect2.top) + i4;
                } else {
                    i = i4;
                }
                if (rect.right > rect2.right) {
                    i5 -= rect.right - rect2.right;
                }
                if (rect.bottom > rect2.bottom) {
                    i2 = i6 - (rect.bottom - rect2.bottom);
                    this.e.setBounds(i3, i, i5, i2);
                }
            } else {
                i = i4;
            }
            i2 = i6;
            this.e.setBounds(i3, i, i5, i2);
        }
        Drawable drawable3 = this.a;
        if (drawable3 != null) {
            drawable3.getPadding(rect2);
            int i8 = i7 - rect2.left;
            int i9 = i7 + this.K + rect2.right;
            this.a.setBounds(i8, i4, i9, i6);
            Drawable background = getBackground();
            if (background != null) {
                background.setHotspotBounds(i8, i4, i9, i6);
            }
        }
        super.draw(canvas);
    }

    @Override // android.widget.CompoundButton, android.widget.TextView, android.view.View
    public final void drawableHotspotChanged(float f, float f2) {
        super.drawableHotspotChanged(f, f2);
        Drawable drawable = this.a;
        if (drawable != null) {
            drawable.setHotspot(f, f2);
        }
        Drawable drawable2 = this.e;
        if (drawable2 != null) {
            drawable2.setHotspot(f, f2);
        }
    }

    @Override // android.widget.CompoundButton, android.widget.TextView, android.view.View
    protected final void drawableStateChanged() {
        super.drawableStateChanged();
        int[] drawableState = getDrawableState();
        Drawable drawable = this.a;
        boolean z = false;
        if (drawable != null && drawable.isStateful()) {
            z = drawable.setState(drawableState);
        }
        Drawable drawable2 = this.e;
        if (drawable2 != null && drawable2.isStateful()) {
            z |= drawable2.setState(drawableState);
        }
        if (z) {
            invalidate();
        }
    }

    public final void e(Typeface typeface) {
        if ((this.P.getTypeface() != null && !this.P.getTypeface().equals(typeface)) || (this.P.getTypeface() == null && typeface != null)) {
            this.P.setTypeface(typeface);
            requestLayout();
            invalidate();
        }
    }

    public void f(Drawable drawable) {
        Drawable drawable2 = this.a;
        if (drawable2 != null) {
            drawable2.setCallback(null);
        }
        this.a = drawable;
        if (drawable != null) {
            drawable.setCallback(this);
        }
        requestLayout();
    }

    public void g(Drawable drawable) {
        Drawable drawable2 = this.e;
        if (drawable2 != null) {
            drawable2.setCallback(null);
        }
        this.e = drawable;
        if (drawable != null) {
            drawable.setCallback(this);
        }
        requestLayout();
    }

    @Override // android.widget.CompoundButton, android.widget.TextView
    public final int getCompoundPaddingLeft() {
        if (getLayoutDirection() == 1) {
            int compoundPaddingLeft = super.getCompoundPaddingLeft() + this.I;
            if (!TextUtils.isEmpty(getText())) {
                return compoundPaddingLeft + this.A;
            }
            return compoundPaddingLeft;
        }
        return super.getCompoundPaddingLeft();
    }

    @Override // android.widget.CompoundButton, android.widget.TextView
    public final int getCompoundPaddingRight() {
        if (getLayoutDirection() != 1) {
            int compoundPaddingRight = super.getCompoundPaddingRight() + this.I;
            if (!TextUtils.isEmpty(getText())) {
                return compoundPaddingRight + this.A;
            }
            return compoundPaddingRight;
        }
        return super.getCompoundPaddingRight();
    }

    @Override // android.widget.TextView
    public final ActionMode.Callback getCustomSelectionActionModeCallback() {
        ActionMode.Callback customSelectionActionModeCallback = super.getCustomSelectionActionModeCallback();
        if (customSelectionActionModeCallback instanceof apf) {
            return ((apf) customSelectionActionModeCallback).a;
        }
        return customSelectionActionModeCallback;
    }

    public final void h() {
        arv arvVar;
        Handler handler;
        if (this.S == null && ((atg) this.t.a.a).a.b && arv.b != null) {
            synchronized (arv.a) {
                arvVar = arv.b;
                if (arvVar == null) {
                    throw new IllegalStateException("EmojiCompat is not initialized.\n\nYou must initialize EmojiCompat prior to referencing the EmojiCompat instance.\n\nThe most likely cause of this error is disabling the EmojiCompatInitializer\neither explicitly in AndroidManifest.xml, or by including\nandroidx.emoji2:emoji2-bundled.\n\nAutomatic initialization is typically performed by EmojiCompatInitializer. If\nyou are not expecting to initialize EmojiCompat manually in your application,\nplease check to ensure it has not been removed from your APK's manifest. You can\ndo this in Android Studio using Build > Analyze APK.\n\nIn the APK Analyzer, ensure that the startup entry for\nEmojiCompatInitializer and InitializationProvider is present in\n AndroidManifest.xml. If it is missing or contains tools:node=\"remove\", and you\nintend to use automatic configuration, verify:\n\n  1. Your application does not include emoji2-bundled\n  2. All modules do not contain an exclusion manifest rule for\n     EmojiCompatInitializer or InitializationProvider. For more information\n     about manifest exclusions see the documentation for the androidx startup\n     library.\n\nIf you intend to use emoji2-bundled, please call EmojiCompat.init. You can\nlearn more in the documentation for BundledEmojiCompatConfig.\n\nIf you intended to perform manual configuration, it is recommended that you call\nEmojiCompat.init immediately on application startup.\n\nIf you still cannot resolve this issue, please open a bug with your specific\nconfiguration to help improve error message.");
                }
            }
            int a = arvVar.a();
            if (a == 3 || a == 0) {
                sp spVar = new sp(this);
                this.S = spVar;
                if (Build.VERSION.SDK_INT >= 28) {
                    handler = Handler.createAsync(Looper.getMainLooper());
                } else {
                    handler = new Handler(Looper.getMainLooper());
                }
                handler.getClass();
                arvVar.b(new arh(handler), spVar);
            }
        }
    }

    @Override // android.widget.CompoundButton, android.widget.TextView, android.view.View
    public final void jumpDrawablesToCurrentState() {
        super.jumpDrawablesToCurrentState();
        Drawable drawable = this.a;
        if (drawable != null) {
            drawable.jumpToCurrentState();
        }
        Drawable drawable2 = this.e;
        if (drawable2 != null) {
            drawable2.jumpToCurrentState();
        }
        ObjectAnimator objectAnimator = this.s;
        if (objectAnimator != null && objectAnimator.isStarted()) {
            this.s.end();
            this.s = null;
        }
    }

    /* JADX INFO: Access modifiers changed from: protected */
    @Override // android.widget.CompoundButton, android.widget.TextView, android.view.View
    public int[] onCreateDrawableState(int i) {
        int[] onCreateDrawableState = super.onCreateDrawableState(i + 1);
        if (isChecked()) {
            mergeDrawableStates(onCreateDrawableState, v);
        }
        return onCreateDrawableState;
    }

    @Override // android.widget.CompoundButton, android.widget.TextView, android.view.View
    protected final void onDraw(Canvas canvas) {
        Layout layout;
        int width;
        super.onDraw(canvas);
        Drawable drawable = this.e;
        Rect rect = this.T;
        if (drawable != null) {
            drawable.getPadding(rect);
        } else {
            rect.setEmpty();
        }
        int i = this.M;
        int i2 = this.O;
        int i3 = i + rect.top;
        int i4 = i2 - rect.bottom;
        Drawable drawable2 = this.a;
        if (drawable != null) {
            if (this.B && drawable2 != null) {
                Rect b = ol.b(drawable2);
                drawable2.copyBounds(rect);
                rect.left += b.left;
                rect.right -= b.right;
                int save = canvas.save();
                canvas.clipRect(rect, Region.Op.DIFFERENCE);
                drawable.draw(canvas);
                canvas.restoreToCount(save);
            } else {
                drawable.draw(canvas);
            }
        }
        int save2 = canvas.save();
        if (drawable2 != null) {
            drawable2.draw(canvas);
        }
        if (this.n > 0.5f) {
            layout = this.p;
        } else {
            layout = this.q;
        }
        if (layout != null) {
            int[] drawableState = getDrawableState();
            ColorStateList colorStateList = this.Q;
            if (colorStateList != null) {
                this.P.setColor(colorStateList.getColorForState(drawableState, 0));
            }
            this.P.drawableState = drawableState;
            if (drawable2 != null) {
                Rect bounds = drawable2.getBounds();
                width = bounds.left + bounds.right;
            } else {
                width = getWidth();
            }
            canvas.translate((width / 2) - (layout.getWidth() / 2), ((i3 + i4) / 2) - (layout.getHeight() / 2));
            layout.draw(canvas);
        }
        canvas.restoreToCount(save2);
    }

    @Override // android.view.View
    public final void onInitializeAccessibilityEvent(AccessibilityEvent accessibilityEvent) {
        super.onInitializeAccessibilityEvent(accessibilityEvent);
        accessibilityEvent.setClassName("android.widget.Switch");
    }

    @Override // android.view.View
    public final void onInitializeAccessibilityNodeInfo(AccessibilityNodeInfo accessibilityNodeInfo) {
        CharSequence charSequence;
        super.onInitializeAccessibilityNodeInfo(accessibilityNodeInfo);
        accessibilityNodeInfo.setClassName("android.widget.Switch");
        if (Build.VERSION.SDK_INT < 30) {
            if (isChecked()) {
                charSequence = this.i;
            } else {
                charSequence = this.k;
            }
            if (!TextUtils.isEmpty(charSequence)) {
                CharSequence text = accessibilityNodeInfo.getText();
                if (TextUtils.isEmpty(text)) {
                    accessibilityNodeInfo.setText(charSequence);
                    return;
                }
                StringBuilder sb = new StringBuilder();
                sb.append(text);
                sb.append(' ');
                sb.append(charSequence);
                accessibilityNodeInfo.setText(sb);
            }
        }
    }

    @Override // android.widget.TextView, android.view.View
    protected final void onLayout(boolean z, int i, int i2, int i3, int i4) {
        int i5;
        int width;
        int i6;
        int i7;
        int i8;
        int i9;
        super.onLayout(z, i, i2, i3, i4);
        int i10 = 0;
        if (this.a != null) {
            Rect rect = this.T;
            Drawable drawable = this.e;
            if (drawable != null) {
                drawable.getPadding(rect);
            } else {
                rect.setEmpty();
            }
            Rect b = ol.b(this.a);
            i5 = Math.max(0, b.left - rect.left);
            i10 = Math.max(0, b.right - rect.right);
        } else {
            i5 = 0;
        }
        if (getLayoutDirection() == 1) {
            i6 = getPaddingLeft() + i5;
            width = ((this.I + i6) - i5) - i10;
        } else {
            width = (getWidth() - getPaddingRight()) - i10;
            i6 = (width - this.I) + i5 + i10;
        }
        int gravity = getGravity() & 112;
        if (gravity != 16) {
            if (gravity != 80) {
                i8 = getPaddingTop();
                i7 = this.J;
            } else {
                i9 = getHeight() - getPaddingBottom();
                i8 = i9 - this.J;
                this.L = i6;
                this.M = i8;
                this.O = i9;
                this.N = width;
            }
        } else {
            int paddingTop = (getPaddingTop() + getHeight()) - getPaddingBottom();
            i7 = this.J;
            i8 = (paddingTop / 2) - (i7 / 2);
        }
        i9 = i7 + i8;
        this.L = i6;
        this.M = i8;
        this.O = i9;
        this.N = width;
    }

    @Override // android.widget.TextView, android.view.View
    public final void onMeasure(int i, int i2) {
        int i3;
        int i4;
        int i5;
        int i6;
        if (this.m) {
            if (this.p == null) {
                this.p = k(this.j);
            }
            if (this.q == null) {
                this.q = k(this.l);
            }
        }
        Rect rect = this.T;
        Drawable drawable = this.a;
        int i7 = 0;
        if (drawable != null) {
            drawable.getPadding(rect);
            i3 = (this.a.getIntrinsicWidth() - rect.left) - rect.right;
            i4 = this.a.getIntrinsicHeight();
        } else {
            i3 = 0;
            i4 = 0;
        }
        if (this.m) {
            int max = Math.max(this.p.getWidth(), this.q.getWidth());
            int i8 = this.y;
            i5 = max + i8 + i8;
        } else {
            i5 = 0;
        }
        this.K = Math.max(i5, i3);
        Drawable drawable2 = this.e;
        if (drawable2 != null) {
            drawable2.getPadding(rect);
            i7 = this.e.getIntrinsicHeight();
        } else {
            rect.setEmpty();
        }
        int i9 = rect.left;
        int i10 = rect.right;
        Drawable drawable3 = this.a;
        if (drawable3 != null) {
            Rect b = ol.b(drawable3);
            i9 = Math.max(i9, b.left);
            i10 = Math.max(i10, b.right);
        }
        if (this.o) {
            int i11 = this.z;
            int i12 = this.K;
            i6 = Math.max(i11, i12 + i12 + i9 + i10);
        } else {
            i6 = this.z;
        }
        int max2 = Math.max(i7, i4);
        this.I = i6;
        this.J = max2;
        super.onMeasure(i, i2);
        if (getMeasuredHeight() < max2) {
            setMeasuredDimension(getMeasuredWidthAndState(), max2);
        }
    }

    @Override // android.view.View
    public final void onPopulateAccessibilityEvent(AccessibilityEvent accessibilityEvent) {
        CharSequence charSequence;
        super.onPopulateAccessibilityEvent(accessibilityEvent);
        if (isChecked()) {
            charSequence = this.i;
        } else {
            charSequence = this.k;
        }
        if (charSequence != null) {
            accessibilityEvent.getText().add(charSequence);
        }
    }

    /* JADX WARN: Code restructure failed: missing block: B:6:0x0013, code lost:
    
        if (r0 != 3) goto L84;
     */
    @Override // android.widget.TextView, android.view.View
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct code enable 'Show inconsistent code' option in preferences
    */
    public final boolean onTouchEvent(android.view.MotionEvent r9) {
        /*
            Method dump skipped, instructions count: 347
            To view this dump change 'Code comments level' option to 'DEBUG'
        */
        throw new UnsupportedOperationException("Method not decompiled: android.support.v7.widget.SwitchCompat.onTouchEvent(android.view.MotionEvent):boolean");
    }

    @Override // android.widget.TextView
    public final void setAllCaps(boolean z) {
        super.setAllCaps(z);
        if (this.t == null) {
            this.t = new mm(this);
        }
        this.t.a.a.c(z);
    }

    @Override // android.widget.CompoundButton, android.widget.Checkable
    public final void setChecked(boolean z) {
        float f;
        super.setChecked(z);
        boolean isChecked = isChecked();
        if (isChecked) {
            d();
        } else {
            c();
        }
        if (true != isChecked) {
            f = 0.0f;
        } else {
            f = 1.0f;
        }
        if (getWindowToken() != null && isLaidOut()) {
            ObjectAnimator ofFloat = ObjectAnimator.ofFloat(this, (Property<SwitchCompat, Float>) u, f);
            this.s = ofFloat;
            ofFloat.setDuration(250L);
            this.s.setAutoCancel(true);
            this.s.start();
            return;
        }
        ObjectAnimator objectAnimator = this.s;
        if (objectAnimator != null) {
            objectAnimator.cancel();
        }
        this.n = f;
        invalidate();
    }

    @Override // android.widget.TextView
    public final void setCustomSelectionActionModeCallback(ActionMode.Callback callback) {
        super.setCustomSelectionActionModeCallback(apg.a(this, callback));
    }

    @Override // android.widget.TextView
    public final void setFilters(InputFilter[] inputFilterArr) {
        if (this.t == null) {
            this.t = new mm(this);
        }
        super.setFilters(this.t.a.a.d(inputFilterArr));
    }

    public void setSwitchMinWidth(int i) {
        this.z = i;
        requestLayout();
    }

    public void setSwitchPadding(int i) {
        this.A = i;
        requestLayout();
    }

    public void setThumbResource(int i) {
        f(ry.e().c(getContext(), i));
    }

    public void setThumbTextPadding(int i) {
        this.y = i;
        requestLayout();
    }

    public void setTrackResource(int i) {
        g(ry.e().c(getContext(), i));
    }

    @Override // android.widget.CompoundButton, android.widget.Checkable
    public final void toggle() {
        setChecked(!isChecked());
    }

    @Override // android.widget.CompoundButton, android.widget.TextView, android.view.View
    protected final boolean verifyDrawable(Drawable drawable) {
        if (!super.verifyDrawable(drawable) && drawable != this.a && drawable != this.e) {
            return false;
        }
        return true;
    }

    public SwitchCompat(Context context, AttributeSet attributeSet) {
        this(context, attributeSet, com.google.android.calendar.R.attr.switchStyle);
    }

    public SwitchCompat(Context context, AttributeSet attributeSet, int i) {
        super(context, attributeSet, i);
        Typeface typeface;
        Typeface create;
        this.b = null;
        this.c = null;
        this.d = false;
        this.w = false;
        this.f = null;
        this.g = null;
        this.h = false;
        this.x = false;
        this.G = VelocityTracker.obtain();
        this.o = true;
        this.T = new Rect();
        sq.b(this, getContext());
        TextPaint textPaint = new TextPaint(1);
        this.P = textPaint;
        textPaint.density = getResources().getDisplayMetrics().density;
        sv svVar = new sv(context, context.obtainStyledAttributes(attributeSet, ia.v, i, 0));
        int[] iArr = ia.v;
        TypedArray typedArray = svVar.b;
        if (Build.VERSION.SDK_INT >= 29) {
            alz.b(this, context, iArr, attributeSet, typedArray, i, 0);
        }
        Drawable b = svVar.b(2);
        this.a = b;
        if (b != null) {
            b.setCallback(this);
        }
        Drawable b2 = svVar.b(11);
        this.e = b2;
        if (b2 != null) {
            b2.setCallback(this);
        }
        CharSequence text = svVar.b.getText(0);
        this.i = text;
        if (this.t == null) {
            this.t = new mm(this);
        }
        mm mmVar = this.t;
        TransformationMethod transformationMethod = this.r;
        atf atfVar = mmVar.a.a;
        if (arv.b != null && ((atg) atfVar).a.b) {
            transformationMethod = new atk(transformationMethod);
        }
        this.j = transformationMethod != null ? transformationMethod.getTransformation(text, this) : text;
        this.p = null;
        if (this.m) {
            h();
        }
        CharSequence text2 = svVar.b.getText(1);
        this.k = text2;
        if (this.t == null) {
            this.t = new mm(this);
        }
        mm mmVar2 = this.t;
        TransformationMethod transformationMethod2 = this.r;
        atf atfVar2 = mmVar2.a.a;
        if (arv.b != null && ((atg) atfVar2).a.b) {
            transformationMethod2 = new atk(transformationMethod2);
        }
        this.l = transformationMethod2 != null ? transformationMethod2.getTransformation(text2, this) : text2;
        this.q = null;
        if (this.m) {
            h();
        }
        this.m = svVar.b.getBoolean(3, true);
        this.y = svVar.b.getDimensionPixelSize(8, 0);
        this.z = svVar.b.getDimensionPixelSize(5, 0);
        this.A = svVar.b.getDimensionPixelSize(6, 0);
        this.B = svVar.b.getBoolean(4, false);
        ColorStateList a = svVar.a(9);
        if (a != null) {
            this.b = a;
            this.d = true;
        }
        PorterDuff.Mode a2 = ol.a(svVar.b.getInt(10, -1), null);
        if (this.c != a2) {
            this.c = a2;
            this.w = true;
        }
        if (this.d || this.w) {
            a();
        }
        ColorStateList a3 = svVar.a(12);
        if (a3 != null) {
            this.f = a3;
            this.h = true;
        }
        PorterDuff.Mode a4 = ol.a(svVar.b.getInt(13, -1), null);
        if (this.g != a4) {
            this.g = a4;
            this.x = true;
        }
        if (this.h || this.x) {
            b();
        }
        int resourceId = svVar.b.getResourceId(7, 0);
        if (resourceId != 0) {
            sv svVar2 = new sv(context, context.obtainStyledAttributes(resourceId, ia.w));
            ColorStateList a5 = svVar2.a(3);
            if (a5 != null) {
                this.Q = a5;
            } else {
                this.Q = getTextColors();
            }
            int dimensionPixelSize = svVar2.b.getDimensionPixelSize(0, 0);
            if (dimensionPixelSize != 0) {
                float f = dimensionPixelSize;
                if (f != textPaint.getTextSize()) {
                    textPaint.setTextSize(f);
                    requestLayout();
                }
            }
            int i2 = svVar2.b.getInt(1, -1);
            int i3 = svVar2.b.getInt(2, -1);
            if (i2 == 1) {
                typeface = Typeface.SANS_SERIF;
            } else if (i2 != 2) {
                typeface = i2 != 3 ? null : Typeface.MONOSPACE;
            } else {
                typeface = Typeface.SERIF;
            }
            if (i3 > 0) {
                if (typeface == null) {
                    create = Typeface.defaultFromStyle(i3);
                } else {
                    create = Typeface.create(typeface, i3);
                }
                e(create);
                int i4 = (~(create != null ? create.getStyle() : 0)) & i3;
                textPaint.setFakeBoldText(1 == (i4 & 1));
                textPaint.setTextSkewX((2 & i4) != 0 ? -0.25f : 0.0f);
            } else {
                textPaint.setFakeBoldText(false);
                textPaint.setTextSkewX(0.0f);
                e(typeface);
            }
            if (svVar2.b.getBoolean(14, false)) {
                this.r = new in(getContext());
            } else {
                this.r = null;
            }
            CharSequence charSequence = this.i;
            if (this.t == null) {
                this.t = new mm(this);
            }
            mm mmVar3 = this.t;
            TransformationMethod transformationMethod3 = this.r;
            atf atfVar3 = mmVar3.a.a;
            if (arv.b != null && ((atg) atfVar3).a.b) {
                transformationMethod3 = new atk(transformationMethod3);
            }
            this.j = transformationMethod3 != null ? transformationMethod3.getTransformation(charSequence, this) : charSequence;
            this.p = null;
            if (this.m) {
                h();
            }
            CharSequence charSequence2 = this.k;
            if (this.t == null) {
                this.t = new mm(this);
            }
            mm mmVar4 = this.t;
            TransformationMethod transformationMethod4 = this.r;
            atf atfVar4 = mmVar4.a.a;
            if (arv.b != null && ((atg) atfVar4).a.b) {
                transformationMethod4 = new atk(transformationMethod4);
            }
            this.l = transformationMethod4 != null ? transformationMethod4.getTransformation(charSequence2, this) : charSequence2;
            this.q = null;
            if (this.m) {
                h();
            }
            svVar2.b.recycle();
        }
        nm nmVar = new nm(this);
        this.R = nmVar;
        nmVar.c(attributeSet, i);
        svVar.b.recycle();
        ViewConfiguration viewConfiguration = ViewConfiguration.get(context);
        this.D = viewConfiguration.getScaledTouchSlop();
        this.H = viewConfiguration.getScaledMinimumFlingVelocity();
        if (this.t == null) {
            this.t = new mm(this);
        }
        this.t.a(attributeSet, i);
        refreshDrawableState();
        setChecked(isChecked());
    }
}
