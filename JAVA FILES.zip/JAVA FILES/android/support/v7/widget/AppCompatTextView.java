package android.support.v7.widget;

import android.R;
import android.content.Context;
import android.graphics.Paint;
import android.graphics.Typeface;
import android.graphics.drawable.Drawable;
import android.os.Build;
import android.text.InputFilter;
import android.util.AttributeSet;
import android.util.Log;
import android.view.ActionMode;
import android.view.inputmethod.EditorInfo;
import android.view.inputmethod.InputConnection;
import android.view.inputmethod.InputMethodManager;
import android.view.textclassifier.TextClassificationManager;
import android.view.textclassifier.TextClassifier;
import android.widget.TextView;
import cal.akd;
import cal.aoo;
import cal.apf;
import cal.apg;
import cal.aw$$ExternalSyntheticApiModelOutline0;
import cal.mc;
import cal.mk;
import cal.mm;
import cal.mn;
import cal.ni;
import cal.nl;
import cal.nm;
import cal.nn;
import cal.no;
import cal.np;
import cal.nt;
import cal.ry;
import cal.sq;
import cal.ss;
import cal.su;
import cal.tr;
import j$.util.Objects;

/* compiled from: PG */
/* loaded from: classes.dex */
public class AppCompatTextView extends TextView {
    private final mc a;
    private final nm b;
    private final ni c;
    private mm d;
    private boolean e;
    private Typeface f;
    private Typeface g;
    private String h;
    private nn i;

    public AppCompatTextView(Context context) {
        this(context, null);
    }

    @Override // android.widget.TextView, android.view.View
    protected final void drawableStateChanged() {
        super.drawableStateChanged();
        mc mcVar = this.a;
        if (mcVar != null) {
            mcVar.a();
        }
        nm nmVar = this.b;
        if (nmVar != null) {
            nmVar.a();
        }
    }

    @Override // android.widget.TextView
    public final int getAutoSizeMaxTextSize() {
        if (tr.c) {
            return super.getAutoSizeMaxTextSize();
        }
        nm nmVar = this.b;
        if (nmVar != null) {
            return Math.round(nmVar.a.d);
        }
        return -1;
    }

    @Override // android.widget.TextView
    public final int getAutoSizeMinTextSize() {
        if (tr.c) {
            return super.getAutoSizeMinTextSize();
        }
        nm nmVar = this.b;
        if (nmVar != null) {
            return Math.round(nmVar.a.c);
        }
        return -1;
    }

    @Override // android.widget.TextView
    public final int getAutoSizeStepGranularity() {
        if (tr.c) {
            return super.getAutoSizeStepGranularity();
        }
        nm nmVar = this.b;
        if (nmVar != null) {
            return Math.round(nmVar.a.b);
        }
        return -1;
    }

    @Override // android.widget.TextView
    public final int[] getAutoSizeTextAvailableSizes() {
        if (tr.c) {
            return super.getAutoSizeTextAvailableSizes();
        }
        nm nmVar = this.b;
        if (nmVar != null) {
            return nmVar.a.e;
        }
        return new int[0];
    }

    @Override // android.widget.TextView
    public final int getAutoSizeTextType() {
        if (tr.c) {
            if (super.getAutoSizeTextType() != 1) {
                return 0;
            }
            return 1;
        }
        nm nmVar = this.b;
        if (nmVar == null) {
            return 0;
        }
        return nmVar.a.a;
    }

    @Override // android.widget.TextView
    public final ActionMode.Callback getCustomSelectionActionModeCallback() {
        ActionMode.Callback customSelectionActionModeCallback = super.getCustomSelectionActionModeCallback();
        if (customSelectionActionModeCallback instanceof apf) {
            return ((apf) customSelectionActionModeCallback).a;
        }
        return customSelectionActionModeCallback;
    }

    @Override // android.widget.TextView
    public final int getFirstBaselineToTopHeight() {
        return getPaddingTop() - getPaint().getFontMetricsInt().top;
    }

    @Override // android.widget.TextView
    public final String getFontVariationSettings() {
        return this.h;
    }

    @Override // android.widget.TextView
    public final int getLastBaselineToBottomHeight() {
        return getPaddingBottom() + getPaint().getFontMetricsInt().bottom;
    }

    @Override // android.widget.TextView
    public final TextClassifier getTextClassifier() {
        ni niVar;
        TextClassifier textClassifier;
        TextClassifier textClassifier2;
        if (Build.VERSION.SDK_INT < 28 && (niVar = this.c) != null) {
            TextClassifier textClassifier3 = niVar.b;
            if (textClassifier3 == null) {
                TextClassificationManager m29m = aw$$ExternalSyntheticApiModelOutline0.m29m(niVar.a.getContext().getSystemService(aw$$ExternalSyntheticApiModelOutline0.m32m()));
                if (m29m == null) {
                    textClassifier = TextClassifier.NO_OP;
                    return textClassifier;
                }
                textClassifier2 = m29m.getTextClassifier();
                return textClassifier2;
            }
            return textClassifier3;
        }
        return super.getTextClassifier();
    }

    @Override // android.widget.TextView
    public final Typeface getTypeface() {
        return this.f;
    }

    final nn i() {
        nn nnVar;
        if (this.i == null) {
            if (Build.VERSION.SDK_INT >= 34) {
                nnVar = new np(this);
            } else if (Build.VERSION.SDK_INT >= 28) {
                nnVar = new no(this);
            } else {
                nnVar = new nn(this);
            }
            this.i = nnVar;
        }
        return this.i;
    }

    @Override // android.widget.TextView, android.view.View
    public final InputConnection onCreateInputConnection(EditorInfo editorInfo) {
        InputConnection onCreateInputConnection = super.onCreateInputConnection(editorInfo);
        if (Build.VERSION.SDK_INT < 30 && onCreateInputConnection != null) {
            CharSequence text = getText();
            if (Build.VERSION.SDK_INT < 30) {
                aoo.a(editorInfo, text);
            } else {
                editorInfo.setInitialSurroundingSubText(text, 0);
            }
        }
        mn.a(onCreateInputConnection, editorInfo, this);
        return onCreateInputConnection;
    }

    @Override // android.view.View
    protected final void onDetachedFromWindow() {
        super.onDetachedFromWindow();
        if (Build.VERSION.SDK_INT >= 30 && Build.VERSION.SDK_INT < 33 && onCheckIsTextEditor()) {
            ((InputMethodManager) getContext().getSystemService("input_method")).isActive(this);
        }
    }

    /* JADX INFO: Access modifiers changed from: protected */
    @Override // android.widget.TextView, android.view.View
    public void onLayout(boolean z, int i, int i2, int i3, int i4) {
        super.onLayout(z, i, i2, i3, i4);
        nm nmVar = this.b;
        if (nmVar != null && !tr.c) {
            nmVar.a.b();
        }
    }

    /* JADX INFO: Access modifiers changed from: protected */
    @Override // android.widget.TextView, android.view.View
    public void onMeasure(int i, int i2) {
        super.onMeasure(i, i2);
    }

    /* JADX INFO: Access modifiers changed from: protected */
    @Override // android.widget.TextView
    public void onTextChanged(CharSequence charSequence, int i, int i2, int i3) {
        super.onTextChanged(charSequence, i, i2, i3);
        nm nmVar = this.b;
        if (nmVar != null && !tr.c) {
            nt ntVar = nmVar.a;
            if (!(ntVar.g instanceof mk) && ntVar.a != 0) {
                ntVar.b();
            }
        }
    }

    @Override // android.widget.TextView
    public final void setAllCaps(boolean z) {
        super.setAllCaps(z);
        if (this.d == null) {
            this.d = new mm(this);
        }
        this.d.a.a.c(z);
    }

    @Override // android.widget.TextView
    public final void setAutoSizeTextTypeUniformWithConfiguration(int i, int i2, int i3, int i4) {
        if (tr.c) {
            super.setAutoSizeTextTypeUniformWithConfiguration(i, i2, i3, i4);
            return;
        }
        nm nmVar = this.b;
        if (nmVar != null) {
            nmVar.a.c(i, i2, i3, i4);
        }
    }

    @Override // android.widget.TextView
    public final void setAutoSizeTextTypeUniformWithPresetSizes(int[] iArr, int i) {
        if (tr.c) {
            super.setAutoSizeTextTypeUniformWithPresetSizes(iArr, i);
            return;
        }
        nm nmVar = this.b;
        if (nmVar != null) {
            nmVar.a.d(iArr, i);
        }
    }

    @Override // android.widget.TextView
    public void setAutoSizeTextTypeWithDefaults(int i) {
        if (tr.c) {
            super.setAutoSizeTextTypeWithDefaults(i);
            return;
        }
        nm nmVar = this.b;
        if (nmVar != null) {
            nmVar.a.e(i);
        }
    }

    @Override // android.view.View
    public final void setBackgroundDrawable(Drawable drawable) {
        super.setBackgroundDrawable(drawable);
        mc mcVar = this.a;
        if (mcVar != null) {
            mcVar.a = -1;
            mcVar.b = null;
            mcVar.a();
            mcVar.a();
        }
    }

    @Override // android.view.View
    public void setBackgroundResource(int i) {
        super.setBackgroundResource(i);
        mc mcVar = this.a;
        if (mcVar != null) {
            mcVar.c(i);
        }
    }

    @Override // android.widget.TextView
    public void setCompoundDrawables(Drawable drawable, Drawable drawable2, Drawable drawable3, Drawable drawable4) {
        super.setCompoundDrawables(drawable, drawable2, drawable3, drawable4);
        nm nmVar = this.b;
        if (nmVar != null) {
            nmVar.a();
        }
    }

    @Override // android.widget.TextView
    public void setCompoundDrawablesRelative(Drawable drawable, Drawable drawable2, Drawable drawable3, Drawable drawable4) {
        super.setCompoundDrawablesRelative(drawable, drawable2, drawable3, drawable4);
        nm nmVar = this.b;
        if (nmVar != null) {
            nmVar.a();
        }
    }

    @Override // android.widget.TextView
    public final void setCompoundDrawablesRelativeWithIntrinsicBounds(int i, int i2, int i3, int i4) {
        Context context = getContext();
        super.setCompoundDrawablesRelativeWithIntrinsicBounds(i != 0 ? ry.e().c(context, i) : null, i2 != 0 ? ry.e().c(context, i2) : null, i3 != 0 ? ry.e().c(context, i3) : null, i4 != 0 ? ry.e().c(context, i4) : null);
        nm nmVar = this.b;
        if (nmVar != null) {
            nmVar.a();
        }
        nm nmVar2 = this.b;
        if (nmVar2 != null) {
            nmVar2.a();
        }
    }

    @Override // android.widget.TextView
    public final void setCompoundDrawablesWithIntrinsicBounds(int i, int i2, int i3, int i4) {
        Context context = getContext();
        super.setCompoundDrawablesWithIntrinsicBounds(i != 0 ? ry.e().c(context, i) : null, i2 != 0 ? ry.e().c(context, i2) : null, i3 != 0 ? ry.e().c(context, i3) : null, i4 != 0 ? ry.e().c(context, i4) : null);
        nm nmVar = this.b;
        if (nmVar != null) {
            nmVar.a();
        }
        nm nmVar2 = this.b;
        if (nmVar2 != null) {
            nmVar2.a();
        }
    }

    @Override // android.widget.TextView
    public final void setCustomSelectionActionModeCallback(ActionMode.Callback callback) {
        super.setCustomSelectionActionModeCallback(apg.a(this, callback));
    }

    @Override // android.widget.TextView
    public final void setFilters(InputFilter[] inputFilterArr) {
        if (this.d == null) {
            this.d = new mm(this);
        }
        super.setFilters(this.d.a.a.d(inputFilterArr));
    }

    @Override // android.widget.TextView
    public void setFirstBaselineToTopHeight(int i) {
        if (Build.VERSION.SDK_INT >= 28) {
            i().a(i);
        } else {
            apg.b(this, i);
        }
    }

    @Override // android.widget.TextView
    public final boolean setFontVariationSettings(String str) {
        String fontVariationSettings;
        boolean fontVariationSettings2;
        Typeface typeface = this.f;
        if (this.g != getPaint().getTypeface()) {
            Log.w("AppCompatTextView", "getPaint().getTypeface() changed unexpectedly. App code should not modify the result of getPaint().");
            typeface = getPaint().getTypeface();
        }
        akd akdVar = new akd(typeface, str);
        Typeface typeface2 = (Typeface) nl.a.a(akdVar);
        if (typeface2 == null) {
            Paint paint = nl.b;
            if (paint == null) {
                paint = new Paint();
                nl.b = paint;
            }
            fontVariationSettings = paint.getFontVariationSettings();
            if (Objects.equals(fontVariationSettings, str)) {
                paint.setFontVariationSettings(null);
            }
            paint.setTypeface(typeface);
            fontVariationSettings2 = paint.setFontVariationSettings(str);
            if (fontVariationSettings2) {
                typeface2 = paint.getTypeface();
                nl.a.b(akdVar, typeface2);
            } else {
                typeface2 = null;
            }
        }
        if (typeface2 != null) {
            this.g = typeface2;
            super.setTypeface(typeface2);
            this.h = str;
            return true;
        }
        return false;
    }

    @Override // android.widget.TextView
    public void setLastBaselineToBottomHeight(int i) {
        if (Build.VERSION.SDK_INT >= 28) {
            i().b(i);
        } else {
            apg.c(this, i);
        }
    }

    @Override // android.widget.TextView
    public void setLineHeight(int i) {
        if (i >= 0) {
            if (i != getPaint().getFontMetricsInt(null)) {
                setLineSpacing(i - r0, 1.0f);
                return;
            }
            return;
        }
        throw new IllegalArgumentException();
    }

    @Override // android.widget.TextView
    public void setTextAppearance(Context context, int i) {
        super.setTextAppearance(context, i);
        nm nmVar = this.b;
        if (nmVar != null) {
            nmVar.d(context, i);
        }
    }

    @Override // android.widget.TextView
    public final void setTextClassifier(TextClassifier textClassifier) {
        ni niVar;
        if (Build.VERSION.SDK_INT < 28 && (niVar = this.c) != null) {
            niVar.b = textClassifier;
        } else {
            super.setTextClassifier(textClassifier);
        }
    }

    @Override // android.widget.TextView
    public final void setTextSize(int i, float f) {
        if (tr.c) {
            super.setTextSize(i, f);
            return;
        }
        nm nmVar = this.b;
        if (nmVar != null) {
            nt ntVar = nmVar.a;
            if ((ntVar.g instanceof mk) || ntVar.a == 0) {
                ntVar.f(i, f);
            }
        }
    }

    @Override // android.widget.TextView
    public final void setTypeface(Typeface typeface) {
        this.f = typeface;
        this.g = typeface;
        super.setTypeface(typeface);
    }

    public AppCompatTextView(Context context, AttributeSet attributeSet) {
        this(context, attributeSet, R.attr.textViewStyle);
    }

    @Override // android.widget.TextView
    public final void setTypeface(Typeface typeface, int i) {
        if (this.e) {
            return;
        }
        if (typeface != null && i > 0) {
            if (getContext() != null) {
                typeface = Typeface.create(typeface, i);
            } else {
                throw new IllegalArgumentException("Context cannot be null");
            }
        }
        this.e = true;
        try {
            super.setTypeface(typeface, i);
        } finally {
            this.e = false;
        }
    }

    /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
    public AppCompatTextView(Context context, AttributeSet attributeSet, int i) {
        super(context, attributeSet, i);
        if (!(context instanceof ss) && !(context.getResources() instanceof su)) {
            context.getResources();
        }
        this.e = false;
        this.i = null;
        sq.b(this, getContext());
        mc mcVar = new mc(this);
        this.a = mcVar;
        mcVar.b(attributeSet, i);
        nm nmVar = new nm(this);
        this.b = nmVar;
        nmVar.c(attributeSet, i);
        nmVar.a();
        this.c = new ni(this);
        if (this.d == null) {
            this.d = new mm(this);
        }
        this.d.a(attributeSet, i);
    }

    @Override // android.widget.TextView
    public final void setLineHeight(int i, float f) {
        if (Build.VERSION.SDK_INT >= 34) {
            i().c(i, f);
        } else {
            apg.d(this, i, f);
        }
    }

    @Override // android.widget.TextView
    public final void setCompoundDrawablesRelativeWithIntrinsicBounds(Drawable drawable, Drawable drawable2, Drawable drawable3, Drawable drawable4) {
        super.setCompoundDrawablesRelativeWithIntrinsicBounds(drawable, drawable2, drawable3, drawable4);
        nm nmVar = this.b;
        if (nmVar != null) {
            nmVar.a();
        }
    }

    @Override // android.widget.TextView
    public final void setCompoundDrawablesWithIntrinsicBounds(Drawable drawable, Drawable drawable2, Drawable drawable3, Drawable drawable4) {
        super.setCompoundDrawablesWithIntrinsicBounds(drawable, drawable2, drawable3, drawable4);
        nm nmVar = this.b;
        if (nmVar != null) {
            nmVar.a();
        }
    }
}
