package android.support.v4.graphics.drawable;

import androidx.core.graphics.drawable.IconCompat;
import cal.blw;

/* compiled from: PG */
/* loaded from: classes.dex */
public final class IconCompatParcelizer extends androidx.core.graphics.drawable.IconCompatParcelizer {
    public static IconCompat read(blw blwVar) {
        return androidx.core.graphics.drawable.IconCompatParcelizer.read(blwVar);
    }

    public static void write(IconCompat iconCompat, blw blwVar) {
        androidx.core.graphics.drawable.IconCompatParcelizer.write(iconCompat, blwVar);
    }
}
