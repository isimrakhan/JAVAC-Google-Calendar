package cal;

/* compiled from: PG */
/* loaded from: classes2.dex */
final class aadm extends aadt {
    private final ahti a;
    private final int b;

    public aadm(int i, ahti ahtiVar) {
        this.b = i;
        this.a = ahtiVar;
    }

    @Override // cal.aadt
    public final ahti c() {
        return this.a;
    }

    @Override // cal.aadt
    public final int d() {
        return this.b;
    }

    public final boolean equals(Object obj) {
        if (obj == this) {
            return true;
        }
        if (obj instanceof aadt) {
            aadt aadtVar = (aadt) obj;
            if (this.b == aadtVar.d()) {
                aadtVar.e();
                if (this.a.equals(aadtVar.c())) {
                    return true;
                }
            }
        }
        return false;
    }

    public final int hashCode() {
        return ((((this.b ^ 1000003) * 1000003) ^ 1237) * 1000003) ^ this.a.hashCode();
    }

    public final String toString() {
        String str;
        int i = this.b;
        if (i != 1) {
            if (i != 2) {
                str = "EXPLICITLY_ENABLED";
            } else {
                str = "EXPLICITLY_DISABLED";
            }
        } else {
            str = "DEFAULT";
        }
        return "StorageConfigurations{enablement=" + str + ", manualCapture=false, dirStatsConfigurations=" + String.valueOf(this.a) + "}";
    }

    @Override // cal.aadt
    public final void e() {
    }
}
