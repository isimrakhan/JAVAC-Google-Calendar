package cal;

import android.content.Context;
import android.content.IntentFilter;
import android.os.Build;
import j$.util.Objects;
import j$.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.ConcurrentMap;

/* compiled from: PG */
/* loaded from: classes2.dex */
public final class aalj {
    public final ConcurrentMap a = new ConcurrentHashMap();

    public final aalk a(aaic aaicVar, String str, ahum ahumVar) {
        ahtj ahtjVar = new ahtj(str, "");
        aalk aalkVar = (aalk) this.a.get(ahtjVar);
        if (aalkVar == null) {
            aalg aalgVar = (aalg) ahumVar;
            final aalk aalkVar2 = new aalk(aalgVar.a, aalgVar.b, aalgVar.c, aalgVar.d);
            aalkVar = (aalk) this.a.putIfAbsent(ahtjVar, aalkVar2);
            if (aalkVar == null) {
                Context context = aaicVar.d;
                aamk.c.putIfAbsent(ahtjVar, new aalh(aalkVar2));
                if (!aamk.b) {
                    synchronized (aamk.a) {
                        if (!aamk.b && !Objects.equals(context.getPackageName(), "com.google.android.gms")) {
                            if (Build.VERSION.SDK_INT >= 33) {
                                context.registerReceiver(new aamk(), new IntentFilter("com.google.android.gms.phenotype.UPDATE"), 2);
                            } else {
                                context.registerReceiver(new aamk(), new IntentFilter("com.google.android.gms.phenotype.UPDATE"));
                            }
                            aamk.b = true;
                        }
                    }
                }
                aalw.a.putIfAbsent(ahtjVar, new ahum() { // from class: cal.aali
                    @Override // cal.ahum
                    public final Object a() {
                        return aalk.this.b();
                    }
                });
                aalkVar = aalkVar2;
            }
        }
        boolean z = aalkVar.e;
        return aalkVar;
    }
}
