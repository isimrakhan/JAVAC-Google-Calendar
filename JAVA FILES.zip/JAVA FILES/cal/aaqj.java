package cal;

/* compiled from: PG */
/* loaded from: classes2.dex */
public enum aaqj implements ampo {
    CONTACT_FIELD_TYPE_UNSPECIFIED(0),
    EMAIL(1),
    PHONE(2),
    UNRECOGNIZED(-1);

    public final int e;

    aaqj(int i) {
        this.e = i;
    }

    @Override // cal.ampo
    public final int a() {
        if (this != UNRECOGNIZED) {
            return this.e;
        }
        throw new IllegalArgumentException("Can't get the number of an unknown enum value.");
    }

    @Override // java.lang.Enum
    public final String toString() {
        if (this != UNRECOGNIZED) {
            return Integer.toString(this.e);
        }
        throw new IllegalArgumentException("Can't get the number of an unknown enum value.");
    }
}
