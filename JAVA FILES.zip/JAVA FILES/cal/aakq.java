package cal;

import com.google.android.gms.phenotype.ExperimentTokens;

/* compiled from: PG */
/* loaded from: classes2.dex */
public final class aakq {
    public final ExperimentTokens a;
    public final String b;

    public aakq(ExperimentTokens experimentTokens, String str) {
        this.a = experimentTokens;
        this.b = str;
    }

    public final boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (!(obj instanceof aakq)) {
            return false;
        }
        aakq aakqVar = (aakq) obj;
        if (this.a.equals(aakqVar.a) && this.b.equals(aakqVar.b)) {
            return true;
        }
        return false;
    }

    public final int hashCode() {
        return (this.a.hashCode() * 31) + this.b.hashCode();
    }

    public final String toString() {
        return "ExperimentTokenData(experimentToken=" + this.a + ", configPackageName=" + this.b + ")";
    }
}
