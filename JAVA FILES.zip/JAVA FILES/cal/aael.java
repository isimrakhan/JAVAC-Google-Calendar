package cal;

import java.util.concurrent.Callable;

/* compiled from: PG */
/* loaded from: classes2.dex */
public final class aael extends aaef implements zwh, aadz {
    private static final Callable a = new Callable() { // from class: cal.aaek
        @Override // java.util.concurrent.Callable
        public final Object call() {
            return null;
        }
    };
    private final aaej b;
    private final aaex c;

    public aael(aaej aaejVar, ahti ahtiVar) {
        this.b = aaejVar;
        aoaw aoawVar = (aoaw) ((aaeq) ((ahts) ahtiVar).a).a;
        Object obj = aoawVar.b;
        this.c = (aaex) (obj == aoaw.a ? aoawVar.c() : obj);
    }

    private final ajdo d(aaee aaeeVar, String str) {
        if (aaeeVar != null && aaeeVar != aaee.a) {
            if (aaeeVar.c) {
                return this.c.c(str);
            }
            aaex aaexVar = this.c;
            zwm zwmVar = aaeeVar.b;
            long j = ((zvs) zwmVar.b).a;
            long j2 = ((zvs) zwmVar.a).a;
            aaexVar.a(str, j2, j - j2);
            return ajdj.a;
        }
        return ajdj.a;
    }

    @Override // cal.aaef
    public final synchronized aaee a() {
        aaee aaeeVar;
        aafw aafwVar = this.b.b.e;
        boolean z = aafwVar.b;
        aagb aagbVar = aafwVar.a;
        if (z && aagbVar.d()) {
            aaeeVar = new aaee();
        } else {
            aaeeVar = aaee.a;
        }
        if (aaeeVar != null && aaeeVar != aaee.a && this.c.b()) {
            aaeeVar.c = true;
            return aaeeVar;
        }
        return aaeeVar;
    }

    @Override // cal.aaef
    public final void b(aaee aaeeVar, zry zryVar, aquh aquhVar, int i) {
        aick aikmVar;
        ajdo d = this.b.d(aaeeVar, zryVar.a, true, aquhVar, i);
        ajdo[] ajdoVarArr = {d, d(aaeeVar, zryVar.a)};
        ailt ailtVar = aick.e;
        Object[] objArr = (Object[]) ajdoVarArr.clone();
        int length = objArr.length;
        for (int i2 = 0; i2 < length; i2++) {
            if (objArr[i2] == null) {
                throw new NullPointerException("at index " + i2);
            }
        }
        int length2 = objArr.length;
        if (length2 == 0) {
            aikmVar = aikm.b;
        } else {
            aikmVar = new aikm(objArr, length2);
        }
        ajcu ajcuVar = new ajcu(true, aikmVar);
        new ajbv(ajcuVar.b, ajcuVar.a, ajbw.a, a);
    }

    @Override // cal.aaef
    public final void c(aaee aaeeVar, String str, aquh aquhVar) {
        aick aikmVar;
        ajdo[] ajdoVarArr = {this.b.d(aaeeVar, str, false, aquhVar, 1), d(aaeeVar, str)};
        ailt ailtVar = aick.e;
        Object[] objArr = (Object[]) ajdoVarArr.clone();
        int length = objArr.length;
        for (int i = 0; i < length; i++) {
            if (objArr[i] == null) {
                throw new NullPointerException("at index " + i);
            }
        }
        int length2 = objArr.length;
        if (length2 == 0) {
            aikmVar = aikm.b;
        } else {
            aikmVar = new aikm(objArr, length2);
        }
        ajcu ajcuVar = new ajcu(true, aikmVar);
        new ajbv(ajcuVar.b, ajcuVar.a, ajbw.a, a);
    }

    @Override // cal.zwh
    public final /* synthetic */ void u() {
    }
}
