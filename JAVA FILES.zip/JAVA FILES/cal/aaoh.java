package cal;

import android.content.pm.PackageManager;
import java.util.HashMap;
import java.util.Map;

/* compiled from: PG */
/* loaded from: classes2.dex */
public final class aaoh {
    public final PackageManager a;
    public final Map b = new HashMap();
    int c = 0;

    public aaoh(PackageManager packageManager) {
        this.a = packageManager;
    }
}
