package cal;

import java.util.concurrent.Executor;

/* compiled from: PG */
/* loaded from: classes2.dex */
public final class aaas implements aoax {
    public static aaar a(zwg zwgVar, Object obj, ajds ajdsVar, anyt anytVar, Object obj2, zsm zsmVar, apxs apxsVar, Executor executor) {
        return new aaar(zwgVar, (aaal) obj, ajdsVar, anytVar, (aaay) obj2, zsmVar, apxsVar, executor);
    }

    @Override // cal.apxs, cal.apxr
    public final /* bridge */ /* synthetic */ Object b() {
        throw null;
    }
}
