package cal;

/* compiled from: PG */
/* loaded from: classes2.dex */
public final class aaea implements aoax {
    public static aaef a(apxs apxsVar) {
        aoaw aoawVar = (aoaw) apxsVar;
        Object obj = aoawVar.b;
        if (obj == aoaw.a) {
            obj = aoawVar.c();
        }
        aaef aaefVar = (aaef) obj;
        aaefVar.getClass();
        return aaefVar;
    }

    @Override // cal.apxs, cal.apxr
    public final /* bridge */ /* synthetic */ Object b() {
        throw null;
    }
}
