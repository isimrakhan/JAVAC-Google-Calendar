package cal;

/* JADX INFO: Access modifiers changed from: package-private */
/* compiled from: PG */
/* loaded from: classes2.dex */
public final class aafy extends aagb {
    private final boolean b;

    public aafy(aqwl aqwlVar, boolean z) {
        super(aqwlVar);
        this.b = z;
    }

    @Override // cal.aagb
    public final long a(String str) {
        aqwl p;
        if (this.b) {
            p = this.a;
        } else {
            aqwl aqwlVar = this.a;
            aqwi aqwiVar = new aqwi();
            ampm ampmVar = aqwiVar.a;
            if (ampmVar != aqwlVar && (aqwlVar == null || ampmVar.getClass() != aqwlVar.getClass() || !amrc.a.a(ampmVar.getClass()).k(ampmVar, aqwlVar))) {
                if ((aqwiVar.b.ad & Integer.MIN_VALUE) == 0) {
                    aqwiVar.s();
                }
                ampm ampmVar2 = aqwiVar.b;
                amrc.a.a(ampmVar2.getClass()).g(ampmVar2, aqwlVar);
            }
            if ((aqwiVar.b.ad & Integer.MIN_VALUE) == 0) {
                aqwiVar.s();
            }
            aqwl aqwlVar2 = (aqwl) aqwiVar.b;
            aqwl aqwlVar3 = aqwl.a;
            aqwlVar2.c |= 2;
            aqwlVar2.d = -1L;
            p = aqwiVar.p();
        }
        aqwl aqwlVar4 = aqwl.a;
        if (p != aqwlVar4) {
            if (aqwlVar4 != null && p.getClass() == aqwlVar4.getClass() && amrc.a.a(p.getClass()).k(p, aqwlVar4)) {
                return 1000L;
            }
            return p.d;
        }
        return 1000L;
    }

    @Override // cal.aagb
    public final aqwl b(Long l) {
        return this.a;
    }

    @Override // cal.aagb
    public final aqwl c(Long l) {
        if (this.b) {
            return this.a;
        }
        aqwl aqwlVar = this.a;
        aqwi aqwiVar = new aqwi();
        ampm ampmVar = aqwiVar.a;
        if (ampmVar != aqwlVar && (aqwlVar == null || ampmVar.getClass() != aqwlVar.getClass() || !amrc.a.a(ampmVar.getClass()).k(ampmVar, aqwlVar))) {
            if ((aqwiVar.b.ad & Integer.MIN_VALUE) == 0) {
                aqwiVar.s();
            }
            ampm ampmVar2 = aqwiVar.b;
            amrc.a.a(ampmVar2.getClass()).g(ampmVar2, aqwlVar);
        }
        if ((aqwiVar.b.ad & Integer.MIN_VALUE) == 0) {
            aqwiVar.s();
        }
        aqwl aqwlVar2 = (aqwl) aqwiVar.b;
        aqwl aqwlVar3 = aqwl.a;
        aqwlVar2.c |= 2;
        aqwlVar2.d = -1L;
        return aqwiVar.p();
    }

    @Override // cal.aagb
    public final boolean d() {
        return this.b;
    }
}
