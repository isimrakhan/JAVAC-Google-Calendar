package cal;

/* compiled from: PG */
/* loaded from: classes2.dex */
public final class aaiy extends ampg implements amqu {
    public aaiy() {
        super(aaiz.a);
    }
}
