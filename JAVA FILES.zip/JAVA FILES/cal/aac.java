package cal;

import java.util.Iterator;

/* compiled from: PG */
/* loaded from: classes.dex */
public abstract class aac extends aad implements Iterator {
    public aaa a;
    public aaa b;

    public aac(aaa aaaVar, aaa aaaVar2) {
        this.a = aaaVar2;
        this.b = aaaVar;
    }

    public abstract aaa a(aaa aaaVar);

    public abstract aaa b(aaa aaaVar);

    @Override // cal.aad
    public final void bi(aaa aaaVar) {
        aaa aaaVar2 = null;
        if (this.a == aaaVar && aaaVar == this.b) {
            this.b = null;
            this.a = null;
        }
        aaa aaaVar3 = this.a;
        if (aaaVar3 == aaaVar) {
            this.a = a(aaaVar3);
        }
        aaa aaaVar4 = this.b;
        if (aaaVar4 == aaaVar) {
            aaa aaaVar5 = this.a;
            if (aaaVar4 != aaaVar5 && aaaVar5 != null) {
                aaaVar2 = b(aaaVar4);
            }
            this.b = aaaVar2;
        }
    }

    @Override // java.util.Iterator
    public final boolean hasNext() {
        if (this.b != null) {
            return true;
        }
        return false;
    }

    @Override // java.util.Iterator
    public final /* synthetic */ Object next() {
        aaa aaaVar = this.b;
        aaa aaaVar2 = this.a;
        aaa aaaVar3 = null;
        if (aaaVar != aaaVar2 && aaaVar2 != null) {
            aaaVar3 = b(aaaVar);
        }
        this.b = aaaVar3;
        return aaaVar;
    }
}
