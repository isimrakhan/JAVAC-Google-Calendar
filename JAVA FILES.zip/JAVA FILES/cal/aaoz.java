package cal;

import java.util.List;

/* compiled from: PG */
/* loaded from: classes2.dex */
public final class aaoz extends aapa {
    public final String a;
    public final List b;

    public aaoz(String str, List list) {
        this.a = str;
        this.b = list;
    }

    @Override // cal.aapa
    public final String a() {
        return this.a;
    }

    @Override // cal.aapa
    public final List b() {
        return this.b;
    }

    public final boolean equals(Object obj) {
        if (obj == this) {
            return true;
        }
        if (obj instanceof aapa) {
            aapa aapaVar = (aapa) obj;
            if (this.a.equals(aapaVar.a()) && this.b.equals(aapaVar.b())) {
                return true;
            }
        }
        return false;
    }

    public final int hashCode() {
        return ((this.a.hashCode() ^ 1000003) * 1000003) ^ this.b.hashCode();
    }

    public final String toString() {
        return "SafeSql{query=" + this.a + ", queryArgs=" + this.b.toString() + "}";
    }
}
