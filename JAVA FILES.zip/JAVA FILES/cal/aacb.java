package cal;

import android.os.SystemClock;
import j$.time.Duration;

/* compiled from: PG */
/* loaded from: classes2.dex */
public final /* synthetic */ class aacb implements Runnable {
    public final /* synthetic */ aacd a;

    public /* synthetic */ aacb(aacd aacdVar) {
        this.a = aacdVar;
    }

    /* JADX WARN: Multi-variable type inference failed */
    @Override // java.lang.Runnable
    public final void run() {
        long millis = Duration.ofMillis(SystemClock.uptimeMillis()).toMillis();
        aacd aacdVar = this.a;
        aabr aabrVar = aacdVar.a;
        long j = aacdVar.f;
        aick g = aabrVar.g();
        long j2 = j - aacdVar.e;
        if (j2 >= 0) {
            if (j2 > ((Integer) g.get(0)).intValue()) {
                zwf zwfVar = aacdVar.c;
                zvq zvqVar = new zvq();
                zvqVar.b = false;
                zvqVar.g = false;
                zvqVar.i = 0;
                zvqVar.j = (byte) 7;
                aqyd aqydVar = aqyd.a;
                aqyc aqycVar = new aqyc();
                aqyb aqybVar = aqyb.a;
                aqya aqyaVar = new aqya();
                if ((aqyaVar.b.ad & Integer.MIN_VALUE) == 0) {
                    aqyaVar.s();
                }
                aqyb aqybVar2 = (aqyb) aqyaVar.b;
                aqybVar2.c = 2;
                aqybVar2.d = Long.valueOf(j2);
                aqyb aqybVar3 = (aqyb) aqyaVar.p();
                if ((aqycVar.b.ad & Integer.MIN_VALUE) == 0) {
                    aqycVar.s();
                }
                aqyd aqydVar2 = (aqyd) aqycVar.b;
                aqybVar3.getClass();
                aqydVar2.q = aqybVar3;
                aqydVar2.c |= 131072;
                aqyd aqydVar3 = (aqyd) aqycVar.p();
                if (aqydVar3 != null) {
                    zvqVar.c = aqydVar3;
                    zvx a = zvqVar.a();
                    if (zwfVar.a.a) {
                        if (ajdh.a == null) {
                            new ajdh();
                        }
                    } else {
                        zwfVar.d.execute(new ajel(new zwc(zwfVar, a)));
                    }
                    aacdVar.d = 0;
                } else {
                    throw new NullPointerException("Null metric");
                }
            }
            aacdVar.a(new aaca(aacdVar), aacdVar.a.f());
            return;
        }
        int intValue = ((Integer) g.get(aacdVar.d)).intValue();
        long j3 = millis - aacdVar.e;
        if (j3 > intValue) {
            aick g2 = aacdVar.a.g();
            if (aacdVar.d != g2.size() && j3 > ((Integer) g2.get(aacdVar.d)).intValue()) {
                boolean z = false;
                while (aacdVar.d != g2.size() && j3 > ((Integer) g2.get(aacdVar.d)).intValue()) {
                    aacdVar.d++;
                    z = true;
                }
                if (z) {
                    zwf zwfVar2 = aacdVar.c;
                    zvq zvqVar2 = new zvq();
                    zvqVar2.b = false;
                    zvqVar2.g = false;
                    zvqVar2.i = 0;
                    zvqVar2.j = (byte) 7;
                    aqyd aqydVar4 = aqyd.a;
                    aqyc aqycVar2 = new aqyc();
                    aqyb aqybVar4 = aqyb.a;
                    aqya aqyaVar2 = new aqya();
                    if ((aqyaVar2.b.ad & Integer.MIN_VALUE) == 0) {
                        aqyaVar2.s();
                    }
                    aqyb aqybVar5 = (aqyb) aqyaVar2.b;
                    aqybVar5.c = 1;
                    aqybVar5.d = Long.valueOf(j3);
                    aqyb aqybVar6 = (aqyb) aqyaVar2.p();
                    if ((aqycVar2.b.ad & Integer.MIN_VALUE) == 0) {
                        aqycVar2.s();
                    }
                    aqyd aqydVar5 = (aqyd) aqycVar2.b;
                    aqybVar6.getClass();
                    aqydVar5.q = aqybVar6;
                    aqydVar5.c |= 131072;
                    aqyd aqydVar6 = (aqyd) aqycVar2.p();
                    if (aqydVar6 != null) {
                        zvqVar2.c = aqydVar6;
                        zvx a2 = zvqVar2.a();
                        if (zwfVar2.a.a) {
                            if (ajdh.a == null) {
                                new ajdh();
                            }
                        } else {
                            zwfVar2.d.execute(new ajel(new zwc(zwfVar2, a2)));
                        }
                    } else {
                        throw new NullPointerException("Null metric");
                    }
                }
            }
        }
        aacdVar.a(new aacb(aacdVar), aacdVar.a.e());
    }
}
