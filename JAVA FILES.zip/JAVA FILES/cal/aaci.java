package cal;

/* compiled from: PG */
/* loaded from: classes2.dex */
public abstract class aaci implements zun {
    @Override // cal.zun
    public final /* synthetic */ int a() {
        return Integer.MAX_VALUE;
    }

    @Override // cal.zun
    public final boolean b() {
        return true;
    }

    public abstract ahti c();

    public abstract ahti d();

    public abstract void e();
}
