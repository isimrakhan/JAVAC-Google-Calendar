package cal;

/* compiled from: PG */
/* loaded from: classes2.dex */
final class aakj {
    static final amqm a = new amqm(amsi.STRING, "", amsi.MESSAGE, aakf.a);
}
