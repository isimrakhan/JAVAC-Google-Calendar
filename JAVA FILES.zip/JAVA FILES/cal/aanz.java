package cal;

/* compiled from: PG */
/* loaded from: classes2.dex */
public final class aanz extends ampg implements amqu {
    public aanz() {
        super(aaoa.a);
    }
}
