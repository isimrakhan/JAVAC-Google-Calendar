package cal;

/* compiled from: PG */
/* loaded from: classes2.dex */
final class aaae {
    static final aaae a = new aaae();

    private aaae() {
    }
}
