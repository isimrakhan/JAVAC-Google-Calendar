package cal;

/* compiled from: PG */
/* loaded from: classes2.dex */
public final class aaen extends aaey {
    public float a;
    public byte b;
    public int c;

    @Override // cal.aaey
    public final aaez a() {
        int i;
        if (this.b == 1 && (i = this.c) != 0) {
            return new aaeo(i, this.a);
        }
        StringBuilder sb = new StringBuilder();
        if (this.c == 0) {
            sb.append(" enablement");
        }
        if (this.b == 0) {
            sb.append(" samplingProbability");
        }
        throw new IllegalStateException("Missing required properties:".concat(sb.toString()));
    }

    @Override // cal.aaey
    public final aaey b(int i) {
        this.c = i;
        return this;
    }

    public final void c() {
        this.a = 0.5f;
        this.b = (byte) 1;
    }
}
