package cal;

/* compiled from: PG */
/* loaded from: classes2.dex */
final class aahc implements aahe {
    @Override // cal.aahe
    public final /* synthetic */ String a(amqs amqsVar) {
        return ((aqtg) ((aqtd) amqsVar).b).g;
    }

    @Override // cal.aahe
    public final /* synthetic */ String b(amqs amqsVar) {
        return ((aqtg) ((aqtd) amqsVar).b).f;
    }

    @Override // cal.aahe
    public final /* synthetic */ void c(amqs amqsVar, Long l) {
        aqtd aqtdVar = (aqtd) amqsVar;
        if (l != null) {
            long longValue = l.longValue();
            if ((aqtdVar.b.ad & Integer.MIN_VALUE) == 0) {
                aqtdVar.s();
            }
            aqtg aqtgVar = (aqtg) aqtdVar.b;
            aqtg aqtgVar2 = aqtg.a;
            aqtgVar.c |= 2;
            aqtgVar.e = longValue;
            return;
        }
        if ((aqtdVar.b.ad & Integer.MIN_VALUE) == 0) {
            aqtdVar.s();
        }
        aqtg aqtgVar3 = (aqtg) aqtdVar.b;
        aqtg aqtgVar4 = aqtg.a;
        aqtgVar3.c &= -3;
        aqtgVar3.e = 0L;
    }

    @Override // cal.aahe
    public final /* synthetic */ void d(amqs amqsVar) {
        aqtd aqtdVar = (aqtd) amqsVar;
        if ((aqtdVar.b.ad & Integer.MIN_VALUE) == 0) {
            aqtdVar.s();
        }
        aqtg aqtgVar = (aqtg) aqtdVar.b;
        aqtg aqtgVar2 = aqtg.a;
        aqtgVar.c &= -5;
        aqtgVar.f = aqtg.a.f;
    }
}
