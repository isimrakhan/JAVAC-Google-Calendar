package cal;

import android.content.Context;
import android.os.Debug;
import com.google.common.base.VerifyException;
import java.lang.reflect.Method;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/* compiled from: PG */
/* loaded from: classes2.dex */
public final class aaay {
    private static ahum f = ahus.a(new ahum() { // from class: cal.aaaw
        @Override // cal.ahum
        public final Object a() {
            return aaay.c();
        }
    });
    public final zul a;
    public final ztr b;
    public final apxs c;
    public final Context d;
    public final apxs e;

    public aaay(final apxs apxsVar, Context context, apxs apxsVar2, apxs apxsVar3, zul zulVar, ztr ztrVar) {
        this.a = zulVar;
        this.b = ztrVar;
        apxsVar.getClass();
        this.c = new aaau(apxsVar3, ahus.a(new ahum() { // from class: cal.aaat
            @Override // cal.ahum
            public final Object a() {
                return (aaad) apxs.this.b();
            }
        }), apxsVar);
        this.d = context;
        this.e = apxsVar2;
    }

    public static int a(Debug.MemoryInfo memoryInfo) {
        Method method = (Method) ((ahti) f.a()).g();
        if (method != null) {
            try {
                return ((Integer) method.invoke(memoryInfo, 14)).intValue();
            } catch (Error | Exception e) {
                f = new ahum() { // from class: cal.aaav
                    @Override // cal.ahum
                    public final Object a() {
                        return ahre.a;
                    }
                };
                a.p(zsj.a.d(), "MemoryInfo.getOtherPss(which) invocation failure", "com/google/android/libraries/performance/primes/metrics/memory/MemoryUsageCapture", "getOtherGraphicsPss", (char) 144, "MemoryUsageCapture.java", e);
                return -1;
            }
        }
        return -1;
    }

    /* JADX INFO: Access modifiers changed from: package-private */
    public static /* synthetic */ aaad b(apxs apxsVar, ahum ahumVar, apxs apxsVar2) {
        Object b;
        if (((Boolean) apxsVar.b()).booleanValue()) {
            b = ahumVar.a();
        } else {
            b = apxsVar2.b();
        }
        return (aaad) b;
    }

    /* JADX INFO: Access modifiers changed from: package-private */
    public static /* synthetic */ ahti c() {
        try {
            Method declaredMethod = Debug.MemoryInfo.class.getDeclaredMethod("getOtherPss", Integer.TYPE);
            declaredMethod.getClass();
            return new ahts(declaredMethod);
        } catch (Error e) {
            e = e;
            a.p(zsj.a.d(), "MemoryInfo.getOtherPss(which) failure", "com/google/android/libraries/performance/primes/metrics/memory/MemoryUsageCapture", "<init>", 'g', "MemoryUsageCapture.java", e);
            return ahre.a;
        } catch (NoSuchMethodException unused) {
            return ahre.a;
        } catch (Exception e2) {
            e = e2;
            a.p(zsj.a.d(), "MemoryInfo.getOtherPss(which) failure", "com/google/android/libraries/performance/primes/metrics/memory/MemoryUsageCapture", "<init>", 'g', "MemoryUsageCapture.java", e);
            return ahre.a;
        }
    }

    public static Long d(Pattern pattern, String str) {
        Matcher matcher = pattern.matcher(str);
        try {
            if (!matcher.find()) {
                return null;
            }
            String group = matcher.group(1);
            Object[] objArr = new Object[0];
            if (group != null) {
                return Long.valueOf(Long.parseLong(group));
            }
            throw new VerifyException(ahul.a("expected a non-null reference", objArr));
        } catch (NumberFormatException unused) {
            return null;
        }
    }
}
