package cal;

import java.io.File;

/* compiled from: PG */
/* loaded from: classes2.dex */
final class aadn implements Comparable {
    final aqxq a;
    final File b;
    final aadn c;
    final int d;
    final boolean e;
    final String f;
    long g;

    public aadn(aqxq aqxqVar, File file) {
        this.g = 0L;
        this.a = aqxqVar;
        this.b = file;
        this.c = null;
        this.d = 0;
        this.e = true;
        this.f = "";
    }

    @Override // java.lang.Comparable
    public final /* bridge */ /* synthetic */ int compareTo(Object obj) {
        aadn aadnVar = (aadn) obj;
        int i = aadnVar.d;
        int i2 = this.d;
        if (i2 != i) {
            if (i2 >= i) {
                return 1;
            }
            return -1;
        }
        boolean z = this.e;
        if (z != aadnVar.e) {
            if (!z) {
                return 1;
            }
            return -1;
        }
        return this.f.compareTo(aadnVar.f);
    }

    public aadn(aadn aadnVar, boolean z, String str) {
        this.g = 0L;
        this.a = aadnVar.a;
        this.b = aadnVar.b;
        this.c = aadnVar;
        this.d = aadnVar.d + 1;
        this.e = z;
        if (aadnVar.d != 0) {
            str = aadnVar.f + "/" + str;
        }
        this.f = str;
    }
}
