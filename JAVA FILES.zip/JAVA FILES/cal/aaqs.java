package cal;

import android.content.Context;
import android.os.Environment;
import android.os.StatFs;
import java.io.File;
import java.util.ArrayList;

/* compiled from: PG */
/* loaded from: classes2.dex */
public final class aaqs {
    private final Context a;
    private final String b = "gnp_media_cache";
    private File c;
    private String d;
    private long e;

    public aaqs(Context context) {
        this.a = context;
    }

    private final long e(File file) {
        long length;
        File[] listFiles = file.listFiles();
        long j = 0;
        if (listFiles != null) {
            for (File file2 : listFiles) {
                if (file2.isDirectory()) {
                    length = e(file2);
                } else {
                    length = file2.length();
                }
                j += length;
            }
        }
        return j;
    }

    public final synchronized long a() {
        long j;
        j = this.e;
        long j2 = 0;
        if (j == 0) {
            float totalBytes = ((float) new StatFs(Environment.getDataDirectory().getPath()).getTotalBytes()) * 0.1f;
            if (totalBytes < 5242880.0f) {
                j = totalBytes;
            } else {
                j = 5242880;
            }
            if (j < 0) {
                j = 0;
            }
            long freeBytes = new StatFs(Environment.getDataDirectory().getPath()).getFreeBytes();
            if (((float) j) >= ((float) freeBytes) * 0.05f) {
                if (b().exists()) {
                    j2 = e(b());
                }
                j = ((float) (freeBytes + j2)) * 0.05f;
            }
            this.e = j;
        }
        return j;
    }

    public final File b() {
        if (this.c == null) {
            Context context = this.a;
            this.c = new File(context.getCacheDir(), this.b);
        }
        return this.c;
    }

    public final String c(String str) {
        if (this.d == null) {
            this.d = b().getPath();
        }
        StringBuilder sb = new StringBuilder(this.d.length() + str.length() + 3);
        if (this.d == null) {
            this.d = b().getPath();
        }
        sb.append(this.d);
        sb.append(File.separatorChar);
        sb.append(str.charAt(0));
        sb.append(File.separatorChar);
        sb.append(str);
        return sb.toString();
    }

    public final void d(File file, ArrayList arrayList) {
        File[] listFiles = file.listFiles();
        if (listFiles != null) {
            for (File file2 : listFiles) {
                if (file2.isDirectory()) {
                    d(file2, arrayList);
                } else {
                    arrayList.add(file2);
                }
            }
        }
    }
}
