package cal;

/* compiled from: PG */
/* loaded from: classes2.dex */
public abstract class aads {
    public abstract aadt a();
}
