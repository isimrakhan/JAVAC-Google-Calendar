package cal;

import android.content.ComponentCallbacks2;
import android.content.res.Configuration;
import com.google.android.libraries.stitch.util.ThreadUtil$CalledOnWrongThreadException;
import java.util.Iterator;

/* compiled from: PG */
/* loaded from: classes2.dex */
final class aaqw implements ComponentCallbacks2 {
    @Override // android.content.ComponentCallbacks
    public final void onLowMemory() {
        if (abyh.b(Thread.currentThread())) {
        } else {
            throw new ThreadUtil$CalledOnWrongThreadException("Must be called on the main thread");
        }
    }

    @Override // android.content.ComponentCallbacks2
    public final void onTrimMemory(int i) {
        if (abyh.b(Thread.currentThread())) {
            aaqv.b = i;
            Iterator it = aaqv.a.iterator();
            while (it.hasNext()) {
                ((aaqt) it.next()).b(i);
            }
            return;
        }
        throw new ThreadUtil$CalledOnWrongThreadException("Must be called on the main thread");
    }

    @Override // android.content.ComponentCallbacks
    public final void onConfigurationChanged(Configuration configuration) {
    }
}
