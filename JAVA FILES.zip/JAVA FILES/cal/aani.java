package cal;

import java.io.IOException;
import java.util.concurrent.Callable;
import java.util.logging.Level;

/* compiled from: PG */
/* loaded from: classes2.dex */
public final /* synthetic */ class aani implements Callable {
    public final /* synthetic */ aanm a;
    public final /* synthetic */ aano b;

    public /* synthetic */ aani(aanm aanmVar, aano aanoVar) {
        this.a = aanmVar;
        this.b = aanoVar;
    }

    @Override // java.util.concurrent.Callable
    public final Object call() {
        abyw abywVar = new abyw();
        aanm aanmVar = this.a;
        try {
            abzp.a(((abym) aanmVar.a.h.a()).a(aanmVar.b), this.b, new abyw[]{abywVar});
            return null;
        } catch (IOException | RuntimeException e) {
            ((ajds) aanmVar.a.e.a()).execute(afwy.a(new aaiq(Level.WARNING, e, "Failed to update snapshot for %s flags may be stale.", new Object[]{aanmVar.c})));
            return null;
        }
    }
}
