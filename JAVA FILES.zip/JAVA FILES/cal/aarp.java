package cal;

import java.util.List;

/* compiled from: PG */
/* loaded from: classes2.dex */
public interface aarp {
    aics a(List list);
}
