package cal;

import java.util.concurrent.Executor;
import java.util.concurrent.ScheduledFuture;
import java.util.concurrent.atomic.AtomicBoolean;

/* compiled from: PG */
/* loaded from: classes2.dex */
public final class aaal {
    private static final aaak e = new aaak() { // from class: cal.aaaf
        @Override // cal.aaak
        public final void a(int i, String str) {
        }
    };
    public final anyt a;
    public ScheduledFuture c;
    public ScheduledFuture d;
    private final Executor f;
    private final AtomicBoolean g = new AtomicBoolean(false);
    public volatile aaak b = e;

    public aaal(ztw ztwVar, ajds ajdsVar, Executor executor, anyt anytVar) {
        this.a = anytVar;
        this.f = executor;
        ztwVar.c.b.add(new aaaj(this, ajdsVar));
    }

    public final void a() {
        ScheduledFuture scheduledFuture = this.c;
        if (scheduledFuture != null) {
            scheduledFuture.cancel(true);
            this.c = null;
        }
        ScheduledFuture scheduledFuture2 = this.d;
        if (scheduledFuture2 != null) {
            scheduledFuture2.cancel(true);
            this.d = null;
        }
    }

    /* JADX INFO: Access modifiers changed from: package-private */
    public final void b(aaak aaakVar) {
        this.b = aaakVar;
        if (this.g.getAndSet(true)) {
            return;
        }
        this.f.execute(new ajel(new ajay() { // from class: cal.aaag
            @Override // cal.ajay
            public final ajdo a() {
                ((aaad) aaal.this.a.b()).i();
                return ajdj.a;
            }
        }));
    }
}
