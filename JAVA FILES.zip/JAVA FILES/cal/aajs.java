package cal;

import java.io.IOException;
import java.math.RoundingMode;
import java.nio.ByteBuffer;
import java.nio.ByteOrder;
import org.chromium.net.UrlRequest;

/* compiled from: PG */
/* loaded from: classes2.dex */
public final class aajs {
    public final aisl a = aisl.e;
    public final ahum b;
    public final ahum c;

    public aajs(final amob amobVar, final String str, final String str2) {
        this.b = ahus.a(new ahum() { // from class: cal.aajq
            @Override // cal.ahum
            public final Object a() {
                byte[] bArr;
                amob amobVar2 = amobVar;
                int d = amobVar2.d();
                if (d == 0) {
                    bArr = ampx.b;
                } else {
                    byte[] bArr2 = new byte[d];
                    amobVar2.e(bArr2, 0, 0, d);
                    bArr = bArr2;
                }
                aisl aislVar = aajs.this.a;
                aish aishVar = ((aisk) aislVar).b;
                int i = aishVar.e;
                int i2 = aishVar.f;
                int length = bArr.length;
                StringBuilder sb = new StringBuilder(i * aiyi.a(length, i2, RoundingMode.CEILING));
                try {
                    aislVar.b(sb, bArr, length);
                    return sb.toString();
                } catch (IOException e) {
                    throw new AssertionError(e);
                }
            }
        });
        this.c = ahus.a(new ahum() { // from class: cal.aajr
            /* JADX WARN: Failed to find 'out' block for switch in B:7:0x0071. Please report as an issue. */
            @Override // cal.ahum
            public final Object a() {
                long j;
                long j2;
                long j3;
                long j4;
                long j5;
                long j6;
                long j7;
                long j8;
                long j9;
                long j10;
                long j11;
                long j12;
                long j13;
                long j14;
                int i = airv.a;
                int i2 = aisa.a;
                airz airzVar = new airz();
                byte[] bytes = str.getBytes();
                airzVar.d(ByteBuffer.wrap(bytes, 0, bytes.length).order(ByteOrder.LITTLE_ENDIAN));
                airzVar.a.put((byte) 0);
                if (airzVar.a.remaining() < 8) {
                    airzVar.b();
                }
                byte[] bytes2 = str2.getBytes();
                airzVar.d(ByteBuffer.wrap(bytes2, 0, bytes2.length).order(ByteOrder.LITTLE_ENDIAN));
                airzVar.b();
                airzVar.a.flip();
                if (airzVar.a.remaining() > 0) {
                    ByteBuffer byteBuffer = airzVar.a;
                    airzVar.d += byteBuffer.remaining();
                    switch (byteBuffer.remaining()) {
                        case 1:
                            j = 0;
                            j7 = (byteBuffer.get(0) & 255) ^ j;
                            j8 = 0;
                            airzVar.b = (Long.rotateLeft(j7 * (-8663945395140668459L), 31) * 5545529020109919103L) ^ airzVar.b;
                            airzVar.c ^= Long.rotateLeft(j8 * 5545529020109919103L, 33) * (-8663945395140668459L);
                            ByteBuffer byteBuffer2 = airzVar.a;
                            byteBuffer2.position(byteBuffer2.limit());
                            break;
                        case 2:
                            j2 = 0;
                            j = j2 ^ ((byteBuffer.get(1) & 255) << 8);
                            j7 = (byteBuffer.get(0) & 255) ^ j;
                            j8 = 0;
                            airzVar.b = (Long.rotateLeft(j7 * (-8663945395140668459L), 31) * 5545529020109919103L) ^ airzVar.b;
                            airzVar.c ^= Long.rotateLeft(j8 * 5545529020109919103L, 33) * (-8663945395140668459L);
                            ByteBuffer byteBuffer22 = airzVar.a;
                            byteBuffer22.position(byteBuffer22.limit());
                            break;
                        case 3:
                            j3 = 0;
                            j2 = j3 ^ ((byteBuffer.get(2) & 255) << 16);
                            j = j2 ^ ((byteBuffer.get(1) & 255) << 8);
                            j7 = (byteBuffer.get(0) & 255) ^ j;
                            j8 = 0;
                            airzVar.b = (Long.rotateLeft(j7 * (-8663945395140668459L), 31) * 5545529020109919103L) ^ airzVar.b;
                            airzVar.c ^= Long.rotateLeft(j8 * 5545529020109919103L, 33) * (-8663945395140668459L);
                            ByteBuffer byteBuffer222 = airzVar.a;
                            byteBuffer222.position(byteBuffer222.limit());
                            break;
                        case 4:
                            j4 = 0;
                            j3 = j4 ^ ((byteBuffer.get(3) & 255) << 24);
                            j2 = j3 ^ ((byteBuffer.get(2) & 255) << 16);
                            j = j2 ^ ((byteBuffer.get(1) & 255) << 8);
                            j7 = (byteBuffer.get(0) & 255) ^ j;
                            j8 = 0;
                            airzVar.b = (Long.rotateLeft(j7 * (-8663945395140668459L), 31) * 5545529020109919103L) ^ airzVar.b;
                            airzVar.c ^= Long.rotateLeft(j8 * 5545529020109919103L, 33) * (-8663945395140668459L);
                            ByteBuffer byteBuffer2222 = airzVar.a;
                            byteBuffer2222.position(byteBuffer2222.limit());
                            break;
                        case 5:
                            j5 = 0;
                            j4 = j5 ^ ((byteBuffer.get(4) & 255) << 32);
                            j3 = j4 ^ ((byteBuffer.get(3) & 255) << 24);
                            j2 = j3 ^ ((byteBuffer.get(2) & 255) << 16);
                            j = j2 ^ ((byteBuffer.get(1) & 255) << 8);
                            j7 = (byteBuffer.get(0) & 255) ^ j;
                            j8 = 0;
                            airzVar.b = (Long.rotateLeft(j7 * (-8663945395140668459L), 31) * 5545529020109919103L) ^ airzVar.b;
                            airzVar.c ^= Long.rotateLeft(j8 * 5545529020109919103L, 33) * (-8663945395140668459L);
                            ByteBuffer byteBuffer22222 = airzVar.a;
                            byteBuffer22222.position(byteBuffer22222.limit());
                            break;
                        case 6:
                            j6 = 0;
                            j5 = ((byteBuffer.get(5) & 255) << 40) ^ j6;
                            j4 = j5 ^ ((byteBuffer.get(4) & 255) << 32);
                            j3 = j4 ^ ((byteBuffer.get(3) & 255) << 24);
                            j2 = j3 ^ ((byteBuffer.get(2) & 255) << 16);
                            j = j2 ^ ((byteBuffer.get(1) & 255) << 8);
                            j7 = (byteBuffer.get(0) & 255) ^ j;
                            j8 = 0;
                            airzVar.b = (Long.rotateLeft(j7 * (-8663945395140668459L), 31) * 5545529020109919103L) ^ airzVar.b;
                            airzVar.c ^= Long.rotateLeft(j8 * 5545529020109919103L, 33) * (-8663945395140668459L);
                            ByteBuffer byteBuffer222222 = airzVar.a;
                            byteBuffer222222.position(byteBuffer222222.limit());
                            break;
                        case 7:
                            j6 = (byteBuffer.get(6) & 255) << 48;
                            j5 = ((byteBuffer.get(5) & 255) << 40) ^ j6;
                            j4 = j5 ^ ((byteBuffer.get(4) & 255) << 32);
                            j3 = j4 ^ ((byteBuffer.get(3) & 255) << 24);
                            j2 = j3 ^ ((byteBuffer.get(2) & 255) << 16);
                            j = j2 ^ ((byteBuffer.get(1) & 255) << 8);
                            j7 = (byteBuffer.get(0) & 255) ^ j;
                            j8 = 0;
                            airzVar.b = (Long.rotateLeft(j7 * (-8663945395140668459L), 31) * 5545529020109919103L) ^ airzVar.b;
                            airzVar.c ^= Long.rotateLeft(j8 * 5545529020109919103L, 33) * (-8663945395140668459L);
                            ByteBuffer byteBuffer2222222 = airzVar.a;
                            byteBuffer2222222.position(byteBuffer2222222.limit());
                            break;
                        case 8:
                            j8 = 0;
                            j7 = byteBuffer.getLong();
                            airzVar.b = (Long.rotateLeft(j7 * (-8663945395140668459L), 31) * 5545529020109919103L) ^ airzVar.b;
                            airzVar.c ^= Long.rotateLeft(j8 * 5545529020109919103L, 33) * (-8663945395140668459L);
                            ByteBuffer byteBuffer22222222 = airzVar.a;
                            byteBuffer22222222.position(byteBuffer22222222.limit());
                            break;
                        case 9:
                            j9 = 0;
                            j8 = j9 ^ (byteBuffer.get(8) & 255);
                            j7 = byteBuffer.getLong();
                            airzVar.b = (Long.rotateLeft(j7 * (-8663945395140668459L), 31) * 5545529020109919103L) ^ airzVar.b;
                            airzVar.c ^= Long.rotateLeft(j8 * 5545529020109919103L, 33) * (-8663945395140668459L);
                            ByteBuffer byteBuffer222222222 = airzVar.a;
                            byteBuffer222222222.position(byteBuffer222222222.limit());
                            break;
                        case 10:
                            j10 = 0;
                            j9 = j10 ^ ((byteBuffer.get(9) & 255) << 8);
                            j8 = j9 ^ (byteBuffer.get(8) & 255);
                            j7 = byteBuffer.getLong();
                            airzVar.b = (Long.rotateLeft(j7 * (-8663945395140668459L), 31) * 5545529020109919103L) ^ airzVar.b;
                            airzVar.c ^= Long.rotateLeft(j8 * 5545529020109919103L, 33) * (-8663945395140668459L);
                            ByteBuffer byteBuffer2222222222 = airzVar.a;
                            byteBuffer2222222222.position(byteBuffer2222222222.limit());
                            break;
                        case 11:
                            j11 = 0;
                            j10 = j11 ^ ((byteBuffer.get(10) & 255) << 16);
                            j9 = j10 ^ ((byteBuffer.get(9) & 255) << 8);
                            j8 = j9 ^ (byteBuffer.get(8) & 255);
                            j7 = byteBuffer.getLong();
                            airzVar.b = (Long.rotateLeft(j7 * (-8663945395140668459L), 31) * 5545529020109919103L) ^ airzVar.b;
                            airzVar.c ^= Long.rotateLeft(j8 * 5545529020109919103L, 33) * (-8663945395140668459L);
                            ByteBuffer byteBuffer22222222222 = airzVar.a;
                            byteBuffer22222222222.position(byteBuffer22222222222.limit());
                            break;
                        case UrlRequest.Status.SENDING_REQUEST /* 12 */:
                            j12 = 0;
                            j11 = j12 ^ ((byteBuffer.get(11) & 255) << 24);
                            j10 = j11 ^ ((byteBuffer.get(10) & 255) << 16);
                            j9 = j10 ^ ((byteBuffer.get(9) & 255) << 8);
                            j8 = j9 ^ (byteBuffer.get(8) & 255);
                            j7 = byteBuffer.getLong();
                            airzVar.b = (Long.rotateLeft(j7 * (-8663945395140668459L), 31) * 5545529020109919103L) ^ airzVar.b;
                            airzVar.c ^= Long.rotateLeft(j8 * 5545529020109919103L, 33) * (-8663945395140668459L);
                            ByteBuffer byteBuffer222222222222 = airzVar.a;
                            byteBuffer222222222222.position(byteBuffer222222222222.limit());
                            break;
                        case UrlRequest.Status.WAITING_FOR_RESPONSE /* 13 */:
                            j13 = 0;
                            j12 = j13 ^ ((byteBuffer.get(12) & 255) << 32);
                            j11 = j12 ^ ((byteBuffer.get(11) & 255) << 24);
                            j10 = j11 ^ ((byteBuffer.get(10) & 255) << 16);
                            j9 = j10 ^ ((byteBuffer.get(9) & 255) << 8);
                            j8 = j9 ^ (byteBuffer.get(8) & 255);
                            j7 = byteBuffer.getLong();
                            airzVar.b = (Long.rotateLeft(j7 * (-8663945395140668459L), 31) * 5545529020109919103L) ^ airzVar.b;
                            airzVar.c ^= Long.rotateLeft(j8 * 5545529020109919103L, 33) * (-8663945395140668459L);
                            ByteBuffer byteBuffer2222222222222 = airzVar.a;
                            byteBuffer2222222222222.position(byteBuffer2222222222222.limit());
                            break;
                        case UrlRequest.Status.READING_RESPONSE /* 14 */:
                            j14 = 0;
                            j13 = j14 ^ ((byteBuffer.get(13) & 255) << 40);
                            j12 = j13 ^ ((byteBuffer.get(12) & 255) << 32);
                            j11 = j12 ^ ((byteBuffer.get(11) & 255) << 24);
                            j10 = j11 ^ ((byteBuffer.get(10) & 255) << 16);
                            j9 = j10 ^ ((byteBuffer.get(9) & 255) << 8);
                            j8 = j9 ^ (byteBuffer.get(8) & 255);
                            j7 = byteBuffer.getLong();
                            airzVar.b = (Long.rotateLeft(j7 * (-8663945395140668459L), 31) * 5545529020109919103L) ^ airzVar.b;
                            airzVar.c ^= Long.rotateLeft(j8 * 5545529020109919103L, 33) * (-8663945395140668459L);
                            ByteBuffer byteBuffer22222222222222 = airzVar.a;
                            byteBuffer22222222222222.position(byteBuffer22222222222222.limit());
                            break;
                        case 15:
                            j14 = (byteBuffer.get(14) & 255) << 48;
                            j13 = j14 ^ ((byteBuffer.get(13) & 255) << 40);
                            j12 = j13 ^ ((byteBuffer.get(12) & 255) << 32);
                            j11 = j12 ^ ((byteBuffer.get(11) & 255) << 24);
                            j10 = j11 ^ ((byteBuffer.get(10) & 255) << 16);
                            j9 = j10 ^ ((byteBuffer.get(9) & 255) << 8);
                            j8 = j9 ^ (byteBuffer.get(8) & 255);
                            j7 = byteBuffer.getLong();
                            airzVar.b = (Long.rotateLeft(j7 * (-8663945395140668459L), 31) * 5545529020109919103L) ^ airzVar.b;
                            airzVar.c ^= Long.rotateLeft(j8 * 5545529020109919103L, 33) * (-8663945395140668459L);
                            ByteBuffer byteBuffer222222222222222 = airzVar.a;
                            byteBuffer222222222222222.position(byteBuffer222222222222222.limit());
                            break;
                        default:
                            throw new AssertionError("Should never get here.");
                    }
                }
                aajs aajsVar = aajs.this;
                long j15 = airzVar.b;
                long j16 = airzVar.d;
                long j17 = j15 ^ j16;
                long j18 = j16 ^ airzVar.c;
                long j19 = j17 + j18;
                long j20 = ((j19 >>> 33) ^ j19) * (-49064778989728563L);
                long j21 = (j20 ^ (j20 >>> 33)) * (-4265267296055464877L);
                long j22 = j18 + j19;
                long j23 = ((j22 >>> 33) ^ j22) * (-49064778989728563L);
                long j24 = (j23 ^ (j23 >>> 33)) * (-4265267296055464877L);
                long j25 = j24 ^ (j24 >>> 33);
                long j26 = (j21 ^ (j21 >>> 33)) + j25;
                airzVar.b = j26;
                airzVar.c = j25 + j26;
                byte[] array = ByteBuffer.wrap(new byte[16]).order(ByteOrder.LITTLE_ENDIAN).putLong(airzVar.b).putLong(airzVar.c).array();
                int i3 = airq.b;
                byte[] bArr = (byte[]) new airo(array).a.clone();
                int length = bArr.length;
                aisl aislVar = aajsVar.a;
                aish aishVar = ((aisk) aislVar).b;
                StringBuilder sb = new StringBuilder(aishVar.e * aiyi.a(length, aishVar.f, RoundingMode.CEILING));
                try {
                    aislVar.b(sb, bArr, length);
                    return sb.toString();
                } catch (IOException e) {
                    throw new AssertionError(e);
                }
            }
        });
    }
}
