package cal;

/* compiled from: PG */
/* loaded from: classes2.dex */
public abstract class aagb {
    protected final aqwl a;

    public aagb(aqwl aqwlVar) {
        this.a = aqwlVar;
    }

    public abstract long a(String str);

    public abstract aqwl b(Long l);

    public abstract aqwl c(Long l);

    public abstract boolean d();
}
