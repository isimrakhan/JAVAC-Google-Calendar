package cal;

/* compiled from: PG */
/* loaded from: classes2.dex */
public interface aapz extends AutoCloseable {
    ajdo a(aapy aapyVar);
}
