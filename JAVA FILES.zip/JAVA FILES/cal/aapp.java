package cal;

import java.io.Serializable;
import java.util.Locale;

/* compiled from: PG */
/* loaded from: classes2.dex */
public final class aapp implements Serializable {
    private static final long serialVersionUID = 1;
    public final int a;
    public final boolean b;

    public aapp(int i, boolean z) {
        this.a = i;
        this.b = z;
    }

    public final boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if ((obj instanceof aapp) && this.a == ((aapp) obj).a) {
            return true;
        }
        return false;
    }

    public final int hashCode() {
        return this.a + 527;
    }

    public final String toString() {
        return String.format(Locale.US, "VisualElementTag {id: %d, isRootPage: %b}", Integer.valueOf(this.a), Boolean.valueOf(this.b));
    }
}
