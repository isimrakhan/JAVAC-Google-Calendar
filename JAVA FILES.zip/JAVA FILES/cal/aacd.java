package cal;

import android.os.Handler;
import java.util.concurrent.Executors;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.atomic.AtomicReference;

/* JADX INFO: Access modifiers changed from: package-private */
/* compiled from: PG */
/* loaded from: classes2.dex */
public final class aacd {
    public final aabr a;
    public final Handler b;
    public final zwf c;
    public int d = 0;
    public long e = -1;
    public volatile long f = -1;
    volatile boolean g = false;
    final AtomicReference h = new AtomicReference(ajdj.a);
    private final ajds i;

    public aacd(ajds ajdsVar, aabr aabrVar, zwf zwfVar, Handler handler) {
        this.i = ajdsVar;
        this.a = aabrVar;
        this.b = handler;
        this.c = zwfVar;
    }

    public final void a(Runnable runnable, int i) {
        if (this.g) {
            ajee ajeeVar = new ajee();
            this.h.set(ajeeVar);
            if (this.g) {
                ajeeVar.k(this.i.schedule(runnable, i, TimeUnit.MILLISECONDS));
            }
        }
    }

    /* JADX INFO: Access modifiers changed from: package-private */
    public final void b() {
        if (this.g) {
            return;
        }
        this.g = true;
        AtomicReference atomicReference = this.h;
        aaca aacaVar = new aaca(this);
        ajds ajdsVar = this.i;
        ajel ajelVar = new ajel(Executors.callable(aacaVar, null));
        ajdsVar.execute(ajelVar);
        atomicReference.set(ajelVar);
    }
}
