package cal;

import android.content.Context;
import java.util.concurrent.Executor;
import java.util.concurrent.TimeUnit;

/* compiled from: PG */
/* loaded from: classes2.dex */
public final class aadw extends aadu implements ztq, zwh {
    public static final long a = TimeUnit.HOURS.toMillis(12);
    public final zwf b;
    public final Context c;
    public final anyt d;
    public final aafo e;
    private final ztw f;
    private final Executor g;

    public aadw(zwg zwgVar, Context context, ztw ztwVar, Executor executor, anyt anytVar, aafo aafoVar, apxs apxsVar) {
        this.b = zwgVar.a(executor, anytVar, apxsVar);
        this.g = executor;
        this.c = context;
        this.d = anytVar;
        this.e = aafoVar;
        this.f = ztwVar;
    }

    @Override // cal.ztq
    public final void i(zry zryVar) {
        this.f.c.b.remove(this);
        this.g.execute(new ajel(new ajay() { // from class: cal.aadv
            /* JADX WARN: Removed duplicated region for block: B:111:0x053a  */
            /* JADX WARN: Removed duplicated region for block: B:114:0x0549  */
            /* JADX WARN: Removed duplicated region for block: B:118:0x0570  */
            /* JADX WARN: Removed duplicated region for block: B:121:0x0592  */
            /* JADX WARN: Removed duplicated region for block: B:127:0x05cc  */
            /* JADX WARN: Removed duplicated region for block: B:135:0x05f3  */
            /* JADX WARN: Removed duplicated region for block: B:198:0x03c4 A[EXC_TOP_SPLITTER, SYNTHETIC] */
            @Override // cal.ajay
            /*
                Code decompiled incorrectly, please refer to instructions dump.
                To view partially-correct code enable 'Show inconsistent code' option in preferences
            */
            public final cal.ajdo a() {
                /*
                    Method dump skipped, instructions count: 1555
                    To view this dump change 'Code comments level' option to 'DEBUG'
                */
                throw new UnsupportedOperationException("Method not decompiled: cal.aadv.a():cal.ajdo");
            }
        }));
    }

    @Override // cal.zwh
    public final void u() {
        this.f.c.b.add(this);
    }

    @Override // cal.ztq
    public final /* synthetic */ void j(zry zryVar) {
    }
}
