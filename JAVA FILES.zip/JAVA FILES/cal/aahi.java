package cal;

import android.content.Context;

/* compiled from: PG */
/* loaded from: classes2.dex */
final class aahi extends aaio {
    public final Context a;
    public final ahum b;

    public aahi(Context context, ahum ahumVar) {
        this.a = context;
        this.b = ahumVar;
    }

    @Override // cal.aaio
    public final Context a() {
        return this.a;
    }

    @Override // cal.aaio
    public final ahum b() {
        return this.b;
    }

    public final boolean equals(Object obj) {
        if (obj == this) {
            return true;
        }
        if (obj instanceof aaio) {
            aaio aaioVar = (aaio) obj;
            if (this.a.equals(aaioVar.a()) && this.b.equals(aaioVar.b())) {
                return true;
            }
        }
        return false;
    }

    public final int hashCode() {
        return ((this.a.hashCode() ^ 1000003) * 1000003) ^ this.b.hashCode();
    }

    public final String toString() {
        ahum ahumVar = this.b;
        return "FlagsContext{context=" + this.a.toString() + ", hermeticFileOverrides=" + ahumVar.toString() + "}";
    }
}
