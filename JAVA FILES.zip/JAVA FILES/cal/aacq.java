package cal;

/* compiled from: PG */
/* loaded from: classes2.dex */
public final class aacq {
    volatile String a;
    public volatile zwn b;
    volatile zwn c;
    volatile zwn d;
}
