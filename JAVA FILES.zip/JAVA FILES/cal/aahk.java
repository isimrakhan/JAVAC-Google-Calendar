package cal;

import android.content.ContentProviderClient;
import android.content.ContentResolver;
import android.database.ContentObserver;
import android.database.Cursor;
import android.net.Uri;
import android.os.RemoteException;
import android.util.Log;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/* compiled from: PG */
/* loaded from: classes2.dex */
public final class aahk implements aahn {
    public static final Map a = new aaz();
    public static final String[] b = {"key", "value"};
    public final Object c;
    public volatile Map d;
    public final List e;
    private final ContentResolver f;
    private final Uri g;
    private final ContentObserver h;

    public aahk(ContentResolver contentResolver, Uri uri) {
        aahj aahjVar = new aahj(this);
        this.h = aahjVar;
        this.c = new Object();
        this.e = new ArrayList();
        contentResolver.getClass();
        uri.getClass();
        this.f = contentResolver;
        this.g = uri;
        contentResolver.registerContentObserver(uri, false, aahjVar);
    }

    /* JADX INFO: Access modifiers changed from: package-private */
    public static synchronized void c() {
        synchronized (aahk.class) {
            Map map = a;
            aax aaxVar = ((aaz) map).c;
            if (aaxVar == null) {
                aaxVar = new aax((aaz) map);
                ((aaz) map).c = aaxVar;
            }
            aay aayVar = new aay(aaxVar.a);
            while (aayVar.c < aayVar.b) {
                aahk aahkVar = (aahk) aayVar.next();
                aahkVar.f.unregisterContentObserver(aahkVar.h);
            }
            Object obj = a;
            if (((abh) obj).f > 0) {
                ((abh) obj).d = abk.a;
                ((abh) obj).e = abk.c;
                ((abh) obj).f = 0;
            }
        }
    }

    /* JADX WARN: Removed duplicated region for block: B:37:0x004b  */
    @Override // cal.aahn
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct code enable 'Show inconsistent code' option in preferences
    */
    public final /* synthetic */ java.lang.Object a(java.lang.String r6) {
        /*
            r5 = this;
            java.util.Map r0 = r5.d
            if (r0 != 0) goto L49
            java.lang.Object r1 = r5.c
            monitor-enter(r1)
            java.util.Map r0 = r5.d     // Catch: java.lang.Throwable -> L46
            if (r0 != 0) goto L44
            android.os.StrictMode$ThreadPolicy r0 = android.os.StrictMode.allowThreadDiskReads()     // Catch: java.lang.Throwable -> L46
            java.util.Map r2 = r5.b()     // Catch: java.lang.Throwable -> L14 java.lang.IllegalStateException -> L16 android.database.sqlite.SQLiteException -> L18 java.lang.SecurityException -> L1a
            goto L26
        L14:
            r6 = move-exception
            goto L40
        L16:
            r2 = move-exception
            goto L30
        L18:
            r2 = move-exception
            goto L30
        L1a:
            long r2 = android.os.Binder.clearCallingIdentity()     // Catch: java.lang.Throwable -> L14 java.lang.IllegalStateException -> L16 android.database.sqlite.SQLiteException -> L18 java.lang.SecurityException -> L2f
            java.util.Map r4 = r5.b()     // Catch: java.lang.Throwable -> L2a
            android.os.Binder.restoreCallingIdentity(r2)     // Catch: java.lang.Throwable -> L14 java.lang.IllegalStateException -> L16 android.database.sqlite.SQLiteException -> L18 java.lang.SecurityException -> L2f
            r2 = r4
        L26:
            android.os.StrictMode.setThreadPolicy(r0)     // Catch: java.lang.Throwable -> L46
            goto L3c
        L2a:
            r4 = move-exception
            android.os.Binder.restoreCallingIdentity(r2)     // Catch: java.lang.Throwable -> L14 java.lang.IllegalStateException -> L16 android.database.sqlite.SQLiteException -> L18 java.lang.SecurityException -> L2f
            throw r4     // Catch: java.lang.Throwable -> L14 java.lang.IllegalStateException -> L16 android.database.sqlite.SQLiteException -> L18 java.lang.SecurityException -> L2f
        L2f:
            r2 = move-exception
        L30:
            java.lang.String r3 = "ConfigurationContentLdr"
            java.lang.String r4 = "Unable to query ContentProvider, using default values"
            android.util.Log.w(r3, r4, r2)     // Catch: java.lang.Throwable -> L14
            java.util.Map r2 = java.util.Collections.emptyMap()     // Catch: java.lang.Throwable -> L14
            goto L26
        L3c:
            r5.d = r2     // Catch: java.lang.Throwable -> L46
            r0 = r2
            goto L44
        L40:
            android.os.StrictMode.setThreadPolicy(r0)     // Catch: java.lang.Throwable -> L46
            throw r6     // Catch: java.lang.Throwable -> L46
        L44:
            monitor-exit(r1)     // Catch: java.lang.Throwable -> L46
            goto L49
        L46:
            r6 = move-exception
            monitor-exit(r1)     // Catch: java.lang.Throwable -> L46
            throw r6
        L49:
            if (r0 != 0) goto L4f
            java.util.Map r0 = java.util.Collections.emptyMap()
        L4f:
            java.lang.Object r6 = r0.get(r6)
            java.lang.String r6 = (java.lang.String) r6
            return r6
        */
        throw new UnsupportedOperationException("Method not decompiled: cal.aahk.a(java.lang.String):java.lang.Object");
    }

    final /* synthetic */ Map b() {
        Map emptyMap;
        Cursor query;
        Map hashMap;
        Map emptyMap2;
        ContentProviderClient acquireUnstableContentProviderClient = this.f.acquireUnstableContentProviderClient(this.g);
        try {
            if (acquireUnstableContentProviderClient == null) {
                Log.w("ConfigurationContentLdr", "Unable to acquire ContentProviderClient, using default values");
                return Collections.emptyMap();
            }
            try {
                query = acquireUnstableContentProviderClient.query(this.g, b, null, null, null);
            } catch (RemoteException e) {
                Log.w("ConfigurationContentLdr", "ContentProvider query failed, using default values", e);
                emptyMap = Collections.emptyMap();
            }
            try {
                if (query == null) {
                    Log.w("ConfigurationContentLdr", "ContentProvider query returned null cursor, using default values");
                    emptyMap = Collections.emptyMap();
                } else {
                    int count = query.getCount();
                    if (count == 0) {
                        emptyMap2 = Collections.emptyMap();
                    } else {
                        if (count <= 256) {
                            hashMap = new aaz(count);
                        } else {
                            hashMap = new HashMap(count, 1.0f);
                        }
                        while (query.moveToNext()) {
                            hashMap.put(query.getString(0), query.getString(1));
                        }
                        if (!query.isAfterLast()) {
                            Log.w("ConfigurationContentLdr", "Cursor read incomplete (ContentProvider dead?), using default values");
                            emptyMap2 = Collections.emptyMap();
                        } else {
                            query.close();
                            emptyMap = hashMap;
                        }
                    }
                    query.close();
                    emptyMap = emptyMap2;
                }
                return emptyMap;
            } catch (Throwable th) {
                if (query != null) {
                    try {
                        query.close();
                    } catch (Throwable th2) {
                        th.addSuppressed(th2);
                    }
                }
                throw th;
            }
        } finally {
            acquireUnstableContentProviderClient.release();
        }
    }
}
