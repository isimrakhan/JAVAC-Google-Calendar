package cal;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Iterator;
import java.util.List;

/* compiled from: PG */
/* loaded from: classes2.dex */
final class aaeu {
    public final aaet a;
    private long b = 1;

    public aaeu(aaet aaetVar) {
        this.a = aaetVar;
    }

    /* JADX WARN: Multi-variable type inference failed */
    public final void a(aaet aaetVar, long j, ArrayList arrayList) {
        List list;
        if (aaetVar.f == null) {
            if (aaetVar.f == null) {
                list = Collections.emptyList();
            } else {
                list = aaetVar.f;
            }
        } else {
            list = aaetVar.f;
            aaetVar.f = null;
        }
        if (aaetVar.h != 1 || !list.isEmpty()) {
            aqvu aqvuVar = aqvu.a;
            aqvs aqvsVar = new aqvs();
            int i = aaetVar.g;
            String str = aaetVar.b;
            if ((aqvsVar.b.ad & Integer.MIN_VALUE) == 0) {
                aqvsVar.s();
            }
            aqvu aqvuVar2 = (aqvu) aqvsVar.b;
            str.getClass();
            aqvuVar2.c |= 1;
            aqvuVar2.d = str;
            long j2 = aaetVar.c;
            if ((aqvsVar.b.ad & Integer.MIN_VALUE) == 0) {
                aqvsVar.s();
            }
            aqvu aqvuVar3 = (aqvu) aqvsVar.b;
            aqvuVar3.c |= 512;
            aqvuVar3.i = j2;
            long j3 = aaetVar.d;
            long j4 = -1;
            if (j3 != -1) {
                j4 = j3 - aaetVar.c;
            }
            if ((aqvsVar.b.ad & Integer.MIN_VALUE) == 0) {
                aqvsVar.s();
            }
            aqvu aqvuVar4 = (aqvu) aqvsVar.b;
            aqvuVar4.c |= 1024;
            aqvuVar4.j = j4;
            long j5 = aaetVar.e;
            if ((aqvsVar.b.ad & Integer.MIN_VALUE) == 0) {
                aqvsVar.s();
            }
            aqvu aqvuVar5 = (aqvu) aqvsVar.b;
            aqvuVar5.c |= 4096;
            aqvuVar5.k = j5;
            long j6 = this.b;
            this.b = 1 + j6;
            if ((aqvsVar.b.ad & Integer.MIN_VALUE) == 0) {
                aqvsVar.s();
            }
            aqvu aqvuVar6 = (aqvu) aqvsVar.b;
            aqvuVar6.c |= 8;
            aqvuVar6.g = j6;
            if ((aqvsVar.b.ad & Integer.MIN_VALUE) == 0) {
                aqvsVar.s();
            }
            aqvu aqvuVar7 = (aqvu) aqvsVar.b;
            aqvuVar7.c |= 16;
            aqvuVar7.h = j;
            int i2 = aaetVar.h - 1;
            if (i2 != 1) {
                if (i2 != 3) {
                    if ((aqvsVar.b.ad & Integer.MIN_VALUE) == 0) {
                        aqvsVar.s();
                    }
                    aqvu aqvuVar8 = (aqvu) aqvsVar.b;
                    aqvuVar8.l = 0;
                    aqvuVar8.c |= 8192;
                } else {
                    if ((aqvsVar.b.ad & Integer.MIN_VALUE) == 0) {
                        aqvsVar.s();
                    }
                    aqvu aqvuVar9 = (aqvu) aqvsVar.b;
                    aqvuVar9.l = 4;
                    aqvuVar9.c |= 8192;
                }
            } else {
                if ((aqvsVar.b.ad & Integer.MIN_VALUE) == 0) {
                    aqvsVar.s();
                }
                aqvu aqvuVar10 = (aqvu) aqvsVar.b;
                aqvuVar10.l = 1;
                aqvuVar10.c |= 8192;
            }
            if (aaetVar.h == 1) {
                long j7 = ((aaet) list.get(list.size() - 1)).d - aaetVar.c;
                if ((aqvsVar.b.ad & Integer.MIN_VALUE) == 0) {
                    aqvsVar.s();
                }
                aqvu aqvuVar11 = (aqvu) aqvsVar.b;
                aqvuVar11.c |= 1024;
                aqvuVar11.j = j7;
            }
            arrayList.add((aqvu) aqvsVar.p());
            Iterator it = list.iterator();
            while (it.hasNext()) {
                a((aaet) it.next(), ((aqvu) aqvsVar.b).g, arrayList);
            }
        }
    }
}
