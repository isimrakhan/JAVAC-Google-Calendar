package cal;

import android.graphics.Paint;
import android.graphics.Typeface;
import java.lang.ref.WeakReference;

/* compiled from: PG */
/* loaded from: classes2.dex */
public final class aaqt<T> {
    private T a;
    private WeakReference b;
    private boolean c = false;
    private boolean d = true;

    /* JADX WARN: Multi-variable type inference failed */
    /* JADX WARN: Type inference failed for: r0v16 */
    /* JADX WARN: Type inference failed for: r0v17 */
    /* JADX WARN: Type inference failed for: r0v5 */
    /* JADX WARN: Type inference failed for: r0v7, types: [T, android.graphics.Paint, java.lang.Object] */
    public final synchronized Object a() {
        Object obj;
        if (!this.c) {
            this.c = true;
            if (abyh.b(Thread.currentThread())) {
                aaqv.a.add(this);
                int i = aaqv.b;
                if (i != -1) {
                    b(i);
                }
            } else {
                abyh.a().post(new aaqu(this));
            }
        }
        T t = this.a;
        if (t != null) {
            return t;
        }
        WeakReference weakReference = this.b;
        if (weakReference == null) {
            obj = (T) null;
        } else {
            obj = weakReference.get();
        }
        if (obj == 0) {
            obj = (T) new Paint();
            obj.setAntiAlias(true);
            obj.setTextAlign(Paint.Align.CENTER);
            obj.setTypeface(Typeface.create(Typeface.SANS_SERIF, 0));
            if (this.d) {
                this.a = obj;
                this.b = null;
            } else {
                this.b = new WeakReference(obj);
            }
        }
        return obj;
    }

    /* JADX INFO: Access modifiers changed from: package-private */
    public final synchronized void b(int i) {
        boolean z;
        T t;
        if (i < 20) {
            z = true;
        } else {
            z = false;
        }
        if (z != this.d) {
            this.d = z;
            if (z) {
                if (this.a == null) {
                    WeakReference weakReference = this.b;
                    if (weakReference == null) {
                        t = null;
                    } else {
                        t = (T) weakReference.get();
                    }
                    if (t != null) {
                        this.a = t;
                    } else {
                        this.b = null;
                    }
                }
            } else {
                T t2 = this.a;
                if (t2 != null) {
                    this.b = new WeakReference(t2);
                    this.a = null;
                }
            }
        }
    }
}
