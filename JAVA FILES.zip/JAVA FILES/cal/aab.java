package cal;

import java.util.Iterator;
import java.util.Map;

/* compiled from: PG */
/* loaded from: classes.dex */
public final class aab extends aad implements Iterator {
    final /* synthetic */ aae a;
    private aaa b;
    private boolean c = true;

    public aab(aae aaeVar) {
        this.a = aaeVar;
    }

    @Override // java.util.Iterator
    /* renamed from: a, reason: merged with bridge method [inline-methods] */
    public final Map.Entry next() {
        aaa aaaVar;
        if (this.c) {
            this.c = false;
            aaaVar = this.a.b;
        } else {
            aaa aaaVar2 = this.b;
            if (aaaVar2 != null) {
                aaaVar = aaaVar2.c;
            } else {
                aaaVar = null;
            }
        }
        this.b = aaaVar;
        return this.b;
    }

    @Override // cal.aad
    public final void bi(aaa aaaVar) {
        boolean z;
        aaa aaaVar2 = this.b;
        if (aaaVar == aaaVar2) {
            aaa aaaVar3 = aaaVar2.d;
            this.b = aaaVar3;
            if (aaaVar3 == null) {
                z = true;
            } else {
                z = false;
            }
            this.c = z;
        }
    }

    @Override // java.util.Iterator
    public final boolean hasNext() {
        if (this.c) {
            if (this.a.b != null) {
                return true;
            }
            return false;
        }
        aaa aaaVar = this.b;
        if (aaaVar != null && aaaVar.c != null) {
            return true;
        }
        return false;
    }
}
