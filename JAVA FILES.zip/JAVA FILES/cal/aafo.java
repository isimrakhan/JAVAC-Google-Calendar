package cal;

import android.content.Context;

/* compiled from: PG */
/* loaded from: classes2.dex */
public final class aafo {
    public final Context a;
    public final apxs b;

    public aafo(Context context, apxs apxsVar) {
        this.a = context;
        this.b = apxsVar;
    }
}
