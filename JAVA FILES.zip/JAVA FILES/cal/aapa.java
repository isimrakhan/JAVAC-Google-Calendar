package cal;

import java.util.List;

/* compiled from: PG */
/* loaded from: classes2.dex */
public abstract class aapa {
    public abstract String a();

    public abstract List b();
}
