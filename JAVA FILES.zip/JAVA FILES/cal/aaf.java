package cal;

/* compiled from: PG */
/* loaded from: classes.dex */
public interface aaf<I, O> {
    Object a();
}
