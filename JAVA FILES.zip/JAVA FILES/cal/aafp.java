package cal;

import java.util.Random;

/* compiled from: PG */
/* loaded from: classes2.dex */
public final class aafp {
    public final float a;
    public final Random b;

    public aafp(Random random, float f) {
        if (f >= 0.0f && f <= 1.0f) {
            this.a = f;
            this.b = random;
            return;
        }
        throw new IllegalArgumentException("Sampling rate should be a floating number >= 0 and <= 1.");
    }
}
