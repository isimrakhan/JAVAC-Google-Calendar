package cal;

/* compiled from: PG */
/* loaded from: classes2.dex */
public final class aajk {
    public static final amqm a = new amqm(amsi.STRING, "", amsi.MESSAGE, aajc.a);
}
