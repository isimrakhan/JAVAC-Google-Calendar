package cal;

/* compiled from: PG */
/* loaded from: classes2.dex */
public final class aaeb implements aoax {
    public static aadz a(apxs apxsVar) {
        aoaw aoawVar = (aoaw) apxsVar;
        Object obj = aoawVar.b;
        if (obj == aoaw.a) {
            obj = aoawVar.c();
        }
        aadz aadzVar = (aadz) obj;
        aadzVar.getClass();
        return aadzVar;
    }

    @Override // cal.apxs, cal.apxr
    public final /* bridge */ /* synthetic */ Object b() {
        throw null;
    }
}
