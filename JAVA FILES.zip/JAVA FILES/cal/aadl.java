package cal;

/* compiled from: PG */
/* loaded from: classes2.dex */
public final class aadl extends aads {
    public ahti a = ahre.a;
    public byte b;
    public int c;

    @Override // cal.aads
    public final aadt a() {
        int i;
        if (this.b == 1 && (i = this.c) != 0) {
            return new aadm(i, this.a);
        }
        StringBuilder sb = new StringBuilder();
        if (this.c == 0) {
            sb.append(" enablement");
        }
        if (this.b == 0) {
            sb.append(" manualCapture");
        }
        throw new IllegalStateException("Missing required properties:".concat(sb.toString()));
    }
}
