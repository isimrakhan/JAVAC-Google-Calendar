package cal;

/* compiled from: PG */
/* loaded from: classes2.dex */
public final /* synthetic */ class aaau implements apxs {
    public final /* synthetic */ apxs a;
    public final /* synthetic */ ahum b;
    public final /* synthetic */ apxs c;

    public /* synthetic */ aaau(apxs apxsVar, ahum ahumVar, apxs apxsVar2) {
        this.a = apxsVar;
        this.b = ahumVar;
        this.c = apxsVar2;
    }

    @Override // cal.apxs, cal.apxr
    public final Object b() {
        return aaay.b(this.a, this.b, this.c);
    }
}
