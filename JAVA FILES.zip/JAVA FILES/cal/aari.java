package cal;

import android.net.Uri;

/* compiled from: PG */
/* loaded from: classes2.dex */
public final class aari {
    public static final aarh a;

    static {
        Uri.parse("https://lh3.googleusercontent.com");
        a = new aarh();
    }
}
