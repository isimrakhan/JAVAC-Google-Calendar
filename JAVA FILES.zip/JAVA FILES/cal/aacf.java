package cal;

/* compiled from: PG */
/* loaded from: classes2.dex */
public final class aacf extends aach {
    public int a;
    private final ahti b;
    private final ahti c;

    public aacf() {
        ahre ahreVar = ahre.a;
        this.b = ahreVar;
        this.c = ahreVar;
    }

    @Override // cal.aach
    public final aaci a() {
        if (this.a != 0) {
            return new aacg(this.b, this.c);
        }
        throw new IllegalStateException("Missing required properties: enablement");
    }
}
