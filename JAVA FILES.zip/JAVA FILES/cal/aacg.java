package cal;

/* compiled from: PG */
/* loaded from: classes2.dex */
final class aacg extends aaci {
    private final ahti a;
    private final ahti b;

    public aacg(ahti ahtiVar, ahti ahtiVar2) {
        this.a = ahtiVar;
        this.b = ahtiVar2;
    }

    @Override // cal.aaci
    public final ahti c() {
        return this.b;
    }

    @Override // cal.aaci
    public final ahti d() {
        return this.a;
    }

    public final boolean equals(Object obj) {
        if (obj == this) {
            return true;
        }
        if (obj instanceof aaci) {
            aaci aaciVar = (aaci) obj;
            aaciVar.e();
            if (aaciVar.d() == this.a) {
                if (aaciVar.c() == this.b) {
                    return true;
                }
            }
        }
        return false;
    }

    public final int hashCode() {
        return 395873938;
    }

    public final String toString() {
        return "StartupConfigurations{enablement=DEFAULT, metricExtensionProvider=Optional.absent(), customTimestampProvider=Optional.absent()}";
    }

    @Override // cal.aaci
    public final void e() {
    }
}
