package cal;

/* compiled from: PG */
/* loaded from: classes2.dex */
final class aajx implements ampt {
    @Override // cal.ampt
    public final /* synthetic */ Object a(int i) {
        ajvx b = ajvx.b(i);
        if (b == null) {
            return ajvx.UNKNOWN;
        }
        return b;
    }
}
