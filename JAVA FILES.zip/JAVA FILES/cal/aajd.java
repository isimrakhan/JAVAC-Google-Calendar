package cal;

/* compiled from: PG */
/* loaded from: classes2.dex */
public interface aajd {
    ajdo a(String str);

    ajdo b(aaix aaixVar);

    ajdo c(String str, String str2);

    ajdo d();

    ajdo e(aalz aalzVar);
}
