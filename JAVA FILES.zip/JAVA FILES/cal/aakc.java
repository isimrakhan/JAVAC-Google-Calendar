package cal;

/* compiled from: PG */
/* loaded from: classes2.dex */
public final class aakc extends ampg implements amqu {
    public aakc() {
        super(aakd.a);
    }
}
