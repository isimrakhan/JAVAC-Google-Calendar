package cal;

/* compiled from: PG */
/* loaded from: classes2.dex */
public final /* synthetic */ class aalh {
    public final /* synthetic */ aalk a;

    public /* synthetic */ aalh(aalk aalkVar) {
        this.a = aalkVar;
    }
}
