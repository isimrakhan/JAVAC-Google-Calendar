package cal;

/* compiled from: PG */
/* loaded from: classes2.dex */
abstract class aank {
    public abstract aaiw a();

    public abstract aajt b();
}
