package cal;

/* compiled from: PG */
/* loaded from: classes2.dex */
public final class aafx {
    public final apxs a;
    public final apxs b;
    public final apxs c;
    public final apxs d;
    public final apxs e;

    public aafx(apxs apxsVar, apxs apxsVar2, apxs apxsVar3, apxs apxsVar4, apxs apxsVar5) {
        apxsVar.getClass();
        this.a = apxsVar;
        this.b = apxsVar2;
        this.c = apxsVar3;
        this.d = apxsVar4;
        this.e = apxsVar5;
    }
}
