package cal;

import android.util.Log;

/* compiled from: PG */
/* loaded from: classes2.dex */
public final class aaij extends aaip {
    public aaij(aain aainVar, String str, Double d) {
        super(aainVar, str, d, true);
    }

    @Override // cal.aaip
    public final /* bridge */ /* synthetic */ Object a(Object obj) {
        String concat;
        if (obj instanceof Double) {
            return (Double) obj;
        }
        if (obj instanceof Float) {
            return Double.valueOf(((Float) obj).doubleValue());
        }
        if (obj instanceof String) {
            try {
                return Double.valueOf(Double.parseDouble((String) obj));
            } catch (NumberFormatException unused) {
            }
        }
        String str = this.b.d;
        if (str.isEmpty()) {
            concat = this.c;
        } else {
            concat = str.concat(this.c);
        }
        Log.e("PhenotypeFlag", a.r(obj, concat, "Invalid double value for ", ": "));
        return null;
    }
}
