package cal;

import java.util.EnumMap;

/* compiled from: PG */
/* loaded from: classes2.dex */
public final class aapr {
    public final aaqq a;
    public final EnumMap b = new EnumMap(aaqk.class);
    public final EnumMap c = new EnumMap(aaqj.class);

    public aapr(aaqq aaqqVar) {
        this.a = aaqqVar;
    }
}
