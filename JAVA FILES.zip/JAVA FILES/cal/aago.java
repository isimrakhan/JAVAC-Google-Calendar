package cal;

import android.content.Context;
import android.os.Looper;
import android.util.Log;
import com.google.android.gms.common.Feature;
import com.google.android.gms.usagereporting.UsageReportingOptInOptions;
import java.util.concurrent.Executor;
import java.util.concurrent.atomic.AtomicBoolean;
import java.util.concurrent.atomic.AtomicReference;

/* compiled from: PG */
/* loaded from: classes2.dex */
public final class aago {
    private volatile vev b;
    public final AtomicReference a = new AtomicReference();
    private final AtomicBoolean c = new AtomicBoolean(false);

    /* JADX WARN: Multi-variable type inference failed */
    /* JADX WARN: Type inference failed for: r7v23 */
    /* JADX WARN: Type inference failed for: r7v24 */
    /* JADX WARN: Type inference failed for: r7v5 */
    public final ajdo a(Context context, boolean z, boolean z2) {
        vev vevVar;
        if (!z) {
            return new ajdj(true);
        }
        Boolean bool = (Boolean) this.a.get();
        if (bool == null) {
            vev vevVar2 = this.b;
            uhp uhpVar = vevVar2;
            if (vevVar2 == null) {
                synchronized (this) {
                    vev vevVar3 = this.b;
                    vevVar = vevVar3;
                    if (vevVar3 == null) {
                        ven venVar = new ven(context, new ves());
                        this.b = venVar;
                        vevVar = venVar;
                    }
                }
                uhpVar = vevVar;
            }
            if (z2 && !this.c.getAndSet(true)) {
                veu veuVar = new veu() { // from class: cal.aagl
                    @Override // cal.veu
                    public final void a() {
                        aago.this.a.set(null);
                    }
                };
                uhp uhpVar2 = uhpVar;
                Looper looper = uhpVar2.h;
                String simpleName = veu.class.getSimpleName();
                if (looper != null) {
                    if (simpleName != null) {
                        final ukd ukdVar = new ukd(looper, veuVar, simpleName);
                        final vfh vfhVar = ((ves) uhpVar2.f).b;
                        final ven venVar2 = uhpVar;
                        ukp ukpVar = new ukp() { // from class: cal.veh
                            @Override // cal.ukp
                            public final void a(Object obj, Object obj2) {
                                vfh vfhVar2 = new vfh(ukdVar);
                                ((vfi) obj).E(vfhVar, vfhVar2, new vel(ven.this, (vdv) obj2, vfhVar2));
                            }
                        };
                        ukp ukpVar2 = new ukp() { // from class: cal.vei
                            @Override // cal.ukp
                            public final void a(Object obj, Object obj2) {
                                ven venVar3 = ven.this;
                                ((vfi) obj).E(((ves) venVar3.f).b, null, new vem(venVar3, (vdv) obj2));
                            }
                        };
                        ukn uknVar = new ukn();
                        uknVar.a = ukpVar;
                        uknVar.b = ukpVar2;
                        uknVar.c = ukdVar;
                        uknVar.d = new Feature[]{veg.a};
                        uknVar.f = 4507;
                        uhpVar2.d(uknVar.a());
                    } else {
                        throw new NullPointerException("Listener type must not be null");
                    }
                } else {
                    throw new NullPointerException("Looper must not be null");
                }
            }
            ukv ukvVar = new ukv();
            ukvVar.a = new vej();
            ukvVar.d = 4501;
            ukw a = ukvVar.a();
            vdv vdvVar = new vdv();
            uhp uhpVar3 = uhpVar;
            uhpVar3.k.h(uhpVar3, 0, a, vdvVar);
            vdz vdzVar = vdvVar.a;
            vwj vwjVar = new vwj(vdzVar);
            vdzVar.b.a(new vdg(ajbw.a, new vwi(vwjVar)));
            synchronized (vdzVar.a) {
                if (vdzVar.c) {
                    vdzVar.b.b(vdzVar);
                }
            }
            ajcj ajcjVar = new ajcj(vwjVar);
            ahsr ahsrVar = new ahsr() { // from class: cal.aagm
                @Override // cal.ahsr
                /* renamed from: a */
                public final Object b(Object obj) {
                    UsageReportingOptInOptions usageReportingOptInOptions = ((vfc) ((veo) obj).a).a;
                    if (usageReportingOptInOptions != null) {
                        int i = usageReportingOptInOptions.a;
                        boolean z3 = true;
                        if (i != 1 && i != 3) {
                            z3 = false;
                        }
                        AtomicReference atomicReference = aago.this.a;
                        Boolean valueOf = Boolean.valueOf(z3);
                        atomicReference.set(valueOf);
                        return valueOf;
                    }
                    throw new NullPointerException("null reference");
                }
            };
            int i = afwy.a;
            afwi afwiVar = (afwi) afvq.d.get();
            afwk afwkVar = afwiVar.b;
            if (afwkVar == null) {
                afwkVar = afvv.h(afwiVar);
            }
            afwv afwvVar = new afwv(afwkVar, ahsrVar);
            Executor executor = ajbw.a;
            ajap ajapVar = new ajap(ajcjVar, afwvVar);
            executor.getClass();
            if (executor != ajbw.a) {
                executor = new ajdt(executor, ajapVar);
            }
            ajcjVar.a.d(ajapVar, executor);
            ahsr ahsrVar2 = new ahsr() { // from class: cal.aagn
                @Override // cal.ahsr
                /* renamed from: a */
                public final Object b(Object obj) {
                    Log.e("CheckboxChecker", "fetching usage reporting opt-in failed", (Throwable) obj);
                    return true;
                }
            };
            Executor executor2 = ajbw.a;
            aizy aizyVar = new aizy(ajapVar, Throwable.class, ahsrVar2);
            executor2.getClass();
            if (executor2 != ajbw.a) {
                executor2 = new ajdt(executor2, aizyVar);
            }
            ajapVar.d(aizyVar, executor2);
            return aizyVar;
        }
        return new ajdj(bool);
    }
}
