package cal;

import android.content.ClipData;
import android.content.Intent;

/* compiled from: PG */
/* loaded from: classes2.dex */
public final class aapc {
    public static final /* synthetic */ int a = 0;

    static {
        ClipData.newIntent("", new Intent());
    }
}
