package cal;

import android.app.Activity;
import android.app.Application;
import android.os.Bundle;
import java.util.Set;

/* compiled from: PG */
/* loaded from: classes2.dex */
final class aaos implements Application.ActivityLifecycleCallbacks {
    boolean a = false;
    final /* synthetic */ Application b;
    final /* synthetic */ apxs c;

    public aaos(Application application, apxs apxsVar) {
        this.b = application;
        this.c = apxsVar;
    }

    private final aick a() {
        if (!this.a) {
            this.a = true;
            this.b.unregisterActivityLifecycleCallbacks(this);
            Set<Application.ActivityLifecycleCallbacks> set = (Set) ((aoay) this.c).a;
            int size = set.size();
            ahzj.b(size, "expectedSize");
            aicf aicfVar = new aicf(size);
            for (Application.ActivityLifecycleCallbacks activityLifecycleCallbacks : set) {
                this.b.registerActivityLifecycleCallbacks(activityLifecycleCallbacks);
                aicfVar.f(activityLifecycleCallbacks);
            }
            aicfVar.c = true;
            Object[] objArr = aicfVar.a;
            int i = aicfVar.b;
            if (i == 0) {
                return aikm.b;
            }
            return new aikm(objArr, i);
        }
        ailt ailtVar = aick.e;
        return aikm.b;
    }

    @Override // android.app.Application.ActivityLifecycleCallbacks
    public final void onActivityCreated(Activity activity, Bundle bundle) {
        aick a = a();
        int i = ((aikm) a).d;
        for (int i2 = 0; i2 < i; i2++) {
            ((Application.ActivityLifecycleCallbacks) a.get(i2)).onActivityCreated(activity, bundle);
        }
    }

    @Override // android.app.Application.ActivityLifecycleCallbacks
    public final void onActivityDestroyed(Activity activity) {
        if (this.a) {
        } else {
            throw new IllegalStateException();
        }
    }

    @Override // android.app.Application.ActivityLifecycleCallbacks
    public final void onActivityPaused(Activity activity) {
        if (this.a) {
        } else {
            throw new IllegalStateException();
        }
    }

    @Override // android.app.Application.ActivityLifecycleCallbacks
    public final void onActivityPreCreated(Activity activity, Bundle bundle) {
        aick a = a();
        int i = ((aikm) a).d;
        for (int i2 = 0; i2 < i; i2++) {
            ((Application.ActivityLifecycleCallbacks) a.get(i2)).onActivityPreCreated(activity, bundle);
        }
    }

    @Override // android.app.Application.ActivityLifecycleCallbacks
    public final void onActivityResumed(Activity activity) {
        if (this.a) {
        } else {
            throw new IllegalStateException();
        }
    }

    @Override // android.app.Application.ActivityLifecycleCallbacks
    public final void onActivitySaveInstanceState(Activity activity, Bundle bundle) {
        if (this.a) {
        } else {
            throw new IllegalStateException();
        }
    }

    @Override // android.app.Application.ActivityLifecycleCallbacks
    public final void onActivityStarted(Activity activity) {
        if (this.a) {
        } else {
            throw new IllegalStateException();
        }
    }

    @Override // android.app.Application.ActivityLifecycleCallbacks
    public final void onActivityStopped(Activity activity) {
        if (this.a) {
        } else {
            throw new IllegalStateException();
        }
    }
}
