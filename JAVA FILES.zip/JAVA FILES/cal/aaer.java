package cal;

/* compiled from: PG */
/* loaded from: classes2.dex */
public final class aaer implements aoax {
    public static aafd a(apxs apxsVar) {
        aoaw aoawVar = (aoaw) apxsVar;
        Object obj = aoawVar.b;
        if (obj == aoaw.a) {
            obj = aoawVar.c();
        }
        aafd aafdVar = (aafd) obj;
        aafdVar.getClass();
        return aafdVar;
    }

    @Override // cal.apxs, cal.apxr
    public final /* bridge */ /* synthetic */ Object b() {
        throw null;
    }
}
