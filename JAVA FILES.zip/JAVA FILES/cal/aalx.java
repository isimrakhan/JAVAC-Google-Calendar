package cal;

import java.util.concurrent.ExecutionException;

/* compiled from: PG */
/* loaded from: classes2.dex */
public final /* synthetic */ class aalx implements Runnable {
    public final /* synthetic */ ajdo a;

    @Override // java.lang.Runnable
    public final void run() {
        ajdo ajdoVar = this.a;
        try {
            if (ajdoVar.isDone()) {
                ajem.a(ajdoVar);
                return;
            }
            throw new IllegalStateException(ahul.a("Future was expected to be done: %s", ajdoVar));
        } catch (ExecutionException e) {
            abyh.a().post(new Runnable() { // from class: cal.aaly
                @Override // java.lang.Runnable
                public final void run() {
                    throw new RuntimeException(e.getCause());
                }
            });
        }
    }
}
