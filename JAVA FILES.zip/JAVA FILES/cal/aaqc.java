package cal;

import android.app.appsearch.SearchResults;
import androidx.appsearch.exceptions.AppSearchException;
import com.google.android.libraries.social.connections.schema.InteractionsDocument;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collection;
import java.util.Iterator;
import java.util.List;
import java.util.concurrent.Executor;

/* compiled from: PG */
/* loaded from: classes2.dex */
public final class aaqc implements aapz {
    public static final aimm a = aimm.h("com/google/android/libraries/social/connections/dataloaders/AppSearchInteractionLoader");
    public final String b;
    public final String c;
    public final Executor d;
    private final ajdo e;

    public aaqc(String str, String str2, Executor executor, ajdo ajdoVar) {
        this.b = str;
        this.c = str2;
        this.d = executor;
        this.e = ajdoVar;
    }

    @Override // cal.aapz
    public final ajdo a(final aapy aapyVar) {
        final int i;
        long a2 = ((aoqu) ((ahur) aoqt.a.b).a).a();
        if (a2 > 2147483647L) {
            i = Integer.MAX_VALUE;
        } else if (a2 < -2147483648L) {
            i = Integer.MIN_VALUE;
        } else {
            i = (int) a2;
        }
        afxe afxeVar = new afxe(this.e);
        ajaz ajazVar = new ajaz() { // from class: cal.aaqa
            @Override // cal.ajaz
            public final ajdo a(Object obj) {
                ajdo ajdiVar;
                SearchResults search;
                Executor ajdtVar;
                xw xwVar = (xw) obj;
                xo xoVar = new xo();
                boolean b = ((aoqu) ((ahur) aoqt.a.b).a).b();
                int i2 = i;
                aaqc aaqcVar = aaqc.this;
                if (b) {
                    if (!"com.google".equals(aaqcVar.b)) {
                        ailt ailtVar = aick.e;
                        aick aickVar = aikm.b;
                        if (aickVar == null) {
                            return ajdj.a;
                        }
                        ajdiVar = new ajdj(aickVar);
                        return ajdiVar;
                    }
                    String[] strArr = {aaqcVar.c};
                    xoVar.b();
                    List asList = Arrays.asList(strArr);
                    asList.getClass();
                    xoVar.b();
                    xoVar.b.addAll(asList);
                }
                Executor executor = aaqcVar.d;
                try {
                    xoVar.b();
                    List asList2 = Arrays.asList("com.google.android.contacts");
                    if (asList2 != null) {
                        xoVar.b();
                        xoVar.c.addAll(asList2);
                        xoVar.b();
                        List asList3 = Arrays.asList(InteractionsDocument.class);
                        if (asList3 != null) {
                            xoVar.b();
                            ArrayList arrayList = new ArrayList(asList3.size());
                            wv b2 = wv.b();
                            Iterator it = asList3.iterator();
                            while (it.hasNext()) {
                                arrayList.add(b2.a((Class) it.next()).getSchemaName());
                            }
                            xoVar.b();
                            xoVar.a.addAll(arrayList);
                            akh.a(2, 1, 2, "Term match type");
                            xoVar.b();
                            xoVar.e = 2;
                            akh.a(i2, 0, 10000, "resultCountPerPage");
                            xoVar.b();
                            xoVar.d = i2;
                            aapy aapyVar2 = aapyVar;
                            final ArrayList arrayList2 = new ArrayList();
                            if (!aapyVar2.a.isEmpty()) {
                                arrayList2.add(new ahzl(aapyVar2.a, new ahsr() { // from class: cal.aaqd
                                    @Override // cal.ahsr
                                    /* renamed from: a */
                                    public final Object b(Object obj2) {
                                        aaqk aaqkVar = (aaqk) obj2;
                                        ahtc ahtcVar = aaqg.a;
                                        if (aaqkVar != aaqk.UNRECOGNIZED) {
                                            String valueOf = String.valueOf(aaqkVar.h);
                                            ahtc ahtcVar2 = aaqg.c;
                                            StringBuilder sb = new StringBuilder();
                                            try {
                                                ahtcVar2.c(sb, new ahta(new Object[0], "interactionType", valueOf).iterator());
                                                return sb;
                                            } catch (IOException e) {
                                                throw new AssertionError(e);
                                            }
                                        }
                                        throw new IllegalArgumentException("Can't get the number of an unknown enum value.");
                                    }
                                }));
                            }
                            if (!aapyVar2.b.isEmpty()) {
                                arrayList2.add(new ahzl(aapyVar2.b, new ahsr() { // from class: cal.aaqe
                                    @Override // cal.ahsr
                                    /* renamed from: a */
                                    public final Object b(Object obj2) {
                                        aaqj aaqjVar = (aaqj) obj2;
                                        ahtc ahtcVar = aaqg.a;
                                        if (aaqjVar != aaqj.UNRECOGNIZED) {
                                            String valueOf = String.valueOf(aaqjVar.e);
                                            ahtc ahtcVar2 = aaqg.c;
                                            StringBuilder sb = new StringBuilder();
                                            try {
                                                ahtcVar2.c(sb, new ahta(new Object[0], "fieldType", valueOf).iterator());
                                                return sb;
                                            } catch (IOException e) {
                                                throw new AssertionError(e);
                                            }
                                        }
                                        throw new IllegalArgumentException("Can't get the number of an unknown enum value.");
                                    }
                                }));
                            }
                            ahtc ahtcVar = aaqg.a;
                            ahzl ahzlVar = new ahzl(arrayList2, new ahsr() { // from class: cal.aaqf
                                @Override // cal.ahsr
                                /* renamed from: a */
                                public final Object b(Object obj2) {
                                    Collection collection = (Collection) obj2;
                                    StringBuilder sb = new StringBuilder();
                                    try {
                                        aaqg.b.c(sb, collection.iterator());
                                        if (collection.size() > 1 && arrayList2.size() > 1) {
                                            sb.insert(0, '(');
                                            sb.append(')');
                                        }
                                        return sb;
                                    } catch (IOException e) {
                                        throw new AssertionError(e);
                                    }
                                }
                            });
                            Collection collection = ahzlVar.a;
                            ahsr ahsrVar = ahzlVar.b;
                            Iterator it2 = collection.iterator();
                            ahsrVar.getClass();
                            aiet aietVar = new aiet(it2, ahsrVar);
                            StringBuilder sb = new StringBuilder();
                            try {
                                ahtcVar.c(sb, aietVar);
                                String sb2 = sb.toString();
                                xp a3 = xoVar.a();
                                search = xwVar.a.search(sb2, yu.a(a3));
                                final yd ydVar = new yd(search, a3, xwVar.b);
                                ace aceVar = new ace();
                                ydVar.a.getNextPage(ydVar.c, new yc(ydVar, aceVar));
                                afxe afxeVar2 = new afxe(aceVar);
                                aaqi aaqiVar = new aaqi(ydVar, executor);
                                int i3 = afwy.a;
                                afwi afwiVar = (afwi) afvq.d.get();
                                afwk afwkVar = afwiVar.b;
                                if (afwkVar == null) {
                                    afwkVar = afvv.h(afwiVar);
                                }
                                ajdo ajdoVar = afxeVar2.b;
                                ajao ajaoVar = new ajao(ajdoVar, new afwt(afwkVar, aaqiVar));
                                if (executor == ajbw.a) {
                                    ajdtVar = executor;
                                } else {
                                    ajdtVar = new ajdt(executor, ajaoVar);
                                }
                                ajdoVar.d(ajaoVar, ajdtVar);
                                afxe afxeVar3 = new afxe(ajaoVar);
                                ajaz ajazVar2 = new ajaz() { // from class: cal.aaqh
                                    @Override // cal.ajaz
                                    public final ajdo a(Object obj2) {
                                        Exception exc = (Exception) obj2;
                                        yd.this.a.close();
                                        exc.getClass();
                                        return new ajdi(exc);
                                    }
                                };
                                ajdo ajdoVar2 = afxeVar3.b;
                                afwi afwiVar2 = (afwi) afvq.d.get();
                                afwk afwkVar2 = afwiVar2.b;
                                if (afwkVar2 == null) {
                                    afwkVar2 = afvv.h(afwiVar2);
                                }
                                aizx aizxVar = new aizx(ajdoVar2, Exception.class, new afwt(afwkVar2, ajazVar2));
                                if (executor != ajbw.a) {
                                    executor = new ajdt(executor, aizxVar);
                                }
                                ajdoVar2.d(aizxVar, executor);
                                return new afxe(aizxVar);
                            } catch (IOException e) {
                                throw new AssertionError(e);
                            }
                        }
                        throw null;
                    }
                    throw null;
                } catch (AppSearchException e2) {
                    ajdiVar = new ajdi(e2);
                }
            }
        };
        Executor executor = this.d;
        int i2 = afwy.a;
        afwi afwiVar = (afwi) afvq.d.get();
        afwk afwkVar = afwiVar.b;
        if (afwkVar == null) {
            afwkVar = afvv.h(afwiVar);
        }
        ajdo ajdoVar = afxeVar.b;
        ajao ajaoVar = new ajao(ajdoVar, new afwt(afwkVar, ajazVar));
        if (executor != ajbw.a) {
            executor = new ajdt(executor, ajaoVar);
        }
        ajdoVar.d(ajaoVar, executor);
        return new afxe(ajaoVar);
    }

    @Override // java.lang.AutoCloseable
    public final void close() {
        aaqb aaqbVar = new aaqb();
        int i = afwy.a;
        afwi afwiVar = (afwi) afvq.d.get();
        afwk afwkVar = afwiVar.b;
        if (afwkVar == null) {
            afwkVar = afvv.h(afwiVar);
        }
        ajdo ajdoVar = this.e;
        afww afwwVar = new afww(afwkVar, aaqbVar);
        ajdoVar.d(new ajcr(ajdoVar, afwwVar), this.d);
    }
}
