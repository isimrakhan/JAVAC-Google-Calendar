package cal;

import java.util.concurrent.Executor;

/* compiled from: PG */
/* loaded from: classes2.dex */
public final /* synthetic */ class aaan implements ajay {
    public final /* synthetic */ aaar a;
    public final /* synthetic */ String b;
    public final /* synthetic */ boolean c;
    public final /* synthetic */ String d;
    public final /* synthetic */ int e;

    public /* synthetic */ aaan(aaar aaarVar, int i, String str, boolean z, String str2) {
        this.a = aaarVar;
        this.e = i;
        this.b = str;
        this.c = z;
        this.d = str2;
    }

    @Override // cal.ajay
    public final ajdo a() {
        long a;
        final aaar aaarVar = this.a;
        final aaad aaadVar = (aaad) aaarVar.c.b();
        final int i = this.e;
        final String str = this.b;
        if (i != 1) {
            if (aaadVar.f() == 2) {
                a = -1;
            } else {
                a = 1000;
            }
        } else {
            a = aaarVar.d.a(str);
        }
        final long j = a;
        if (j == -1) {
            return ajdj.a;
        }
        aaadVar.g();
        ajdo ajdoVar = ajdj.a;
        gbc gbcVar = (gbc) aaadVar.c().g();
        if (gbcVar != null) {
            try {
                aquh b = gbcVar.a.b();
                if (b == null) {
                    ajdoVar = ajdj.a;
                } else {
                    ajdoVar = new ajdj(b);
                }
            } catch (RuntimeException e) {
                ((aimj) ((aimj) ((aimj) zsj.a.d()).j(e)).k("com/google/android/libraries/performance/primes/metrics/memory/MemoryMetricServiceImpl", "record", (char) 414, "MemoryMetricServiceImpl.java")).s("Metric extension provider failed.");
            }
        }
        ajcj ajcjVar = new ajcj(ajdoVar);
        ahsr ahsrVar = new ahsr() { // from class: cal.aaap
            @Override // cal.ahsr
            /* renamed from: a */
            public final Object b(Object obj) {
                ((aimj) ((aimj) ((aimj) zsj.a.d()).j((RuntimeException) obj)).k("com/google/android/libraries/performance/primes/metrics/memory/MemoryMetricServiceImpl", "record", 422, "MemoryMetricServiceImpl.java")).s("Metric extension provider failed.");
                return null;
            }
        };
        Executor executor = aaarVar.a;
        aizy aizyVar = new aizy(ajcjVar, RuntimeException.class, ahsrVar);
        executor.getClass();
        if (executor != ajbw.a) {
            executor = new ajdt(executor, aizyVar);
        }
        final String str2 = this.d;
        final boolean z = this.c;
        ajcjVar.a.d(aizyVar, executor);
        ajaz ajazVar = new ajaz() { // from class: cal.aaaq
            /* JADX WARN: Multi-variable type inference failed */
            /* JADX WARN: Removed duplicated region for block: B:139:0x04a8  */
            /* JADX WARN: Removed duplicated region for block: B:147:0x04e6  */
            /* JADX WARN: Removed duplicated region for block: B:179:0x058e  */
            /* JADX WARN: Removed duplicated region for block: B:182:0x05a7  */
            /* JADX WARN: Removed duplicated region for block: B:185:0x05d9  */
            /* JADX WARN: Removed duplicated region for block: B:188:0x05f8  */
            /* JADX WARN: Removed duplicated region for block: B:191:0x0611  */
            /* JADX WARN: Removed duplicated region for block: B:194:0x0648  */
            /* JADX WARN: Removed duplicated region for block: B:197:0x065e  */
            /* JADX WARN: Removed duplicated region for block: B:200:0x067d  */
            /* JADX WARN: Removed duplicated region for block: B:203:0x0696  */
            /* JADX WARN: Removed duplicated region for block: B:209:0x06bb  */
            /* JADX WARN: Removed duplicated region for block: B:212:0x06f2  */
            /* JADX WARN: Removed duplicated region for block: B:225:0x072d  */
            /* JADX WARN: Removed duplicated region for block: B:227:0x05e2  */
            /* JADX WARN: Removed duplicated region for block: B:244:0x01f0 A[Catch: all -> 0x020b, TryCatch #6 {all -> 0x020b, blocks: (B:242:0x01e4, B:244:0x01f0, B:246:0x01f4, B:248:0x01f8, B:249:0x01fa, B:250:0x01fb, B:251:0x0200, B:252:0x0201, B:253:0x0203, B:254:0x0204, B:255:0x020a), top: B:241:0x01e4 }] */
            /* JADX WARN: Removed duplicated region for block: B:254:0x0204 A[Catch: all -> 0x020b, TryCatch #6 {all -> 0x020b, blocks: (B:242:0x01e4, B:244:0x01f0, B:246:0x01f4, B:248:0x01f8, B:249:0x01fa, B:250:0x01fb, B:251:0x0200, B:252:0x0201, B:253:0x0203, B:254:0x0204, B:255:0x020a), top: B:241:0x01e4 }] */
            /* JADX WARN: Removed duplicated region for block: B:44:0x0252  */
            @Override // cal.ajaz
            /*
                Code decompiled incorrectly, please refer to instructions dump.
                To view partially-correct code enable 'Show inconsistent code' option in preferences
            */
            public final cal.ajdo a(java.lang.Object r28) {
                /*
                    Method dump skipped, instructions count: 1857
                    To view this dump change 'Code comments level' option to 'DEBUG'
                */
                throw new UnsupportedOperationException("Method not decompiled: cal.aaaq.a(java.lang.Object):cal.ajdo");
            }
        };
        Executor executor2 = aaarVar.a;
        executor2.getClass();
        ajao ajaoVar = new ajao(aizyVar, ajazVar);
        if (executor2 != ajbw.a) {
            executor2 = new ajdt(executor2, ajaoVar);
        }
        aizyVar.d(ajaoVar, executor2);
        return ajaoVar;
    }
}
