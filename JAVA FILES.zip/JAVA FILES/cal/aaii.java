package cal;

import android.util.Log;

/* compiled from: PG */
/* loaded from: classes2.dex */
public final class aaii extends aaip {
    public aaii(aain aainVar, String str, Boolean bool) {
        super(aainVar, str, bool, true);
    }

    @Override // cal.aaip
    public final /* bridge */ /* synthetic */ Object a(Object obj) {
        String concat;
        if (obj instanceof Boolean) {
            return (Boolean) obj;
        }
        if (obj instanceof String) {
            String str = (String) obj;
            if (vjm.c.matcher(str).matches()) {
                return true;
            }
            if (vjm.d.matcher(str).matches()) {
                return false;
            }
        }
        String str2 = this.b.d;
        if (str2.isEmpty()) {
            concat = this.c;
        } else {
            concat = str2.concat(this.c);
        }
        Log.e("PhenotypeFlag", a.r(obj, concat, "Invalid boolean value for ", ": "));
        return null;
    }
}
