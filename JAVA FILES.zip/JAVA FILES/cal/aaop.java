package cal;

import java.util.Map;

/* compiled from: PG */
/* loaded from: classes2.dex */
public final class aaop {
    public final boolean a = true;
    public Map b;

    public aaop(Map map) {
        this.b = map;
    }
}
