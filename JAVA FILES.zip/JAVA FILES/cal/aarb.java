package cal;

import android.content.Context;
import java.util.List;

/* compiled from: PG */
/* loaded from: classes2.dex */
public final class aarb extends axu {
    public List j;

    public aarb(Context context) {
        super(context.getApplicationContext());
    }
}
