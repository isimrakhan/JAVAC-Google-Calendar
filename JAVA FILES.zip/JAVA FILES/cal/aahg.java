package cal;

/* compiled from: PG */
/* loaded from: classes2.dex */
public final class aahg extends ampg implements amqu {
    public aahg() {
        super(aahh.a);
    }
}
