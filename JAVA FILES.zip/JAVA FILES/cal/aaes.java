package cal;

/* compiled from: PG */
/* loaded from: classes2.dex */
public final class aaes implements aoax {
    public static ahti a(apxs apxsVar) {
        apxsVar.getClass();
        return new ahts(new aaeq(apxsVar));
    }

    @Override // cal.apxs, cal.apxr
    public final /* bridge */ /* synthetic */ Object b() {
        throw null;
    }
}
