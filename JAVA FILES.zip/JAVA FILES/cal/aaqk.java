package cal;

/* compiled from: PG */
/* loaded from: classes2.dex */
public enum aaqk implements ampo {
    INTERACTION_TYPE_UNSPECIFIED(0),
    CONTACTS_CALL(1),
    CONTACTS_TEXT(2),
    CONTACTS_VIDEO_CALL(3),
    CONTACTS_EMAIL(4),
    CONTACTS_DIRECTION(5),
    UNRECOGNIZED(-1);

    public final int h;

    aaqk(int i2) {
        this.h = i2;
    }

    @Override // cal.ampo
    public final int a() {
        if (this != UNRECOGNIZED) {
            return this.h;
        }
        throw new IllegalArgumentException("Can't get the number of an unknown enum value.");
    }

    @Override // java.lang.Enum
    public final String toString() {
        if (this != UNRECOGNIZED) {
            return Integer.toString(this.h);
        }
        throw new IllegalArgumentException("Can't get the number of an unknown enum value.");
    }
}
