package cal;

import java.util.regex.Pattern;

/* compiled from: PG */
/* loaded from: classes2.dex */
public final class aabf {
    private final apxs i;
    private static final aidr d = aidr.i(4, "googleapis.com", "adwords.google.com", "m.google.com", "sandbox.google.com");
    private static final Pattern e = Pattern.compile("(?:[^\\/]*\\/)([^;]*)");
    public static final Pattern a = Pattern.compile("([^\\?]+)(\\?+)");
    private static final Pattern f = Pattern.compile("((?:https?:\\/\\/|)[a-zA-Z0-9-_\\.]+(?::\\d+)?)(.*)?");
    public static final Pattern b = Pattern.compile("(.*)(?<!https?:\\/)(?:\\/[\\w]+$)");
    public static final Pattern c = Pattern.compile("(.*)(?<!https?:\\/)(?:\\/[\\w]+\\.[\\w]*$)");
    private static final Pattern g = Pattern.compile("([a-zA-Z0-9-_]+)");
    private static final Pattern h = Pattern.compile("\\b([0-9]{1,3}\\.[0-9]{1,3}\\.[0-9]{1,3}\\.[0-9]{1,3})(:\\d{1,5})?\\b");

    public aabf(apxs apxsVar) {
        this.i = apxsVar;
    }

    /* JADX WARN: Removed duplicated region for block: B:10:0x0030  */
    /* JADX WARN: Removed duplicated region for block: B:13:0x0039  */
    /* JADX WARN: Removed duplicated region for block: B:19:0x0058  */
    /* JADX WARN: Removed duplicated region for block: B:31:0x003b  */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct code enable 'Show inconsistent code' option in preferences
    */
    static java.lang.String b(java.lang.String r5, boolean r6) {
        /*
            boolean r0 = r5.isEmpty()
            r1 = 0
            if (r0 == 0) goto L8
            return r1
        L8:
            r0 = 1
            if (r6 == 0) goto Ld
        Lb:
            r6 = r0
            goto L24
        Ld:
            java.util.regex.Pattern r6 = cal.aabf.f
            java.util.regex.Matcher r6 = r6.matcher(r5)
            boolean r2 = r6.matches()
            if (r2 == 0) goto L1e
            java.lang.String r6 = r6.group(r0)
            goto L1f
        L1e:
            r6 = r1
        L1f:
            if (r6 == 0) goto L23
            r5 = r6
            goto Lb
        L23:
            r6 = 0
        L24:
            java.util.regex.Pattern r2 = cal.aabf.a
            java.util.regex.Matcher r2 = r2.matcher(r5)
            boolean r3 = r2.find()
            if (r3 == 0) goto L35
            java.lang.String r5 = r2.group(r0)
            r6 = r0
        L35:
            java.lang.String r2 = "<ip>"
            if (r5 != 0) goto L3b
            r3 = r1
            goto L4d
        L3b:
            java.util.regex.Pattern r3 = cal.aabf.h
            java.util.regex.Matcher r3 = r3.matcher(r5)
            boolean r4 = r3.find()
            if (r4 == 0) goto L4c
            java.lang.String r3 = r3.replaceFirst(r2)
            goto L4d
        L4c:
            r3 = r5
        L4d:
            if (r3 == 0) goto L56
            boolean r5 = r3.equals(r5)
            if (r5 != 0) goto L56
            r6 = r0
        L56:
            if (r3 == 0) goto L69
            java.util.regex.Pattern r5 = cal.aabf.h
            java.util.regex.Matcher r5 = r5.matcher(r3)
            boolean r4 = r5.find()
            if (r4 == 0) goto L69
            java.lang.String r3 = r5.replaceFirst(r2)
            r6 = r0
        L69:
            if (r3 == 0) goto L7f
            if (r6 != 0) goto L7f
            java.util.regex.Pattern r5 = cal.aabf.g
            java.util.regex.Matcher r5 = r5.matcher(r3)
            boolean r6 = r5.find()
            if (r6 != 0) goto L7a
            goto L80
        L7a:
            java.lang.String r5 = r5.group(r0)
            return r5
        L7f:
            r1 = r3
        L80:
            return r1
        */
        throw new UnsupportedOperationException("Method not decompiled: cal.aabf.b(java.lang.String, boolean):java.lang.String");
    }

    /* JADX INFO: Access modifiers changed from: package-private */
    /* JADX WARN: Code restructure failed: missing block: B:167:0x01c9, code lost:
    
        r6 = b(r6, true);
     */
    /* JADX WARN: Code restructure failed: missing block: B:168:0x01cd, code lost:
    
        if (r6 == null) goto L103;
     */
    /* JADX WARN: Code restructure failed: missing block: B:169:0x01cf, code lost:
    
        r6 = cal.aabf.f.matcher(r6);
     */
    /* JADX WARN: Code restructure failed: missing block: B:170:0x01d9, code lost:
    
        if (r6.matches() == false) goto L90;
     */
    /* JADX WARN: Code restructure failed: missing block: B:171:0x01db, code lost:
    
        r6 = r6.group(2);
     */
    /* JADX WARN: Code restructure failed: missing block: B:172:0x01e1, code lost:
    
        if (r6 == null) goto L103;
     */
    /* JADX WARN: Code restructure failed: missing block: B:174:0x01e8, code lost:
    
        if ((r5.b.ad & Integer.MIN_VALUE) != 0) goto L95;
     */
    /* JADX WARN: Code restructure failed: missing block: B:175:0x01ea, code lost:
    
        r5.s();
     */
    /* JADX WARN: Code restructure failed: missing block: B:176:0x01ed, code lost:
    
        r13 = (cal.aqvc) r5.b;
        r13.c |= 524288;
        r13.v = r6;
     */
    /* JADX WARN: Code restructure failed: missing block: B:177:0x01e0, code lost:
    
        r6 = null;
     */
    /* JADX WARN: Code restructure failed: missing block: B:184:0x01c6, code lost:
    
        if (r13 != 2) goto L96;
     */
    /* JADX WARN: Removed duplicated region for block: B:46:0x0129  */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct code enable 'Show inconsistent code' option in preferences
    */
    public final cal.aqyd a(java.lang.Iterable r17) {
        /*
            Method dump skipped, instructions count: 1112
            To view this dump change 'Code comments level' option to 'DEBUG'
        */
        throw new UnsupportedOperationException("Method not decompiled: cal.aabf.a(java.lang.Iterable):cal.aqyd");
    }
}
