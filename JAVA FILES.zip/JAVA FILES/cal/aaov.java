package cal;

import java.lang.Thread;

/* compiled from: PG */
/* loaded from: classes2.dex */
public final class aaov implements aaoo {
    private final apxs a;

    public aaov(apxs apxsVar) {
        this.a = apxsVar;
    }

    @Override // cal.aaoo
    public final void a() {
        final Thread.UncaughtExceptionHandler defaultUncaughtExceptionHandler = Thread.getDefaultUncaughtExceptionHandler();
        Thread.setDefaultUncaughtExceptionHandler(new Thread.UncaughtExceptionHandler() { // from class: cal.aaou
            @Override // java.lang.Thread.UncaughtExceptionHandler
            public final void uncaughtException(Thread thread, Throwable th) {
                aaov.this.b(defaultUncaughtExceptionHandler, thread, th);
            }
        });
    }

    /* JADX INFO: Access modifiers changed from: package-private */
    /* JADX WARN: Removed duplicated region for block: B:66:0x00f9 A[Catch: all -> 0x0101, TimeoutException -> 0x0106, TRY_ENTER, TryCatch #9 {TimeoutException -> 0x0106, all -> 0x0101, blocks: (B:46:0x00ca, B:57:0x00e0, B:66:0x00f9, B:67:0x0100), top: B:45:0x00ca, outer: #4 }] */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct code enable 'Show inconsistent code' option in preferences
    */
    public final /* synthetic */ void b(java.lang.Thread.UncaughtExceptionHandler r16, java.lang.Thread r17, java.lang.Throwable r18) {
        /*
            Method dump skipped, instructions count: 322
            To view this dump change 'Code comments level' option to 'DEBUG'
        */
        throw new UnsupportedOperationException("Method not decompiled: cal.aaov.b(java.lang.Thread$UncaughtExceptionHandler, java.lang.Thread, java.lang.Throwable):void");
    }
}
