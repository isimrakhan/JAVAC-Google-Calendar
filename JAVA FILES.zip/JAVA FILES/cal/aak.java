package cal;

import android.content.Intent;
import android.os.Bundle;

/* compiled from: PG */
/* loaded from: classes.dex */
public final class aak {
    public final Intent a;
    public final Bundle b;

    public aak(Intent intent, Bundle bundle) {
        this.a = intent;
        this.b = bundle;
    }
}
