package cal;

import android.content.Context;
import android.os.Process;
import java.util.Map;
import java.util.Set;

/* compiled from: PG */
/* loaded from: classes2.dex */
public final class aaom {
    private final Context a;
    private final Set b;

    public aaom(Context context, Map map) {
        this.a = context;
        aics aicsVar = (aics) map;
        aidr aidrVar = aicsVar.c;
        if (aidrVar == null) {
            aikr aikrVar = (aikr) map;
            aidrVar = new aikp(aicsVar, new aikq(aikrVar.g, 0, aikrVar.h));
            aicsVar.c = aidrVar;
        }
        this.b = aidrVar;
    }

    public final boolean a() {
        if (aaok.a == null) {
            aaok.a = Boolean.valueOf(aw$$ExternalSyntheticApiModelOutline1.m(Process.myUid()));
        }
        if (!aaok.a.booleanValue()) {
            return false;
        }
        String a = aaok.a(this.a);
        if (a == null) {
            return true;
        }
        int size = this.b.size();
        if (size != 0) {
            if (size == 1) {
                String a2 = ((aaol) aifa.g(this.b.iterator())).a();
                if (a2.startsWith(":")) {
                    return a.equals(String.valueOf(this.a.getPackageName()).concat(String.valueOf(a2)));
                }
                throw new IllegalArgumentException(ahul.a("The provided @CustomMainProcess is not an app-private one, i.e. the one staring with colon(':'). @CustomMainProcess value: %s", a2));
            }
            throw new IllegalArgumentException("More than 1 custom main process specified");
        }
        return a.equals(this.a.getPackageName());
    }
}
