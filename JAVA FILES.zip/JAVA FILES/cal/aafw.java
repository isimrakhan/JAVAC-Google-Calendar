package cal;

import android.content.Context;
import java.util.concurrent.Executor;

/* compiled from: PG */
/* loaded from: classes2.dex */
public final class aafw {
    private static final aafs d = new aafs(new aafr(Integer.MAX_VALUE));
    public volatile aagb a = aaga.a;
    public volatile boolean b = true;
    public volatile aafs c = d;

    public aafw(final Context context, final Executor executor, final aaga aagaVar, final anyt anytVar, boolean z, ahti ahtiVar, apxs apxsVar) {
        final apxs apxsVar2;
        if (z && !ahtiVar.i()) {
            apxsVar2 = apxsVar;
        } else {
            apxsVar2 = null;
        }
        executor.execute(new Runnable() { // from class: cal.aaft
            @Override // java.lang.Runnable
            public final void run() {
                aafw aafwVar = aafw.this;
                anyt anytVar2 = anytVar;
                Context context2 = context;
                if (vvg.a(context2)) {
                    aafwVar.a(anytVar2);
                } else {
                    aafu aafuVar = new aafu(aafwVar, anytVar2, executor);
                    if (vvg.a(context2)) {
                        aafuVar.c.execute(new aafv(aafuVar.a, aafuVar.b));
                        ajdo ajdoVar = ajdj.a;
                    } else {
                        aca.a(new vvd(context2, aafuVar));
                    }
                }
                if (aafwVar.b) {
                    apxs apxsVar3 = apxsVar2;
                    aaga aagaVar2 = aagaVar;
                    if (apxsVar3 == null) {
                        aqwl aqwlVar = aqwl.a;
                        aqwi aqwiVar = new aqwi();
                        if ((Integer.MIN_VALUE & aqwiVar.b.ad) == 0) {
                            aqwiVar.s();
                        }
                        aqwl aqwlVar2 = (aqwl) aqwiVar.b;
                        aqwlVar2.e = 2;
                        aqwlVar2.c |= 4;
                        aafwVar.a = aagaVar2.a(aqwiVar.p());
                        return;
                    }
                    try {
                        aafwVar.a = aagaVar2.a((aqwl) apxsVar3.b());
                    } catch (Throwable th) {
                        ((aimj) ((aimj) ((aimj) zsj.a.d()).j(th)).k("com/google/android/libraries/performance/primes/sampling/Sampler", "fetchSamplingParameters", '}', "Sampler.java")).s("Couldn't get sampling strategy");
                        aqwl aqwlVar3 = aqwl.a;
                        aqwi aqwiVar2 = new aqwi();
                        if ((aqwiVar2.b.ad & Integer.MIN_VALUE) == 0) {
                            aqwiVar2.s();
                        }
                        aqwl aqwlVar4 = (aqwl) aqwiVar2.b;
                        aqwlVar4.c = 2 | aqwlVar4.c;
                        aqwlVar4.d = 1L;
                        if ((aqwiVar2.b.ad & Integer.MIN_VALUE) == 0) {
                            aqwiVar2.s();
                        }
                        aqwl aqwlVar5 = (aqwl) aqwiVar2.b;
                        aqwlVar5.e = 3;
                        aqwlVar5.c |= 4;
                        aafwVar.a = aagaVar2.a(aqwiVar2.p());
                    }
                }
            }
        });
    }

    public final void a(anyt anytVar) {
        try {
            zun zunVar = (zun) anytVar.b();
            this.b = zunVar.b();
            this.c = new aafs(new aafr(zunVar.a()));
        } catch (Throwable th) {
            ((aimj) ((aimj) ((aimj) zsj.a.d()).j(th)).k("com/google/android/libraries/performance/primes/sampling/Sampler", "fetchConfig", 'h', "Sampler.java")).s("Couldn't get config");
            this.b = false;
        }
    }
}
