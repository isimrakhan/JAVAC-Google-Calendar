package cal;

import com.google.protobuf.InvalidProtocolBufferException;
import com.google.protobuf.UninitializedMessageException;
import java.io.IOException;
import java.io.InputStream;

/* compiled from: PG */
/* loaded from: classes2.dex */
public final class aajz extends ampm implements amqu {
    public static final ampt a = new aajx();
    public static final aajz b;
    public static volatile amra c;
    public int d;
    public boolean f;
    public ampw h;
    public ampw i;
    public amps j;
    public aakb k;
    public amob e = amob.b;
    public String g = "";

    static {
        aajz aajzVar = new aajz();
        b = aajzVar;
        aajzVar.ad &= Integer.MAX_VALUE;
        ampm.ac.put(aajz.class, aajzVar);
    }

    public aajz() {
        amrd amrdVar = amrd.b;
        this.h = amrdVar;
        this.i = amrdVar;
        this.j = ampn.b;
    }

    public static aajz parseFrom(InputStream inputStream) {
        amof amoeVar;
        int i = amof.f;
        if (inputStream == null) {
            byte[] bArr = ampx.b;
            int length = bArr.length;
            amoeVar = new amoc(bArr, 0, 0);
            try {
                amoeVar.d(0);
            } catch (InvalidProtocolBufferException e) {
                throw new IllegalArgumentException(e);
            }
        } else {
            amoeVar = new amoe(inputStream, 4096);
        }
        amov amovVar = amov.a;
        amrc amrcVar = amrc.a;
        amov amovVar2 = amov.b;
        aajz aajzVar = new aajz();
        try {
            amrk a2 = amrc.a.a(aajzVar.getClass());
            amog amogVar = amoeVar.e;
            if (amogVar == null) {
                amogVar = new amog(amoeVar);
            }
            a2.h(aajzVar, amogVar, amovVar2);
            a2.f(aajzVar);
            Byte b2 = (byte) 1;
            b2.getClass();
            return aajzVar;
        } catch (InvalidProtocolBufferException e2) {
            if (e2.a) {
                throw new InvalidProtocolBufferException(e2);
            }
            throw e2;
        } catch (UninitializedMessageException e3) {
            throw new InvalidProtocolBufferException(e3.getMessage());
        } catch (IOException e4) {
            if (e4.getCause() instanceof InvalidProtocolBufferException) {
                throw ((InvalidProtocolBufferException) e4.getCause());
            }
            throw new InvalidProtocolBufferException(e4);
        } catch (RuntimeException e5) {
            if (e5.getCause() instanceof InvalidProtocolBufferException) {
                throw ((InvalidProtocolBufferException) e5.getCause());
            }
            throw e5;
        }
    }

    @Override // cal.ampm
    public final Object a(int i, Object obj) {
        int i2 = i - 1;
        if (i2 != 0) {
            if (i2 != 2) {
                if (i2 != 3) {
                    if (i2 != 4) {
                        if (i2 != 5) {
                            if (i2 != 6) {
                                return null;
                            }
                            amra amraVar = c;
                            if (amraVar == null) {
                                synchronized (aajz.class) {
                                    amraVar = c;
                                    if (amraVar == null) {
                                        amraVar = new amph(b);
                                        c = amraVar;
                                    }
                                }
                            }
                            return amraVar;
                        }
                        return b;
                    }
                    return new aajy();
                }
                return new aajz();
            }
            return new amre(b, "\u0004\u0007\u0000\u0001\u0001\b\u0007\u0000\u0003\u0000\u0001ည\u0000\u0002ဇ\u0001\u0003ဈ\u0002\u0004\u001a\u0005\u001a\u0007ࠬ\bဉ\u0003", new Object[]{"d", "e", "f", "g", "h", "i", "j", ajvw.a, "k"});
        }
        return (byte) 1;
    }
}
