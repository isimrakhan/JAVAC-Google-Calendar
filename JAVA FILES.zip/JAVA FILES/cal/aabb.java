package cal;

/* compiled from: PG */
/* loaded from: classes2.dex */
final class aabb extends aabd {
    private final int a;
    private final boolean b;
    private final ahti c;
    private final int d;

    public aabb(int i, int i2, boolean z, ahti ahtiVar) {
        this.d = i;
        this.a = i2;
        this.b = z;
        this.c = ahtiVar;
    }

    @Override // cal.aabd
    public final int c() {
        return this.a;
    }

    @Override // cal.aabd
    public final ahti d() {
        return this.c;
    }

    @Override // cal.aabd
    public final boolean e() {
        return this.b;
    }

    public final boolean equals(Object obj) {
        if (obj == this) {
            return true;
        }
        if (obj instanceof aabd) {
            aabd aabdVar = (aabd) obj;
            if (this.d == aabdVar.f() && this.a == aabdVar.c()) {
                aabdVar.g();
                if (this.b == aabdVar.e() && this.c.equals(aabdVar.d())) {
                    return true;
                }
            }
        }
        return false;
    }

    @Override // cal.aabd
    public final int f() {
        return this.d;
    }

    public final int hashCode() {
        int i;
        boolean z = this.b;
        int hashCode = this.c.hashCode();
        if (true != z) {
            i = 1237;
        } else {
            i = 1231;
        }
        return ((i ^ ((this.a ^ ((this.d ^ 1000003) * 1000003)) * (-721379959))) * 1000003) ^ hashCode;
    }

    public final String toString() {
        String str;
        int i = this.d;
        if (i != 1) {
            if (i != 2) {
                str = "EXPLICITLY_ENABLED";
            } else {
                str = "EXPLICITLY_DISABLED";
            }
        } else {
            str = "DEFAULT";
        }
        return "NetworkConfigurations{enablement=" + str + ", batchSize=" + this.a + ", urlSanitizer=null, enableUrlAutoSanitization=" + this.b + ", metricExtensionProvider=" + String.valueOf(this.c) + "}";
    }

    @Override // cal.aabd
    public final void g() {
    }
}
