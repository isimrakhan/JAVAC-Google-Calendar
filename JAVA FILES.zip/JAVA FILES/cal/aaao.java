package cal;

/* compiled from: PG */
/* loaded from: classes2.dex */
public final /* synthetic */ class aaao implements aaak {
    public final /* synthetic */ aaar a;

    public /* synthetic */ aaao(aaar aaarVar) {
        this.a = aaarVar;
    }

    @Override // cal.aaak
    public final void a(int i, String str) {
        aaar aaarVar = this.a;
        if (aaarVar.b.a) {
            if (ajdh.a != null) {
                return;
            }
            new ajdh();
        } else {
            aaarVar.a.execute(new ajel(new aaan(aaarVar, i, null, true, str)));
        }
    }
}
