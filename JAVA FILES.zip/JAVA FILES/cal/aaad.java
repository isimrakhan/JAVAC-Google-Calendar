package cal;

/* compiled from: PG */
/* loaded from: classes2.dex */
public abstract class aaad implements zun {
    @Override // cal.zun
    public abstract int a();

    @Override // cal.zun
    public final boolean b() {
        if (f() != 2) {
            return true;
        }
        return false;
    }

    public abstract ahti c();

    public abstract boolean d();

    public abstract boolean e();

    public abstract int f();

    public abstract void g();

    public abstract void h();

    public abstract void i();

    public abstract void j();
}
