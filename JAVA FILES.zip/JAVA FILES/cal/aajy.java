package cal;

/* compiled from: PG */
/* loaded from: classes2.dex */
public final class aajy extends ampg implements amqu {
    public aajy() {
        super(aajz.b);
    }
}
