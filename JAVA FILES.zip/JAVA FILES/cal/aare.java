package cal;

import android.content.Context;
import android.os.Bundle;
import android.os.Looper;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.ListAdapter;
import android.widget.ListView;
import com.google.android.calendar.R;
import java.lang.reflect.Modifier;
import java.util.ArrayList;

/* compiled from: PG */
/* loaded from: classes2.dex */
public final class aare extends ci implements axm {
    public ArrayAdapter a;
    public aard b;

    @Override // cal.ci
    public final void onAttach(Context context) {
        super.onAttach(context);
        bfz parentFragment = getParentFragment();
        if (parentFragment instanceof aard) {
            this.b = (aard) parentFragment;
            return;
        }
        bfz activity = getActivity();
        if (activity instanceof aard) {
            this.b = (aard) activity;
        }
    }

    @Override // cal.ci
    public final View onCreateView(LayoutInflater layoutInflater, ViewGroup viewGroup, Bundle bundle) {
        return layoutInflater.inflate(R.layout.libraries_social_licenses_license_menu_fragment, viewGroup, false);
    }

    /* JADX WARN: Multi-variable type inference failed */
    /* JADX WARN: Type inference failed for: r0v10, types: [java.lang.Object[]] */
    /* JADX WARN: Type inference failed for: r0v11 */
    @Override // cal.ci
    public final void onDestroy() {
        ?? r0;
        super.onDestroy();
        co activity = getActivity();
        axs axsVar = new axs(activity, activity.getViewModelStore());
        if (!axsVar.b.c) {
            if (Looper.getMainLooper() == Looper.myLooper()) {
                abi abiVar = axsVar.b.b;
                int a = abk.a(abiVar.b, abiVar.d, 54321);
                axo axoVar = null;
                if (a >= 0 && (r0 = abiVar.c[a]) != abj.a) {
                    axoVar = r0;
                }
                axo axoVar2 = axoVar;
                if (axoVar2 != null) {
                    axoVar2.j();
                    abi abiVar2 = axsVar.b.b;
                    int a2 = abk.a(abiVar2.b, abiVar2.d, 54321);
                    if (a2 >= 0) {
                        Object[] objArr = abiVar2.c;
                        Object obj = objArr[a2];
                        Object obj2 = abj.a;
                        if (obj != obj2) {
                            objArr[a2] = obj2;
                            abiVar2.a = true;
                            return;
                        }
                        return;
                    }
                    return;
                }
                return;
            }
            throw new IllegalStateException("destroyLoader must be called on the main thread");
        }
        throw new IllegalStateException("Called while creating a loader");
    }

    @Override // cal.ci
    public final void onDetach() {
        super.onDetach();
        this.b = null;
    }

    /* JADX WARN: Multi-variable type inference failed */
    /* JADX WARN: Type inference failed for: r0v8, types: [java.lang.Object[]] */
    /* JADX WARN: Type inference failed for: r0v9 */
    @Override // cal.ci
    public final void onViewCreated(View view, Bundle bundle) {
        ?? r0;
        co activity = getActivity();
        this.a = new ArrayAdapter(activity, R.layout.libraries_social_licenses_license, R.id.license, new ArrayList());
        axs axsVar = new axs(activity, activity.getViewModelStore());
        if (!axsVar.b.c) {
            if (Looper.getMainLooper() == Looper.myLooper()) {
                abi abiVar = axsVar.b.b;
                int a = abk.a(abiVar.b, abiVar.d, 54321);
                axo axoVar = null;
                if (a >= 0 && (r0 = abiVar.c[a]) != abj.a) {
                    axoVar = r0;
                }
                axo axoVar2 = axoVar;
                if (axoVar2 == null) {
                    try {
                        axsVar.b.c = true;
                        aarb aarbVar = new aarb(getActivity());
                        if (aarbVar.getClass().isMemberClass() && !Modifier.isStatic(aarbVar.getClass().getModifiers())) {
                            throw new IllegalArgumentException("Object returned from onCreateLoader must not be a non-static inner member class: " + aarbVar);
                        }
                        axo axoVar3 = new axo(aarbVar);
                        axsVar.b.b.a(54321, axoVar3);
                        axsVar.b.c = false;
                        axoVar3.l(axsVar.a, this);
                    } catch (Throwable th) {
                        axsVar.b.c = false;
                        throw th;
                    }
                } else {
                    axoVar2.l(axsVar.a, this);
                }
                ListView listView = (ListView) view.findViewById(R.id.license_list);
                listView.setAdapter((ListAdapter) this.a);
                listView.setOnItemClickListener(new AdapterView.OnItemClickListener() { // from class: cal.aarc
                    @Override // android.widget.AdapterView.OnItemClickListener
                    public final void onItemClick(AdapterView adapterView, View view2, int i, long j) {
                        aaqz aaqzVar = (aaqz) adapterView.getItemAtPosition(i);
                        aard aardVar = aare.this.b;
                        if (aardVar != null) {
                            aardVar.u(aaqzVar);
                        }
                    }
                });
                return;
            }
            throw new IllegalStateException("initLoader must be called on the main thread");
        }
        throw new IllegalStateException("Called while creating a loader");
    }
}
