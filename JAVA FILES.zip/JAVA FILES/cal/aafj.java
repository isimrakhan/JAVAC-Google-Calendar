package cal;

import android.os.SystemClock;
import java.lang.ref.WeakReference;
import java.util.ArrayDeque;
import java.util.ArrayList;
import java.util.Collections;
import java.util.concurrent.atomic.AtomicReference;

/* compiled from: PG */
/* loaded from: classes2.dex */
public final class aafj {
    public static int a = 10;
    public static int b;
    public static final AtomicReference c = new AtomicReference();

    public static void a(aaet aaetVar) {
        if (!aaetVar.equals(aaet.a)) {
            if (aaetVar.d < 0) {
                aaetVar.d = SystemClock.elapsedRealtime();
            }
            AtomicReference atomicReference = c;
            aafc aafcVar = (aafc) atomicReference.get();
            if (aafcVar != null) {
                if (aaetVar == ((aaet) ((ArrayDeque) ((WeakReference) aafcVar.d.get()).get()).poll())) {
                    long j = aaetVar.d;
                    long j2 = -1;
                    if (j != -1) {
                        j2 = j - aaetVar.c;
                    }
                    if (j2 >= a) {
                        if (aafcVar.a.incrementAndGet() < b) {
                            aaet aaetVar2 = (aaet) ((ArrayDeque) ((WeakReference) aafcVar.d.get()).get()).peek();
                            if (aaetVar2 != null) {
                                if (aaetVar2.f == Collections.EMPTY_LIST) {
                                    aaetVar2.f = new ArrayList();
                                }
                                if (aaetVar2.f != null) {
                                    aaetVar2.f.add(aaetVar);
                                    return;
                                }
                                return;
                            }
                            ((aimj) ((aimj) zsj.a.d()).k("com/google/android/libraries/performance/primes/metrics/trace/TraceData", "linkToParent", gl.FEATURE_SUPPORT_ACTION_BAR, "TraceData.java")).v("null Parent for Span: %s", aaetVar.b);
                            return;
                        }
                        ((aimj) ((aimj) zsj.a.d()).k("com/google/android/libraries/performance/primes/metrics/trace/Tracer", "endSpan", 183, "Tracer.java")).t("Dropping trace as max buffer size is hit. Size: %d", aafcVar.a.get());
                        atomicReference.set(null);
                        return;
                    }
                    return;
                }
                ((aimj) ((aimj) zsj.a.d()).k("com/google/android/libraries/performance/primes/metrics/trace/Tracer", "endSpan", 174, "Tracer.java")).s("Incorrect Span passed. Ignore...");
            }
        }
    }
}
