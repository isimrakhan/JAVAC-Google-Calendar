package cal;

import com.google.android.gms.common.api.ApiException;
import com.google.android.libraries.phenotype.client.api.PhenotypeRuntimeException;

/* compiled from: PG */
/* loaded from: classes2.dex */
public final /* synthetic */ class aajf implements ajaz {
    @Override // cal.ajaz
    public final ajdo a(Object obj) {
        ApiException apiException = (ApiException) obj;
        throw new PhenotypeRuntimeException(apiException.a.f, apiException.getMessage(), apiException);
    }
}
