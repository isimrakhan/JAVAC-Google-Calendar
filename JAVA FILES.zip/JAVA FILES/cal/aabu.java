package cal;

import java.util.concurrent.Executors;

/* compiled from: PG */
/* loaded from: classes2.dex */
public final /* synthetic */ class aabu implements Runnable {
    public final /* synthetic */ aabz a;

    public /* synthetic */ aabu(aabz aabzVar) {
        this.a = aabzVar;
    }

    @Override // java.lang.Runnable
    public final void run() {
        aabz aabzVar = this.a;
        aabzVar.b.execute(new ajel(Executors.callable(new aabw(aabzVar), null)));
    }
}
