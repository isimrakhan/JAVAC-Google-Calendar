package cal;

/* compiled from: PG */
/* loaded from: classes2.dex */
final class aair {
    static final aimm a = aimm.h("com/google/android/libraries/phenotype/client/Phlogger$PhClient");
}
