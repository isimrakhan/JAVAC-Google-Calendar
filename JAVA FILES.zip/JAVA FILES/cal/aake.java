package cal;

/* compiled from: PG */
/* loaded from: classes2.dex */
public final class aake extends ampg implements amqu {
    public aake() {
        super(aakf.a);
    }
}
