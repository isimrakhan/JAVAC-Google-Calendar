package cal;

import androidx.cardview.widget.CardView;

/* compiled from: PG */
/* loaded from: classes.dex */
public final class aaq {
    public static final void a(aap aapVar) {
        float f;
        CardView cardView = aapVar.b;
        if (cardView.a) {
            aar aarVar = (aar) aapVar.a;
            float f2 = aarVar.b;
            float f3 = aarVar.a;
            boolean z = cardView.b;
            double d = aas.a;
            if (z) {
                f = (float) (f2 + ((1.0d - aas.a) * f3));
            } else {
                f = f2;
            }
            int ceil = (int) Math.ceil(f);
            float f4 = f2 * 1.5f;
            if (aapVar.b.b) {
                f4 = (float) (f4 + ((1.0d - aas.a) * f3));
            }
            int ceil2 = (int) Math.ceil(f4);
            aapVar.a(ceil, ceil2, ceil, ceil2);
            return;
        }
        aapVar.a(0, 0, 0, 0);
    }
}
