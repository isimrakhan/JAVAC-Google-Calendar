package cal;

import java.util.Set;

/* compiled from: PG */
/* loaded from: classes2.dex */
public final class aapy {
    public final Set a;
    public final Set b;
    public final boolean c = true;

    public aapy(Set set, Set set2) {
        this.a = set;
        this.b = set2;
    }

    public final boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (!(obj instanceof aapy)) {
            return false;
        }
        aapy aapyVar = (aapy) obj;
        if (!this.a.equals(aapyVar.a) || !this.b.equals(aapyVar.b)) {
            return false;
        }
        boolean z = aapyVar.c;
        return true;
    }

    public final int hashCode() {
        return (((this.a.hashCode() * 31) + this.b.hashCode()) * 31) + 1231;
    }

    public final String toString() {
        return "QuerySpec(interactionTypes=" + this.a + ", contactFieldTypes=" + this.b + ", propagateFieldLevelSignalsToContact=true)";
    }
}
