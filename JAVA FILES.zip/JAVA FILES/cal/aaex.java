package cal;

/* compiled from: PG */
/* loaded from: classes2.dex */
public interface aaex {
    void a(String str, long j, long j2);

    boolean b();

    ajdo c(String str);
}
