package cal;

/* compiled from: PG */
/* loaded from: classes2.dex */
public final /* synthetic */ class aafv implements Runnable {
    public final /* synthetic */ aafw a;
    public final /* synthetic */ anyt b;

    public /* synthetic */ aafv(aafw aafwVar, anyt anytVar) {
        this.a = aafwVar;
        this.b = anytVar;
    }

    @Override // java.lang.Runnable
    public final void run() {
        this.a.a(this.b);
    }
}
