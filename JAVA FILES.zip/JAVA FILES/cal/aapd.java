package cal;

/* compiled from: PG */
/* loaded from: classes2.dex */
public abstract class aapd {
    public abstract int a();
}
