package cal;

/* compiled from: PG */
/* loaded from: classes2.dex */
public abstract class aach {
    public abstract aaci a();
}
