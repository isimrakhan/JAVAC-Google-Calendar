package cal;

import java.util.Map;

/* compiled from: PG */
/* loaded from: classes2.dex */
public final class aaoy {
    public static void a(Map map) {
        aics aicsVar = (aics) map;
        aidr<Map.Entry> aidrVar = aicsVar.b;
        if (aidrVar == null) {
            aikr aikrVar = (aikr) map;
            aiko aikoVar = new aiko(aicsVar, aikrVar.g, 0, aikrVar.h);
            aicsVar.b = aikoVar;
            aidrVar = aikoVar;
        }
        for (Map.Entry entry : aidrVar) {
            afwa a = afxc.a((String) entry.getKey(), afwc.a, true);
            try {
                ((aaow) ((apxs) entry.getValue()).b()).a();
                a.close();
            } catch (Throwable th) {
                try {
                    a.close();
                } catch (Throwable th2) {
                    th.addSuppressed(th2);
                }
                throw th;
            }
        }
    }
}
