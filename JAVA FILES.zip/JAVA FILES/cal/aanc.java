package cal;

import java.util.concurrent.atomic.AtomicBoolean;

/* compiled from: PG */
/* loaded from: classes2.dex */
public final class aanc {
    public static final AtomicBoolean a = new AtomicBoolean(false);
}
