package cal;

import java.util.concurrent.atomic.AtomicBoolean;

/* compiled from: PG */
/* loaded from: classes2.dex */
public final class aadg extends aadd implements zwh, ztq {
    private final ztw a;
    private final apxs b;
    private final apxs c;
    private final apxs d;
    private final AtomicBoolean e = new AtomicBoolean();
    private final apxs f;
    private final ahum g;
    private final apxs h;
    private final apxs i;

    public aadg(ztw ztwVar, apxs apxsVar, apxs apxsVar2, apxs apxsVar3, final apxs apxsVar4, apxs apxsVar5, apxs apxsVar6, anyt anytVar) {
        this.g = ahus.a(new ahum() { // from class: cal.aade
            @Override // cal.ahum
            public final Object a() {
                int intValue = ((Long) apxs.this.b()).intValue();
                for (aadj aadjVar : aadj.values()) {
                    if (intValue == aadjVar.f) {
                        return aadjVar;
                    }
                }
                return aadj.DELAY_UNSPECIFIED;
            }
        });
        this.h = apxsVar5;
        this.i = apxsVar6;
        this.a = ztwVar;
        this.b = apxsVar;
        this.c = apxsVar2;
        this.d = apxsVar3;
        this.f = new aadf(anytVar);
    }

    private static aqvw a(aacq aacqVar) {
        aqvw aqvwVar = aqvw.a;
        aqvv aqvvVar = new aqvv();
        if (aacqVar.a != null) {
            String str = aacqVar.a;
            if ((aqvvVar.b.ad & Integer.MIN_VALUE) == 0) {
                aqvvVar.s();
            }
            aqvw aqvwVar2 = (aqvw) aqvvVar.b;
            str.getClass();
            aqvwVar2.c |= 1;
            aqvwVar2.d = str;
        }
        if (aacqVar.b != null) {
            long j = ((zvs) aacqVar.b).a;
            if ((aqvvVar.b.ad & Integer.MIN_VALUE) == 0) {
                aqvvVar.s();
            }
            aqvw aqvwVar3 = (aqvw) aqvvVar.b;
            aqvwVar3.c |= 2;
            aqvwVar3.e = j;
        }
        if (aacqVar.c != null) {
            long j2 = ((zvs) aacqVar.c).a;
            if ((aqvvVar.b.ad & Integer.MIN_VALUE) == 0) {
                aqvvVar.s();
            }
            aqvw aqvwVar4 = (aqvw) aqvvVar.b;
            aqvwVar4.c |= 4;
            aqvwVar4.f = j2;
        }
        if (aacqVar.d != null) {
            long j3 = ((zvs) aacqVar.d).a;
            if ((aqvvVar.b.ad & Integer.MIN_VALUE) == 0) {
                aqvvVar.s();
            }
            aqvw aqvwVar5 = (aqvw) aqvvVar.b;
            aqvwVar5.c |= 8;
            aqvwVar5.g = j3;
        }
        return (aqvw) aqvvVar.p();
    }

    /* JADX WARN: Removed duplicated region for block: B:166:0x043d  */
    /* JADX WARN: Removed duplicated region for block: B:167:0x0441  */
    /* JADX WARN: Removed duplicated region for block: B:239:0x050f  */
    /* JADX WARN: Removed duplicated region for block: B:248:0x054b  */
    /* JADX WARN: Removed duplicated region for block: B:251:0x055d  */
    /* JADX WARN: Removed duplicated region for block: B:254:0x0570  */
    /* JADX WARN: Removed duplicated region for block: B:257:0x0598  */
    /* JADX WARN: Removed duplicated region for block: B:366:0x07ff  */
    /* JADX WARN: Removed duplicated region for block: B:371:0x081f  */
    @Override // cal.ztq
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct code enable 'Show inconsistent code' option in preferences
    */
    public final void i(cal.zry r20) {
        /*
            Method dump skipped, instructions count: 2110
            To view this dump change 'Code comments level' option to 'DEBUG'
        */
        throw new UnsupportedOperationException("Method not decompiled: cal.aadg.i(cal.zry):void");
    }

    @Override // cal.zwh
    public final void u() {
        this.a.c.b.add(this);
    }

    @Override // cal.ztq
    public final /* synthetic */ void j(zry zryVar) {
    }
}
