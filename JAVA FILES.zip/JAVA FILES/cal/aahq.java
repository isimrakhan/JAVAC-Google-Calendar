package cal;

/* compiled from: PG */
/* loaded from: classes2.dex */
public final class aahq {
    private static volatile ahti a;

    private aahq() {
    }

    /* JADX WARN: Can't wrap try/catch for region: R(16:8|(2:12|13)|19|(1:21)|22|23|24|25|26|27|28|(1:30)(1:81)|31|(10:33|34|35|36|37|(2:38|(3:40|(3:59|60|61)(9:42|43|(2:45|(1:48))|49|(1:51)(1:58)|52|(1:54)|55|56)|57)(1:62))|63|64|65|66)(1:80)|67|13) */
    /* JADX WARN: Code restructure failed: missing block: B:83:0x0066, code lost:
    
        r3 = move-exception;
     */
    /* JADX WARN: Code restructure failed: missing block: B:84:0x0067, code lost:
    
        android.util.Log.e("HermeticFileOverrides", "no data dir", r3);
        r4 = cal.ahre.a;
     */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct code enable 'Show inconsistent code' option in preferences
    */
    public static cal.ahti a(android.content.Context r14) {
        /*
            Method dump skipped, instructions count: 356
            To view this dump change 'Code comments level' option to 'DEBUG'
        */
        throw new UnsupportedOperationException("Method not decompiled: cal.aahq.a(android.content.Context):cal.ahti");
    }
}
