package cal;

/* JADX INFO: Access modifiers changed from: package-private */
/* compiled from: PG */
/* loaded from: classes2.dex */
public final class aakn extends aank {
    public final aajt a;
    public final aaiw b;

    public aakn(aajt aajtVar, aaiw aaiwVar) {
        this.a = aajtVar;
        if (aaiwVar != null) {
            this.b = aaiwVar;
            return;
        }
        throw new NullPointerException("Null snapshotResult");
    }

    @Override // cal.aank
    public final aaiw a() {
        return this.b;
    }

    @Override // cal.aank
    public final aajt b() {
        return this.a;
    }

    public final boolean equals(Object obj) {
        if (obj == this) {
            return true;
        }
        if (obj instanceof aank) {
            aank aankVar = (aank) obj;
            aajt aajtVar = this.a;
            if (aajtVar != null ? aajtVar.equals(aankVar.b()) : aankVar.b() == null) {
                aaiw aaiwVar = this.b;
                aaiw a = aankVar.a();
                if (aaiwVar != a) {
                    if (aaiwVar.getClass() == a.getClass()) {
                        if (amrc.a.a(aaiwVar.getClass()).k(aaiwVar, a)) {
                        }
                    }
                }
                return true;
            }
        }
        return false;
    }

    public final int hashCode() {
        int hashCode;
        int i;
        aajt aajtVar = this.a;
        if (aajtVar == null) {
            hashCode = 0;
        } else {
            hashCode = aajtVar.hashCode();
        }
        aaiw aaiwVar = this.b;
        if ((aaiwVar.ad & Integer.MIN_VALUE) != 0) {
            i = amrc.a.a(aaiwVar.getClass()).b(aaiwVar);
        } else {
            int i2 = aaiwVar.ab;
            if (i2 == 0) {
                i2 = amrc.a.a(aaiwVar.getClass()).b(aaiwVar);
                aaiwVar.ab = i2;
            }
            i = i2;
        }
        return ((hashCode ^ 1000003) * 1000003) ^ i;
    }

    public final String toString() {
        aaiw aaiwVar = this.b;
        return "SnapshotBlobAndResult{snapshotBlob=" + String.valueOf(this.a) + ", snapshotResult=" + aaiwVar.toString() + "}";
    }
}
