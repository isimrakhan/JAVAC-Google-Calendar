package cal;

/* compiled from: PG */
/* loaded from: classes2.dex */
public abstract class aabh {
    public abstract ajdo a();

    public abstract void b(aabe aabeVar);
}
