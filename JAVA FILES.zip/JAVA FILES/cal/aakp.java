package cal;

import java.util.Set;

/* compiled from: PG */
/* loaded from: classes2.dex */
public final class aakp {
    public final boolean a;
    public final boolean b;
    public final Set c;
    public final aamz d;
    public final aamz e;

    public aakp(boolean z, boolean z2, Set set, aamz aamzVar, aamz aamzVar2) {
        this.a = z;
        this.b = z2;
        this.c = set;
        this.d = aamzVar;
        this.e = aamzVar2;
    }
}
