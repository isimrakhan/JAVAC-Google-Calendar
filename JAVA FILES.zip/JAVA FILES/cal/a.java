package cal;

import android.accounts.Account;
import android.util.AttributeSet;
import com.google.calendar.v2a.shared.series.EventIds;

/* compiled from: PG */
/* loaded from: classes.dex */
public final class a {
    public static /* synthetic */ void A(aina ainaVar, String str, String str2, String str3, char c, String str4, Throwable th) {
        ((ainp) ((ainp) ((ainp) ainaVar).j(th)).k(str2, str3, c, str4)).s(str);
    }

    public static /* synthetic */ String B(ampm ampmVar, String str) {
        return "Serializing " + ampmVar.getClass().getName() + " to a " + str + " threw an IOException (should never happen).";
    }

    public static /* synthetic */ String C(ampm ampmVar, String str) {
        return "Serializing " + ampmVar.getClass().getName() + " to a " + str + " threw an IOException (should never happen).";
    }

    public static /* synthetic */ String D(bfo bfoVar, bfo bfoVar2, String str) {
        return str + bfr.b(bfoVar2) + "\n Found:\n" + bfr.b(bfoVar);
    }

    public static /* synthetic */ String E(EventIds.InstanceEventId instanceEventId) {
        return instanceEventId.a.a + "_" + instanceEventId.b;
    }

    public static /* synthetic */ String F(ajtg ajtgVar, String str) {
        return str + ajtgVar.g;
    }

    public static /* synthetic */ String a(String str, String str2, String str3) {
        return str2 + str + str3;
    }

    public static /* synthetic */ String b(Object obj, String str, String str2) {
        return str + obj.toString() + str2;
    }

    public static /* synthetic */ String c(String str, String str2, String str3, String str4, String str5) {
        return str3 + str2 + str4 + str + str5;
    }

    public static /* synthetic */ String d(String str, String str2, String str3) {
        return str2 + str3 + str;
    }

    public static /* synthetic */ String e(Object obj, String str, String str2) {
        return str + obj + str2;
    }

    public static /* synthetic */ String f(int i, String str) {
        return str + i;
    }

    public static /* synthetic */ String g(String str, AttributeSet attributeSet, String str2) {
        return attributeSet.getPositionDescription() + str2 + str;
    }

    public static /* synthetic */ String h(Object obj, Object obj2, String str, String str2) {
        return str + obj2 + str2 + obj;
    }

    public static /* synthetic */ String i(int i, String str, String str2) {
        return str + i + str2;
    }

    public static /* synthetic */ String j(String str, String str2) {
        return str2 + str;
    }

    public static /* synthetic */ String k(int i, int i2, String str, String str2, String str3) {
        return str + i2 + str2 + i + str3;
    }

    public static /* synthetic */ String l(String str, String str2, String str3) {
        return str + str2 + str3;
    }

    public static /* synthetic */ String m(String str, String str2, String str3, String str4) {
        return str3 + str2 + str4 + str;
    }

    public static /* synthetic */ String n(int i, String str) {
        return i + str;
    }

    public static /* synthetic */ String o(long j, String str) {
        return str + j;
    }

    public static /* synthetic */ void p(aina ainaVar, String str, String str2, String str3, char c, String str4, Throwable th) {
        ((aimj) ((aimj) ((aimj) ainaVar).j(th)).k(str2, str3, c, str4)).s(str);
    }

    public static /* synthetic */ String q(Object obj, String str, String str2) {
        return str + String.valueOf(obj) + str2;
    }

    public static /* synthetic */ String r(Object obj, String str, String str2, String str3) {
        return str2 + str + str3 + String.valueOf(obj);
    }

    public static /* synthetic */ String s(Object obj, String str) {
        return str + String.valueOf(obj);
    }

    public static /* synthetic */ String t(ampm ampmVar, String str) {
        return "Serializing " + ampmVar.getClass().getName() + str;
    }

    public static /* synthetic */ String u(Object obj, String str, String str2) {
        return str + obj.getClass().getName() + str2;
    }

    public static /* synthetic */ String v(String str, ampm ampmVar) {
        return "Serializing " + ampmVar.getClass().getName() + str;
    }

    public static /* synthetic */ String x(Account account, String str) {
        return str + account.hashCode();
    }

    public static /* synthetic */ String y(int i, int i2, String str, String str2) {
        return str + i2 + str2 + i;
    }
}
