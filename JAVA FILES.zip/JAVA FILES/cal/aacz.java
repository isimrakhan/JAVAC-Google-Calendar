package cal;

/* compiled from: PG */
/* loaded from: classes2.dex */
public final class aacz {
    public static final aacz a = new aacz();
    public volatile boolean b;
    public volatile boolean c;
    public volatile boolean d;
    public volatile boolean e;
    public volatile boolean f;
    public volatile zwn g;
    public volatile zwn h;
    public volatile zwn i;
    public volatile zwn j;
    public volatile zwn k;
    public volatile zwn l;
    public volatile zwn m;
    public volatile zwn n;
    public volatile zwn o;
    public volatile zwn p;
    public volatile zwn q;
    public volatile zry r;
    private volatile boolean[] u = new boolean[5];
    public final aacq s = new aacq();
    public final aacq t = new aacq();

    public final void a(final int i) {
        boolean z;
        if (i < 5) {
            boolean[] zArr = this.u;
            if (this.s.b != null) {
                z = true;
            } else {
                z = false;
            }
            zArr[i] = z;
            if (this.u[i]) {
                for (int i2 = i + 1; i2 < 5; i2++) {
                    this.u[i2] = true;
                }
                return;
            }
            abyh.a().post(new Runnable() { // from class: cal.aacj
                @Override // java.lang.Runnable
                public final void run() {
                    aacz.this.a(i + 1);
                }
            });
        }
    }

    /* JADX INFO: Access modifiers changed from: package-private */
    public final boolean b(boolean z, long j, aadj aadjVar) {
        if (z) {
            return this.u[((int) j) - 1];
        }
        int ordinal = aadjVar.ordinal();
        if (ordinal != 1) {
            if (ordinal != 2) {
                if (ordinal != 3) {
                    if (ordinal != 4) {
                        return this.b;
                    }
                    return this.f;
                }
                return this.e;
            }
            return this.d;
        }
        return this.c;
    }
}
