package cal;

import java.util.HashMap;

/* compiled from: PG */
/* loaded from: classes2.dex */
public final class aapw {
    public final aaqq a;
    public aaqp b = null;
    public final HashMap c = new HashMap();
    public final HashMap d = new HashMap();

    public aapw(aaqq aaqqVar) {
        this.a = aaqqVar;
    }

    public static final void a(HashMap hashMap, Long l, Integer num) {
        if (hashMap.containsKey(l)) {
            hashMap.put(l, Integer.valueOf(((Integer) hashMap.get(l)).intValue() + num.intValue()));
        } else {
            hashMap.put(l, num);
        }
    }
}
