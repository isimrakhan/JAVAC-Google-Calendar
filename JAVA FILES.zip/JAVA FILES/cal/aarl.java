package cal;

/* compiled from: PG */
/* loaded from: classes2.dex */
public final class aarl implements aark {
    public final apxs a;
    public final aqda b;

    public aarl(apxs apxsVar, aqda aqdaVar) {
        this.a = apxsVar;
        this.b = aqdaVar;
    }
}
