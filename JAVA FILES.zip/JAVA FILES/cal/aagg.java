package cal;

/* compiled from: PG */
/* loaded from: classes2.dex */
public final class aagg extends ampj implements amqu {
    public static final aagg a;
    public static volatile amra b;
    public int c;
    public aqyd d;
    public byte e = 2;

    static {
        aagg aaggVar = new aagg();
        a = aaggVar;
        aaggVar.ad &= Integer.MAX_VALUE;
        ampm.ac.put(aagg.class, aaggVar);
    }

    /* JADX WARN: Code restructure failed: missing block: B:21:0x006c, code lost:
    
        if (r5 != false) goto L30;
     */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct code enable 'Show inconsistent code' option in preferences
    */
    public static cal.aagg parseFrom(java.io.InputStream r5) {
        /*
            int r0 = cal.amof.f
            r0 = 0
            if (r5 != 0) goto L18
            byte[] r5 = cal.ampx.b
            int r1 = r5.length
            cal.amoc r1 = new cal.amoc
            r1.<init>(r5, r0, r0)
            r1.d(r0)     // Catch: com.google.protobuf.InvalidProtocolBufferException -> L11
            goto L1f
        L11:
            r5 = move-exception
            java.lang.IllegalArgumentException r0 = new java.lang.IllegalArgumentException
            r0.<init>(r5)
            throw r0
        L18:
            cal.amoe r1 = new cal.amoe
            r2 = 4096(0x1000, float:5.74E-42)
            r1.<init>(r5, r2)
        L1f:
            cal.amov r5 = cal.amov.a
            cal.amrc r5 = cal.amrc.a
            cal.amov r5 = cal.amov.b
            cal.aagg r2 = new cal.aagg
            r2.<init>()
            cal.amrc r3 = cal.amrc.a     // Catch: java.lang.RuntimeException -> L7e java.io.IOException -> L8f com.google.protobuf.UninitializedMessageException -> La5 com.google.protobuf.InvalidProtocolBufferException -> Lb0
            java.lang.Class r4 = r2.getClass()     // Catch: java.lang.RuntimeException -> L7e java.io.IOException -> L8f com.google.protobuf.UninitializedMessageException -> La5 com.google.protobuf.InvalidProtocolBufferException -> Lb0
            cal.amrk r3 = r3.a(r4)     // Catch: java.lang.RuntimeException -> L7e java.io.IOException -> L8f com.google.protobuf.UninitializedMessageException -> La5 com.google.protobuf.InvalidProtocolBufferException -> Lb0
            cal.amog r4 = r1.e     // Catch: java.lang.RuntimeException -> L7e java.io.IOException -> L8f com.google.protobuf.UninitializedMessageException -> La5 com.google.protobuf.InvalidProtocolBufferException -> Lb0
            if (r4 == 0) goto L39
            goto L3e
        L39:
            cal.amog r4 = new cal.amog     // Catch: java.lang.RuntimeException -> L7e java.io.IOException -> L8f com.google.protobuf.UninitializedMessageException -> La5 com.google.protobuf.InvalidProtocolBufferException -> Lb0
            r4.<init>(r1)     // Catch: java.lang.RuntimeException -> L7e java.io.IOException -> L8f com.google.protobuf.UninitializedMessageException -> La5 com.google.protobuf.InvalidProtocolBufferException -> Lb0
        L3e:
            r3.h(r2, r4, r5)     // Catch: java.lang.RuntimeException -> L7e java.io.IOException -> L8f com.google.protobuf.UninitializedMessageException -> La5 com.google.protobuf.InvalidProtocolBufferException -> Lb0
            r3.f(r2)     // Catch: java.lang.RuntimeException -> L7e java.io.IOException -> L8f com.google.protobuf.UninitializedMessageException -> La5 com.google.protobuf.InvalidProtocolBufferException -> Lb0
            byte r5 = r2.e
            java.lang.Byte r1 = java.lang.Byte.valueOf(r5)
            r1.getClass()
            r1 = 1
            if (r5 != r1) goto L51
            goto L6e
        L51:
            if (r5 == 0) goto L6f
            cal.amrc r5 = cal.amrc.a
            java.lang.Class r3 = r2.getClass()
            cal.amrk r5 = r5.a(r3)
            boolean r5 = r5.l(r2)
            if (r1 == r5) goto L65
            r3 = 0
            goto L66
        L65:
            r3 = r2
        L66:
            if (r3 != 0) goto L69
            goto L6a
        L69:
            r0 = r1
        L6a:
            r2.e = r0
            if (r5 == 0) goto L6f
        L6e:
            return r2
        L6f:
            com.google.protobuf.UninitializedMessageException r5 = new com.google.protobuf.UninitializedMessageException
            r5.<init>()
            com.google.protobuf.InvalidProtocolBufferException r0 = new com.google.protobuf.InvalidProtocolBufferException
            java.lang.String r5 = r5.getMessage()
            r0.<init>(r5)
            throw r0
        L7e:
            r5 = move-exception
            java.lang.Throwable r0 = r5.getCause()
            boolean r0 = r0 instanceof com.google.protobuf.InvalidProtocolBufferException
            if (r0 == 0) goto L8e
            java.lang.Throwable r5 = r5.getCause()
            com.google.protobuf.InvalidProtocolBufferException r5 = (com.google.protobuf.InvalidProtocolBufferException) r5
            throw r5
        L8e:
            throw r5
        L8f:
            r5 = move-exception
            java.lang.Throwable r0 = r5.getCause()
            boolean r0 = r0 instanceof com.google.protobuf.InvalidProtocolBufferException
            if (r0 == 0) goto L9f
            java.lang.Throwable r5 = r5.getCause()
            com.google.protobuf.InvalidProtocolBufferException r5 = (com.google.protobuf.InvalidProtocolBufferException) r5
            throw r5
        L9f:
            com.google.protobuf.InvalidProtocolBufferException r0 = new com.google.protobuf.InvalidProtocolBufferException
            r0.<init>(r5)
            throw r0
        La5:
            r5 = move-exception
            com.google.protobuf.InvalidProtocolBufferException r0 = new com.google.protobuf.InvalidProtocolBufferException
            java.lang.String r5 = r5.getMessage()
            r0.<init>(r5)
            throw r0
        Lb0:
            r5 = move-exception
            boolean r0 = r5.a
            if (r0 == 0) goto Lbb
            com.google.protobuf.InvalidProtocolBufferException r0 = new com.google.protobuf.InvalidProtocolBufferException
            r0.<init>(r5)
            throw r0
        Lbb:
            throw r5
        */
        throw new UnsupportedOperationException("Method not decompiled: cal.aagg.parseFrom(java.io.InputStream):cal.aagg");
    }

    @Override // cal.ampm
    public final Object a(int i, Object obj) {
        int i2 = i - 1;
        if (i2 != 0) {
            byte b2 = 1;
            if (i2 != 2) {
                if (i2 != 3) {
                    if (i2 != 4) {
                        if (i2 != 5) {
                            if (i2 != 6) {
                                if (obj == null) {
                                    b2 = 0;
                                }
                                this.e = b2;
                                return null;
                            }
                            amra amraVar = b;
                            if (amraVar == null) {
                                synchronized (aagg.class) {
                                    amraVar = b;
                                    if (amraVar == null) {
                                        amraVar = new amph(a);
                                        b = amraVar;
                                    }
                                }
                            }
                            return amraVar;
                        }
                        return a;
                    }
                    return new aagf();
                }
                return new aagg();
            }
            return new amre(a, "\u0004\u0001\u0000\u0001\u0001\u0001\u0001\u0000\u0000\u0001\u0001ᐉ\u0000", new Object[]{"c", "d"});
        }
        return Byte.valueOf(this.e);
    }
}
