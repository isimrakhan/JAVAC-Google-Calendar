package cal;

import android.app.ActivityOptions;
import android.content.Intent;
import android.os.Build;
import android.os.Bundle;
import android.os.LocaleList;
import android.text.TextUtils;
import java.util.Locale;

/* compiled from: PG */
/* loaded from: classes.dex */
public final class aaj {
    public final Intent a;
    public final aag b;
    public Bundle c;
    private ActivityOptions d;

    public aaj() {
        this.a = new Intent("android.intent.action.VIEW");
        this.b = new aag();
    }

    public final aak a() {
        LocaleList adjustedDefault;
        int size;
        String str;
        Bundle bundle;
        Locale locale;
        Bundle bundle2 = null;
        if (!this.a.hasExtra("android.support.customtabs.extra.SESSION")) {
            Bundle bundle3 = new Bundle();
            bundle3.putBinder("android.support.customtabs.extra.SESSION", null);
            this.a.putExtras(bundle3);
        }
        this.a.putExtra("android.support.customtabs.extra.EXTRA_ENABLE_INSTANT_APPS", true);
        Intent intent = this.a;
        Integer num = this.b.a;
        Bundle bundle4 = new Bundle();
        if (num != null) {
            bundle4.putInt("android.support.customtabs.extra.TOOLBAR_COLOR", num.intValue());
        }
        intent.putExtras(bundle4);
        Bundle bundle5 = this.c;
        if (bundle5 != null) {
            this.a.putExtras(bundle5);
        }
        this.a.putExtra("androidx.browser.customtabs.extra.SHARE_STATE", 0);
        adjustedDefault = LocaleList.getAdjustedDefault();
        size = adjustedDefault.size();
        if (size > 0) {
            locale = adjustedDefault.get(0);
            str = locale.toLanguageTag();
        } else {
            str = null;
        }
        if (!TextUtils.isEmpty(str)) {
            if (this.a.hasExtra("com.android.browser.headers")) {
                bundle = this.a.getBundleExtra("com.android.browser.headers");
            } else {
                bundle = new Bundle();
            }
            if (!bundle.containsKey("Accept-Language")) {
                bundle.putString("Accept-Language", str);
                this.a.putExtra("com.android.browser.headers", bundle);
            }
        }
        if (Build.VERSION.SDK_INT >= 34) {
            if (this.d == null) {
                this.d = ActivityOptions.makeBasic();
            }
            this.d.setShareIdentityEnabled(false);
        }
        ActivityOptions activityOptions = this.d;
        if (activityOptions != null) {
            bundle2 = activityOptions.toBundle();
        }
        return new aak(this.a, bundle2);
    }

    /* JADX WARN: Multi-variable type inference failed */
    /* JADX WARN: Type inference failed for: r4v1, types: [cal.af, android.os.IBinder] */
    public aaj(aan aanVar) {
        Intent intent = new Intent("android.intent.action.VIEW");
        this.a = intent;
        this.b = new aag();
        if (aanVar != null) {
            intent.setPackage(aanVar.b.getPackageName());
            ?? r4 = aanVar.a;
            Bundle bundle = new Bundle();
            bundle.putBinder("android.support.customtabs.extra.SESSION", r4);
            intent.putExtras(bundle);
        }
    }
}
