package cal;

import java.util.EnumMap;

/* compiled from: PG */
/* loaded from: classes2.dex */
public final class aapt {
    public final aaqq a;
    public final aidp b = new aidp();
    public final EnumMap c = new EnumMap(aaqk.class);

    public aapt(aaqq aaqqVar) {
        this.a = aaqqVar;
    }
}
