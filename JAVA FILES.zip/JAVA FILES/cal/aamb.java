package cal;

import java.util.concurrent.TimeUnit;

/* compiled from: PG */
/* loaded from: classes2.dex */
final class aamb implements Runnable {
    final /* synthetic */ ajds a;
    final /* synthetic */ long b;
    final /* synthetic */ TimeUnit c;

    public aamb(ajds ajdsVar, long j, TimeUnit timeUnit) {
        this.a = ajdsVar;
        this.b = j;
        this.c = timeUnit;
    }

    /* JADX WARN: Removed duplicated region for block: B:9:0x0025  */
    @Override // java.lang.Runnable
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct code enable 'Show inconsistent code' option in preferences
    */
    public final void run() {
        /*
            r4 = this;
            android.app.ActivityManager$RunningAppProcessInfo r0 = new android.app.ActivityManager$RunningAppProcessInfo
            r0.<init>()
            r1 = 0
            android.app.ActivityManager.getMyMemoryState(r0)     // Catch: java.lang.RuntimeException -> L13
            int r2 = r0.importance
            int r0 = r0.importance
            r2 = 400(0x190, float:5.6E-43)
            if (r0 < r2) goto L1b
            r0 = 1
            goto L1c
        L13:
            r0 = move-exception
            java.lang.String r2 = "PhenotypeProcessReaper"
            java.lang.String r3 = "Failed to retrieve memory state, not killing process."
            android.util.Log.w(r2, r3, r0)
        L1b:
            r0 = r1
        L1c:
            java.lang.Boolean r2 = java.lang.Boolean.valueOf(r0)
            r2.getClass()
            if (r0 == 0) goto L2f
            int r0 = android.os.Process.myPid()
            android.os.Process.killProcess(r0)
            java.lang.System.exit(r1)
        L2f:
            cal.ajds r0 = r4.a
            long r1 = r4.b
            java.util.concurrent.TimeUnit r3 = r4.c
            cal.ajdq r0 = r0.e(r4, r1, r3)
            cal.aalx r1 = new cal.aalx
            r1.<init>(r0)
            cal.ajbw r2 = cal.ajbw.a
            r0.d(r1, r2)
            return
        */
        throw new UnsupportedOperationException("Method not decompiled: cal.aamb.run():void");
    }
}
