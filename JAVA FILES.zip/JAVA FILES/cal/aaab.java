package cal;

/* compiled from: PG */
/* loaded from: classes2.dex */
public interface aaab {
    void a(String str);
}
