package cal;

/* compiled from: PG */
/* loaded from: classes.dex */
abstract class aad {
    public abstract void bi(aaa aaaVar);
}
