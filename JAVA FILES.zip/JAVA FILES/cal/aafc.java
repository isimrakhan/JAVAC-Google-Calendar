package cal;

import android.os.SystemClock;
import j$.util.concurrent.ConcurrentHashMap;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.concurrent.atomic.AtomicInteger;

/* compiled from: PG */
/* loaded from: classes2.dex */
public final class aafc {
    public final AtomicInteger a = new AtomicInteger(0);
    public final Map c = new ConcurrentHashMap();
    public final ThreadLocal d = new aafb(this);
    public final List e = new ArrayList();
    public final aaet b = new aaet("", SystemClock.elapsedRealtime(), -1, Thread.currentThread().getId(), 2);
}
