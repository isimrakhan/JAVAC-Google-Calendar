package cal;

/* compiled from: PG */
/* loaded from: classes2.dex */
public final class aajp {
    public static final aajp a = new aajp(aikw.e);
    public final aiee b;

    public aajp(aiee aieeVar) {
        this.b = aieeVar;
    }

    public final boolean equals(Object obj) {
        if (obj instanceof aajp) {
            return this.b.equals(((aajp) obj).b);
        }
        return false;
    }

    public final int hashCode() {
        return ailm.a(this.b);
    }
}
