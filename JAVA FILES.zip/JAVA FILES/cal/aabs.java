package cal;

/* compiled from: PG */
/* loaded from: classes2.dex */
public class aabs implements zwh {
    @Override // cal.zwh
    public /* synthetic */ void u() {
        throw null;
    }
}
