package cal;

import android.content.Context;

/* compiled from: PG */
/* loaded from: classes2.dex */
public final class aarn implements aarm {
    public final Context a;
    public final aavv b;
    public final aqcw c;

    public aarn(Context context, aavv aavvVar, aqcw aqcwVar) {
        this.a = context;
        this.b = aavvVar;
        this.c = aqcwVar;
    }
}
