package cal;

import j$.util.Objects;

/* compiled from: PG */
/* loaded from: classes2.dex */
public final class aajo implements Comparable {
    public final long a;
    public final String b;
    public final int c;
    public final long d;
    public final Object e;

    public aajo(long j, String str, int i, long j2, Object obj) {
        boolean z;
        if (j != 0) {
            z = false;
        } else {
            z = true;
        }
        if (z == (str != null)) {
            this.a = j;
            this.b = str;
            this.c = i;
            this.d = j2;
            this.e = obj;
            return;
        }
        throw new IllegalArgumentException();
    }

    public final Object a() {
        int i = this.c;
        if (i != 0) {
            if (i != 1) {
                if (i != 2) {
                    if (i != 3) {
                        if (i != 4) {
                            if (i == 5) {
                                Object obj = this.e;
                                obj.getClass();
                                if (obj instanceof byte[]) {
                                    return (byte[]) obj;
                                }
                                amob amobVar = (amob) obj;
                                int d = amobVar.d();
                                if (d == 0) {
                                    return ampx.b;
                                }
                                byte[] bArr = new byte[d];
                                amobVar.e(bArr, 0, 0, d);
                                return bArr;
                            }
                            throw new AssertionError("Impossible, this was validated when parsed or created");
                        }
                        Object obj2 = this.e;
                        obj2.getClass();
                        return obj2;
                    }
                    return Double.valueOf(Double.longBitsToDouble(this.d));
                }
                return Long.valueOf(this.d);
            }
            return true;
        }
        return false;
    }

    @Override // java.lang.Comparable
    public final /* bridge */ /* synthetic */ int compareTo(Object obj) {
        aajo aajoVar = (aajo) obj;
        int compare = Long.compare(this.a, aajoVar.a);
        if (compare == 0) {
            if (this.a != 0) {
                return 0;
            }
            String str = this.b;
            str.getClass();
            String str2 = aajoVar.b;
            str2.getClass();
            return str.compareTo(str2);
        }
        return compare;
    }

    public final boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (!(obj instanceof aajo)) {
            return false;
        }
        aajo aajoVar = (aajo) obj;
        if (this.a == aajoVar.a && Objects.equals(this.b, aajoVar.b)) {
            return true;
        }
        return false;
    }

    public final int hashCode() {
        return Objects.hash(Long.valueOf(this.a), this.b);
    }

    public final String toString() {
        String str = this.b;
        if (str == null) {
            str = Long.toString(this.a);
        }
        return str + ":" + String.valueOf(a());
    }
}
