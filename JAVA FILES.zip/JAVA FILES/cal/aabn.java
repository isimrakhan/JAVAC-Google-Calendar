package cal;

/* compiled from: PG */
/* loaded from: classes2.dex */
public final class aabn {
    public static aabh a(apxs apxsVar) {
        aoaw aoawVar = (aoaw) apxsVar;
        Object obj = aoawVar.b;
        if (obj == aoaw.a) {
            obj = aoawVar.c();
        }
        return (aabh) obj;
    }
}
