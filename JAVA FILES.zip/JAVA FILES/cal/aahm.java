package cal;

/* compiled from: PG */
/* loaded from: classes2.dex */
public final class aahm {
    private final abh a;

    public aahm(abh abhVar) {
        this.a = abhVar;
    }

    /* JADX WARN: Removed duplicated region for block: B:11:0x002c A[RETURN] */
    /* JADX WARN: Removed duplicated region for block: B:13:0x002d  */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct code enable 'Show inconsistent code' option in preferences
    */
    public final java.lang.String a(android.net.Uri r3, java.lang.String r4, java.lang.String r5, java.lang.String r6) {
        /*
            r2 = this;
            r0 = 0
            if (r3 == 0) goto L8
            java.lang.String r4 = r3.toString()
            goto Lc
        L8:
            if (r4 != 0) goto Lc
            r3 = r0
            goto L2a
        Lc:
            cal.abh r3 = r2.a
            if (r4 != 0) goto L15
            int r4 = r3.e()
            goto L1d
        L15:
            int r1 = r4.hashCode()
            int r4 = r3.d(r4, r1)
        L1d:
            if (r4 < 0) goto L27
            java.lang.Object[] r3 = r3.e
            int r4 = r4 + r4
            int r4 = r4 + 1
            r3 = r3[r4]
            goto L28
        L27:
            r3 = r0
        L28:
            cal.abh r3 = (cal.abh) r3
        L2a:
            if (r3 != 0) goto L2d
            return r0
        L2d:
            if (r5 == 0) goto L33
            java.lang.String r6 = r5.concat(r6)
        L33:
            int r4 = r6.hashCode()
            int r4 = r3.d(r6, r4)
            if (r4 < 0) goto L44
            java.lang.Object[] r3 = r3.e
            int r4 = r4 + r4
            int r4 = r4 + 1
            r0 = r3[r4]
        L44:
            java.lang.String r0 = (java.lang.String) r0
            return r0
        */
        throw new UnsupportedOperationException("Method not decompiled: cal.aahm.a(android.net.Uri, java.lang.String, java.lang.String, java.lang.String):java.lang.String");
    }
}
