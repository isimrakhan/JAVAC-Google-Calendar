package cal;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

/* compiled from: PG */
/* loaded from: classes2.dex */
public final class aapn implements Serializable {
    private static final long serialVersionUID = 1;
    public final List a = new ArrayList();

    public final boolean equals(Object obj) {
        if (!(obj instanceof aapn)) {
            return false;
        }
        return ((aapn) obj).a.equals(this.a);
    }

    public final int hashCode() {
        return this.a.hashCode();
    }

    public final String toString() {
        StringBuilder sb = new StringBuilder();
        int i = 0;
        while (true) {
            List list = this.a;
            if (i < list.size()) {
                if (i > 0) {
                    sb.append("->");
                }
                sb.append(((aapm) list.get(i)).a.a);
                i++;
            } else {
                sb.append(" (leaf->root)");
                return sb.toString();
            }
        }
    }
}
