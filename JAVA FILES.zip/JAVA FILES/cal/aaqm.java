package cal;

import java.util.concurrent.Executor;

/* compiled from: PG */
/* loaded from: classes2.dex */
public final class aaqm implements AutoCloseable {
    private static final aimm c = aimm.h("com/google/android/libraries/social/connections/signalprovider/ContactSignalProviderImpl");
    public final Executor a;
    public final ahum b;

    public aaqm(Executor executor, ahum ahumVar) {
        this.a = executor;
        this.b = ahus.a(ahumVar);
    }

    @Override // java.lang.AutoCloseable
    public final void close() {
        try {
            ((aapz) this.b.a()).close();
        } catch (Exception e) {
            ((aimj) ((aimj) ((aimj) c.c()).j(e)).k("com/google/android/libraries/social/connections/signalprovider/ContactSignalProviderImpl", "close", 't', "ContactSignalProviderImpl.java")).s("Failed to close AppSearch loader.");
        }
    }
}
