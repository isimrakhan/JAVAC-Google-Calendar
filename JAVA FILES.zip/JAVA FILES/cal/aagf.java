package cal;

/* compiled from: PG */
/* loaded from: classes2.dex */
public final class aagf extends ampi implements amqu {
    public aagf() {
        super(aagg.a);
    }
}
