package cal;

import android.content.Context;
import android.os.Process;

/* compiled from: PG */
/* loaded from: classes2.dex */
final class aapg extends aapl {
    @Override // cal.aapl
    public final int a(Context context, aapk aapkVar) {
        if (aapkVar.a.getAuthority().lastIndexOf(64) >= 0 && agx.a(context, "android.permission.INTERACT_ACROSS_USERS", Process.myPid(), Process.myUid(), context.getPackageName()) == 0) {
            return 2;
        }
        return 3;
    }
}
