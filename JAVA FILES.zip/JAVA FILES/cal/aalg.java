package cal;

import java.util.Set;

/* compiled from: PG */
/* loaded from: classes2.dex */
public final /* synthetic */ class aalg implements ahum {
    public final /* synthetic */ aaic a;
    public final /* synthetic */ String b;
    public final /* synthetic */ boolean c;
    public final /* synthetic */ Set d;

    public /* synthetic */ aalg(aaic aaicVar, String str, boolean z, Set set) {
        this.a = aaicVar;
        this.b = str;
        this.c = z;
        this.d = set;
    }

    @Override // cal.ahum
    public final Object a() {
        return new aalk(this.a, this.b, this.c, this.d);
    }
}
