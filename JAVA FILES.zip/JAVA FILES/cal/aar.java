package cal;

import android.content.res.ColorStateList;
import android.graphics.Canvas;
import android.graphics.ColorFilter;
import android.graphics.Outline;
import android.graphics.Paint;
import android.graphics.PorterDuff;
import android.graphics.PorterDuffColorFilter;
import android.graphics.Rect;
import android.graphics.RectF;
import android.graphics.drawable.Drawable;

/* compiled from: PG */
/* loaded from: classes.dex */
public final class aar extends Drawable {
    public float a;
    public float b;
    public ColorStateList c;
    private final RectF e;
    private final Rect f;
    private PorterDuffColorFilter i;
    private ColorStateList j;
    private boolean g = false;
    private boolean h = true;
    private PorterDuff.Mode k = PorterDuff.Mode.SRC_IN;
    private final Paint d = new Paint(5);

    public aar(ColorStateList colorStateList, float f) {
        this.a = f;
        a(colorStateList);
        this.e = new RectF();
        this.f = new Rect();
    }

    public final void a(ColorStateList colorStateList) {
        if (colorStateList == null) {
            colorStateList = ColorStateList.valueOf(0);
        }
        this.c = colorStateList;
        this.d.setColor(colorStateList.getColorForState(getState(), this.c.getDefaultColor()));
    }

    public final void b(float f, boolean z, boolean z2) {
        if (f == this.b && this.g == z && this.h == z2) {
            return;
        }
        this.b = f;
        this.g = z;
        this.h = z2;
        c(null);
        invalidateSelf();
    }

    public final void c(Rect rect) {
        if (rect == null) {
            rect = getBounds();
        }
        this.e.set(rect.left, rect.top, rect.right, rect.bottom);
        this.f.set(rect);
        if (this.g) {
            float f = this.b;
            float f2 = this.a;
            boolean z = this.h;
            float f3 = f * 1.5f;
            double d = aas.a;
            if (z) {
                f3 = (float) (f3 + ((1.0d - aas.a) * f2));
            }
            float f4 = this.b;
            float f5 = this.a;
            if (this.h) {
                f4 = (float) (f4 + ((1.0d - aas.a) * f5));
            }
            this.f.inset((int) Math.ceil(f4), (int) Math.ceil(f3));
            this.e.set(this.f);
        }
    }

    @Override // android.graphics.drawable.Drawable
    public final void draw(Canvas canvas) {
        Paint paint = this.d;
        boolean z = false;
        if (this.i != null && paint.getColorFilter() == null) {
            paint.setColorFilter(this.i);
            z = true;
        }
        RectF rectF = this.e;
        float f = this.a;
        canvas.drawRoundRect(rectF, f, f, paint);
        if (z) {
            paint.setColorFilter(null);
        }
    }

    @Override // android.graphics.drawable.Drawable
    public final int getOpacity() {
        return -3;
    }

    @Override // android.graphics.drawable.Drawable
    public final void getOutline(Outline outline) {
        outline.setRoundRect(this.f, this.a);
    }

    @Override // android.graphics.drawable.Drawable
    public final boolean isStateful() {
        ColorStateList colorStateList = this.j;
        if (colorStateList == null || !colorStateList.isStateful()) {
            ColorStateList colorStateList2 = this.c;
            if ((colorStateList2 != null && colorStateList2.isStateful()) || super.isStateful()) {
                return true;
            }
            return false;
        }
        return true;
    }

    @Override // android.graphics.drawable.Drawable
    protected final void onBoundsChange(Rect rect) {
        super.onBoundsChange(rect);
        c(rect);
    }

    @Override // android.graphics.drawable.Drawable
    protected final boolean onStateChange(int[] iArr) {
        boolean z;
        PorterDuff.Mode mode;
        ColorStateList colorStateList = this.c;
        int colorForState = colorStateList.getColorForState(iArr, colorStateList.getDefaultColor());
        if (colorForState != this.d.getColor()) {
            z = true;
        } else {
            z = false;
        }
        if (z) {
            this.d.setColor(colorForState);
        }
        ColorStateList colorStateList2 = this.j;
        if (colorStateList2 != null && (mode = this.k) != null) {
            this.i = new PorterDuffColorFilter(colorStateList2.getColorForState(getState(), 0), mode);
            return true;
        }
        return z;
    }

    @Override // android.graphics.drawable.Drawable
    public final void setAlpha(int i) {
        this.d.setAlpha(i);
    }

    @Override // android.graphics.drawable.Drawable
    public final void setColorFilter(ColorFilter colorFilter) {
        this.d.setColorFilter(colorFilter);
    }

    @Override // android.graphics.drawable.Drawable
    public final void setTintList(ColorStateList colorStateList) {
        this.j = colorStateList;
        PorterDuff.Mode mode = this.k;
        PorterDuffColorFilter porterDuffColorFilter = null;
        if (colorStateList != null && mode != null) {
            porterDuffColorFilter = new PorterDuffColorFilter(colorStateList.getColorForState(getState(), 0), mode);
        }
        this.i = porterDuffColorFilter;
        invalidateSelf();
    }

    @Override // android.graphics.drawable.Drawable
    public final void setTintMode(PorterDuff.Mode mode) {
        this.k = mode;
        ColorStateList colorStateList = this.j;
        PorterDuffColorFilter porterDuffColorFilter = null;
        if (colorStateList != null && mode != null) {
            porterDuffColorFilter = new PorterDuffColorFilter(colorStateList.getColorForState(getState(), 0), mode);
        }
        this.i = porterDuffColorFilter;
        invalidateSelf();
    }
}
