package cal;

import android.os.SystemClock;
import j$.util.DesugarCollections;
import java.io.Closeable;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

/* compiled from: PG */
/* loaded from: classes2.dex */
public final class aaet implements Closeable {
    public static final aaet a = new aaet("", SystemClock.elapsedRealtime(), -1, Thread.currentThread().getId(), 3);
    String b;
    final long c;
    long d;
    final long e;
    public volatile List f;
    final int g = 1;
    final int h;

    public aaet(String str, long j, long j2, long j3, int i) {
        this.b = str;
        this.c = j;
        this.d = j2;
        this.e = j3;
        this.h = i;
        if (i == 1) {
            this.f = DesugarCollections.synchronizedList(new ArrayList());
        } else {
            this.f = Collections.emptyList();
        }
    }

    /* JADX INFO: Access modifiers changed from: package-private */
    public final void a(List list) {
        if (this.f == Collections.EMPTY_LIST) {
            this.f = new ArrayList();
        }
        if (this.f != null) {
            this.f.addAll(list);
        }
    }

    @Override // java.io.Closeable, java.lang.AutoCloseable
    public final void close() {
        aafj.a(this);
    }
}
