package cal;

/* compiled from: PG */
/* loaded from: classes2.dex */
public interface aard {
    void u(aaqz aaqzVar);
}
