package cal;

/* compiled from: PG */
/* loaded from: classes2.dex */
public final class aajh {
    public final boolean a;

    public aajh(aaji aajiVar) {
        aajiVar.a();
        this.a = false;
    }
}
