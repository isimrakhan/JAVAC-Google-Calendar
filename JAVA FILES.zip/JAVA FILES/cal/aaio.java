package cal;

import android.content.Context;

/* compiled from: PG */
/* loaded from: classes2.dex */
abstract class aaio {
    public abstract Context a();

    public abstract ahum b();
}
