package cal;

import android.content.Context;
import java.util.concurrent.Callable;

/* compiled from: PG */
/* loaded from: classes2.dex */
public final /* synthetic */ class aapf implements Callable {
    public final /* synthetic */ Context a;

    @Override // java.util.concurrent.Callable
    public final Object call() {
        String[] strArr = aapj.a;
        return this.a.getExternalCacheDirs();
    }
}
