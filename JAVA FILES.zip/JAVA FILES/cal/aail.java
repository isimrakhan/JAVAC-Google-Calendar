package cal;

import android.util.Base64;
import android.util.Log;
import com.google.protobuf.InvalidProtocolBufferException;
import com.google.protobuf.UninitializedMessageException;
import java.io.IOException;

/* compiled from: PG */
/* loaded from: classes2.dex */
public final class aail extends aaip {
    public aail(aain aainVar, String str, Object obj) {
        super(aainVar, str, obj, false);
    }

    @Override // cal.aaip
    public final Object a(Object obj) {
        byte byteValue;
        ampm ampmVar;
        String concat;
        if (obj instanceof String) {
            try {
                byte[] decode = Base64.decode((String) obj, 3);
                anym anymVar = anym.a;
                int length = decode.length;
                amov amovVar = amov.a;
                amrc amrcVar = amrc.a;
                ampm i = ampm.i(anymVar, decode, 0, length, amov.b);
                if (i != null && (byteValue = ((Byte) i.a(1, null)).byteValue()) != 1) {
                    if (byteValue != 0) {
                        boolean l = amrc.a.a(i.getClass()).l(i);
                        if (true != l) {
                            ampmVar = null;
                        } else {
                            ampmVar = i;
                        }
                        i.a(2, ampmVar);
                        if (l) {
                        }
                    }
                    throw new InvalidProtocolBufferException(new UninitializedMessageException().getMessage());
                }
                return (anym) i;
            } catch (IOException | IllegalArgumentException unused) {
            }
        }
        String str = this.b.d;
        if (str.isEmpty()) {
            concat = this.c;
        } else {
            concat = str.concat(this.c);
        }
        Log.e("PhenotypeFlag", a.r(obj, concat, "Invalid byte[] value for ", ": "));
        return null;
    }
}
