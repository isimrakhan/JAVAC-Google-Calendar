package cal;

import com.google.protobuf.InvalidProtocolBufferException;
import com.google.protobuf.UninitializedMessageException;
import java.io.IOException;
import java.io.InputStream;

/* compiled from: PG */
/* loaded from: classes2.dex */
public final class aakb extends ampm implements amqu {
    public static final aakb a;
    private static volatile amra d;
    public String b = "";
    public long c;
    private int e;

    static {
        aakb aakbVar = new aakb();
        a = aakbVar;
        aakbVar.ad &= Integer.MAX_VALUE;
        ampm.ac.put(aakb.class, aakbVar);
    }

    private aakb() {
    }

    public static aakb parseFrom(InputStream inputStream) {
        amof amoeVar;
        int i = amof.f;
        if (inputStream == null) {
            byte[] bArr = ampx.b;
            int length = bArr.length;
            amoeVar = new amoc(bArr, 0, 0);
            try {
                amoeVar.d(0);
            } catch (InvalidProtocolBufferException e) {
                throw new IllegalArgumentException(e);
            }
        } else {
            amoeVar = new amoe(inputStream, 4096);
        }
        amov amovVar = amov.a;
        amrc amrcVar = amrc.a;
        amov amovVar2 = amov.b;
        aakb aakbVar = new aakb();
        try {
            amrk a2 = amrc.a.a(aakbVar.getClass());
            amog amogVar = amoeVar.e;
            if (amogVar == null) {
                amogVar = new amog(amoeVar);
            }
            a2.h(aakbVar, amogVar, amovVar2);
            a2.f(aakbVar);
            Byte b = (byte) 1;
            b.getClass();
            return aakbVar;
        } catch (InvalidProtocolBufferException e2) {
            if (e2.a) {
                throw new InvalidProtocolBufferException(e2);
            }
            throw e2;
        } catch (UninitializedMessageException e3) {
            throw new InvalidProtocolBufferException(e3.getMessage());
        } catch (IOException e4) {
            if (e4.getCause() instanceof InvalidProtocolBufferException) {
                throw ((InvalidProtocolBufferException) e4.getCause());
            }
            throw new InvalidProtocolBufferException(e4);
        } catch (RuntimeException e5) {
            if (e5.getCause() instanceof InvalidProtocolBufferException) {
                throw ((InvalidProtocolBufferException) e5.getCause());
            }
            throw e5;
        }
    }

    @Override // cal.ampm
    public final Object a(int i, Object obj) {
        int i2 = i - 1;
        if (i2 != 0) {
            if (i2 != 2) {
                if (i2 != 3) {
                    if (i2 != 4) {
                        if (i2 != 5) {
                            if (i2 != 6) {
                                return null;
                            }
                            amra amraVar = d;
                            if (amraVar == null) {
                                synchronized (aakb.class) {
                                    amraVar = d;
                                    if (amraVar == null) {
                                        amraVar = new amph(a);
                                        d = amraVar;
                                    }
                                }
                            }
                            return amraVar;
                        }
                        return a;
                    }
                    return new aaka();
                }
                return new aakb();
            }
            return new amre(a, "\u0004\u0002\u0000\u0001\u0001\u0002\u0002\u0000\u0000\u0000\u0001ဈ\u0000\u0002ဂ\u0001", new Object[]{"e", "b", "c"});
        }
        return (byte) 1;
    }
}
