package cal;

import java.util.concurrent.TimeUnit;

/* JADX INFO: Access modifiers changed from: package-private */
/* compiled from: PG */
/* loaded from: classes2.dex */
public final class aaaj implements ztq {
    final /* synthetic */ ajds a;
    final /* synthetic */ aaal b;

    public aaaj(aaal aaalVar, ajds ajdsVar) {
        this.a = ajdsVar;
        this.b = aaalVar;
    }

    @Override // cal.ztq
    public final void i(final zry zryVar) {
        this.b.b.a(3, zryVar.a);
        this.b.a();
        this.b.d = this.a.e(new Runnable() { // from class: cal.aaah
            @Override // java.lang.Runnable
            public final void run() {
                aaaj.this.b.b.a(5, zryVar.a);
            }
        }, 10L, TimeUnit.SECONDS);
    }

    @Override // cal.ztq
    public final void j(final zry zryVar) {
        this.b.b.a(4, zryVar.a);
        this.b.a();
        this.b.c = this.a.e(new Runnable() { // from class: cal.aaai
            @Override // java.lang.Runnable
            public final void run() {
                aaaj.this.b.b.a(6, zryVar.a);
            }
        }, 10L, TimeUnit.SECONDS);
    }
}
