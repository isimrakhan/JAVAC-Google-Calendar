package cal;

/* compiled from: PG */
/* loaded from: classes2.dex */
public final /* synthetic */ class aamy implements aamz {
    public final /* synthetic */ Class a;

    @Override // cal.aamz
    public final Object a(Object obj) {
        return (String) this.a.cast(obj);
    }
}
