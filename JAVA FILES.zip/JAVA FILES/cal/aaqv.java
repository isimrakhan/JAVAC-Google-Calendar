package cal;

import java.util.Collections;
import java.util.Set;
import java.util.WeakHashMap;

/* compiled from: PG */
/* loaded from: classes2.dex */
public final class aaqv {
    public static final Set a = Collections.newSetFromMap(new WeakHashMap());
    public static int b = -1;
}
