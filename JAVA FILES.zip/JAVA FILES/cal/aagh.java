package cal;

import android.content.Context;

/* compiled from: PG */
/* loaded from: classes2.dex */
public interface aagh {
    ajdo a(Context context, aagg aaggVar);
}
