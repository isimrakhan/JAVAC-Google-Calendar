package cal;

import android.content.pm.PackageManager;
import android.content.res.Resources;
import com.google.protobuf.InvalidProtocolBufferException;
import java.io.IOException;
import java.io.InputStream;

/* compiled from: PG */
/* loaded from: classes2.dex */
public final class aaof {
    public final String a;
    public final ahum b;
    final /* synthetic */ aaog c;

    public aaof(aaog aaogVar, String str, final int i, final int i2) {
        this.c = aaogVar;
        this.a = str;
        this.b = new aaoc(new ahum() { // from class: cal.aaoe
            @Override // cal.ahum
            public final Object a() {
                int i3;
                ajwa ajwaVar = ajwa.a;
                ajvy ajvyVar = new ajvy();
                aaof aaofVar = aaof.this;
                int i4 = i;
                try {
                    aaog aaogVar2 = aaofVar.c;
                    Resources resources = aaogVar2.d;
                    if (resources == null) {
                        resources = aaogVar2.e.a.getResourcesForApplication(aaogVar2.a);
                        aaogVar2.d = resources;
                    }
                    if (resources == null) {
                        return null;
                    }
                    aaofVar.a(ajvyVar, resources, i4);
                    long longValue = ((Long) aaofVar.c.b.a()).longValue();
                    if ((ajvyVar.b.ad & Integer.MIN_VALUE) == 0) {
                        ajvyVar.s();
                    }
                    ajwa ajwaVar2 = (ajwa) ajvyVar.b;
                    ajwaVar2.c |= 128;
                    ajwaVar2.o = longValue;
                    String str2 = ajwaVar2.h;
                    int indexOf = str2.indexOf(35);
                    if (indexOf >= 0) {
                        str2 = str2.substring(0, indexOf);
                    }
                    String str3 = aaofVar.a;
                    if (str2.equals(str3)) {
                        ajwa ajwaVar3 = (ajwa) ajvyVar.b;
                        String str4 = ajwaVar3.h;
                        aaog aaogVar3 = aaofVar.c;
                        boolean z = ajwaVar3.i;
                        if (!str4.isEmpty()) {
                            if (z) {
                                if (str4.indexOf(35) < 0) {
                                    str4 = str4 + "#" + aaogVar3.a;
                                } else {
                                    throw new IllegalArgumentException(String.format("When %s is present, %s should not contain subpackage separator %s (config package=%s)", "auto-subpackage", "configuration-package", '#', str4));
                                }
                            }
                            if (((ajwa) ajvyVar.b).d != 2) {
                                Integer num = (Integer) aaofVar.c.c.a();
                                num.intValue();
                                if ((ajvyVar.b.ad & Integer.MIN_VALUE) == 0) {
                                    ajvyVar.s();
                                }
                                ajwa ajwaVar4 = (ajwa) ajvyVar.b;
                                ajwaVar4.d = 2;
                                ajwaVar4.e = num;
                            }
                            if ((ajvyVar.b.ad & Integer.MIN_VALUE) == 0) {
                                ajvyVar.s();
                            }
                            ajwa ajwaVar5 = (ajwa) ajvyVar.b;
                            str4.getClass();
                            ajwaVar5.c |= 1;
                            ajwaVar5.h = str4;
                            aaog aaogVar4 = aaofVar.c;
                            if ((ajvyVar.b.ad & Integer.MIN_VALUE) == 0) {
                                ajvyVar.s();
                            }
                            String str5 = aaogVar4.a;
                            ajwa ajwaVar6 = (ajwa) ajvyVar.b;
                            str5.getClass();
                            ajwaVar6.f = 7;
                            ajwaVar6.g = str5;
                            if ((ajvyVar.b.ad & Integer.MIN_VALUE) == 0) {
                                ajvyVar.s();
                            }
                            int i5 = i2;
                            ajwa ajwaVar7 = (ajwa) ajvyVar.b;
                            ajwaVar7.n = 3;
                            ajwaVar7.c |= 32;
                            if (i5 == 0) {
                                return (ajwa) ajvyVar.p();
                            }
                            aaoa aaoaVar = aaoa.a;
                            aanz aanzVar = new aanz();
                            aaofVar.a(aanzVar, resources, i5);
                            boolean equals = ((aaoa) aanzVar.b).d.equals(aaofVar.a);
                            String str6 = ((aaoa) aanzVar.b).d;
                            String str7 = aaofVar.a;
                            if (equals) {
                                if ((aanzVar.b.ad & Integer.MIN_VALUE) == 0) {
                                    aanzVar.s();
                                }
                                aaoa aaoaVar2 = (aaoa) aanzVar.b;
                                aaoaVar2.c &= -2;
                                aaoaVar2.d = aaoa.a.d;
                                aaoa aaoaVar3 = (aaoa) aanzVar.p();
                                try {
                                    int i6 = aaoaVar3.ad;
                                    if ((i6 & Integer.MIN_VALUE) != 0) {
                                        i3 = amrc.a.a(aaoaVar3.getClass()).a(aaoaVar3);
                                        if (i3 < 0) {
                                            throw new IllegalStateException(a.f(i3, "serialized size must be non-negative, was "));
                                        }
                                    } else {
                                        i3 = i6 & Integer.MAX_VALUE;
                                        if (i3 == Integer.MAX_VALUE) {
                                            i3 = amrc.a.a(aaoaVar3.getClass()).a(aaoaVar3);
                                            if (i3 >= 0) {
                                                aaoaVar3.ad = (aaoaVar3.ad & Integer.MIN_VALUE) | i3;
                                            } else {
                                                throw new IllegalStateException(a.f(i3, "serialized size must be non-negative, was "));
                                            }
                                        }
                                    }
                                    amob amobVar = amob.b;
                                    byte[] bArr = new byte[i3];
                                    amoi amoiVar = new amoi(bArr, 0, i3);
                                    amrk a = amrc.a.a(aaoaVar3.getClass());
                                    amol amolVar = amoiVar.g;
                                    if (amolVar == null) {
                                        amolVar = new amol(amoiVar);
                                    }
                                    a.j(aaoaVar3, amolVar);
                                    if (amoiVar.a - amoiVar.b == 0) {
                                        amnz amnzVar = new amnz(bArr);
                                        if ((ajvyVar.b.ad & Integer.MIN_VALUE) == 0) {
                                            ajvyVar.s();
                                        }
                                        ajwa ajwaVar8 = (ajwa) ajvyVar.b;
                                        ajwaVar8.c |= 256;
                                        ajwaVar8.p = amnzVar;
                                        return (ajwa) ajvyVar.p();
                                    }
                                    throw new IllegalStateException("Did not write as much data as expected.");
                                } catch (IOException e) {
                                    throw new RuntimeException(a.t(aaoaVar3, " to a ByteString threw an IOException (should never happen)."), e);
                                }
                            }
                            throw new IllegalStateException(ahul.a("Package in HeterodyneInfo binary %s does not match resource lookup for %s", str6, str7));
                        }
                        throw new IllegalArgumentException("Empty configuration package");
                    }
                    throw new IllegalStateException(ahul.a("Resource package does not match expected package, expected package: %s", str3));
                } catch (PackageManager.NameNotFoundException | IOException | NullPointerException unused) {
                    return null;
                }
            }
        });
    }

    public final void a(amqs amqsVar, Resources resources, int i) {
        amof amoeVar;
        amov amovVar;
        InputStream openRawResource = resources.openRawResource(i);
        try {
            this.c.e.c++;
            int max = Math.max(512, Math.min(4096, openRawResource.available()));
            int i2 = amof.f;
            if (max > 0) {
                if (openRawResource == null) {
                    byte[] bArr = ampx.b;
                    int length = bArr.length;
                    amoeVar = new amoc(bArr, 0, 0);
                    try {
                        amoeVar.d(0);
                    } catch (InvalidProtocolBufferException e) {
                        throw new IllegalArgumentException(e);
                    }
                } else {
                    amoeVar = new amoe(openRawResource, max);
                }
                amov amovVar2 = amov.a;
                if (amovVar2 == null) {
                    synchronized (amov.class) {
                        amovVar = amov.a;
                        if (amovVar == null) {
                            amrc amrcVar = amrc.a;
                            amovVar = ampe.b(amov.class);
                            amov.a = amovVar;
                        }
                    }
                    amovVar2 = amovVar;
                }
                amqsVar.j(amoeVar, amovVar2);
                if (openRawResource != null) {
                    openRawResource.close();
                    return;
                }
                return;
            }
            throw new IllegalArgumentException("bufferSize must be > 0");
        } catch (Throwable th) {
            if (openRawResource != null) {
                try {
                    openRawResource.close();
                } catch (Throwable th2) {
                    th.addSuppressed(th2);
                }
            }
            throw th;
        }
    }
}
