package cal;

/* compiled from: PG */
/* loaded from: classes.dex */
public final class aag {
    public Integer a;
}
