package cal;

import android.content.ComponentName;

/* compiled from: PG */
/* loaded from: classes.dex */
public final class aan {
    public final af a;
    public final ComponentName b;

    public aan(af afVar, ComponentName componentName) {
        this.a = afVar;
        this.b = componentName;
    }
}
