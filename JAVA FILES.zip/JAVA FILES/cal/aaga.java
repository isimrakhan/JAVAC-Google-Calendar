package cal;

import java.util.Random;

/* compiled from: PG */
/* loaded from: classes2.dex */
public final class aaga {
    static final aagb a = new aafy(aqwl.a, true);
    private final Random b;
    private final aizu c;
    private final aafl d;

    public aaga(Random random, aafl aaflVar, aizu aizuVar) {
        this.b = random;
        this.c = aizuVar;
        this.d = aaflVar;
    }

    public final aagb a(aqwl aqwlVar) {
        int a2 = aqwk.a(aqwlVar.e);
        boolean z = true;
        if (a2 == 0) {
            a2 = 1;
        }
        int i = a2 - 1;
        if (i != 1) {
            if (i != 3) {
                if (i != 4) {
                    if (i == 5) {
                        aqwlVar = aqwl.a;
                    }
                    return new aafy(aqwlVar, true);
                }
                Random random = this.b;
                aafl aaflVar = this.d;
                aaflVar.getClass();
                return new aafz(aqwlVar, random, aaflVar, this.c);
            }
            if (this.b.nextDouble() * 1000.0d >= aqwlVar.d) {
                z = false;
            }
            return new aafy(aqwlVar, z);
        }
        if (aqwlVar.d != 1000) {
            z = false;
        }
        return new aafy(aqwlVar, z);
    }
}
