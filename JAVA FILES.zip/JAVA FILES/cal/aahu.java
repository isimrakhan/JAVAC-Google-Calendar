package cal;

import android.content.Context;

/* compiled from: PG */
/* loaded from: classes2.dex */
public final /* synthetic */ class aahu implements ahum {
    public final /* synthetic */ Context a;

    public /* synthetic */ aahu(Context context) {
        this.a = context;
    }

    @Override // cal.ahum
    public final Object a() {
        aaia aaiaVar = new aaia();
        aaiaVar.a = this.a;
        return aaiaVar.a();
    }
}
