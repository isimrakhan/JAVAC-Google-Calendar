package cal;

import android.content.Context;
import com.google.android.libraries.phenotype.client.PhenotypeContextTestMode$FirstFlagReadHere;
import java.util.concurrent.Executor;
import java.util.concurrent.Executors;
import java.util.concurrent.ScheduledExecutorService;
import java.util.concurrent.ThreadFactory;
import java.util.logging.Level;

/* compiled from: PG */
/* loaded from: classes2.dex */
public final class aaic {
    public static Context a;
    private static volatile aaic m;
    private static volatile aaic n;
    public final aakr c = new aakx();
    public final Context d;
    public final ahum e;
    public final ahum f;
    public final ahum g;
    public final ahum h;
    public final aany i;
    public final ahum j;
    public final aama k;
    private static final Object l = new Object();
    public static final ahum b = ahus.a(new ahum() { // from class: cal.aaht
        @Override // cal.ahum
        public final Object a() {
            ScheduledExecutorService newSingleThreadScheduledExecutor = Executors.newSingleThreadScheduledExecutor(new ThreadFactory() { // from class: cal.aahx
                @Override // java.util.concurrent.ThreadFactory
                public final Thread newThread(Runnable runnable) {
                    return new Thread(runnable, "ProcessStablePhenotypeFlag");
                }
            });
            if (newSingleThreadScheduledExecutor instanceof ajds) {
                return (ajds) newSingleThreadScheduledExecutor;
            }
            return new ajdx(newSingleThreadScheduledExecutor);
        }
    });

    public aaic(Context context, ahum ahumVar, ahum ahumVar2, ahum ahumVar3, ahum ahumVar4, ahum ahumVar5) {
        Context applicationContext = context.getApplicationContext();
        applicationContext.getClass();
        ahumVar.getClass();
        ahumVar2.getClass();
        ahumVar3.getClass();
        ahumVar4.getClass();
        ahumVar5.getClass();
        ahum a2 = ahus.a(ahumVar);
        ahum a3 = ahus.a(ahumVar2);
        ahum a4 = ahus.a(ahumVar3);
        ahum a5 = ahus.a(ahumVar4);
        ahum a6 = ahus.a(ahumVar5);
        this.d = applicationContext;
        this.e = a2;
        this.f = a3;
        this.g = a4;
        this.h = a5;
        this.i = new aany(applicationContext, a2, a5, a3);
        this.j = a6;
        this.k = new aama(a4, a3);
    }

    public static aaic a() {
        aaid.c = true;
        if (aaid.d == null) {
            aaid.d = new PhenotypeContextTestMode$FirstFlagReadHere();
        }
        Context context = a;
        if (context != null) {
            return b(context);
        }
        synchronized (aaid.a) {
        }
        throw new IllegalStateException("Must call PhenotypeContext.setContext() first");
    }

    /* JADX WARN: Multi-variable type inference failed */
    public static aaic b(Context context) {
        boolean z;
        aaic aaicVar = m;
        if (aaicVar != null) {
            return aaicVar;
        }
        Context applicationContext = context.getApplicationContext();
        try {
            ((aaib) afvg.a(applicationContext, aaib.class)).bd();
            z = true;
        } catch (IllegalStateException unused) {
            z = false;
        }
        synchronized (l) {
            if (m != null) {
                return m;
            }
            boolean z2 = applicationContext instanceof aaib;
            if (z2) {
                ((aaib) applicationContext).bd();
            }
            Context context2 = new aahu(applicationContext).a;
            aaia aaiaVar = new aaia();
            aaiaVar.a = context2;
            aaic a2 = aaiaVar.a();
            m = a2;
            if (!z && !z2) {
                ((ajds) a2.e.a()).execute(afwy.a(new aaiq(Level.CONFIG, null, "Application doesn't implement PhenotypeApplication interface, falling back to globally set context. See go/phenotype-flag#process-stable-init for more info.", new Object[0])));
            }
            return a2;
        }
    }

    public static void c(Context context) {
        synchronized (l) {
            if (a != null) {
                return;
            }
            try {
                a = context.getApplicationContext();
            } catch (NullPointerException unused) {
                synchronized (aaid.a) {
                    if (a == null && aaid.b == null) {
                        aaid.b = new PhenotypeContextTestMode$FirstFlagReadHere();
                    }
                    ((Executor) b.a()).execute(afwy.a(new aaiq(Level.WARNING, null, "context.getApplicationContext() yielded NullPointerException", new Object[0])));
                }
            }
        }
    }
}
