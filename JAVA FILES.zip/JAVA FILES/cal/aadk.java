package cal;

/* compiled from: PG */
/* loaded from: classes2.dex */
public final class aadk extends aadp {
    public final int a = 5;
    public final aick b;
    public final int c;

    public aadk(int i, int i2, aick aickVar) {
        this.c = i;
        this.b = aickVar;
    }

    @Override // cal.aadp
    public final int c() {
        return 5;
    }

    @Override // cal.aadp
    public final aick d() {
        return this.b;
    }

    @Override // cal.aadp
    public final int e() {
        return this.c;
    }

    public final boolean equals(Object obj) {
        if (obj == this) {
            return true;
        }
        if (obj instanceof aadp) {
            aadp aadpVar = (aadp) obj;
            if (this.c == aadpVar.e()) {
                aadpVar.c();
                if (aiga.e(this.b, aadpVar.d())) {
                    aadpVar.f();
                    return true;
                }
            }
        }
        return false;
    }

    public final int hashCode() {
        return ((((((this.c ^ 1000003) * 1000003) ^ 5) * 1000003) ^ this.b.hashCode()) * 1000003) ^ 1237;
    }

    public final String toString() {
        String str;
        if (this.c != 2) {
            str = "EXPLICITLY_ENABLED";
        } else {
            str = "EXPLICITLY_DISABLED";
        }
        return "DirStatsConfigurations{enablement=" + str + ", maxFolderDepth=5, listPathMatchers=" + String.valueOf(this.b) + ", includeDeviceEncryptedStorage=false}";
    }

    @Override // cal.aadp
    public final void f() {
    }
}
