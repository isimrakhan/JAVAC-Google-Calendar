package cal;

import java.util.concurrent.Executor;

/* compiled from: PG */
/* loaded from: classes2.dex */
public final /* synthetic */ class aafu implements Runnable {
    public final /* synthetic */ aafw a;
    public final /* synthetic */ anyt b;
    public final /* synthetic */ Executor c;

    public /* synthetic */ aafu(aafw aafwVar, anyt anytVar, Executor executor) {
        this.a = aafwVar;
        this.b = anytVar;
        this.c = executor;
    }

    @Override // java.lang.Runnable
    public final void run() {
        this.c.execute(new aafv(this.a, this.b));
    }
}
