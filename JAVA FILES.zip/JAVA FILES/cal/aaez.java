package cal;

/* compiled from: PG */
/* loaded from: classes2.dex */
public abstract class aaez implements zun {
    @Override // cal.zun
    public final /* synthetic */ int a() {
        return Integer.MAX_VALUE;
    }

    @Override // cal.zun
    public final boolean b() {
        if (d() == 3) {
            return true;
        }
        return false;
    }

    public abstract float c();

    public abstract int d();
}
