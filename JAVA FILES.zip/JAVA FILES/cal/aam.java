package cal;

import android.content.ComponentName;
import android.content.Context;
import android.content.ServiceConnection;
import android.os.IBinder;
import android.os.IInterface;

/* compiled from: PG */
/* loaded from: classes.dex */
public abstract class aam implements ServiceConnection {
    public Context a;

    public abstract void a(aai aaiVar);

    @Override // android.content.ServiceConnection
    public final void onServiceConnected(ComponentName componentName, IBinder iBinder) {
        ai agVar;
        if (this.a != null) {
            int i = ah.a;
            if (iBinder == null) {
                agVar = null;
            } else {
                IInterface queryLocalInterface = iBinder.queryLocalInterface(ah.b);
                if (queryLocalInterface != null && (queryLocalInterface instanceof ai)) {
                    agVar = (ai) queryLocalInterface;
                } else {
                    agVar = new ag(iBinder);
                }
            }
            a(new aal(agVar, componentName));
            return;
        }
        throw new IllegalStateException("Custom Tabs Service connected before an applicationcontext has been provided.");
    }
}
