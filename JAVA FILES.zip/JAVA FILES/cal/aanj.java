package cal;

/* compiled from: PG */
/* loaded from: classes2.dex */
abstract class aanj {
    public abstract aick a();

    public abstract aick b();

    public abstract amob c();

    public abstract String d();

    public abstract String e();

    public abstract boolean f();

    public abstract boolean g();
}
