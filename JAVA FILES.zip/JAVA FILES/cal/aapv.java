package cal;

import java.util.Map;

/* compiled from: PG */
/* loaded from: classes2.dex */
public final class aapv {
    public final Map a;
    private final aaqq b;

    public aapv(aaqq aaqqVar, Map map) {
        this.b = aaqqVar;
        this.a = map;
    }

    public final boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (!(obj instanceof aapv)) {
            return false;
        }
        aapv aapvVar = (aapv) obj;
        if (this.b.equals(aapvVar.b) && this.a.equals(aapvVar.a)) {
            return true;
        }
        return false;
    }

    public final int hashCode() {
        long j = this.b.a;
        return (((int) (j ^ (j >>> 32))) * 31) + this.a.hashCode();
    }

    public final String toString() {
        return "ContactSignalResult(queryTime=" + this.b + ", contactSignals=" + this.a + ")";
    }
}
