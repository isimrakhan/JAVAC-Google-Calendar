package cal;

import android.os.Handler;
import android.os.SystemClock;
import android.view.View;
import android.view.ViewTreeObserver;
import com.google.android.libraries.stitch.util.ThreadUtil$CalledOnWrongThreadException;
import java.util.concurrent.atomic.AtomicReference;

/* compiled from: PG */
/* loaded from: classes2.dex */
final class aacx implements ViewTreeObserver.OnPreDrawListener {
    final /* synthetic */ aacy a;
    private final AtomicReference b;

    public aacx(aacy aacyVar, View view) {
        this.a = aacyVar;
        this.b = new AtomicReference(view);
    }

    @Override // android.view.ViewTreeObserver.OnPreDrawListener
    public final boolean onPreDraw() {
        View view = (View) this.b.getAndSet(null);
        if (view != null) {
            try {
                view.getViewTreeObserver().removeOnPreDrawListener(this);
                Handler a = abyh.a();
                final aacy aacyVar = this.a;
                a.postAtFrontOfQueue(new Runnable() { // from class: cal.aacv
                    @Override // java.lang.Runnable
                    public final void run() {
                        if (abyh.b(Thread.currentThread())) {
                            aacy aacyVar2 = aacy.this;
                            if (aacyVar2.b.p != null) {
                                return;
                            }
                            aacyVar2.b.p = new zvs(SystemClock.elapsedRealtime(), SystemClock.uptimeMillis());
                            return;
                        }
                        throw new ThreadUtil$CalledOnWrongThreadException("Must be called on the main thread");
                    }
                });
                final aacy aacyVar2 = this.a;
                abyh.a().post(new Runnable() { // from class: cal.aacw
                    @Override // java.lang.Runnable
                    public final void run() {
                        if (abyh.b(Thread.currentThread())) {
                            aacy aacyVar3 = aacy.this;
                            if (aacyVar3.b.o != null) {
                                return;
                            }
                            aacyVar3.b.o = new zvs(SystemClock.elapsedRealtime(), SystemClock.uptimeMillis());
                            return;
                        }
                        throw new ThreadUtil$CalledOnWrongThreadException("Must be called on the main thread");
                    }
                });
                return true;
            } catch (RuntimeException unused) {
                return true;
            }
        }
        return true;
    }
}
