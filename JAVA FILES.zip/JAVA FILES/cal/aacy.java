package cal;

import android.R;
import android.app.Activity;
import android.app.Application;
import android.os.Bundle;
import android.os.SystemClock;
import android.view.View;
import android.view.ViewTreeObserver;

/* compiled from: PG */
/* loaded from: classes2.dex */
public final class aacy implements Application.ActivityLifecycleCallbacks {
    public final Application a;
    final /* synthetic */ aacz b;

    public aacy(aacz aaczVar, Application application) {
        this.b = aaczVar;
        this.a = application;
    }

    @Override // android.app.Application.ActivityLifecycleCallbacks
    public final void onActivityCreated(Activity activity, Bundle bundle) {
        aacq aacqVar;
        if (this.b.s.b == null) {
            aacqVar = this.b.s;
        } else {
            aacqVar = this.b.t;
        }
        aacqVar.a = activity.getClass().getSimpleName();
        aacqVar.b = new zvs(SystemClock.elapsedRealtime(), SystemClock.uptimeMillis());
    }

    @Override // android.app.Application.ActivityLifecycleCallbacks
    public final void onActivityResumed(Activity activity) {
        aacq aacqVar;
        if (this.b.t.b == null) {
            aacqVar = this.b.s;
        } else {
            aacqVar = this.b.t;
        }
        if (aacqVar.d == null) {
            aacqVar.d = new zvs(SystemClock.elapsedRealtime(), SystemClock.uptimeMillis());
        }
        try {
            View findViewById = activity.findViewById(R.id.content);
            ViewTreeObserver viewTreeObserver = findViewById.getViewTreeObserver();
            viewTreeObserver.addOnDrawListener(new aacu(this, findViewById));
            viewTreeObserver.addOnPreDrawListener(new aacx(this, findViewById));
        } catch (RuntimeException unused) {
        }
    }

    @Override // android.app.Application.ActivityLifecycleCallbacks
    public final void onActivityStarted(Activity activity) {
        aacq aacqVar;
        if (this.b.t.b == null) {
            aacqVar = this.b.s;
        } else {
            aacqVar = this.b.t;
        }
        if (aacqVar.c == null) {
            aacqVar.c = new zvs(SystemClock.elapsedRealtime(), SystemClock.uptimeMillis());
        }
    }

    @Override // android.app.Application.ActivityLifecycleCallbacks
    public final void onActivityDestroyed(Activity activity) {
    }

    @Override // android.app.Application.ActivityLifecycleCallbacks
    public final void onActivityPaused(Activity activity) {
    }

    @Override // android.app.Application.ActivityLifecycleCallbacks
    public final void onActivityStopped(Activity activity) {
    }

    @Override // android.app.Application.ActivityLifecycleCallbacks
    public final void onActivitySaveInstanceState(Activity activity, Bundle bundle) {
    }
}
