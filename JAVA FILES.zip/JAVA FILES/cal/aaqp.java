package cal;

/* compiled from: PG */
/* loaded from: classes2.dex */
public final class aaqp implements Comparable {
    public final long a;

    public aaqp(long j) {
        this.a = j;
    }

    @Override // java.lang.Comparable
    public final /* synthetic */ int compareTo(Object obj) {
        aaqp aaqpVar = (aaqp) obj;
        aaqpVar.getClass();
        long j = this.a;
        long j2 = aaqpVar.a;
        if (j < j2) {
            return -1;
        }
        if (j != j2) {
            return 1;
        }
        return 0;
    }

    public final boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if ((obj instanceof aaqp) && this.a == ((aaqp) obj).a) {
            return true;
        }
        return false;
    }

    public final int hashCode() {
        long j = this.a;
        return (int) (j ^ (j >>> 32));
    }

    public final String toString() {
        return "Duration(millis=" + this.a + ")";
    }
}
