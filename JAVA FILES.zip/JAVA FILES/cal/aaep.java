package cal;

import java.util.List;

/* compiled from: PG */
/* loaded from: classes2.dex */
public interface aaep {
    List a();
}
