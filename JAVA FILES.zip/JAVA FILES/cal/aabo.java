package cal;

/* compiled from: PG */
/* loaded from: classes2.dex */
public final class aabo extends aabq {
    public int a;
    public int b;
    public int c;
    public int d;
    public aick e;
    public byte f;
    public int g;

    @Override // cal.aabq
    public final aabr a() {
        aick aickVar;
        int i;
        if (this.f == 15 && (aickVar = this.e) != null && (i = this.g) != 0) {
            return new aabp(this.a, this.b, this.c, this.d, aickVar, i);
        }
        StringBuilder sb = new StringBuilder();
        if ((this.f & 1) == 0) {
            sb.append(" initialMonitoringDelayMs");
        }
        if ((this.f & 2) == 0) {
            sb.append(" checkForResponseIntervalMs");
        }
        if ((this.f & 4) == 0) {
            sb.append(" midStallCheckForResponseIntervalMs");
        }
        if ((this.f & 8) == 0) {
            sb.append(" postToMainIntervalMs");
        }
        if (this.e == null) {
            sb.append(" stallThresholdsMs");
        }
        if (this.g == 0) {
            sb.append(" enablement");
        }
        throw new IllegalStateException("Missing required properties:".concat(sb.toString()));
    }
}
