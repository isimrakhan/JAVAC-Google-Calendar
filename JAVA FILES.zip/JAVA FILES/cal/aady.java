package cal;

/* compiled from: PG */
/* loaded from: classes2.dex */
public final class aady extends aaed {
    public final float a;
    private final int b;
    private final ahti c;
    private final int d;

    public aady(int i, int i2, float f, ahti ahtiVar) {
        this.d = i;
        this.b = i2;
        this.a = f;
        this.c = ahtiVar;
    }

    @Override // cal.aaed, cal.zun
    public final int a() {
        return this.b;
    }

    @Override // cal.aaed
    public final float c() {
        return this.a;
    }

    @Override // cal.aaed
    public final ahti d() {
        return this.c;
    }

    @Override // cal.aaed
    public final int e() {
        return this.d;
    }

    public final boolean equals(Object obj) {
        if (obj == this) {
            return true;
        }
        if (obj instanceof aaed) {
            aaed aaedVar = (aaed) obj;
            if (this.d == aaedVar.e() && this.b == aaedVar.a() && Float.floatToIntBits(this.a) == Float.floatToIntBits(aaedVar.c())) {
                if (aaedVar.d() == this.c) {
                    return true;
                }
            }
        }
        return false;
    }

    public final int hashCode() {
        return ((((((this.d ^ 1000003) * 1000003) ^ this.b) * 1000003) ^ Float.floatToIntBits(this.a)) * 1000003) ^ 2040732332;
    }

    public final String toString() {
        String str;
        int i = this.d;
        if (i != 1) {
            if (i != 2) {
                str = "EXPLICITLY_ENABLED";
            } else {
                str = "EXPLICITLY_DISABLED";
            }
        } else {
            str = "DEFAULT";
        }
        return "TimerConfigurations{enablement=" + str + ", rateLimitPerSecond=" + this.b + ", samplingProbability=" + this.a + ", perEventConfigurationFlags=" + String.valueOf(this.c) + "}";
    }
}
