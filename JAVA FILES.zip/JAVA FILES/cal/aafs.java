package cal;

import android.os.SystemClock;

/* compiled from: PG */
/* loaded from: classes2.dex */
public final class aafs {
    public final apxs a;
    private final Object b = new Object();
    private int c = 0;
    private long d = 0;

    public aafs(apxs apxsVar) {
        this.a = apxsVar;
    }

    public final void a() {
        long elapsedRealtime = SystemClock.elapsedRealtime();
        synchronized (this.b) {
            this.c++;
            if (elapsedRealtime - this.d > 1000) {
                this.c = 0;
                this.d = elapsedRealtime;
            }
        }
    }

    public final boolean b(int i) {
        if (i == 0) {
            return true;
        }
        if (i == Integer.MAX_VALUE) {
            return false;
        }
        synchronized (this.b) {
            if (this.c < i) {
                return false;
            }
            long j = this.d;
            if (SystemClock.elapsedRealtime() - j <= 1000) {
                return true;
            }
            return false;
        }
    }
}
