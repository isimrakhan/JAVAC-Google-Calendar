package cal;

/* compiled from: PG */
/* loaded from: classes2.dex */
public final class aaoq {
    public static String a;
    public static Boolean b;
}
