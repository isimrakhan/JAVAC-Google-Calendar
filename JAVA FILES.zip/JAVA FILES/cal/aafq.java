package cal;

/* compiled from: PG */
/* loaded from: classes2.dex */
public final class aafq {
    public final apxs a;

    public aafq(apxs apxsVar) {
        this.a = apxsVar;
    }
}
