package cal;

/* compiled from: PG */
/* loaded from: classes2.dex */
public final /* synthetic */ class aado {
    public final /* synthetic */ String a = "databases/";

    public /* synthetic */ aado(String str) {
    }
}
