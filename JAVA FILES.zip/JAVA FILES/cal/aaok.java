package cal;

/* compiled from: PG */
/* loaded from: classes2.dex */
public final class aaok {
    public static Boolean a;
    private static String b;

    private aaok() {
    }

    /* JADX WARN: Removed duplicated region for block: B:30:0x0044  */
    /* JADX WARN: Removed duplicated region for block: B:55:0x0087 A[RETURN] */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct code enable 'Show inconsistent code' option in preferences
    */
    public static java.lang.String a(android.content.Context r5) {
        /*
            java.lang.String r0 = cal.aaok.b
            if (r0 == 0) goto L5
            return r0
        L5:
            int r0 = android.os.Build.VERSION.SDK_INT
            r1 = 28
            if (r0 < r1) goto L12
            java.lang.String r5 = cal.ke$$ExternalSyntheticApiModelOutline0.m99m()
            cal.aaok.b = r5
            return r5
        L12:
            java.lang.String r0 = "robolectric"
            java.lang.String r1 = android.os.Build.FINGERPRINT
            boolean r0 = r0.equals(r1)
            r1 = 0
            if (r0 != 0) goto L88
            java.lang.String r0 = "android.app.ActivityThread"
            java.lang.Class<cal.aaok> r2 = cal.aaok.class
            java.lang.ClassLoader r2 = r2.getClassLoader()     // Catch: java.lang.Throwable -> L3f
            r3 = 0
            java.lang.Class r0 = java.lang.Class.forName(r0, r3, r2)     // Catch: java.lang.Throwable -> L3f
            java.lang.String r2 = "currentProcessName"
            java.lang.reflect.Method r0 = r0.getDeclaredMethod(r2, r1)     // Catch: java.lang.Throwable -> L3f
            r2 = 1
            r0.setAccessible(r2)     // Catch: java.lang.Throwable -> L3f
            java.lang.Object r0 = r0.invoke(r1, r1)     // Catch: java.lang.Throwable -> L3f
            boolean r2 = r0 instanceof java.lang.String     // Catch: java.lang.Throwable -> L3f
            if (r2 == 0) goto L3f
            java.lang.String r0 = (java.lang.String) r0     // Catch: java.lang.Throwable -> L3f
            goto L40
        L3f:
            r0 = r1
        L40:
            cal.aaok.b = r0
            if (r0 != 0) goto L87
            android.os.StrictMode$ThreadPolicy r0 = android.os.StrictMode.allowThreadDiskReads()
            java.io.BufferedReader r2 = new java.io.BufferedReader     // Catch: java.lang.Throwable -> L6f java.lang.Exception -> L71
            java.io.FileReader r3 = new java.io.FileReader     // Catch: java.lang.Throwable -> L6f java.lang.Exception -> L71
            java.lang.String r4 = "/proc/self/cmdline"
            r3.<init>(r4)     // Catch: java.lang.Throwable -> L6f java.lang.Exception -> L71
            r4 = 50
            r2.<init>(r3, r4)     // Catch: java.lang.Throwable -> L6f java.lang.Exception -> L71
            java.lang.String r3 = r2.readLine()     // Catch: java.lang.Throwable -> L65
            java.lang.String r3 = r3.trim()     // Catch: java.lang.Throwable -> L65
            r2.close()     // Catch: java.lang.Throwable -> L6f java.lang.Exception -> L71
            android.os.StrictMode.setThreadPolicy(r0)
            goto L7d
        L65:
            r3 = move-exception
            r2.close()     // Catch: java.lang.Throwable -> L6a
            goto L6e
        L6a:
            r2 = move-exception
            r3.addSuppressed(r2)     // Catch: java.lang.Throwable -> L6f java.lang.Exception -> L71
        L6e:
            throw r3     // Catch: java.lang.Throwable -> L6f java.lang.Exception -> L71
        L6f:
            r5 = move-exception
            goto L83
        L71:
            r2 = move-exception
            java.lang.String r3 = "CurrentProcess"
            java.lang.String r4 = "Unable to read /proc/self/cmdline"
            android.util.Log.e(r3, r4, r2)     // Catch: java.lang.Throwable -> L6f
            android.os.StrictMode.setThreadPolicy(r0)
            r3 = r1
        L7d:
            cal.aaok.b = r3
            if (r3 != 0) goto L82
            goto L88
        L82:
            return r3
        L83:
            android.os.StrictMode.setThreadPolicy(r0)
            throw r5
        L87:
            return r0
        L88:
            java.lang.String r0 = "activity"
            java.lang.Object r5 = r5.getSystemService(r0)
            android.app.ActivityManager r5 = (android.app.ActivityManager) r5
            java.util.List r5 = r5.getRunningAppProcesses()
            if (r5 == 0) goto Lb0
            int r0 = android.os.Process.myPid()
            java.util.Iterator r5 = r5.iterator()
        L9e:
            boolean r2 = r5.hasNext()
            if (r2 == 0) goto Lb0
            java.lang.Object r2 = r5.next()
            android.app.ActivityManager$RunningAppProcessInfo r2 = (android.app.ActivityManager.RunningAppProcessInfo) r2
            int r3 = r2.pid
            if (r3 != r0) goto L9e
            java.lang.String r1 = r2.processName
        Lb0:
            cal.aaok.b = r1
            return r1
        */
        throw new UnsupportedOperationException("Method not decompiled: cal.aaok.a(android.content.Context):java.lang.String");
    }
}
