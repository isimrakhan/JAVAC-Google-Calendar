package cal;

import java.util.Set;

/* JADX INFO: Access modifiers changed from: package-private */
/* compiled from: PG */
/* loaded from: classes2.dex */
public final class aakw implements uds {
    public final aakr a;

    public aakw(aakr aakrVar) {
        this.a = aakrVar;
    }

    @Override // cal.uds
    public final void a(final udt udtVar) {
        uee ueeVar = uee.b;
        if (ueeVar instanceof uee) {
            udm udmVar = udtVar.a;
            if (udmVar.k.d.equals(ueeVar.d)) {
                return;
            }
        }
        aakx.a(udtVar, new ahum() { // from class: cal.aaks
            @Override // cal.ahum
            public final Object a() {
                udt udtVar2 = udtVar;
                Set set = (Set) ((aakx) aakw.this.a).d.get(new ahtj(udtVar2.k, udtVar2.j));
                if (set != null) {
                    return set;
                }
                return aikv.b;
            }
        }, new ahsr() { // from class: cal.aakt
            @Override // cal.ahsr
            /* renamed from: a */
            public final Object b(Object obj) {
                return (aakq) ((aakx) aakw.this.a).b.get(new ahtj((String) obj, udtVar.j));
            }
        });
        ahum ahumVar = new ahum() { // from class: cal.aaku
            @Override // cal.ahum
            public final Object a() {
                Set set = (Set) ((aakx) aakw.this.a).e.get(udtVar.k);
                if (set != null) {
                    return set;
                }
                return aikv.b;
            }
        };
        final aakr aakrVar = this.a;
        aakx.a(udtVar, ahumVar, new ahsr() { // from class: cal.aakv
            @Override // cal.ahsr
            /* renamed from: a */
            public final Object b(Object obj) {
                return (aakq) ((aakx) aakr.this).c.get((String) obj);
            }
        });
    }
}
