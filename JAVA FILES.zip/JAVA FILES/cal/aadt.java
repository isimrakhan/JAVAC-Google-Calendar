package cal;

/* compiled from: PG */
/* loaded from: classes2.dex */
public abstract class aadt implements zun {
    @Override // cal.zun
    public final /* synthetic */ int a() {
        return Integer.MAX_VALUE;
    }

    @Override // cal.zun
    public final boolean b() {
        if (d() == 3 || d() == 1) {
            return true;
        }
        return false;
    }

    public abstract ahti c();

    public abstract int d();

    public abstract void e();
}
