package cal;

/* compiled from: PG */
/* loaded from: classes2.dex */
public abstract class aaew implements zun {
    @Override // cal.zun
    public abstract int a();

    @Override // cal.zun
    public final boolean b() {
        return false;
    }

    public abstract aaev c();

    public abstract void d();

    public abstract void e();

    public abstract void f();
}
