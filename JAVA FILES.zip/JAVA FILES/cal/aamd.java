package cal;

import j$.util.concurrent.ConcurrentHashMap;

/* compiled from: PG */
/* loaded from: classes2.dex */
public final class aamd {
    public static final /* synthetic */ int a = 0;

    static {
        new ConcurrentHashMap();
    }
}
