package cal;

/* compiled from: PG */
/* loaded from: classes2.dex */
public final /* synthetic */ class aabw implements Runnable {
    public final /* synthetic */ aabz a;

    public /* synthetic */ aabw(aabz aabzVar) {
        this.a = aabzVar;
    }

    @Override // java.lang.Runnable
    public final void run() {
        this.a.a();
    }
}
