package cal;

/* compiled from: PG */
/* loaded from: classes2.dex */
public final class aapi {
    public static final aapi a;
    public final boolean b;
    public final boolean c = false;
    public final aick d;
    public final aick e;

    static {
        aaph aaphVar = new aaph();
        if (aaphVar.b == null) {
            aaphVar.b = false;
            a = aaphVar.a();
            aaph aaphVar2 = new aaph();
            if (aaphVar2.b == null) {
                aaphVar2.b = false;
                aapg aapgVar = new aapg();
                aaphVar2.b.getClass();
                aaphVar2.a.f(aapgVar);
                aaphVar2.a();
                aaph aaphVar3 = new aaph();
                if (aaphVar3.b == null) {
                    aaphVar3.b = true;
                    aaphVar3.a();
                    return;
                }
                throw new IllegalStateException("A SourcePolicy can only set internal() or external() once.");
            }
            throw new IllegalStateException("A SourcePolicy can only set internal() or external() once.");
        }
        throw new IllegalStateException("A SourcePolicy can only set internal() or external() once.");
    }

    public aapi(boolean z, aick aickVar, aick aickVar2) {
        this.b = z;
        this.d = aickVar;
        this.e = aickVar2;
    }
}
