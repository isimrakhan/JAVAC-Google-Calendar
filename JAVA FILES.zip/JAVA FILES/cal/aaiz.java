package cal;

import com.google.protobuf.InvalidProtocolBufferException;
import com.google.protobuf.UninitializedMessageException;
import java.io.IOException;
import java.io.InputStream;

/* compiled from: PG */
/* loaded from: classes2.dex */
public final class aaiz extends ampm implements amqu {
    public static final aaiz a;
    public static volatile amra b;
    public int c;
    public String d = "";
    public amob e = amob.b;
    public String f = "";
    public ampw g;
    public ampw h;
    public boolean i;
    public long j;

    static {
        aaiz aaizVar = new aaiz();
        a = aaizVar;
        aaizVar.ad &= Integer.MAX_VALUE;
        ampm.ac.put(aaiz.class, aaizVar);
    }

    public aaiz() {
        amrd amrdVar = amrd.b;
        this.g = amrdVar;
        this.h = amrdVar;
    }

    public static aaiz parseFrom(InputStream inputStream) {
        amof amoeVar;
        int i = amof.f;
        if (inputStream == null) {
            byte[] bArr = ampx.b;
            int length = bArr.length;
            amoeVar = new amoc(bArr, 0, 0);
            try {
                amoeVar.d(0);
            } catch (InvalidProtocolBufferException e) {
                throw new IllegalArgumentException(e);
            }
        } else {
            amoeVar = new amoe(inputStream, 4096);
        }
        amov amovVar = amov.a;
        amrc amrcVar = amrc.a;
        amov amovVar2 = amov.b;
        aaiz aaizVar = new aaiz();
        try {
            amrk a2 = amrc.a.a(aaizVar.getClass());
            amog amogVar = amoeVar.e;
            if (amogVar == null) {
                amogVar = new amog(amoeVar);
            }
            a2.h(aaizVar, amogVar, amovVar2);
            a2.f(aaizVar);
            Byte b2 = (byte) 1;
            b2.getClass();
            return aaizVar;
        } catch (InvalidProtocolBufferException e2) {
            if (e2.a) {
                throw new InvalidProtocolBufferException(e2);
            }
            throw e2;
        } catch (UninitializedMessageException e3) {
            throw new InvalidProtocolBufferException(e3.getMessage());
        } catch (IOException e4) {
            if (e4.getCause() instanceof InvalidProtocolBufferException) {
                throw ((InvalidProtocolBufferException) e4.getCause());
            }
            throw new InvalidProtocolBufferException(e4);
        } catch (RuntimeException e5) {
            if (e5.getCause() instanceof InvalidProtocolBufferException) {
                throw ((InvalidProtocolBufferException) e5.getCause());
            }
            throw e5;
        }
    }

    @Override // cal.ampm
    public final Object a(int i, Object obj) {
        int i2 = i - 1;
        if (i2 != 0) {
            if (i2 != 2) {
                if (i2 != 3) {
                    if (i2 != 4) {
                        if (i2 != 5) {
                            if (i2 != 6) {
                                return null;
                            }
                            amra amraVar = b;
                            if (amraVar == null) {
                                synchronized (aaiz.class) {
                                    amraVar = b;
                                    if (amraVar == null) {
                                        amraVar = new amph(a);
                                        b = amraVar;
                                    }
                                }
                            }
                            return amraVar;
                        }
                        return a;
                    }
                    return new aaiy();
                }
                return new aaiz();
            }
            return new amre(a, "\u0004\u0007\u0000\u0001\u0001\t\u0007\u0000\u0002\u0000\u0001ဈ\u0002\u0002ဈ\u0000\u0003ည\u0001\u0004\u001b\u0005\u001a\bဇ\u0003\tဂ\u0004", new Object[]{"c", "f", "d", "e", "g", aajc.class, "h", "i", "j"});
        }
        return (byte) 1;
    }
}
