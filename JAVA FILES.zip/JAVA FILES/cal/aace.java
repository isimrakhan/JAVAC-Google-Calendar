package cal;

/* compiled from: PG */
/* loaded from: classes2.dex */
public final class aace {
    public final apxs a;
    public final apxs b;

    public aace(apxs apxsVar, apxs apxsVar2) {
        this.a = apxsVar;
        apxsVar2.getClass();
        this.b = apxsVar2;
    }
}
