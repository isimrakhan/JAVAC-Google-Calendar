package cal;

import java.util.logging.Level;

/* compiled from: PG */
/* loaded from: classes2.dex */
public final /* synthetic */ class aaiq implements Runnable {
    public final /* synthetic */ Level a;
    public final /* synthetic */ Throwable b;
    public final /* synthetic */ String c;
    public final /* synthetic */ Object[] d;

    public /* synthetic */ aaiq(Level level, Throwable th, String str, Object[] objArr) {
        this.a = level;
        this.b = th;
        this.c = str;
        this.d = objArr;
    }

    @Override // java.lang.Runnable
    public final void run() {
        ((aimj) ((aimj) aair.a.a(this.a).j(this.b)).k("com/google/android/libraries/phenotype/client/Phlogger", "logInternal", 49, "Phlogger.java")).E(this.c, this.d);
    }
}
