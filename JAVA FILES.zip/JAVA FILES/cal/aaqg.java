package cal;

/* compiled from: PG */
/* loaded from: classes2.dex */
final class aaqg {
    public static final ahtc a = new ahtc(" AND ");
    public static final ahtc b = new ahtc(" OR ");
    public static final ahtc c = new ahtc(":");
}
