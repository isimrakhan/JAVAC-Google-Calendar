package cal;

import android.os.Parcel;
import com.google.android.gms.common.Feature;
import com.google.android.gms.common.api.ApiException;
import com.google.android.gms.common.api.UnsupportedApiCallException;
import com.google.android.gms.phenotype.Configuration;
import com.google.android.gms.phenotype.Configurations;
import com.google.android.gms.phenotype.Flag;
import java.io.IOException;
import java.util.concurrent.Executor;

/* compiled from: PG */
/* loaded from: classes2.dex */
public final class aajg implements aajd {
    private final vbc a;

    public aajg(vbc vbcVar) {
        this.a = vbcVar;
    }

    @Override // cal.aajd
    public final ajdo a(String str) {
        str.getClass();
        ukv ukvVar = new ukv();
        ukvVar.a = new vat(str);
        ukw a = ukvVar.a();
        vdv vdvVar = new vdv();
        vbc vbcVar = this.a;
        vbcVar.k.h(vbcVar, 0, a, vdvVar);
        vdz vdzVar = vdvVar.a;
        vwj vwjVar = new vwj(vdzVar);
        vdzVar.b.a(new vdg(ajbw.a, new vwi(vwjVar)));
        synchronized (vdzVar.a) {
            if (vdzVar.c) {
                vdzVar.b.b(vdzVar);
            }
        }
        aajf aajfVar = new aajf();
        Executor executor = ajbw.a;
        aizx aizxVar = new aizx(vwjVar, ApiException.class, aajfVar);
        executor.getClass();
        if (executor != ajbw.a) {
            executor = new ajdt(executor, aizxVar);
        }
        vwjVar.d(aizxVar, executor);
        return aizxVar;
    }

    @Override // cal.aajd
    public final ajdo b(final aaix aaixVar) {
        aaixVar.getClass();
        ukv ukvVar = new ukv();
        ukvVar.a = new ukp() { // from class: cal.vax
            @Override // cal.ukp
            public final void a(Object obj, Object obj2) {
                int i;
                vbb vbbVar = new vbb((vdv) obj2);
                vbq vbqVar = (vbq) ((vbr) obj).w();
                aaix aaixVar2 = aaix.this;
                try {
                    int i2 = aaixVar2.ad;
                    if ((i2 & Integer.MIN_VALUE) != 0) {
                        i = amrc.a.a(aaixVar2.getClass()).a(aaixVar2);
                        if (i < 0) {
                            throw new IllegalStateException(a.f(i, "serialized size must be non-negative, was "));
                        }
                    } else {
                        i = i2 & Integer.MAX_VALUE;
                        if (i == Integer.MAX_VALUE) {
                            i = amrc.a.a(aaixVar2.getClass()).a(aaixVar2);
                            if (i >= 0) {
                                aaixVar2.ad = (Integer.MIN_VALUE & aaixVar2.ad) | i;
                            } else {
                                throw new IllegalStateException(a.f(i, "serialized size must be non-negative, was "));
                            }
                        }
                    }
                    byte[] bArr = new byte[i];
                    amoi amoiVar = new amoi(bArr, 0, i);
                    amrk a = amrc.a.a(aaixVar2.getClass());
                    amol amolVar = amoiVar.g;
                    if (amolVar == null) {
                        amolVar = new amol(amoiVar);
                    }
                    a.j(aaixVar2, amolVar);
                    if (amoiVar.a - amoiVar.b == 0) {
                        String str = vbqVar.b;
                        Parcel obtain = Parcel.obtain();
                        obtain.writeInterfaceToken(str);
                        ClassLoader classLoader = dgl.a;
                        obtain.writeStrongBinder(vbbVar);
                        obtain.writeByteArray(bArr);
                        Parcel obtain2 = Parcel.obtain();
                        try {
                            vbqVar.a.transact(31, obtain, obtain2, 0);
                            obtain2.readException();
                            return;
                        } finally {
                            obtain.recycle();
                            obtain2.recycle();
                        }
                    }
                    throw new IllegalStateException("Did not write as much data as expected.");
                } catch (IOException e) {
                    throw new RuntimeException(a.u(aaixVar2, "Serializing ", " to a byte array threw an IOException (should never happen)."), e);
                }
            }
        };
        ukvVar.c = new Feature[]{vah.a};
        ukvVar.b = false;
        ukw a = ukvVar.a();
        vdv vdvVar = new vdv();
        final vbc vbcVar = this.a;
        vbcVar.k.h(vbcVar, 0, a, vdvVar);
        vdz vdzVar = vdvVar.a;
        vcx vcxVar = new vcx() { // from class: cal.vaw
            @Override // cal.vcx
            public final Object a(vdr vdrVar) {
                Exception exc;
                Exception exc2;
                Exception exc3;
                vdz vdzVar2 = (vdz) vdrVar;
                synchronized (vdzVar2.a) {
                    exc = ((vdz) vdrVar).f;
                }
                aaix aaixVar2 = aaixVar;
                vbc vbcVar2 = vbc.this;
                if (exc instanceof UnsupportedApiCallException) {
                    String str = aaixVar2.d;
                    ukv ukvVar2 = new ukv();
                    ukvVar2.a = new vat(str);
                    ukw a2 = ukvVar2.a();
                    vdv vdvVar2 = new vdv();
                    vbcVar2.k.h(vbcVar2, 0, a2, vdvVar2);
                    return vdvVar2.a;
                }
                synchronized (vdzVar2.a) {
                    exc2 = ((vdz) vdrVar).f;
                }
                if (exc2 instanceof ApiException) {
                    synchronized (vdzVar2.a) {
                        exc3 = ((vdz) vdrVar).f;
                    }
                    ApiException apiException = (ApiException) exc3;
                    apiException.getClass();
                    if (apiException.a.f == 29514) {
                        String str2 = aaixVar2.d;
                        ukv ukvVar3 = new ukv();
                        ukvVar3.a = new vat(str2);
                        ukw a3 = ukvVar3.a();
                        vdv vdvVar3 = new vdv();
                        vbcVar2.k.h(vbcVar2, 0, a3, vdvVar3);
                        return vdvVar3.a;
                    }
                    return vdrVar;
                }
                return vdrVar;
            }
        };
        Executor executor = vdy.a;
        vdz vdzVar2 = new vdz();
        vdzVar.b.a(new vdb(executor, vcxVar, vdzVar2));
        synchronized (vdzVar.a) {
            if (vdzVar.c) {
                vdzVar.b.b(vdzVar);
            }
        }
        vwj vwjVar = new vwj(vdzVar2);
        vdzVar2.b.a(new vdg(ajbw.a, new vwi(vwjVar)));
        synchronized (vdzVar2.a) {
            if (vdzVar2.c) {
                vdzVar2.b.b(vdzVar2);
            }
        }
        aajf aajfVar = new aajf();
        Executor executor2 = ajbw.a;
        aizx aizxVar = new aizx(vwjVar, ApiException.class, aajfVar);
        executor2.getClass();
        if (executor2 != ajbw.a) {
            executor2 = new ajdt(executor2, aizxVar);
        }
        vwjVar.d(aizxVar, executor2);
        return aizxVar;
    }

    @Override // cal.aajd
    public final ajdo c(String str, String str2) {
        str2.getClass();
        ukv ukvVar = new ukv();
        ukvVar.a = new vap(str, str2, null);
        ukw a = ukvVar.a();
        vdv vdvVar = new vdv();
        vbc vbcVar = this.a;
        vbcVar.k.h(vbcVar, 0, a, vdvVar);
        vdz vdzVar = vdvVar.a;
        ajbw ajbwVar = ajbw.a;
        vcx vcxVar = new vcx() { // from class: cal.aaje
            @Override // cal.vcx
            public final Object a(vdr vdrVar) {
                int i;
                aajc aajcVar;
                Configurations configurations = (Configurations) vdrVar.d();
                aaiz aaizVar = aaiz.a;
                aaiy aaiyVar = new aaiy();
                String str3 = configurations.a;
                int i2 = Integer.MIN_VALUE;
                if ((aaiyVar.b.ad & Integer.MIN_VALUE) == 0) {
                    aaiyVar.s();
                }
                aaiz aaizVar2 = (aaiz) aaiyVar.b;
                str3.getClass();
                aaizVar2.c |= 1;
                aaizVar2.d = str3;
                String str4 = configurations.c;
                if ((aaiyVar.b.ad & Integer.MIN_VALUE) == 0) {
                    aaiyVar.s();
                }
                aaiz aaizVar3 = (aaiz) aaiyVar.b;
                str4.getClass();
                int i3 = 4;
                aaizVar3.c |= 4;
                aaizVar3.f = str4;
                boolean z = configurations.f;
                if ((aaiyVar.b.ad & Integer.MIN_VALUE) == 0) {
                    aaiyVar.s();
                }
                aaiz aaizVar4 = (aaiz) aaiyVar.b;
                aaizVar4.c |= 8;
                aaizVar4.i = z;
                long j = configurations.g;
                if ((aaiyVar.b.ad & Integer.MIN_VALUE) == 0) {
                    aaiyVar.s();
                }
                aaiz aaizVar5 = (aaiz) aaiyVar.b;
                aaizVar5.c |= 16;
                aaizVar5.j = j;
                byte[] bArr = configurations.b;
                int i4 = 2;
                int i5 = 0;
                if (bArr != null) {
                    int length = bArr.length;
                    amob.p(0, length, length);
                    byte[] bArr2 = new byte[length];
                    System.arraycopy(bArr, 0, bArr2, 0, length);
                    amnz amnzVar = new amnz(bArr2);
                    if ((aaiyVar.b.ad & Integer.MIN_VALUE) == 0) {
                        aaiyVar.s();
                    }
                    aaiz aaizVar6 = (aaiz) aaiyVar.b;
                    aaizVar6.c |= 2;
                    aaizVar6.e = amnzVar;
                }
                Configuration[] configurationArr = configurations.d;
                int length2 = configurationArr.length;
                int i6 = 0;
                while (i6 < length2) {
                    Configuration configuration = configurationArr[i6];
                    Flag[] flagArr = configuration.b;
                    int length3 = flagArr.length;
                    int i7 = i5;
                    while (i7 < length3) {
                        Flag flag = flagArr[i7];
                        int i8 = flag.g;
                        if (i8 != 1) {
                            if (i8 != i4) {
                                if (i8 != 3) {
                                    if (i8 != i3) {
                                        if (i8 == 5) {
                                            aajc aajcVar2 = aajc.a;
                                            aaja aajaVar = new aaja();
                                            String str5 = flag.a;
                                            if ((aajaVar.b.ad & i2) == 0) {
                                                aajaVar.s();
                                            }
                                            aajc aajcVar3 = (aajc) aajaVar.b;
                                            str5.getClass();
                                            aajcVar3.c |= 1;
                                            aajcVar3.f = str5;
                                            if (flag.g == 5) {
                                                byte[] bArr3 = flag.f;
                                                if (bArr3 != null) {
                                                    int length4 = bArr3.length;
                                                    amob.p(0, length4, length4);
                                                    byte[] bArr4 = new byte[length4];
                                                    System.arraycopy(bArr3, 0, bArr4, 0, length4);
                                                    amnz amnzVar2 = new amnz(bArr4);
                                                    if ((aajaVar.b.ad & Integer.MIN_VALUE) == 0) {
                                                        aajaVar.s();
                                                    }
                                                    aajc aajcVar4 = (aajc) aajaVar.b;
                                                    aajcVar4.d = 5;
                                                    aajcVar4.e = amnzVar2;
                                                    aajcVar = (aajc) aajaVar.p();
                                                } else {
                                                    throw new NullPointerException("null reference");
                                                }
                                            } else {
                                                throw new IllegalArgumentException("Not a bytes type");
                                            }
                                        } else {
                                            throw new IllegalArgumentException(a.f(i8, "Unrecognized flag type: "));
                                        }
                                    } else {
                                        aajc aajcVar5 = aajc.a;
                                        aaja aajaVar2 = new aaja();
                                        String str6 = flag.a;
                                        if ((aajaVar2.b.ad & Integer.MIN_VALUE) == 0) {
                                            aajaVar2.s();
                                        }
                                        aajc aajcVar6 = (aajc) aajaVar2.b;
                                        str6.getClass();
                                        aajcVar6.c |= 1;
                                        aajcVar6.f = str6;
                                        if (flag.g == 4) {
                                            String str7 = flag.e;
                                            if (str7 != null) {
                                                if ((aajaVar2.b.ad & Integer.MIN_VALUE) == 0) {
                                                    aajaVar2.s();
                                                }
                                                aajc aajcVar7 = (aajc) aajaVar2.b;
                                                aajcVar7.d = 4;
                                                aajcVar7.e = str7;
                                                aajcVar = (aajc) aajaVar2.p();
                                            } else {
                                                throw new NullPointerException("null reference");
                                            }
                                        } else {
                                            throw new IllegalArgumentException("Not a String type");
                                        }
                                    }
                                } else {
                                    aajc aajcVar8 = aajc.a;
                                    aaja aajaVar3 = new aaja();
                                    String str8 = flag.a;
                                    if ((aajaVar3.b.ad & Integer.MIN_VALUE) == 0) {
                                        aajaVar3.s();
                                    }
                                    aajc aajcVar9 = (aajc) aajaVar3.b;
                                    str8.getClass();
                                    aajcVar9.c |= 1;
                                    aajcVar9.f = str8;
                                    if (flag.g == 3) {
                                        double d = flag.d;
                                        if ((aajaVar3.b.ad & Integer.MIN_VALUE) == 0) {
                                            aajaVar3.s();
                                        }
                                        aajc aajcVar10 = (aajc) aajaVar3.b;
                                        aajcVar10.d = 3;
                                        aajcVar10.e = Double.valueOf(d);
                                        aajcVar = (aajc) aajaVar3.p();
                                    } else {
                                        throw new IllegalArgumentException("Not a double type");
                                    }
                                }
                                i = 2;
                            } else {
                                aajc aajcVar11 = aajc.a;
                                aaja aajaVar4 = new aaja();
                                String str9 = flag.a;
                                if ((aajaVar4.b.ad & Integer.MIN_VALUE) == 0) {
                                    aajaVar4.s();
                                }
                                aajc aajcVar12 = (aajc) aajaVar4.b;
                                str9.getClass();
                                aajcVar12.c |= 1;
                                aajcVar12.f = str9;
                                i = 2;
                                if (flag.g == 2) {
                                    boolean z2 = flag.c;
                                    if ((aajaVar4.b.ad & Integer.MIN_VALUE) == 0) {
                                        aajaVar4.s();
                                    }
                                    aajc aajcVar13 = (aajc) aajaVar4.b;
                                    aajcVar13.d = 2;
                                    aajcVar13.e = Boolean.valueOf(z2);
                                    aajcVar = (aajc) aajaVar4.p();
                                } else {
                                    throw new IllegalArgumentException("Not a boolean type");
                                }
                            }
                        } else {
                            i = i4;
                            aajc aajcVar14 = aajc.a;
                            aaja aajaVar5 = new aaja();
                            String str10 = flag.a;
                            if ((aajaVar5.b.ad & Integer.MIN_VALUE) == 0) {
                                aajaVar5.s();
                            }
                            aajc aajcVar15 = (aajc) aajaVar5.b;
                            str10.getClass();
                            aajcVar15.c |= 1;
                            aajcVar15.f = str10;
                            if (flag.g == 1) {
                                long j2 = flag.b;
                                if ((aajaVar5.b.ad & Integer.MIN_VALUE) == 0) {
                                    aajaVar5.s();
                                }
                                aajc aajcVar16 = (aajc) aajaVar5.b;
                                aajcVar16.d = 1;
                                aajcVar16.e = Long.valueOf(j2);
                                aajcVar = (aajc) aajaVar5.p();
                            } else {
                                throw new IllegalArgumentException("Not a long type");
                            }
                        }
                        if ((aaiyVar.b.ad & Integer.MIN_VALUE) == 0) {
                            aaiyVar.s();
                        }
                        aaiz aaizVar7 = (aaiz) aaiyVar.b;
                        aajcVar.getClass();
                        ampw ampwVar = aaizVar7.g;
                        if (!ampwVar.b()) {
                            int size = ampwVar.size();
                            aaizVar7.g = ampwVar.c(size + size);
                        }
                        aaizVar7.g.add(aajcVar);
                        i7++;
                        i4 = i;
                        i2 = Integer.MIN_VALUE;
                        i5 = 0;
                        i3 = 4;
                    }
                    int i9 = i4;
                    String[] strArr = configuration.c;
                    if (strArr != null) {
                        for (String str11 : strArr) {
                            if ((aaiyVar.b.ad & Integer.MIN_VALUE) == 0) {
                                aaiyVar.s();
                            }
                            aaiz aaizVar8 = (aaiz) aaiyVar.b;
                            str11.getClass();
                            ampw ampwVar2 = aaizVar8.h;
                            if (!ampwVar2.b()) {
                                int size2 = ampwVar2.size();
                                aaizVar8.h = ampwVar2.c(size2 + size2);
                            }
                            aaizVar8.h.add(str11);
                        }
                    }
                    i6++;
                    i4 = i9;
                    i2 = Integer.MIN_VALUE;
                    i5 = 0;
                    i3 = 4;
                }
                return (aaiz) aaiyVar.p();
            }
        };
        vdz vdzVar2 = new vdz();
        vdzVar.b.a(new vcz(ajbwVar, vcxVar, vdzVar2));
        synchronized (vdzVar.a) {
            if (vdzVar.c) {
                vdzVar.b.b(vdzVar);
            }
        }
        vwj vwjVar = new vwj(vdzVar2);
        vdzVar2.b.a(new vdg(ajbw.a, new vwi(vwjVar)));
        synchronized (vdzVar2.a) {
            if (vdzVar2.c) {
                vdzVar2.b.b(vdzVar2);
            }
        }
        aajf aajfVar = new aajf();
        Executor executor = ajbw.a;
        aizx aizxVar = new aizx(vwjVar, ApiException.class, aajfVar);
        executor.getClass();
        if (executor != ajbw.a) {
            executor = new ajdt(executor, aizxVar);
        }
        vwjVar.d(aizxVar, executor);
        return aizxVar;
    }

    @Override // cal.aajd
    public final ajdo d() {
        ukv ukvVar = new ukv();
        ukvVar.a = new ukp() { // from class: cal.vao
            @Override // cal.ukp
            public final void a(Object obj, Object obj2) {
                vbq vbqVar = (vbq) ((vbr) obj).w();
                vay vayVar = new vay((vdv) obj2);
                String str = vbqVar.b;
                Parcel obtain = Parcel.obtain();
                obtain.writeInterfaceToken(str);
                ClassLoader classLoader = dgl.a;
                obtain.writeStrongBinder(vayVar);
                Parcel obtain2 = Parcel.obtain();
                try {
                    vbqVar.a.transact(27, obtain, obtain2, 0);
                    obtain2.readException();
                } finally {
                    obtain.recycle();
                    obtain2.recycle();
                }
            }
        };
        ukvVar.c = new Feature[]{vah.i};
        ukvVar.b = false;
        ukw a = ukvVar.a();
        vdv vdvVar = new vdv();
        vbc vbcVar = this.a;
        vbcVar.k.h(vbcVar, 0, a, vdvVar);
        vdz vdzVar = vdvVar.a;
        vwj vwjVar = new vwj(vdzVar);
        vdzVar.b.a(new vdg(ajbw.a, new vwi(vwjVar)));
        synchronized (vdzVar.a) {
            if (vdzVar.c) {
                vdzVar.b.b(vdzVar);
            }
        }
        aajf aajfVar = new aajf();
        Executor executor = ajbw.a;
        aizx aizxVar = new aizx(vwjVar, ApiException.class, aajfVar);
        executor.getClass();
        if (executor != ajbw.a) {
            executor = new ajdt(executor, aizxVar);
        }
        vwjVar.d(aizxVar, executor);
        return aizxVar;
    }

    /* JADX WARN: Code restructure failed: missing block: B:32:0x0071, code lost:
    
        if (r4 == null) goto L38;
     */
    /* JADX WARN: Multi-variable type inference failed */
    /* JADX WARN: Type inference failed for: r0v3, types: [cal.ajdo, cal.vwj] */
    /* JADX WARN: Type inference failed for: r7v16, types: [cal.ajdt] */
    @Override // cal.aajd
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct code enable 'Show inconsistent code' option in preferences
    */
    public final cal.ajdo e(cal.aalz r7) {
        /*
            Method dump skipped, instructions count: 286
            To view this dump change 'Code comments level' option to 'DEBUG'
        */
        throw new UnsupportedOperationException("Method not decompiled: cal.aajg.e(cal.aalz):cal.ajdo");
    }
}
