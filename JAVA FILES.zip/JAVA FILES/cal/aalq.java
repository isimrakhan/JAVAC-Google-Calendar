package cal;

import java.util.concurrent.atomic.AtomicInteger;

/* compiled from: PG */
/* loaded from: classes2.dex */
public final class aalq {
    public final AtomicInteger a = new AtomicInteger();
}
