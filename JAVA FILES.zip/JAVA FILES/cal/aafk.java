package cal;

import android.content.Context;

/* compiled from: PG */
/* loaded from: classes2.dex */
public final class aafk {
    public final Context a;
    public final apxs b;

    public aafk(Context context, apxs apxsVar) {
        this.a = context;
        this.b = apxsVar;
    }
}
