package cal;

import j$.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.Executor;
import java.util.concurrent.atomic.AtomicReference;

/* JADX INFO: Access modifiers changed from: package-private */
/* compiled from: PG */
/* loaded from: classes2.dex */
public final class aaar extends aaam implements zwh, aaab {
    public final ajds a;
    public final zsm b;
    public final anyt c;
    public final zwf d;
    public final aaay e;
    private final boolean f;
    private final aaal g;

    public aaar(zwg zwgVar, aaal aaalVar, ajds ajdsVar, anyt anytVar, aaay aaayVar, zsm zsmVar, apxs apxsVar, Executor executor) {
        new AtomicReference(aaae.a);
        new ConcurrentHashMap();
        this.g = aaalVar;
        this.b = zsmVar;
        this.d = zwgVar.a(executor, anytVar, apxsVar);
        this.a = ajdsVar;
        this.c = anytVar;
        this.e = aaayVar;
        Boolean bool = Boolean.FALSE;
        bool.getClass();
        this.f = bool.booleanValue();
    }

    @Override // cal.aaab
    public final synchronized void a(String str) {
        if (this.b.a) {
            if (ajdh.a != null) {
                return;
            }
            new ajdh();
        } else {
            this.a.execute(new ajel(new aaan(this, 1, str, false, null)));
        }
    }

    @Override // cal.aaam
    public final void b() {
        this.g.b(new aaao(this));
    }

    @Override // cal.zwh
    public final void u() {
        if (this.f) {
            this.g.b(new aaao(this));
        }
    }
}
