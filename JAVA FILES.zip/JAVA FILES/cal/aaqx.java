package cal;

import android.content.Context;

/* compiled from: PG */
/* loaded from: classes2.dex */
public final class aaqx implements aaow {
    private final Context a;

    public aaqx(Context context) {
        this.a = context;
    }

    @Override // cal.aaow
    public final void a() {
        this.a.registerComponentCallbacks(new aaqw());
    }
}
