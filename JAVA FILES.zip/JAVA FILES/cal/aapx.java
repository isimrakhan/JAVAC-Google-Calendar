package cal;

import java.math.RoundingMode;
import java.util.Map;

/* compiled from: PG */
/* loaded from: classes2.dex */
public final class aapx {
    public final aaqp a;
    public final aieb b;
    public final aieb c;

    public aapx(aaqp aaqpVar, aieb aiebVar, aieb aiebVar2) {
        this.a = aaqpVar;
        this.b = aiebVar;
        this.c = aiebVar2;
    }

    public final double a() {
        Long valueOf = Long.valueOf(Math.max(0L, 0L));
        aieb aiebVar = this.b;
        aieb a = aiebVar.a(aiebVar.g.w(valueOf, true), aiebVar.h.size());
        aidr aidrVar = a.b;
        if (aidrVar == null) {
            if (a.h.size() == 0) {
                aidrVar = aikv.b;
            } else {
                aidrVar = new aidy(a);
            }
            a.b = aidrVar;
        }
        ails it = aidrVar.iterator();
        double d = 0.0d;
        while (it.hasNext()) {
            Map.Entry entry = (Map.Entry) it.next();
            double intValue = ((Integer) entry.getValue()).intValue();
            long longValue = ((Long) entry.getKey()).longValue();
            RoundingMode.FLOOR.getClass();
            d += intValue * Math.pow(0.95d, longValue);
        }
        return d;
    }
}
