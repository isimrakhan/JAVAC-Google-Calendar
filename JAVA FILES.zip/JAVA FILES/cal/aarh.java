package cal;

/* compiled from: PG */
/* loaded from: classes2.dex */
public final class aarh {
    private int K;
    private int L;
    private int M;
    private int N;
    private int O;
    private boolean P;
    private boolean Q;
    private boolean R;
    private boolean S;
    private boolean T;
    private int V;
    private int W;
    private int X;
    private static final char[] a = "http://".toCharArray();
    private static final char[] b = "https://".toCharArray();
    private static final char[] c = "lh".toCharArray();
    private static final char[] d = "photos-image-dev".toCharArray();
    private static final char[] e = "drive-image-dev".toCharArray();
    private static final char[] f = "drive-qa".toCharArray();
    private static final char[] g = "drive".toCharArray();
    private static final char[] h = "contribution-image-dev".toCharArray();
    private static final char[] i = ".corp.google.com/".toCharArray();
    private static final char[] j = "ap".toCharArray();
    private static final char[] k = "yt".toCharArray();
    private static final char[] l = "sp".toCharArray();
    private static final char[] m = "bp".toCharArray();
    private static final char[] n = "ccp-lh".toCharArray();
    private static final char[] o = "work.fife.usercontent".toCharArray();
    private static final char[] p = "photos-d".toCharArray();
    private static final char[] q = ".fife.usercontent.google.com/".toCharArray();
    private static final char[] r = "photos.fife.usercontent".toCharArray();
    private static final char[] s = "testonly.fife.usercontent".toCharArray();
    private static final char[] t = "play-lh".toCharArray();
    private static final char[] u = "gz0".toCharArray();
    private static final char[] v = ".googleusercontent.com/".toCharArray();
    private static final char[] w = "www.google.com/visualsearch/lh/".toCharArray();
    private static final char[] x = ".google.com/".toCharArray();
    private static final char[] y = ".sandbox.google.com/".toCharArray();
    private static final char[] z = ".corp.google.com/".toCharArray();
    private static final char[] A = ".blogger.com/".toCharArray();
    private static final char[] B = ".bp.blogspot.com/".toCharArray();
    private static final char[] C = ".ggpht.com/".toCharArray();
    private static final char[] D = "image".toCharArray();
    private static final char[] E = "drive-usercontent/".toCharArray();
    private static final char[] F = "drive-viewer/".toCharArray();
    private static final char[] G = "%3D".toCharArray();
    private static final char[] H = "%3d".toCharArray();
    private static final char[][] I = {new char[]{'O'}, new char[]{'J'}, new char[]{'U', 't'}, new char[]{'U'}, new char[]{'I'}};
    private final char[] J = new char[2000];
    private boolean U = true;
    private final int[] Y = new int[8];
    private final int[] Z = new int[8];

    /* JADX WARN: Code restructure failed: missing block: B:10:0x0012, code lost:
    
        r5 = r5 + 1;
     */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct code enable 'Show inconsistent code' option in preferences
    */
    private final int c(int r5, int r6, char[] r7) {
        /*
            r4 = this;
            int r0 = r7.length
        L1:
            int r1 = r5 + r0
            if (r1 >= r6) goto L19
            r1 = 0
        L6:
            if (r1 >= r0) goto L18
            char[] r2 = r4.J
            int r3 = r5 + r1
            char r2 = r2[r3]
            char r3 = r7[r1]
            if (r2 == r3) goto L15
            int r5 = r5 + 1
            goto L1
        L15:
            int r1 = r1 + 1
            goto L6
        L18:
            return r5
        L19:
            r5 = -1
            return r5
        */
        throw new UnsupportedOperationException("Method not decompiled: cal.aarh.c(int, int, char[]):int");
    }

    /* JADX WARN: Code restructure failed: missing block: B:129:0x0095, code lost:
    
        if (e(cal.aarh.v) == false) goto L98;
     */
    /* JADX WARN: Code restructure failed: missing block: B:140:0x00b3, code lost:
    
        if (e(cal.aarh.v) == false) goto L98;
     */
    /* JADX WARN: Code restructure failed: missing block: B:161:0x0107, code lost:
    
        if (e(cal.aarh.v) == false) goto L98;
     */
    /* JADX WARN: Code restructure failed: missing block: B:168:0x0125, code lost:
    
        if (e(cal.aarh.C) == false) goto L98;
     */
    /* JADX WARN: Code restructure failed: missing block: B:169:0x00b7, code lost:
    
        if (r5 == '-') goto L41;
     */
    /* JADX WARN: Code restructure failed: missing block: B:177:0x0143, code lost:
    
        if (r1[r3 + 3] != 'u') goto L81;
     */
    /* JADX WARN: Code restructure failed: missing block: B:178:0x0167, code lost:
    
        r17.L = r3 + 4;
     */
    /* JADX WARN: Code restructure failed: missing block: B:179:0x0170, code lost:
    
        if (e(cal.aarh.v) == false) goto L95;
     */
    /* JADX WARN: Code restructure failed: missing block: B:181:0x017a, code lost:
    
        if (e(cal.aarh.x) == false) goto L98;
     */
    /* JADX WARN: Code restructure failed: missing block: B:182:0x017c, code lost:
    
        r17.S = true;
     */
    /* JADX WARN: Code restructure failed: missing block: B:185:0x014f, code lost:
    
        if (r1[r3 + 3] == 's') goto L92;
     */
    /* JADX WARN: Code restructure failed: missing block: B:189:0x015b, code lost:
    
        if (r1[r3 + 3] == 'w') goto L92;
     */
    /* JADX WARN: Code restructure failed: missing block: B:193:0x0165, code lost:
    
        if (r1[r3 + 3] == 't') goto L92;
     */
    /* JADX WARN: Code restructure failed: missing block: B:222:0x01f6, code lost:
    
        if (e(cal.aarh.F) != false) goto L205;
     */
    /* JADX WARN: Code restructure failed: missing block: B:230:0x0218, code lost:
    
        if (e(cal.aarh.F) != false) goto L205;
     */
    /* JADX WARN: Code restructure failed: missing block: B:239:0x0243, code lost:
    
        if (e(cal.aarh.C) == false) goto L98;
     */
    /* JADX WARN: Code restructure failed: missing block: B:249:0x026e, code lost:
    
        if (e(cal.aarh.C) == false) goto L98;
     */
    /* JADX WARN: Code restructure failed: missing block: B:257:0x0297, code lost:
    
        if (e(cal.aarh.C) == false) goto L98;
     */
    /* JADX WARN: Code restructure failed: missing block: B:261:0x02ac, code lost:
    
        if (e(cal.aarh.v) == false) goto L269;
     */
    /* JADX WARN: Code restructure failed: missing block: B:265:0x02c1, code lost:
    
        if (e(cal.aarh.v) == false) goto L269;
     */
    /* JADX WARN: Code restructure failed: missing block: B:269:0x02d5, code lost:
    
        if (e(cal.aarh.v) == false) goto L269;
     */
    /* JADX WARN: Code restructure failed: missing block: B:276:0x02f8, code lost:
    
        if (e(cal.aarh.A) == false) goto L98;
     */
    /* JADX WARN: Code restructure failed: missing block: B:284:0x031b, code lost:
    
        if (e(cal.aarh.B) == false) goto L98;
     */
    /* JADX WARN: Code restructure failed: missing block: B:299:0x035f, code lost:
    
        if (e(r1) != false) goto L205;
     */
    /* JADX WARN: Code restructure failed: missing block: B:315:0x039a, code lost:
    
        if (e(r1) != false) goto L205;
     */
    /* JADX WARN: Code restructure failed: missing block: B:325:0x03c4, code lost:
    
        if (r3[r5 + 5] != 'u') goto L251;
     */
    /* JADX WARN: Code restructure failed: missing block: B:327:0x03d5, code lost:
    
        r17.L = r5 + 6;
     */
    /* JADX WARN: Code restructure failed: missing block: B:328:0x03dc, code lost:
    
        if (e(r1) == false) goto L98;
     */
    /* JADX WARN: Code restructure failed: missing block: B:331:0x03d2, code lost:
    
        if (r3[r5 + 5] == 's') goto L249;
     */
    /* JADX WARN: Code restructure failed: missing block: B:340:0x0401, code lost:
    
        if (e(r1) != false) goto L205;
     */
    /* JADX WARN: Code restructure failed: missing block: B:342:0x039e, code lost:
    
        if (r11 != '-') goto L98;
     */
    /* JADX WARN: Removed duplicated region for block: B:23:0x0556 A[LOOP:0: B:15:0x0415->B:23:0x0556, LOOP_END] */
    /* JADX WARN: Removed duplicated region for block: B:24:0x0458 A[EDGE_INSN: B:24:0x0458->B:25:0x0458 BREAK  A[LOOP:0: B:15:0x0415->B:23:0x0556], SYNTHETIC] */
    /* JADX WARN: Removed duplicated region for block: B:41:0x0487  */
    /* JADX WARN: Removed duplicated region for block: B:58:0x04c7  */
    /* JADX WARN: Removed duplicated region for block: B:70:0x050e  */
    /* JADX WARN: Removed duplicated region for block: B:76:0x0520  */
    /* JADX WARN: Removed duplicated region for block: B:78:0x053f  */
    /* JADX WARN: Removed duplicated region for block: B:81:0x0547  */
    /* JADX WARN: Removed duplicated region for block: B:82:0x0525  */
    /* JADX WARN: Removed duplicated region for block: B:87:0x051a A[SYNTHETIC] */
    /* JADX WARN: Removed duplicated region for block: B:98:0x0494  */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct code enable 'Show inconsistent code' option in preferences
    */
    private final void d(java.lang.String r18) {
        /*
            Method dump skipped, instructions count: 1379
            To view this dump change 'Code comments level' option to 'DEBUG'
        */
        throw new UnsupportedOperationException("Method not decompiled: cal.aarh.d(java.lang.String):void");
    }

    private final boolean e(char[] cArr) {
        int i2 = this.L;
        int length = cArr.length;
        if (i2 + length <= this.K) {
            int i3 = 0;
            while (i3 < length) {
                int i4 = i2 + 1;
                int i5 = i3 + 1;
                if (this.J[i2] == cArr[i3]) {
                    i3 = i5;
                    i2 = i4;
                }
            }
            this.L = i2;
            return true;
        }
        return false;
    }

    private final boolean f(int i2, char[] cArr) {
        int length = cArr.length;
        if (i2 + length > this.K) {
            return false;
        }
        for (int i3 = 0; i3 < length; i3++) {
            if (this.J[i2 + i3] != cArr[i3]) {
                return false;
            }
        }
        return true;
    }

    public final synchronized boolean a(String str) {
        d(str);
        return this.P;
    }

    /* JADX WARN: Code restructure failed: missing block: B:85:0x014c, code lost:
    
        r3.append(cal.aarh.I[r10]);
        r3.append('-');
     */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct code enable 'Show inconsistent code' option in preferences
    */
    public final synchronized java.lang.String b(java.lang.String r18, int r19, int r20, int r21, int r22, int r23) {
        /*
            Method dump skipped, instructions count: 499
            To view this dump change 'Code comments level' option to 'DEBUG'
        */
        throw new UnsupportedOperationException("Method not decompiled: cal.aarh.b(java.lang.String, int, int, int, int, int):java.lang.String");
    }
}
