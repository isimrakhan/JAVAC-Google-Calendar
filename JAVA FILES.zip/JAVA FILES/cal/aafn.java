package cal;

import java.util.Random;

/* compiled from: PG */
/* loaded from: classes2.dex */
public final class aafn implements aoax {
    public static aaga a(Random random, aafl aaflVar, aizu aizuVar) {
        random.getClass();
        return new aaga(random, aaflVar, aizuVar);
    }

    @Override // cal.apxs, cal.apxr
    public final /* bridge */ /* synthetic */ Object b() {
        throw null;
    }
}
