package cal;

import java.nio.ByteBuffer;

/* compiled from: PG */
/* loaded from: classes2.dex */
public final class aadh {
    public static volatile ahti a;
    private static volatile ahti b;

    public static boolean a(ByteBuffer byteBuffer, int i) {
        while (byteBuffer.hasRemaining()) {
            if (i > 0) {
                if (byteBuffer.get() == 32) {
                    i--;
                }
            } else {
                return true;
            }
        }
        if (i != 0) {
            return false;
        }
        return true;
    }
}
