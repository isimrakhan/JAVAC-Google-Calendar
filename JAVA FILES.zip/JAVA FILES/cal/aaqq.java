package cal;

/* compiled from: PG */
/* loaded from: classes2.dex */
public final class aaqq {
    public final long a;

    public aaqq(long j) {
        this.a = j;
    }

    public final boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if ((obj instanceof aaqq) && this.a == ((aaqq) obj).a) {
            return true;
        }
        return false;
    }

    public final int hashCode() {
        long j = this.a;
        return (int) (j ^ (j >>> 32));
    }

    public final String toString() {
        return "Instant(epochMillis=" + this.a + ")";
    }
}
