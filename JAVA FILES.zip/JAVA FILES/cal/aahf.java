package cal;

/* compiled from: PG */
/* loaded from: classes2.dex */
public final class aahf {
    public static final ahue a;
    public static final aahe b;
    public static final aahe c;
    public static final aahe d;

    static {
        ahue ahueVar = new ahue(new ahtw(new ahrr('/')), false, ahry.a);
        a = new ahue(ahueVar.c, true, ahueVar.a);
        b = new aahb();
        c = new aahc();
        d = new aahd();
    }

    public static void a(aahe aaheVar, amqs amqsVar) {
        String a2 = aaheVar.a(amqsVar);
        String b2 = aaheVar.b(amqsVar);
        if (a2.isEmpty() && !b2.isEmpty()) {
            aaheVar.c(amqsVar, ajvs.a(b2));
        } else {
            aaheVar.c(amqsVar, null);
        }
        aaheVar.d(amqsVar);
    }

    /* JADX WARN: Can't fix incorrect switch cases order, some code will duplicate */
    /* JADX WARN: Code restructure failed: missing block: B:11:0x0158, code lost:
    
        if (r1 == false) goto L124;
     */
    /* JADX WARN: Code restructure failed: missing block: B:24:0x00da, code lost:
    
        if (r0.equals("Attempt to do a synchronize operation on a null object") == false) goto L124;
     */
    /* JADX WARN: Code restructure failed: missing block: B:33:0x0102, code lost:
    
        if (java.util.regex.Pattern.matches("Conflicting default method implementations .+", r0) == false) goto L124;
     */
    /* JADX WARN: Code restructure failed: missing block: B:45:0x0134, code lost:
    
        if (java.util.regex.Pattern.matches("Method '.+' implementing interface method '.+' is not public", r0) == false) goto L124;
     */
    /* JADX WARN: Code restructure failed: missing block: B:80:0x01d2, code lost:
    
        if (java.util.regex.Pattern.matches(".*unmatched serializable field(s) declared", r0) == false) goto L124;
     */
    /* JADX WARN: Failed to find 'out' block for switch in B:9:0x0097. Please report as an issue. */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct code enable 'Show inconsistent code' option in preferences
    */
    public static final cal.aivp b(cal.aivp r7) {
        /*
            Method dump skipped, instructions count: 676
            To view this dump change 'Code comments level' option to 'DEBUG'
        */
        throw new UnsupportedOperationException("Method not decompiled: cal.aahf.b(cal.aivp):cal.aivp");
    }
}
