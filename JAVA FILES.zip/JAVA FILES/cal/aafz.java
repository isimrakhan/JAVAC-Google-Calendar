package cal;

import java.util.Random;

/* JADX INFO: Access modifiers changed from: package-private */
/* compiled from: PG */
/* loaded from: classes2.dex */
public final class aafz extends aagb {
    private final Random b;
    private final long c;
    private final aafl d;
    private final aizu e;

    public aafz(aqwl aqwlVar, Random random, aafl aaflVar, aizu aizuVar) {
        super(aqwlVar);
        this.b = random;
        this.c = aqwlVar.d;
        this.d = aaflVar;
        this.e = aizuVar;
    }

    @Override // cal.aagb
    public final long a(String str) {
        long j;
        if (str != null && !str.isEmpty()) {
            aafl aaflVar = this.d;
            long epochMilli = this.e.a().toEpochMilli() - aaflVar.d;
            char c = 0;
            if (epochMilli >= 14400000) {
                long j2 = epochMilli / 14400000;
                long min = Math.min(j2, 15L);
                for (int i = 0; i < 256; i++) {
                    short[] sArr = aaflVar.a;
                    int i2 = (int) min;
                    sArr[i] = (short) (sArr[i] >> i2);
                    short[] sArr2 = aaflVar.b;
                    sArr2[i] = (short) (sArr2[i] >> i2);
                }
                aaflVar.d += j2 * 14400000;
            }
            int hashCode = str.hashCode() * aaflVar.c;
            if (!str.isEmpty()) {
                c = str.charAt(0);
            }
            int i3 = ((hashCode >>> 24) + c) & 255;
            int length = ((hashCode >>> 16) + str.length()) & 255;
            int min2 = Math.min((int) aaflVar.a[i3], (int) aaflVar.b[length]);
            int i4 = min2 + 1;
            short min3 = (short) Math.min(32767, i4);
            short[] sArr3 = aaflVar.a;
            if (sArr3[i3] == min2) {
                sArr3[i3] = min3;
            }
            short[] sArr4 = aaflVar.b;
            if (sArr4[length] == min2) {
                sArr4[length] = min3;
            }
            j = (int) (this.c / (i4 < 50 ? Math.sqrt(i4) : i4));
        } else {
            j = this.c;
        }
        if (this.b.nextDouble() * 1000.0d < j) {
            return j;
        }
        return -1L;
    }

    @Override // cal.aagb
    public final aqwl b(Long l) {
        if (l != null) {
            if (l.longValue() != this.a.d) {
                aqwi aqwiVar = new aqwi();
                int a = aqwk.a(this.a.e);
                if (a == 0) {
                    a = 1;
                }
                if ((aqwiVar.b.ad & Integer.MIN_VALUE) == 0) {
                    aqwiVar.s();
                }
                aqwl aqwlVar = (aqwl) aqwiVar.b;
                aqwlVar.e = a - 1;
                aqwlVar.c |= 4;
                long longValue = l.longValue();
                if ((aqwiVar.b.ad & Integer.MIN_VALUE) == 0) {
                    aqwiVar.s();
                }
                aqwl aqwlVar2 = (aqwl) aqwiVar.b;
                aqwlVar2.c |= 2;
                aqwlVar2.d = longValue;
                return aqwiVar.p();
            }
        }
        return this.a;
    }

    @Override // cal.aagb
    public final aqwl c(Long l) {
        if (this.c > 0) {
            return b(l);
        }
        aqwl aqwlVar = this.a;
        aqwi aqwiVar = new aqwi();
        ampm ampmVar = aqwiVar.a;
        if (ampmVar != aqwlVar && (aqwlVar == null || ampmVar.getClass() != aqwlVar.getClass() || !amrc.a.a(ampmVar.getClass()).k(ampmVar, aqwlVar))) {
            if ((aqwiVar.b.ad & Integer.MIN_VALUE) == 0) {
                aqwiVar.s();
            }
            ampm ampmVar2 = aqwiVar.b;
            amrc.a.a(ampmVar2.getClass()).g(ampmVar2, aqwlVar);
        }
        if ((aqwiVar.b.ad & Integer.MIN_VALUE) == 0) {
            aqwiVar.s();
        }
        aqwl aqwlVar2 = (aqwl) aqwiVar.b;
        aqwl aqwlVar3 = aqwl.a;
        aqwlVar2.c |= 2;
        aqwlVar2.d = -1L;
        return aqwiVar.p();
    }

    @Override // cal.aagb
    public final boolean d() {
        if (this.c > 0) {
            return true;
        }
        return false;
    }
}
