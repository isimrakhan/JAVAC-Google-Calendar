package cal;

/* compiled from: PG */
/* loaded from: classes2.dex */
public abstract class aabd implements zun {
    public static final aabc h() {
        aaba aabaVar = new aaba();
        aabaVar.b = false;
        aabaVar.a = 50;
        aabaVar.d = (byte) 3;
        aabaVar.c = ahre.a;
        aabaVar.e = 1;
        return aabaVar;
    }

    @Override // cal.zun
    public final /* synthetic */ int a() {
        return Integer.MAX_VALUE;
    }

    @Override // cal.zun
    public final boolean b() {
        if (f() == 3) {
            return true;
        }
        return false;
    }

    public abstract int c();

    public abstract ahti d();

    public abstract boolean e();

    public abstract int f();

    public abstract void g();
}
