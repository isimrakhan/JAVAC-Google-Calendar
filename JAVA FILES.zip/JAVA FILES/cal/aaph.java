package cal;

/* compiled from: PG */
/* loaded from: classes2.dex */
public final class aaph {
    public Boolean b;
    public final aicf a = new aicf(4);
    private final aicf c = new aicf(4);

    public final aapi a() {
        aick aikmVar;
        aick aikmVar2;
        this.b.getClass();
        boolean booleanValue = this.b.booleanValue();
        aicf aicfVar = this.a;
        aicfVar.c = true;
        ailt ailtVar = aick.e;
        int i = aicfVar.b;
        if (i == 0) {
            aikmVar = aikm.b;
        } else {
            aikmVar = new aikm(aicfVar.a, i);
        }
        aicf aicfVar2 = this.c;
        aicfVar2.c = true;
        int i2 = aicfVar2.b;
        if (i2 == 0) {
            aikmVar2 = aikm.b;
        } else {
            aikmVar2 = new aikm(aicfVar2.a, i2);
        }
        return new aapi(booleanValue, aikmVar, aikmVar2);
    }
}
