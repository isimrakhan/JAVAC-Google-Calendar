package cal;

import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import com.google.android.libraries.performance.primes.transmitter.LifeboatReceiver;
import com.google.android.libraries.performance.primes.transmitter.clearcut.ClearcutMetricSnapshotTransmitter;
import java.io.IOException;
import java.util.concurrent.Executor;

/* compiled from: PG */
/* loaded from: classes2.dex */
public final class aagz implements aagi {
    public final Context a;
    public final ClearcutMetricSnapshotTransmitter b;
    private final ahum c;
    private final boolean d;
    private final aags e;

    public aagz(final Context context, ahti ahtiVar, aags aagsVar, ClearcutMetricSnapshotTransmitter clearcutMetricSnapshotTransmitter) {
        this.a = context;
        this.c = ahus.a(new ahum() { // from class: cal.aagy
            @Override // cal.ahum
            public final Object a() {
                return Boolean.valueOf(((aoxk) ((ahur) aoxj.a.b).a).b(context));
            }
        });
        this.d = ((Boolean) ((ahts) ahtiVar).a).booleanValue();
        this.e = aagsVar;
        this.b = clearcutMetricSnapshotTransmitter;
    }

    @Override // cal.aagi
    public final ajdo a(final aqyd aqydVar) {
        int i;
        if (this.d) {
            aqxa aqxaVar = aqydVar.j;
            if (aqxaVar == null) {
                aqxaVar = aqxa.a;
            }
            if ((aqxaVar.c & 1) != 0) {
                ajdo a = this.e.a();
                ahsr ahsrVar = new ahsr() { // from class: cal.aagx
                    /* JADX WARN: Multi-variable type inference failed */
                    @Override // cal.ahsr
                    /* renamed from: a */
                    public final Object b(Object obj) {
                        int i2;
                        aagg aaggVar = (aagg) obj;
                        aagf aagfVar = new aagf();
                        ampm ampmVar = aagfVar.a;
                        if (ampmVar != aaggVar && (aaggVar == null || ampmVar.getClass() != aaggVar.getClass() || !amrc.a.a(ampmVar.getClass()).k(ampmVar, aaggVar))) {
                            if ((aagfVar.b.ad & Integer.MIN_VALUE) == 0) {
                                aagfVar.s();
                            }
                            ampm ampmVar2 = aagfVar.b;
                            amrc.a.a(ampmVar2.getClass()).g(ampmVar2, aaggVar);
                        }
                        if ((aagfVar.b.ad & Integer.MIN_VALUE) == 0) {
                            aagfVar.s();
                        }
                        aqyd aqydVar2 = aqydVar;
                        aagz aagzVar = aagz.this;
                        aagg aaggVar2 = (aagg) aagfVar.b;
                        aagg aaggVar3 = aagg.a;
                        aqydVar2.getClass();
                        aaggVar2.d = aqydVar2;
                        aaggVar2.c |= 1;
                        aagg aaggVar4 = (aagg) aagfVar.p();
                        String[] strArr = {aagzVar.b.getClass().getName()};
                        Intent intent = new Intent();
                        Context context = aagzVar.a;
                        intent.setComponent(new ComponentName(context, (Class<?>) LifeboatReceiver.class));
                        intent.setPackage(context.getPackageName());
                        intent.putExtra("Transmitters", strArr);
                        try {
                            int i3 = aaggVar4.ad;
                            if ((i3 & Integer.MIN_VALUE) != 0) {
                                i2 = amrc.a.a(aaggVar4.getClass()).a(aaggVar4);
                                if (i2 < 0) {
                                    throw new IllegalStateException(a.f(i2, "serialized size must be non-negative, was "));
                                }
                            } else {
                                i2 = i3 & Integer.MAX_VALUE;
                                if (i2 == Integer.MAX_VALUE) {
                                    i2 = amrc.a.a(aaggVar4.getClass()).a(aaggVar4);
                                    if (i2 >= 0) {
                                        aaggVar4.ad = (Integer.MIN_VALUE & aaggVar4.ad) | i2;
                                    } else {
                                        throw new IllegalStateException(a.f(i2, "serialized size must be non-negative, was "));
                                    }
                                }
                            }
                            byte[] bArr = new byte[i2];
                            amoi amoiVar = new amoi(bArr, 0, i2);
                            amrk a2 = amrc.a.a(aaggVar4.getClass());
                            amol amolVar = amoiVar.g;
                            if (amolVar == null) {
                                amolVar = new amol(amoiVar);
                            }
                            a2.j(aaggVar4, amolVar);
                            if (amoiVar.a - amoiVar.b == 0) {
                                intent.putExtra("MetricSnapshot", bArr);
                                context.sendBroadcast(intent);
                                return null;
                            }
                            throw new IllegalStateException("Did not write as much data as expected.");
                        } catch (IOException e) {
                            throw new RuntimeException(a.t(aaggVar4, " to a byte array threw an IOException (should never happen)."), e);
                        }
                    }
                };
                Executor executor = ajbw.a;
                ajap ajapVar = new ajap(a, ahsrVar);
                executor.getClass();
                if (executor != ajbw.a) {
                    executor = new ajdt(executor, ajapVar);
                }
                a.d(ajapVar, executor);
                return ajapVar;
            }
        }
        if ((aqydVar.c & 1024) != 0 && ((Boolean) this.c.a()).booleanValue()) {
            aqyc aqycVar = new aqyc();
            ampm ampmVar = aqycVar.a;
            if (ampmVar != aqydVar && (aqydVar == null || ampmVar.getClass() != aqydVar.getClass() || !amrc.a.a(ampmVar.getClass()).k(ampmVar, aqydVar))) {
                if ((aqycVar.b.ad & Integer.MIN_VALUE) == 0) {
                    aqycVar.s();
                }
                ampm ampmVar2 = aqycVar.b;
                amrc.a.a(ampmVar2.getClass()).g(ampmVar2, aqydVar);
            }
            aqxm aqxmVar = aqydVar.m;
            if (aqxmVar == null) {
                aqxmVar = aqxm.a;
            }
            ampw<aqxk> ampwVar = aqxmVar.l;
            if (!ampwVar.isEmpty()) {
                aqxu aqxuVar = aqxu.a;
                aqxt aqxtVar = new aqxt();
                aqxk aqxkVar = null;
                for (aqxk aqxkVar2 : ampwVar) {
                    if (aqxkVar != null && (i = aqxkVar.f + 1) != aqxkVar2.e) {
                        if ((aqxtVar.b.ad & Integer.MIN_VALUE) == 0) {
                            aqxtVar.s();
                        }
                        aqxu aqxuVar2 = (aqxu) aqxtVar.b;
                        amps ampsVar = aqxuVar2.c;
                        if (!ampsVar.b()) {
                            int size = ampsVar.size();
                            aqxuVar2.c = ampsVar.c(size + size);
                        }
                        aqxuVar2.c.f(0);
                        if ((aqxtVar.b.ad & Integer.MIN_VALUE) == 0) {
                            aqxtVar.s();
                        }
                        aqxu aqxuVar3 = (aqxu) aqxtVar.b;
                        amps ampsVar2 = aqxuVar3.d;
                        if (!ampsVar2.b()) {
                            int size2 = ampsVar2.size();
                            aqxuVar3.d = ampsVar2.c(size2 + size2);
                        }
                        aqxuVar3.d.f(i);
                    }
                    int i2 = aqxkVar2.d;
                    if ((aqxtVar.b.ad & Integer.MIN_VALUE) == 0) {
                        aqxtVar.s();
                    }
                    aqxu aqxuVar4 = (aqxu) aqxtVar.b;
                    amps ampsVar3 = aqxuVar4.c;
                    if (!ampsVar3.b()) {
                        int size3 = ampsVar3.size();
                        aqxuVar4.c = ampsVar3.c(size3 + size3);
                    }
                    aqxuVar4.c.f(i2);
                    int i3 = aqxkVar2.e;
                    if ((aqxtVar.b.ad & Integer.MIN_VALUE) == 0) {
                        aqxtVar.s();
                    }
                    aqxu aqxuVar5 = (aqxu) aqxtVar.b;
                    amps ampsVar4 = aqxuVar5.d;
                    if (!ampsVar4.b()) {
                        int size4 = ampsVar4.size();
                        aqxuVar5.d = ampsVar4.c(size4 + size4);
                    }
                    aqxuVar5.d.f(i3);
                    aqxkVar = aqxkVar2;
                }
                if (aqxkVar != null && (aqxkVar.c & 4) != 0) {
                    int i4 = aqxkVar.f + 1;
                    if ((aqxtVar.b.ad & Integer.MIN_VALUE) == 0) {
                        aqxtVar.s();
                    }
                    aqxu aqxuVar6 = (aqxu) aqxtVar.b;
                    amps ampsVar5 = aqxuVar6.c;
                    if (!ampsVar5.b()) {
                        int size5 = ampsVar5.size();
                        aqxuVar6.c = ampsVar5.c(size5 + size5);
                    }
                    aqxuVar6.c.f(0);
                    if ((aqxtVar.b.ad & Integer.MIN_VALUE) == 0) {
                        aqxtVar.s();
                    }
                    aqxu aqxuVar7 = (aqxu) aqxtVar.b;
                    amps ampsVar6 = aqxuVar7.d;
                    if (!ampsVar6.b()) {
                        int size6 = ampsVar6.size();
                        aqxuVar7.d = ampsVar6.c(size6 + size6);
                    }
                    aqxuVar7.d.f(i4);
                }
                aqxl aqxlVar = new aqxl();
                ampm ampmVar3 = aqxlVar.a;
                if (ampmVar3 != aqxmVar && (aqxmVar == null || ampmVar3.getClass() != aqxmVar.getClass() || !amrc.a.a(ampmVar3.getClass()).k(ampmVar3, aqxmVar))) {
                    if ((aqxlVar.b.ad & Integer.MIN_VALUE) == 0) {
                        aqxlVar.s();
                    }
                    ampm ampmVar4 = aqxlVar.b;
                    amrc.a.a(ampmVar4.getClass()).g(ampmVar4, aqxmVar);
                }
                if ((aqxlVar.b.ad & Integer.MIN_VALUE) == 0) {
                    aqxlVar.s();
                }
                ((aqxm) aqxlVar.b).l = amrd.b;
                if ((aqxlVar.b.ad & Integer.MIN_VALUE) == 0) {
                    aqxlVar.s();
                }
                aqxm aqxmVar2 = (aqxm) aqxlVar.b;
                aqxu aqxuVar8 = (aqxu) aqxtVar.p();
                aqxuVar8.getClass();
                aqxmVar2.k = aqxuVar8;
                aqxmVar2.c |= 128;
                aqxmVar = (aqxm) aqxlVar.p();
            }
            if ((aqycVar.b.ad & Integer.MIN_VALUE) == 0) {
                aqycVar.s();
            }
            aqyd aqydVar2 = (aqyd) aqycVar.b;
            aqxmVar.getClass();
            aqydVar2.m = aqxmVar;
            aqydVar2.c |= 1024;
            aqydVar = (aqyd) aqycVar.p();
        }
        ajdo a2 = this.e.a();
        ajaz ajazVar = new ajaz() { // from class: cal.aagw
            /* JADX WARN: Multi-variable type inference failed */
            @Override // cal.ajaz
            public final ajdo a(Object obj) {
                aagg aaggVar = (aagg) obj;
                aagf aagfVar = new aagf();
                ampm ampmVar5 = aagfVar.a;
                if (ampmVar5 != aaggVar && (aaggVar == null || ampmVar5.getClass() != aaggVar.getClass() || !amrc.a.a(ampmVar5.getClass()).k(ampmVar5, aaggVar))) {
                    if ((aagfVar.b.ad & Integer.MIN_VALUE) == 0) {
                        aagfVar.s();
                    }
                    ampm ampmVar6 = aagfVar.b;
                    amrc.a.a(ampmVar6.getClass()).g(ampmVar6, aaggVar);
                }
                if ((aagfVar.b.ad & Integer.MIN_VALUE) == 0) {
                    aagfVar.s();
                }
                aagz aagzVar = aagz.this;
                aqyd aqydVar3 = aqydVar;
                aagg aaggVar2 = (aagg) aagfVar.b;
                aagg aaggVar3 = aagg.a;
                aqydVar3.getClass();
                aaggVar2.d = aqydVar3;
                aaggVar2.c |= 1;
                return aagzVar.b.a(aagzVar.a, (aagg) aagfVar.p());
            }
        };
        Executor executor2 = ajbw.a;
        int i5 = ajaq.c;
        executor2.getClass();
        ajao ajaoVar = new ajao(a2, ajazVar);
        if (executor2 != ajbw.a) {
            executor2 = new ajdt(executor2, ajaoVar);
        }
        a2.d(ajaoVar, executor2);
        return ajaoVar;
    }

    @Override // cal.aagi
    public final void b() {
    }
}
