package cal;

import android.content.Context;
import android.database.ContentObserver;
import android.os.Binder;
import android.util.Log;

/* JADX INFO: Access modifiers changed from: package-private */
/* compiled from: PG */
/* loaded from: classes2.dex */
public final class aahp implements aahn {
    public static aahp a;
    public final Context b;
    private final ContentObserver c;

    public aahp() {
        this.b = null;
        this.c = null;
    }

    /* JADX INFO: Access modifiers changed from: package-private */
    public static synchronized void c() {
        Context context;
        synchronized (aahp.class) {
            aahp aahpVar = a;
            if (aahpVar != null && (context = aahpVar.b) != null && aahpVar.c != null) {
                context.getContentResolver().unregisterContentObserver(a.c);
            }
            a = null;
        }
    }

    @Override // cal.aahn
    /* renamed from: b, reason: merged with bridge method [inline-methods] */
    public final String a(String str) {
        Context context = this.b;
        if (context != null && vvg.a(context)) {
            try {
                try {
                    try {
                        return vjl.a.c(this.b.getContentResolver(), str, null);
                    } catch (IllegalStateException e) {
                        e = e;
                        Log.e("GservicesLoader", "Unable to read GServices for: ".concat(String.valueOf(str)), e);
                        return null;
                    } catch (NullPointerException e2) {
                        e = e2;
                        Log.e("GservicesLoader", "Unable to read GServices for: ".concat(String.valueOf(str)), e);
                        return null;
                    }
                } catch (SecurityException unused) {
                    long clearCallingIdentity = Binder.clearCallingIdentity();
                    try {
                        return vjl.a.c(this.b.getContentResolver(), str, null);
                    } finally {
                        Binder.restoreCallingIdentity(clearCallingIdentity);
                    }
                }
            } catch (SecurityException e3) {
                e = e3;
                Log.e("GservicesLoader", "Unable to read GServices for: ".concat(String.valueOf(str)), e);
                return null;
            }
        }
        return null;
    }

    public aahp(Context context) {
        this.b = context;
        aaho aahoVar = new aaho();
        this.c = aahoVar;
        context.getContentResolver().registerContentObserver(vjm.a, true, aahoVar);
    }
}
