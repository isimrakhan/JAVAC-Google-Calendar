package cal;

import j$.util.concurrent.ConcurrentHashMap;

/* compiled from: PG */
/* loaded from: classes2.dex */
public final class aama {
    public final ahum a;
    public final ahum b;
    public final ConcurrentHashMap c = new ConcurrentHashMap();
    public final Object d = new Object();
    public volatile ajdo e = null;

    public aama(ahum ahumVar, ahum ahumVar2) {
        this.a = ahumVar;
        this.b = ahumVar2;
    }
}
