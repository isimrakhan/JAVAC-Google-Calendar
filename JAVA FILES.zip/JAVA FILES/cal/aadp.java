package cal;

/* compiled from: PG */
/* loaded from: classes2.dex */
public abstract class aadp implements zun {
    @Override // cal.zun
    public final /* synthetic */ int a() {
        return Integer.MAX_VALUE;
    }

    @Override // cal.zun
    public final boolean b() {
        if (e() == 3) {
            return true;
        }
        return false;
    }

    public abstract int c();

    public abstract aick d();

    public abstract int e();

    public abstract void f();
}
