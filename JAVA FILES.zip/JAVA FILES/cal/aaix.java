package cal;

import com.google.protobuf.InvalidProtocolBufferException;
import com.google.protobuf.UninitializedMessageException;
import java.io.IOException;
import java.io.InputStream;

/* compiled from: PG */
/* loaded from: classes2.dex */
public final class aaix extends ampm implements amqu {
    public static final aaix a;
    public static volatile amra b;
    public int c;
    public aaiw e;
    public String d = "";
    public String f = "";

    static {
        aaix aaixVar = new aaix();
        a = aaixVar;
        aaixVar.ad &= Integer.MAX_VALUE;
        ampm.ac.put(aaix.class, aaixVar);
    }

    public static aaix parseFrom(InputStream inputStream) {
        amof amoeVar;
        int i = amof.f;
        if (inputStream == null) {
            byte[] bArr = ampx.b;
            int length = bArr.length;
            amoeVar = new amoc(bArr, 0, 0);
            try {
                amoeVar.d(0);
            } catch (InvalidProtocolBufferException e) {
                throw new IllegalArgumentException(e);
            }
        } else {
            amoeVar = new amoe(inputStream, 4096);
        }
        amov amovVar = amov.a;
        amrc amrcVar = amrc.a;
        amov amovVar2 = amov.b;
        aaix aaixVar = new aaix();
        try {
            amrk a2 = amrc.a.a(aaixVar.getClass());
            amog amogVar = amoeVar.e;
            if (amogVar == null) {
                amogVar = new amog(amoeVar);
            }
            a2.h(aaixVar, amogVar, amovVar2);
            a2.f(aaixVar);
            Byte b2 = (byte) 1;
            b2.getClass();
            return aaixVar;
        } catch (InvalidProtocolBufferException e2) {
            if (e2.a) {
                throw new InvalidProtocolBufferException(e2);
            }
            throw e2;
        } catch (UninitializedMessageException e3) {
            throw new InvalidProtocolBufferException(e3.getMessage());
        } catch (IOException e4) {
            if (e4.getCause() instanceof InvalidProtocolBufferException) {
                throw ((InvalidProtocolBufferException) e4.getCause());
            }
            throw new InvalidProtocolBufferException(e4);
        } catch (RuntimeException e5) {
            if (e5.getCause() instanceof InvalidProtocolBufferException) {
                throw ((InvalidProtocolBufferException) e5.getCause());
            }
            throw e5;
        }
    }

    @Override // cal.ampm
    public final Object a(int i, Object obj) {
        int i2 = i - 1;
        if (i2 != 0) {
            if (i2 != 2) {
                if (i2 != 3) {
                    if (i2 != 4) {
                        if (i2 != 5) {
                            if (i2 != 6) {
                                return null;
                            }
                            amra amraVar = b;
                            if (amraVar == null) {
                                synchronized (aaix.class) {
                                    amraVar = b;
                                    if (amraVar == null) {
                                        amraVar = new amph(a);
                                        b = amraVar;
                                    }
                                }
                            }
                            return amraVar;
                        }
                        return a;
                    }
                    return new aaiu();
                }
                return new aaix();
            }
            return new amre(a, "\u0004\u0003\u0000\u0001\u0001\u0003\u0003\u0000\u0000\u0000\u0001ဈ\u0000\u0002ဉ\u0001\u0003ဈ\u0002", new Object[]{"c", "d", "e", "f"});
        }
        return (byte) 1;
    }
}
