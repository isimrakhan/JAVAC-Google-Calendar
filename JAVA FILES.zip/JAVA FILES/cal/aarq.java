package cal;

/* compiled from: PG */
/* loaded from: classes2.dex */
public final class aarq implements aarm {
    public final /* synthetic */ aarm a;

    public aarq(aarm aarmVar) {
        this.a = aarmVar;
    }
}
