package cal;

/* compiled from: PG */
/* loaded from: classes2.dex */
public final /* synthetic */ class aafr implements apxs {
    public final /* synthetic */ int a;

    @Override // cal.apxs, cal.apxr
    public final Object b() {
        return Integer.valueOf(this.a);
    }
}
