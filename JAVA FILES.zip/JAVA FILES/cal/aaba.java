package cal;

/* compiled from: PG */
/* loaded from: classes2.dex */
public final class aaba extends aabc {
    public int a;
    public boolean b;
    public ahti c = ahre.a;
    public byte d;
    public int e;

    @Override // cal.aabc
    public final aabc a(ahti ahtiVar) {
        this.c = ahtiVar;
        return this;
    }

    @Override // cal.aabc
    public final aabd b() {
        int i;
        if (this.d == 3 && (i = this.e) != 0) {
            return new aabb(i, this.a, this.b, this.c);
        }
        StringBuilder sb = new StringBuilder();
        if (this.e == 0) {
            sb.append(" enablement");
        }
        if ((this.d & 1) == 0) {
            sb.append(" batchSize");
        }
        if ((this.d & 2) == 0) {
            sb.append(" enableUrlAutoSanitization");
        }
        throw new IllegalStateException("Missing required properties:".concat(sb.toString()));
    }

    @Override // cal.aabc
    public final aabc c(int i) {
        this.e = i;
        return this;
    }

    @Override // cal.aabc
    public final void d() {
        this.b = true;
        this.d = (byte) (this.d | 2);
    }
}
