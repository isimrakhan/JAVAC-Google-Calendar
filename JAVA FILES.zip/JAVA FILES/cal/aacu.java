package cal;

import android.os.Build;
import android.os.Handler;
import android.os.Process;
import android.os.SystemClock;
import android.os.Trace;
import android.view.View;
import android.view.ViewTreeObserver;
import com.google.android.libraries.stitch.util.ThreadUtil$CalledOnWrongThreadException;
import java.util.concurrent.atomic.AtomicReference;

/* JADX INFO: Access modifiers changed from: package-private */
/* compiled from: PG */
/* loaded from: classes2.dex */
public final class aacu implements ViewTreeObserver.OnDrawListener {
    public static final /* synthetic */ int b = 0;
    final /* synthetic */ aacy a;
    private final AtomicReference c;

    public aacu(aacy aacyVar, View view) {
        this.a = aacyVar;
        this.c = new AtomicReference(view);
    }

    @Override // android.view.ViewTreeObserver.OnDrawListener
    public final void onDraw() {
        final View view = (View) this.c.getAndSet(null);
        if (view != null) {
            try {
                Handler a = abyh.a();
                final aacy aacyVar = this.a;
                a.postAtFrontOfQueue(new Runnable() { // from class: cal.aacr
                    @Override // java.lang.Runnable
                    public final void run() {
                        int i = aacu.b;
                        if (abyh.b(Thread.currentThread())) {
                            aacy aacyVar2 = aacy.this;
                            if (aacyVar2.b.m != null) {
                                return;
                            }
                            aacyVar2.b.m = new zvs(SystemClock.elapsedRealtime(), SystemClock.uptimeMillis());
                            return;
                        }
                        throw new ThreadUtil$CalledOnWrongThreadException("Must be called on the main thread");
                    }
                });
                final aacy aacyVar2 = this.a;
                abyh.a().post(new Runnable() { // from class: cal.aacs
                    @Override // java.lang.Runnable
                    public final void run() {
                        long startElapsedRealtime;
                        int i = aacu.b;
                        if (abyh.b(Thread.currentThread())) {
                            aacy aacyVar3 = aacy.this;
                            if (aacyVar3.b.n != null) {
                                return;
                            }
                            aacyVar3.b.n = new zvs(SystemClock.elapsedRealtime(), SystemClock.uptimeMillis());
                            long j = ((zvs) aacyVar3.b.n).a;
                            if (Build.VERSION.SDK_INT >= 29) {
                                startElapsedRealtime = Process.getStartElapsedRealtime();
                                Trace.setCounter("Primes-ttfdd-end-and-length-ms", j - startElapsedRealtime);
                                Trace.setCounter("Primes-ttfdd-end-and-length-ms", 0L);
                            }
                            aacyVar3.a.unregisterActivityLifecycleCallbacks(aacyVar3);
                            return;
                        }
                        throw new ThreadUtil$CalledOnWrongThreadException("Must be called on the main thread");
                    }
                });
                abyh.a().post(new Runnable() { // from class: cal.aact
                    @Override // java.lang.Runnable
                    public final void run() {
                        view.getViewTreeObserver().removeOnDrawListener(aacu.this);
                    }
                });
            } catch (RuntimeException unused) {
            }
        }
    }
}
