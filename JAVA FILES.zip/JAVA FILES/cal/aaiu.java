package cal;

/* compiled from: PG */
/* loaded from: classes2.dex */
public final class aaiu extends ampg implements amqu {
    public aaiu() {
        super(aaix.a);
    }
}
