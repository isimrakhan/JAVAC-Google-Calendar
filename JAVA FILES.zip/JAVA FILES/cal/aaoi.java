package cal;

import android.app.Activity;

/* compiled from: PG */
/* loaded from: classes2.dex */
public final /* synthetic */ class aaoi {
    public final /* synthetic */ Activity a;
}
