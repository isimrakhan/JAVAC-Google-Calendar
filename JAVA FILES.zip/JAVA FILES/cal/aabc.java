package cal;

/* compiled from: PG */
/* loaded from: classes2.dex */
public abstract class aabc {
    public abstract aabc a(ahti ahtiVar);

    public abstract aabd b();

    public abstract aabc c(int i);

    public abstract void d();

    public final aabc e(boolean z) {
        int i;
        if (true != z) {
            i = 2;
        } else {
            i = 3;
        }
        return c(i);
    }

    public final aabc f(aabg aabgVar) {
        return a(new ahts(aabgVar));
    }
}
