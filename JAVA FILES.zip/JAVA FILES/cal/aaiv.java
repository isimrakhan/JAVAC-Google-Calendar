package cal;

/* compiled from: PG */
/* loaded from: classes2.dex */
public final class aaiv extends ampg implements amqu {
    public aaiv() {
        super(aaiw.a);
    }
}
