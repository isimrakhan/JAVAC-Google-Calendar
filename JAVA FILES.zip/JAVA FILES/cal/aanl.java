package cal;

import j$.util.DesugarCollections;
import java.util.Collection;
import java.util.HashMap;
import java.util.NoSuchElementException;

/* JADX INFO: Access modifiers changed from: package-private */
/* compiled from: PG */
/* loaded from: classes2.dex */
public final class aanl {
    public final aano a;
    public final aajt b;
    public final aics c;
    public final aaiw d;

    /* JADX WARN: Multi-variable type inference failed */
    public aanl(aano aanoVar, aajt aajtVar, aaiw aaiwVar) {
        boolean z;
        boolean z2;
        String str;
        aajp aajpVar;
        aics d;
        aics d2;
        long j;
        char c;
        double d3;
        amob amobVar;
        byte[] bArr;
        String str2;
        boolean z3;
        long j2;
        String str3;
        boolean z4;
        boolean z5;
        String str4;
        long longValue;
        int i;
        long j3;
        boolean z6;
        double d4;
        String str5;
        amob amobVar2;
        byte[] bArr2;
        aanl aanlVar = this;
        int i2 = 1;
        if (aanoVar != null) {
            z = true;
        } else {
            z = false;
        }
        if (aajtVar != null) {
            z2 = true;
        } else {
            z2 = false;
        }
        if (z ^ z2) {
            aanlVar.a = aanoVar;
            aanlVar.b = aajtVar;
            aanlVar.d = aaiwVar;
            String str6 = "__phenotype_configuration_version";
            int i3 = 5;
            int i4 = 2;
            if (aanoVar != null) {
                int size = aanoVar.h.size() + 3;
                ahzj.b(size, "expectedSize");
                aico aicoVar = new aico(size);
                for (aanq aanqVar : aanoVar.h) {
                    int i5 = aanqVar.d;
                    if (i5 != 0) {
                        if (i5 != 2) {
                            if (i5 != 3) {
                                if (i5 != 4) {
                                    if (i5 != i3) {
                                        if (i5 != 6) {
                                            i = 0;
                                        } else {
                                            i = i3;
                                        }
                                    } else {
                                        i = 4;
                                    }
                                } else {
                                    i = 3;
                                }
                            } else {
                                i = 2;
                            }
                        } else {
                            i = i2;
                        }
                    } else {
                        i = 6;
                    }
                    int i6 = i - 1;
                    if (i != 0) {
                        if (i6 != 0) {
                            if (i6 != i2) {
                                if (i6 != 2) {
                                    if (i6 != 3) {
                                        if (i6 != 4) {
                                            i3 = 5;
                                        } else {
                                            String str7 = aanqVar.f;
                                            if (i5 == 6) {
                                                amobVar2 = (amob) aanqVar.e;
                                            } else {
                                                amobVar2 = amob.b;
                                            }
                                            int d5 = amobVar2.d();
                                            if (d5 == 0) {
                                                bArr2 = ampx.b;
                                            } else {
                                                byte[] bArr3 = new byte[d5];
                                                amobVar2.e(bArr3, 0, 0, d5);
                                                bArr2 = bArr3;
                                            }
                                            aicoVar.f(str7, bArr2);
                                        }
                                    } else {
                                        String str8 = aanqVar.f;
                                        if (i5 != 5) {
                                            str5 = "";
                                        } else {
                                            str5 = (String) aanqVar.e;
                                        }
                                        aicoVar.f(str8, str5);
                                    }
                                } else {
                                    String str9 = aanqVar.f;
                                    if (i5 == 4) {
                                        d4 = ((Double) aanqVar.e).doubleValue();
                                    } else {
                                        d4 = 0.0d;
                                    }
                                    aicoVar.f(str9, Double.valueOf(d4));
                                }
                            } else {
                                String str10 = aanqVar.f;
                                if (i5 == 3) {
                                    z6 = ((Boolean) aanqVar.e).booleanValue();
                                } else {
                                    z6 = false;
                                }
                                aicoVar.f(str10, Boolean.valueOf(z6));
                            }
                        } else {
                            String str11 = aanqVar.f;
                            if (i5 == 2) {
                                j3 = ((Long) aanqVar.e).longValue();
                            } else {
                                j3 = 0;
                            }
                            aicoVar.f(str11, Long.valueOf(j3));
                        }
                        i2 = 1;
                        i3 = 5;
                    } else {
                        throw null;
                    }
                }
                aicoVar.f("__phenotype_server_token", aanoVar.f);
                aicoVar.f("__phenotype_snapshot_token", aanoVar.d);
                aicoVar.f("__phenotype_configuration_version", Long.valueOf(aanoVar.g));
                d = aicoVar.d(false);
            } else {
                aajtVar.getClass();
                if (aajtVar.c.g.size() <= 0) {
                    str = "__phenotype_configuration_version";
                    aajpVar = aajtVar.b;
                } else {
                    aajpVar = aajtVar.b;
                    Collection<aajc> values = DesugarCollections.unmodifiableMap(aajtVar.c.g).values();
                    if (values == null) {
                        d2 = aikr.e;
                    } else {
                        aico aicoVar2 = new aico(4);
                        for (aajc aajcVar : values) {
                            int i7 = aajcVar.d;
                            int a = aajb.a(i7);
                            int i8 = a - 1;
                            if (a != 0) {
                                if (i8 != 0) {
                                    if (i8 != 1) {
                                        if (i8 != i4) {
                                            if (i8 != 3) {
                                                if (i8 == 4) {
                                                    String str12 = aajcVar.f;
                                                    if (i7 == 5) {
                                                        amobVar = (amob) aajcVar.e;
                                                    } else {
                                                        amobVar = amob.b;
                                                    }
                                                    int d6 = amobVar.d();
                                                    if (d6 == 0) {
                                                        bArr = ampx.b;
                                                    } else {
                                                        byte[] bArr4 = new byte[d6];
                                                        amobVar.e(bArr4, 0, 0, d6);
                                                        bArr = bArr4;
                                                    }
                                                    aicoVar2.f(str12, bArr);
                                                    i4 = 2;
                                                } else {
                                                    throw new IllegalStateException("Could not serialize Flag for override: ".concat(String.valueOf(aajcVar.f)));
                                                }
                                            } else {
                                                String str13 = aajcVar.f;
                                                c = 4;
                                                if (i7 != 4) {
                                                    str2 = "";
                                                } else {
                                                    str2 = (String) aajcVar.e;
                                                }
                                                aicoVar2.f(str13, str2);
                                            }
                                        } else {
                                            c = 4;
                                            String str14 = aajcVar.f;
                                            if (i7 == 3) {
                                                d3 = ((Double) aajcVar.e).doubleValue();
                                            } else {
                                                d3 = 0.0d;
                                            }
                                            aicoVar2.f(str14, Double.valueOf(d3));
                                        }
                                        i4 = 2;
                                    } else {
                                        String str15 = aajcVar.f;
                                        if (i7 == 2) {
                                            z3 = ((Boolean) aajcVar.e).booleanValue();
                                        } else {
                                            z3 = false;
                                        }
                                        aicoVar2.f(str15, Boolean.valueOf(z3));
                                        i4 = 2;
                                    }
                                } else {
                                    int i9 = i4;
                                    String str16 = aajcVar.f;
                                    if (i7 == 1) {
                                        j = ((Long) aajcVar.e).longValue();
                                    } else {
                                        j = 0;
                                    }
                                    aicoVar2.f(str16, Long.valueOf(j));
                                    i4 = i9;
                                }
                            } else {
                                throw null;
                            }
                        }
                        d2 = aicoVar2.d(false);
                    }
                    if (((aikr) d2).h == 0) {
                        str = "__phenotype_configuration_version";
                    } else {
                        HashMap hashMap = new HashMap(d2);
                        aiec aiecVar = new aiec(aika.a);
                        ails it = aajpVar.b.iterator();
                        while (true) {
                            ahww ahwwVar = (ahww) it;
                            int i10 = ahwwVar.a;
                            int i11 = ahwwVar.b;
                            if (i11 < i10) {
                                if (i11 < i10) {
                                    ahwwVar.b = i11 + 1;
                                    aajo aajoVar = (aajo) ((aicg) it).c.get(i11);
                                    String str17 = aajoVar.b;
                                    Object remove = hashMap.remove(str17 == null ? Long.toString(aajoVar.a) : str17);
                                    if (remove != null) {
                                        if (!(remove instanceof String) && !(remove instanceof byte[])) {
                                            if (remove instanceof Boolean) {
                                                if (((Boolean) remove).booleanValue()) {
                                                    str4 = str6;
                                                    aiecVar.k(new aajo(aajoVar.a, aajoVar.b, 1, aajoVar.d, aajoVar.e));
                                                } else {
                                                    str4 = str6;
                                                    aiecVar.k(new aajo(aajoVar.a, aajoVar.b, 0, aajoVar.d, aajoVar.e));
                                                }
                                            } else {
                                                str4 = str6;
                                                if (!(remove instanceof Long)) {
                                                    if (remove instanceof Double) {
                                                        longValue = Double.doubleToRawLongBits(((Double) remove).doubleValue());
                                                    } else {
                                                        String str18 = aajoVar.b;
                                                        throw new IllegalStateException("Cannot serialize override for existing flag " + (str18 == null ? Long.toString(aajoVar.a) : str18) + ": " + remove.toString());
                                                    }
                                                } else {
                                                    longValue = ((Long) remove).longValue();
                                                }
                                                aiecVar.k(new aajo(aajoVar.a, aajoVar.b, aajoVar.c, longValue, aajoVar.e));
                                            }
                                            str6 = str4;
                                        } else {
                                            aiecVar.k(new aajo(aajoVar.a, aajoVar.b, aajoVar.c, aajoVar.d, remove));
                                            str6 = str6;
                                            it = it;
                                        }
                                    } else {
                                        aiecVar.k(aajoVar);
                                    }
                                } else {
                                    throw new NoSuchElementException();
                                }
                            } else {
                                str = str6;
                                for (String str19 : hashMap.keySet()) {
                                    Object obj = hashMap.get(str19);
                                    int length = str19.length();
                                    if (length <= 19 && length != 0) {
                                        long charAt = str19.charAt(0) - '0';
                                        if (charAt >= 1 && charAt <= 9) {
                                            int i12 = 1;
                                            while (true) {
                                                if (i12 < length) {
                                                    int charAt2 = str19.charAt(i12) - '0';
                                                    if (charAt2 < 0) {
                                                        z4 = true;
                                                    } else {
                                                        z4 = false;
                                                    }
                                                    if (charAt2 > 9) {
                                                        z5 = true;
                                                    } else {
                                                        z5 = false;
                                                    }
                                                    if (z4 || z5) {
                                                        break;
                                                    }
                                                    charAt = (charAt * 10) + charAt2;
                                                    i12++;
                                                    length = length;
                                                } else if (charAt >= 0 && charAt <= 2305843009213693951L) {
                                                    j2 = charAt;
                                                }
                                            }
                                        }
                                    }
                                    j2 = 0;
                                    if (j2 == 0) {
                                        str3 = str19;
                                    } else {
                                        str3 = null;
                                    }
                                    if (obj instanceof String) {
                                        aiecVar.k(new aajo(j2, str3, 4, 0L, obj));
                                    } else if (obj instanceof byte[]) {
                                        aiecVar.k(new aajo(j2, str3, 5, 0L, obj));
                                    } else if (obj instanceof Boolean) {
                                        if (((Boolean) obj).booleanValue()) {
                                            aiecVar.k(new aajo(j2, str3, 1, 0L, null));
                                        } else {
                                            aiecVar.k(new aajo(j2, str3, 0, 0L, null));
                                        }
                                    } else if (obj instanceof Long) {
                                        aiecVar.k(new aajo(j2, str3, 2, ((Long) obj).longValue(), null));
                                    } else if (obj instanceof Double) {
                                        aiecVar.k(new aajo(j2, str3, 3, Double.doubleToRawLongBits(((Double) obj).doubleValue()), null));
                                    } else {
                                        throw new IllegalStateException(a.r(obj, str19, "Cannot serialize override ", ": "));
                                    }
                                }
                                aiee a2 = aiee.a(aiecVar.e, aiecVar.b, aiecVar.a);
                                aiecVar.b = ((aikw) a2).f.size();
                                aiecVar.c = true;
                                aajpVar = new aajp(a2);
                            }
                        }
                    }
                }
                int size2 = ((aikw) aajpVar.b).f.size() + 3;
                ahzj.b(size2, "expectedSize");
                aico aicoVar3 = new aico(size2);
                ails it2 = aajpVar.b.iterator();
                while (true) {
                    ahww ahwwVar2 = (ahww) it2;
                    int i13 = ahwwVar2.a;
                    int i14 = ahwwVar2.b;
                    if (i14 < i13) {
                        if (i14 < i13) {
                            ahwwVar2.b = i14 + 1;
                            aajo aajoVar2 = (aajo) ((aicg) it2).c.get(i14);
                            String str20 = aajoVar2.b;
                            if (str20 == null) {
                                str20 = Long.toString(aajoVar2.a);
                            }
                            aicoVar3.f(str20, aajoVar2.a());
                        } else {
                            throw new NoSuchElementException();
                        }
                    } else {
                        aicoVar3.f("__phenotype_server_token", aajtVar.c.e);
                        aicoVar3.f("__phenotype_snapshot_token", aajtVar.c.c);
                        aicoVar3.f(str, Long.valueOf(aajtVar.c.f));
                        d = aicoVar3.d(false);
                        aanlVar = this;
                        break;
                    }
                }
            }
            aanlVar.c = d;
            return;
        }
        throw new IllegalStateException();
    }

    /* JADX INFO: Access modifiers changed from: package-private */
    public final String a() {
        aano aanoVar = this.a;
        if (aanoVar != null) {
            return aanoVar.d;
        }
        aajt aajtVar = this.b;
        aajtVar.getClass();
        return aajtVar.c.c;
    }
}
