package cal;

/* compiled from: PG */
/* loaded from: classes2.dex */
public final class aaik extends aaip {
    public aaik(aain aainVar, String str, String str2) {
        super(aainVar, str, str2, true);
    }

    @Override // cal.aaip
    public final /* synthetic */ Object a(Object obj) {
        if (obj instanceof String) {
            return (String) obj;
        }
        return null;
    }
}
