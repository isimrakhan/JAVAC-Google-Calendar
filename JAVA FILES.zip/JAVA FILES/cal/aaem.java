package cal;

/* compiled from: PG */
/* loaded from: classes2.dex */
public final class aaem extends aaew {
    private final aaev a;

    public aaem(aaev aaevVar) {
        this.a = aaevVar;
    }

    @Override // cal.aaew, cal.zun
    public final int a() {
        return 10;
    }

    @Override // cal.aaew
    public final aaev c() {
        return this.a;
    }

    public final boolean equals(Object obj) {
        if (obj == this) {
            return true;
        }
        if (obj instanceof aaew) {
            aaew aaewVar = (aaew) obj;
            aaewVar.e();
            aaewVar.a();
            if (this.a.equals(aaewVar.c())) {
                aaewVar.f();
                aaewVar.d();
                return true;
            }
        }
        return false;
    }

    public final int hashCode() {
        return ((((this.a.hashCode() ^ 2032656219) * 1000003) ^ 1231) * 1000003) ^ 1237;
    }

    public final String toString() {
        return "TikTokTraceConfigurations{enablement=EXPLICITLY_DISABLED, rateLimitPerSecond=10, dynamicSampler=" + this.a.toString() + ", recordTimerDuration=true, sendEmptyTraces=false}";
    }

    @Override // cal.aaew
    public final void d() {
    }

    @Override // cal.aaew
    public final void e() {
    }

    @Override // cal.aaew
    public final void f() {
    }
}
