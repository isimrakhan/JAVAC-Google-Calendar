package cal;

import android.graphics.drawable.Drawable;
import androidx.cardview.widget.CardView;

/* compiled from: PG */
/* loaded from: classes.dex */
public final class aap {
    public Drawable a;
    public final /* synthetic */ CardView b;

    public aap(CardView cardView) {
        this.b = cardView;
    }

    public final void a(int i, int i2, int i3, int i4) {
        this.b.d.set(i, i2, i3, i4);
        super/*android.widget.FrameLayout*/.setPadding(i + this.b.c.left, i2 + this.b.c.top, i3 + this.b.c.right, i4 + this.b.c.bottom);
    }
}
