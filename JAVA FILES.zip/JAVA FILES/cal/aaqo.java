package cal;

import android.content.Context;

/* compiled from: PG */
/* loaded from: classes2.dex */
public final class aaqo {
    public final Context a;

    public aaqo(Context context) {
        this.a = context;
    }
}
