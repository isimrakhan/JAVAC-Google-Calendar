package cal;

import android.R;

/* compiled from: PG */
/* loaded from: classes.dex */
public final class aao {
    public static final int[] a = {R.attr.minWidth, R.attr.minHeight, com.google.android.calendar.R.attr.cardBackgroundColor, com.google.android.calendar.R.attr.cardCornerRadius, com.google.android.calendar.R.attr.cardElevation, com.google.android.calendar.R.attr.cardMaxElevation, com.google.android.calendar.R.attr.cardPreventCornerOverlap, com.google.android.calendar.R.attr.cardUseCompatPadding, com.google.android.calendar.R.attr.contentPadding, com.google.android.calendar.R.attr.contentPaddingBottom, com.google.android.calendar.R.attr.contentPaddingLeft, com.google.android.calendar.R.attr.contentPaddingRight, com.google.android.calendar.R.attr.contentPaddingTop};
}
