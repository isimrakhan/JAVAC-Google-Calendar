package cal;

import java.io.Serializable;
import java.util.Locale;

/* compiled from: PG */
/* loaded from: classes2.dex */
public class aapm implements Serializable {
    private static final long serialVersionUID = 1;
    public final aapp a;

    public aapm(aapp aappVar) {
        this.a = aappVar;
    }

    public boolean equals(Object obj) {
        if (obj != null && getClass() == obj.getClass()) {
            return this.a.equals(((aapm) obj).a);
        }
        return false;
    }

    public int hashCode() {
        return this.a.a + 1054;
    }

    public String toString() {
        return String.format(Locale.US, "VisualElement {tag: %s}", this.a);
    }
}
