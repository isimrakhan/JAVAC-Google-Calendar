package cal;

import androidx.appsearch.exceptions.AppSearchException;
import com.google.android.libraries.social.connections.schema.InteractionsDocument;
import java.util.List;
import java.util.concurrent.Executor;

/* compiled from: PG */
/* loaded from: classes2.dex */
final class aaqi implements ajaz {
    private final Executor a;
    private final aicf b = new aicf(4);
    private final yd c;

    public aaqi(yd ydVar, Executor executor) {
        this.c = ydVar;
        this.a = executor;
    }

    @Override // cal.ajaz
    public final /* synthetic */ ajdo a(Object obj) {
        ajdo ajdiVar;
        aick aikmVar;
        List<xn> list = (List) obj;
        try {
            for (xn xnVar : list) {
                aicf aicfVar = this.b;
                try {
                    if (xnVar.b == null) {
                        xnVar.b = new wy(xnVar.a);
                    }
                    aicfVar.f((InteractionsDocument) wv.b().a(InteractionsDocument.class).fromGenericDocument(xnVar.b, null));
                } catch (AppSearchException e) {
                    throw new IllegalStateException(e);
                }
            }
        } catch (RuntimeException e2) {
            ajdiVar = new ajdi(e2);
        }
        if (list.isEmpty()) {
            this.c.a.close();
            aicf aicfVar2 = this.b;
            aicfVar2.c = true;
            ailt ailtVar = aick.e;
            int i = aicfVar2.b;
            if (i == 0) {
                aikmVar = aikm.b;
            } else {
                aikmVar = new aikm(aicfVar2.a, i);
            }
            if (aikmVar == null) {
                return ajdj.a;
            }
            ajdiVar = new ajdj(aikmVar);
            return ajdiVar;
        }
        yd ydVar = this.c;
        ace aceVar = new ace();
        ydVar.a.getNextPage(ydVar.c, new yc(ydVar, aceVar));
        afxe afxeVar = new afxe(aceVar);
        Executor executor = this.a;
        int i2 = afwy.a;
        afwi afwiVar = (afwi) afvq.d.get();
        afwk afwkVar = afwiVar.b;
        if (afwkVar == null) {
            afwkVar = afvv.h(afwiVar);
        }
        ajdo ajdoVar = afxeVar.b;
        ajao ajaoVar = new ajao(ajdoVar, new afwt(afwkVar, this));
        if (executor != ajbw.a) {
            executor = new ajdt(executor, ajaoVar);
        }
        ajdoVar.d(ajaoVar, executor);
        return new afxe(ajaoVar);
    }
}
