package cal;

import android.content.Context;
import android.os.Handler;
import java.util.concurrent.Executor;
import java.util.concurrent.Executors;
import java.util.concurrent.Future;
import java.util.concurrent.TimeUnit;

/* compiled from: PG */
/* loaded from: classes2.dex */
public final class aabz extends aabs implements ztq {
    public final Context a;
    public final ajds b;
    public final anyt c;
    public final Handler d;
    public final zwf e;
    public final ztw f;
    public final aace h;
    private final Executor k;
    private final apxs l;
    public volatile boolean g = false;
    public final Object i = new Object();
    public volatile aacd j = null;

    public aabz(Context context, Executor executor, ajds ajdsVar, anyt anytVar, zwg zwgVar, aace aaceVar, ztw ztwVar, apxs apxsVar, Handler handler) {
        this.a = context;
        this.b = ajdsVar;
        this.k = executor;
        this.c = anytVar;
        this.l = apxsVar;
        this.d = handler;
        this.f = ztwVar;
        this.h = aaceVar;
        this.e = zwgVar.a(ajdsVar, anytVar, apxsVar);
    }

    public final void a() {
        if (this.e.a(null) != -1) {
            if (((aabr) this.c.b()).g().isEmpty()) {
                ((aimj) ((aimj) zsj.a.d()).k("com/google/android/libraries/performance/primes/metrics/stall/StallMetricServiceImpl", "readConfigsAndMaybeStart", 181, "StallMetricServiceImpl.java")).t("Stall thresholds list expected to have size > 0, was %s", ((aabr) this.c.b()).g().size());
                return;
            } else {
                this.b.schedule(new Runnable() { // from class: cal.aabt
                    @Override // java.lang.Runnable
                    public final void run() {
                        aabz aabzVar = aabz.this;
                        aabr aabrVar = (aabr) aabzVar.c.b();
                        aace aaceVar = aabzVar.h;
                        ((vui) aaceVar.a.b()).getClass();
                        aoaw aoawVar = (aoaw) aaceVar.b;
                        Object obj = aoawVar.b;
                        if (obj == aoaw.a) {
                            obj = aoawVar.c();
                        }
                        ajds ajdsVar = (ajds) obj;
                        ajdsVar.getClass();
                        aabrVar.getClass();
                        aabzVar.j = new aacd(ajdsVar, aabrVar, aabzVar.e, aabzVar.d);
                        if (aabzVar.g) {
                            aabzVar.j.b();
                        }
                    }
                }, ((aabr) this.c.b()).d(), TimeUnit.MILLISECONDS);
                return;
            }
        }
        synchronized (this.i) {
            this.f.c.b.remove(this);
        }
    }

    @Override // cal.ztq
    public final void i(zry zryVar) {
        this.g = false;
        if (this.j == null) {
            return;
        }
        this.b.execute(new ajel(Executors.callable(new Runnable() { // from class: cal.aaby
            @Override // java.lang.Runnable
            public final void run() {
                aabz aabzVar = aabz.this;
                aabzVar.j.getClass();
                aacd aacdVar = aabzVar.j;
                if (aacdVar.g && aacdVar.h.get() != null) {
                    aacdVar.g = false;
                    ((Future) aacdVar.h.get()).cancel(false);
                }
            }
        }, null)));
    }

    @Override // cal.ztq
    public final void j(zry zryVar) {
        this.g = true;
        if (this.j == null) {
            return;
        }
        this.b.execute(new ajel(Executors.callable(new Runnable() { // from class: cal.aabx
            @Override // java.lang.Runnable
            public final void run() {
                aabz aabzVar = aabz.this;
                if (aabzVar.e.a(null) == -1) {
                    synchronized (aabzVar.i) {
                        aabzVar.f.c.b.remove(aabzVar);
                    }
                } else {
                    aabzVar.j.getClass();
                    aabzVar.j.b();
                }
            }
        }, null)));
    }

    @Override // cal.aabs, cal.zwh
    public final void u() {
        Boolean bool = Boolean.FALSE;
        bool.getClass();
        if (bool.booleanValue()) {
            aqwl aqwlVar = (aqwl) this.l.b();
            int a = aqwk.a(aqwlVar.e);
            if (a != 0 && a == 4 && aqwlVar.d == 0) {
                return;
            }
        }
        this.f.c.b.add(this);
        this.k.execute(new ajel(Executors.callable(new Runnable() { // from class: cal.aabv
            @Override // java.lang.Runnable
            public final void run() {
                aabz aabzVar = aabz.this;
                if (vvg.a(aabzVar.a)) {
                    aabzVar.a();
                    return;
                }
                Context context = aabzVar.a;
                aabu aabuVar = new aabu(aabzVar);
                if (vvg.a(context)) {
                    aabz aabzVar2 = aabuVar.a;
                    aabzVar2.b.execute(new ajel(Executors.callable(new aabw(aabzVar2), null)));
                    ajdo ajdoVar = ajdj.a;
                    return;
                }
                aca.a(new vvd(context, aabuVar));
            }
        }, null)));
    }
}
