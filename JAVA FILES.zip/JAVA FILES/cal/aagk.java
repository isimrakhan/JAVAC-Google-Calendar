package cal;

/* compiled from: PG */
/* loaded from: classes2.dex */
public interface aagk {
    public static final aagk a = new aagk() { // from class: cal.aagj
    };
}
