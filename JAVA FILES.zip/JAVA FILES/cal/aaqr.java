package cal;

import java.io.File;

/* compiled from: PG */
/* loaded from: classes2.dex */
public final class aaqr implements Comparable {
    public final File a;
    public final long b;
    public final long c;
    public boolean d;

    public aaqr(File file) {
        this.a = file;
        this.b = file.lastModified();
        this.c = file.length();
    }

    @Override // java.lang.Comparable
    public final /* bridge */ /* synthetic */ int compareTo(Object obj) {
        aaqr aaqrVar = (aaqr) obj;
        if (this.d) {
            if (aaqrVar.d) {
                long j = this.b;
                long j2 = aaqrVar.b;
                if (j >= j2) {
                    if (j <= j2) {
                        return 0;
                    }
                }
            }
            return 1;
        }
        if (!aaqrVar.d) {
            long j3 = aaqrVar.c;
            long j4 = this.c;
            if (j3 >= j4) {
                if (j3 <= j4) {
                    return 0;
                }
                return 1;
            }
        }
        return -1;
    }
}
