package cal;

import android.content.SharedPreferences;
import android.os.StrictMode;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

/* compiled from: PG */
/* loaded from: classes2.dex */
public final class aait implements aahn {
    public static final Map a = new aaz();
    public final Runnable b;
    public final Object c;
    public volatile Map d;
    private final SharedPreferences e;
    private final SharedPreferences.OnSharedPreferenceChangeListener f;
    private final List g;

    public aait(SharedPreferences sharedPreferences, Runnable runnable) {
        SharedPreferences.OnSharedPreferenceChangeListener onSharedPreferenceChangeListener = new SharedPreferences.OnSharedPreferenceChangeListener() { // from class: cal.aais
            @Override // android.content.SharedPreferences.OnSharedPreferenceChangeListener
            public final void onSharedPreferenceChanged(SharedPreferences sharedPreferences2, String str) {
                aait aaitVar = aait.this;
                synchronized (aaitVar.c) {
                    aaitVar.d = null;
                    aaip.a.incrementAndGet();
                }
                aaitVar.c();
            }
        };
        this.f = onSharedPreferenceChangeListener;
        this.c = new Object();
        this.g = new ArrayList();
        this.e = sharedPreferences;
        this.b = runnable;
        sharedPreferences.registerOnSharedPreferenceChangeListener(onSharedPreferenceChangeListener);
    }

    /* JADX INFO: Access modifiers changed from: package-private */
    public static synchronized void b() {
        synchronized (aait.class) {
            Map map = a;
            aax aaxVar = ((aaz) map).c;
            if (aaxVar == null) {
                aaxVar = new aax((aaz) map);
                ((aaz) map).c = aaxVar;
            }
            aay aayVar = new aay(aaxVar.a);
            while (aayVar.c < aayVar.b) {
                aait aaitVar = (aait) aayVar.next();
                aaitVar.e.unregisterOnSharedPreferenceChangeListener(aaitVar.f);
            }
            Object obj = a;
            if (((abh) obj).f > 0) {
                ((abh) obj).d = abk.a;
                ((abh) obj).e = abk.c;
                ((abh) obj).f = 0;
            }
        }
    }

    @Override // cal.aahn
    public final Object a(String str) {
        Map<String, ?> map = this.d;
        if (map == null) {
            synchronized (this.c) {
                map = this.d;
                if (map == null) {
                    StrictMode.ThreadPolicy allowThreadDiskReads = StrictMode.allowThreadDiskReads();
                    try {
                        Map<String, ?> all = this.e.getAll();
                        this.d = all;
                        StrictMode.setThreadPolicy(allowThreadDiskReads);
                        map = all;
                    } catch (Throwable th) {
                        StrictMode.setThreadPolicy(allowThreadDiskReads);
                        throw th;
                    }
                }
            }
        }
        if (map != null) {
            return map.get(str);
        }
        return null;
    }

    public final void c() {
        synchronized (this) {
            Iterator it = this.g.iterator();
            while (it.hasNext()) {
                ((aahl) it.next()).a();
            }
        }
    }
}
