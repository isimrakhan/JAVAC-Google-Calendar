package cal;

import android.content.Context;
import java.util.List;
import java.util.concurrent.Callable;

/* compiled from: PG */
/* loaded from: classes2.dex */
public final class aags {
    public final String a;
    public final String b;
    private final aagd c;
    private final aagk d;
    private final gav e;

    public aags(Context context, String str, ahti ahtiVar) {
        String packageName = context.getPackageName();
        gav gavVar = (gav) ((ahts) ahtiVar).a;
        aagd aagdVar = aagd.a;
        aagk aagkVar = aagk.a;
        Boolean bool = false;
        bool.getClass();
        bool.getClass();
        this.b = str;
        this.e = gavVar;
        this.c = aagdVar;
        this.d = aagkVar;
        this.a = "com.google.android.libraries.performance.primes#".concat(String.valueOf(packageName));
    }

    public final ajdo a() {
        final ajdo ajdjVar;
        aick aikmVar;
        final ajdo a = gav.a();
        ailt ailtVar = aick.e;
        aick aickVar = aikm.b;
        if (aickVar == null) {
            ajdjVar = ajdj.a;
        } else {
            ajdjVar = new ajdj(aickVar);
        }
        final ajdj ajdjVar2 = new ajdj(ahre.a);
        Object[] objArr = (Object[]) new ajdo[]{a, ajdjVar, ajdjVar2}.clone();
        int length = objArr.length;
        for (int i = 0; i < length; i++) {
            if (objArr[i] == null) {
                throw new NullPointerException("at index " + i);
            }
        }
        int length2 = objArr.length;
        if (length2 == 0) {
            aikmVar = aikm.b;
        } else {
            aikmVar = new aikm(objArr, length2);
        }
        ajcu ajcuVar = new ajcu(false, aikmVar);
        return new ajbv(ajcuVar.b, ajcuVar.a, ajbw.a, new Callable() { // from class: cal.aagr
            /* JADX WARN: Multi-variable type inference failed */
            @Override // java.util.concurrent.Callable
            public final Object call() {
                aagq aagqVar = aagq.a;
                aagp aagpVar = new aagp();
                int i2 = aagpVar.b.ad & Integer.MIN_VALUE;
                ajdo ajdoVar = a;
                ajdo ajdoVar2 = ajdjVar;
                ajdo ajdoVar3 = ajdjVar2;
                if (i2 == 0) {
                    aagpVar.s();
                }
                aags aagsVar = aags.this;
                aagq aagqVar2 = (aagq) aagpVar.b;
                aagqVar2.d |= 1;
                aagqVar2.e = aagsVar.b;
                if ((aagpVar.b.ad & Integer.MIN_VALUE) == 0) {
                    aagpVar.s();
                }
                String str = aagsVar.a;
                aagq aagqVar3 = (aagq) aagpVar.b;
                aagqVar3.d |= 2;
                aagqVar3.f = str;
                if ((aagpVar.b.ad & Integer.MIN_VALUE) == 0) {
                    aagpVar.s();
                }
                aagq aagqVar4 = (aagq) aagpVar.b;
                aagqVar4.d |= 4;
                aagqVar4.g = false;
                if ((aagpVar.b.ad & Integer.MIN_VALUE) == 0) {
                    aagpVar.s();
                }
                aagq aagqVar5 = (aagq) aagpVar.b;
                aagqVar5.d |= 32;
                aagqVar5.k = false;
                try {
                    ahti ahtiVar = (ahti) ajem.a(ajdoVar);
                    if (ahtiVar.i()) {
                        String str2 = (String) ahtiVar.d();
                        if ((aagpVar.b.ad & Integer.MIN_VALUE) == 0) {
                            aagpVar.s();
                        }
                        aagq aagqVar6 = (aagq) aagpVar.b;
                        aagqVar6.d |= 16;
                        aagqVar6.i = str2;
                    }
                } catch (Exception unused) {
                }
                try {
                    List list = (List) ajem.a(ajdoVar2);
                    if ((aagpVar.b.ad & Integer.MIN_VALUE) == 0) {
                        aagpVar.s();
                    }
                    aagq aagqVar7 = (aagq) aagpVar.b;
                    amps ampsVar = aagqVar7.j;
                    if (!ampsVar.b()) {
                        int size = ampsVar.size();
                        aagqVar7.j = ampsVar.c(size + size);
                    }
                    amni.h(list, aagqVar7.j);
                } catch (Exception unused2) {
                }
                try {
                    ahti ahtiVar2 = (ahti) ajem.a(ajdoVar3);
                    if (ahtiVar2.i()) {
                        String str3 = (String) ahtiVar2.d();
                        if ((aagpVar.b.ad & Integer.MIN_VALUE) == 0) {
                            aagpVar.s();
                        }
                        aagq aagqVar8 = (aagq) aagpVar.b;
                        aagqVar8.d |= 8;
                        aagqVar8.h = str3;
                    }
                } catch (Exception unused3) {
                }
                aagg aaggVar = aagg.a;
                aagf aagfVar = new aagf();
                ampl amplVar = aagq.c;
                Object obj = (aagq) aagpVar.p();
                if (amplVar.a == aagfVar.a) {
                    if ((Integer.MIN_VALUE & aagfVar.b.ad) == 0) {
                        aagfVar.s();
                    }
                    amoz a2 = aagfVar.a();
                    ampk ampkVar = amplVar.d;
                    if (ampkVar.b.s == amsj.ENUM) {
                        obj = Integer.valueOf(((ampo) obj).a());
                    }
                    amoz.j(ampkVar, obj);
                    if (obj instanceof amqc) {
                        a2.d = true;
                    }
                    a2.b.put(ampkVar, obj);
                    return (aagg) aagfVar.p();
                }
                throw new IllegalArgumentException("This extension is for a different message type.  Please make sure that you are not suppressing any generics type warnings.");
            }
        });
    }
}
