package cal;

/* compiled from: PG */
/* loaded from: classes2.dex */
final class aabp extends aabr {
    private final int a;
    private final int b;
    private final int c;
    private final int d;
    private final aick e;
    private final int f;

    public aabp(int i, int i2, int i3, int i4, aick aickVar, int i5) {
        this.a = i;
        this.b = i2;
        this.c = i3;
        this.d = i4;
        this.e = aickVar;
        this.f = i5;
    }

    @Override // cal.aabr
    public final int c() {
        return this.b;
    }

    @Override // cal.aabr
    public final int d() {
        return this.a;
    }

    @Override // cal.aabr
    public final int e() {
        return this.c;
    }

    public final boolean equals(Object obj) {
        if (obj == this) {
            return true;
        }
        if (obj instanceof aabr) {
            aabr aabrVar = (aabr) obj;
            if (this.a == aabrVar.d() && this.b == aabrVar.c() && this.c == aabrVar.e() && this.d == aabrVar.f() && aiga.e(this.e, aabrVar.g()) && this.f == aabrVar.h()) {
                return true;
            }
        }
        return false;
    }

    @Override // cal.aabr
    public final int f() {
        return this.d;
    }

    @Override // cal.aabr
    public final aick g() {
        return this.e;
    }

    @Override // cal.aabr
    public final int h() {
        return this.f;
    }

    public final int hashCode() {
        return ((((((((((this.a ^ 1000003) * 1000003) ^ this.b) * 1000003) ^ this.c) * 1000003) ^ this.d) * 1000003) ^ this.e.hashCode()) * 1000003) ^ this.f;
    }

    public final String toString() {
        String str;
        String obj = this.e.toString();
        int i = this.f;
        if (i != 1) {
            if (i != 2) {
                str = "EXPLICITLY_ENABLED";
            } else {
                str = "EXPLICITLY_DISABLED";
            }
        } else {
            str = "DEFAULT";
        }
        int i2 = this.d;
        int i3 = this.c;
        int i4 = this.b;
        return "StallConfigurations{initialMonitoringDelayMs=" + this.a + ", checkForResponseIntervalMs=" + i4 + ", midStallCheckForResponseIntervalMs=" + i3 + ", postToMainIntervalMs=" + i2 + ", stallThresholdsMs=" + obj + ", enablement=" + str + "}";
    }
}
