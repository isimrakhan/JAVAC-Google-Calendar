package cal;

/* compiled from: PG */
/* loaded from: classes2.dex */
public final /* synthetic */ class aaeq implements apxs {
    public final /* synthetic */ apxs a;

    public /* synthetic */ aaeq(apxs apxsVar) {
        this.a = apxsVar;
    }

    @Override // cal.apxs, cal.apxr
    public final Object b() {
        aoaw aoawVar = (aoaw) this.a;
        Object obj = aoawVar.b;
        if (obj == aoaw.a) {
            obj = aoawVar.c();
        }
        return (aaex) obj;
    }
}
