package cal;

/* JADX INFO: Access modifiers changed from: package-private */
/* compiled from: PG */
/* loaded from: classes2.dex */
public final class aakm extends aanj {
    public final boolean a;
    public final amob b;
    public final String c;
    public final String d;
    public final aick e;
    public final aick f;
    public final boolean g;

    public aakm(boolean z, amob amobVar, String str, String str2, aick aickVar, aick aickVar2, boolean z2) {
        this.a = z;
        if (amobVar != null) {
            this.b = amobVar;
            if (str != null) {
                this.c = str;
                if (str2 != null) {
                    this.d = str2;
                    if (aickVar != null) {
                        this.e = aickVar;
                        if (aickVar2 != null) {
                            this.f = aickVar2;
                            this.g = z2;
                            return;
                        }
                        throw new NullPointerException("Null excludeStaticConfigPackages");
                    }
                    throw new NullPointerException("Null includeStaticConfigPackages");
                }
                throw new NullPointerException("Null gmsCoreDirPath");
            }
            throw new NullPointerException("Null dirPath");
        }
        throw new NullPointerException("Null secret");
    }

    @Override // cal.aanj
    public final aick a() {
        return this.f;
    }

    @Override // cal.aanj
    public final aick b() {
        return this.e;
    }

    @Override // cal.aanj
    public final amob c() {
        return this.b;
    }

    @Override // cal.aanj
    public final String d() {
        return this.c;
    }

    @Override // cal.aanj
    public final String e() {
        return this.d;
    }

    public final boolean equals(Object obj) {
        if (obj == this) {
            return true;
        }
        if (obj instanceof aanj) {
            aanj aanjVar = (aanj) obj;
            if (this.a == aanjVar.g() && this.b.equals(aanjVar.c()) && this.c.equals(aanjVar.d()) && this.d.equals(aanjVar.e()) && aiga.e(this.e, aanjVar.b()) && aiga.e(this.f, aanjVar.a()) && this.g == aanjVar.f()) {
                return true;
            }
        }
        return false;
    }

    @Override // cal.aanj
    public final boolean f() {
        return this.g;
    }

    @Override // cal.aanj
    public final boolean g() {
        return this.a;
    }

    public final int hashCode() {
        int i;
        amob amobVar = this.b;
        int i2 = amobVar.c;
        if (i2 == 0) {
            int d = amobVar.d();
            i2 = amobVar.i(d, 0, d);
            if (i2 == 0) {
                i2 = 1;
            }
            amobVar.c = i2;
        }
        int i3 = 1237;
        if (true != this.a) {
            i = 1237;
        } else {
            i = 1231;
        }
        int hashCode = ((((((((((i ^ 1000003) * 1000003) ^ i2) * 1000003) ^ this.c.hashCode()) * 1000003) ^ this.d.hashCode()) * 1000003) ^ this.e.hashCode()) * 1000003) ^ this.f.hashCode();
        if (true == this.g) {
            i3 = 1231;
        }
        return (hashCode * 1000003) ^ i3;
    }

    public final String toString() {
        aick aickVar = this.f;
        aick aickVar2 = this.e;
        return "SharedStorageInfo{shouldUseSharedStorage=" + this.a + ", secret=" + this.b.toString() + ", dirPath=" + this.c + ", gmsCoreDirPath=" + this.d + ", includeStaticConfigPackages=" + aickVar2.toString() + ", excludeStaticConfigPackages=" + aickVar.toString() + ", hasStorageInfoFromGms=" + this.g + "}";
    }
}
