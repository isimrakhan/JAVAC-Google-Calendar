package cal;

/* compiled from: PG */
/* loaded from: classes2.dex */
public abstract class aaey {
    public abstract aaez a();

    public abstract aaey b(int i);

    public final aaey d(boolean z) {
        int i;
        if (true != z) {
            i = 2;
        } else {
            i = 3;
        }
        return b(i);
    }

    public final aaez e() {
        aaez a = a();
        float f = ((aaeo) a).a;
        if (f >= 0.0f && f <= 1.0f) {
            return a;
        }
        throw new IllegalStateException("Probability shall be between 0 and 1.");
    }
}
