package cal;

/* compiled from: PG */
/* loaded from: classes2.dex */
public final class aalo extends ampg implements amqu {
    public aalo() {
        super(aalp.a);
    }
}
