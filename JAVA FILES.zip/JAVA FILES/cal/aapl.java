package cal;

import android.content.Context;

/* compiled from: PG */
/* loaded from: classes2.dex */
public abstract class aapl {
    public abstract int a(Context context, aapk aapkVar);
}
