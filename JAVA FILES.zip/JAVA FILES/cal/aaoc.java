package cal;

/* compiled from: PG */
/* loaded from: classes2.dex */
public final class aaoc implements ahum {
    boolean a;
    Object b;
    final /* synthetic */ ahum c;

    public aaoc(ahum ahumVar) {
        this.c = ahumVar;
    }

    @Override // cal.ahum
    public final Object a() {
        if (this.a) {
            return this.b;
        }
        Object a = this.c.a();
        this.b = a;
        this.a = true;
        return a;
    }
}
