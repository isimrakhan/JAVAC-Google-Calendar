package cal;

import java.util.regex.Pattern;

/* compiled from: PG */
/* loaded from: classes2.dex */
final class aaax {
    static final Pattern a = Pattern.compile("VmHWM:\\s*(\\d+)\\s*kB");
    static final Pattern b = Pattern.compile("VmRSS:\\s*(\\d+)\\s*kB");
    static final Pattern c = Pattern.compile("RssAnon:\\s*(\\d+)\\s*kB");
    static final Pattern d = Pattern.compile("VmSwap:\\s*(\\d+)\\s*kB");
    static final Pattern e = Pattern.compile("VmSize:\\s*(\\d+)\\s*kB");
    Long f;
    Long g;
    Long h;
    Long i;
    Long j;
}
