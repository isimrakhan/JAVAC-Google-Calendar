package cal;

import com.google.protobuf.InvalidProtocolBufferException;
import com.google.protobuf.UninitializedMessageException;
import java.io.IOException;
import java.io.InputStream;

/* compiled from: PG */
/* loaded from: classes2.dex */
public final class aakd extends ampm implements amqu {
    public static final aakd a;
    public static volatile amra b;
    public int c;
    public aajw d;
    public aajz e;

    static {
        aakd aakdVar = new aakd();
        a = aakdVar;
        aakdVar.ad &= Integer.MAX_VALUE;
        ampm.ac.put(aakd.class, aakdVar);
    }

    public static aakd parseFrom(InputStream inputStream) {
        amof amoeVar;
        int i = amof.f;
        if (inputStream == null) {
            byte[] bArr = ampx.b;
            int length = bArr.length;
            amoeVar = new amoc(bArr, 0, 0);
            try {
                amoeVar.d(0);
            } catch (InvalidProtocolBufferException e) {
                throw new IllegalArgumentException(e);
            }
        } else {
            amoeVar = new amoe(inputStream, 4096);
        }
        amov amovVar = amov.a;
        amrc amrcVar = amrc.a;
        amov amovVar2 = amov.b;
        aakd aakdVar = new aakd();
        try {
            amrk a2 = amrc.a.a(aakdVar.getClass());
            amog amogVar = amoeVar.e;
            if (amogVar == null) {
                amogVar = new amog(amoeVar);
            }
            a2.h(aakdVar, amogVar, amovVar2);
            a2.f(aakdVar);
            Byte b2 = (byte) 1;
            b2.getClass();
            return aakdVar;
        } catch (InvalidProtocolBufferException e2) {
            if (e2.a) {
                throw new InvalidProtocolBufferException(e2);
            }
            throw e2;
        } catch (UninitializedMessageException e3) {
            throw new InvalidProtocolBufferException(e3.getMessage());
        } catch (IOException e4) {
            if (e4.getCause() instanceof InvalidProtocolBufferException) {
                throw ((InvalidProtocolBufferException) e4.getCause());
            }
            throw new InvalidProtocolBufferException(e4);
        } catch (RuntimeException e5) {
            if (e5.getCause() instanceof InvalidProtocolBufferException) {
                throw ((InvalidProtocolBufferException) e5.getCause());
            }
            throw e5;
        }
    }

    @Override // cal.ampm
    public final Object a(int i, Object obj) {
        int i2 = i - 1;
        if (i2 != 0) {
            if (i2 != 2) {
                if (i2 != 3) {
                    if (i2 != 4) {
                        if (i2 != 5) {
                            if (i2 != 6) {
                                return null;
                            }
                            amra amraVar = b;
                            if (amraVar == null) {
                                synchronized (aakd.class) {
                                    amraVar = b;
                                    if (amraVar == null) {
                                        amraVar = new amph(a);
                                        b = amraVar;
                                    }
                                }
                            }
                            return amraVar;
                        }
                        return a;
                    }
                    return new aakc();
                }
                return new aakd();
            }
            return new amre(a, "\u0004\u0002\u0000\u0001\u0001\u0002\u0002\u0000\u0000\u0000\u0001ဉ\u0000\u0002ဉ\u0001", new Object[]{"c", "d", "e"});
        }
        return (byte) 1;
    }
}
