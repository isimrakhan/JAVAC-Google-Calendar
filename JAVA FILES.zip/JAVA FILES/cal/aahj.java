package cal;

import android.database.ContentObserver;
import java.util.Iterator;

/* JADX INFO: Access modifiers changed from: package-private */
/* compiled from: PG */
/* loaded from: classes2.dex */
public final class aahj extends ContentObserver {
    final /* synthetic */ aahk a;

    /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
    public aahj(aahk aahkVar) {
        super(null);
        this.a = aahkVar;
    }

    @Override // android.database.ContentObserver
    public final void onChange(boolean z) {
        aahk aahkVar = this.a;
        synchronized (aahkVar.c) {
            aahkVar.d = null;
            aaip.a.incrementAndGet();
        }
        synchronized (aahkVar) {
            Iterator it = aahkVar.e.iterator();
            while (it.hasNext()) {
                ((aahl) it.next()).a();
            }
        }
    }
}
