package cal;

/* compiled from: PG */
/* loaded from: classes2.dex */
public final class aalz {
    public final aaml a;
    public final /* synthetic */ aama b;

    public aalz(aama aamaVar, aaml aamlVar) {
        this.b = aamaVar;
        this.a = aamlVar;
    }
}
