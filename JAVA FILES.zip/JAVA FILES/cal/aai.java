package cal;

import android.content.ComponentName;

/* compiled from: PG */
/* loaded from: classes.dex */
public class aai {
    public final ai a;
    public final ComponentName b;

    public aai(ai aiVar, ComponentName componentName) {
        this.a = aiVar;
        this.b = componentName;
    }
}
