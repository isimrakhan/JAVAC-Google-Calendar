package cal;

import android.content.ComponentName;

/* compiled from: PG */
/* loaded from: classes.dex */
final class aal extends aai {
    public aal(ai aiVar, ComponentName componentName) {
        super(aiVar, componentName);
    }
}
