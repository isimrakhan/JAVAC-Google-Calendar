package cal;

import android.accounts.Account;
import android.content.Context;
import android.net.Uri;

/* compiled from: PG */
/* loaded from: classes2.dex */
public final class aanm {
    public final aaic a;
    public final Uri b;
    public final String c;
    private final String d;
    private final boolean e;

    public aanm(aaic aaicVar, String str, String str2, boolean z) {
        String str3;
        this.a = aaicVar;
        this.c = str;
        this.d = str2;
        this.e = z;
        Context context = aaicVar.d;
        Account account = abys.a;
        Account account2 = abys.a;
        aicf aicfVar = new aicf(4);
        String packageName = context.getPackageName();
        abys.a("phenotype");
        String str4 = str2 + "/" + str + ".pb";
        String substring = str4.startsWith("/") ? str4.substring(1) : str4;
        if (z) {
            int i = vvg.a;
            boolean contains = abys.b.contains("directboot-files");
            Object[] objArr = {abys.b, "directboot-files"};
            if (contains) {
                str3 = "directboot-files";
            } else {
                throw new IllegalArgumentException(String.format("The only supported locations are %s: %s", objArr));
            }
        } else {
            str3 = "files";
        }
        this.b = abyr.a(packageName, str3, "phenotype", account2, substring, aicfVar);
    }

    /* JADX INFO: Access modifiers changed from: package-private */
    /* JADX WARN: Can't wrap try/catch for region: R(10:(3:(2:125|(9:127|(1:129)|130|(1:132)|133|134|135|25|(4:27|(1:29)|30|31)(14:33|(1:35)|36|37|(1:40)|41|42|(3:44|746|51)|56|(1:58)|59|(1:61)|62|(2:64|65)(2:66|67)))(2:136|(1:138)(1:139)))|153|(12:155|156|157|(1:159)|160|161|163|164|165|166|167|(18:169|(9:171|172|173|(2:175|176)(2:200|(1:202)(3:203|204|205))|177|(1:199)(1:(1:(2:182|(2:184|(1:186)(3:193|194|195))(1:196))(1:197))(1:198))|187|(2:189|190)(1:192)|191)|223|224|226|227|228|(2:246|247)|230|(1:232)|233|(1:235)|236|237|238|135|25|(0)(0))(2:251|252))(2:282|283))|143|144|145|146|147|148|149|(4:337|338|339|340)(1:151)|152) */
    /* JADX WARN: Can't wrap try/catch for region: R(15:122|123|(3:(2:125|(9:127|(1:129)|130|(1:132)|133|134|135|25|(4:27|(1:29)|30|31)(14:33|(1:35)|36|37|(1:40)|41|42|(3:44|746|51)|56|(1:58)|59|(1:61)|62|(2:64|65)(2:66|67)))(2:136|(1:138)(1:139)))|153|(12:155|156|157|(1:159)|160|161|163|164|165|166|167|(18:169|(9:171|172|173|(2:175|176)(2:200|(1:202)(3:203|204|205))|177|(1:199)(1:(1:(2:182|(2:184|(1:186)(3:193|194|195))(1:196))(1:197))(1:198))|187|(2:189|190)(1:192)|191)|223|224|226|227|228|(2:246|247)|230|(1:232)|233|(1:235)|236|237|238|135|25|(0)(0))(2:251|252))(2:282|283))|140|141|142|143|144|145|146|147|148|149|(4:337|338|339|340)(1:151)|152) */
    /* JADX WARN: Can't wrap try/catch for region: R(3:(8:(3:(2:125|(9:127|(1:129)|130|(1:132)|133|134|135|25|(4:27|(1:29)|30|31)(14:33|(1:35)|36|37|(1:40)|41|42|(3:44|746|51)|56|(1:58)|59|(1:61)|62|(2:64|65)(2:66|67)))(2:136|(1:138)(1:139)))|153|(12:155|156|157|(1:159)|160|161|163|164|165|166|167|(18:169|(9:171|172|173|(2:175|176)(2:200|(1:202)(3:203|204|205))|177|(1:199)(1:(1:(2:182|(2:184|(1:186)(3:193|194|195))(1:196))(1:197))(1:198))|187|(2:189|190)(1:192)|191)|223|224|226|227|228|(2:246|247)|230|(1:232)|233|(1:235)|236|237|238|135|25|(0)(0))(2:251|252))(2:282|283))|145|146|147|148|149|(4:337|338|339|340)(1:151)|152)|143|144) */
    /* JADX WARN: Can't wrap try/catch for region: R(6:122|123|(10:(3:(2:125|(9:127|(1:129)|130|(1:132)|133|134|135|25|(4:27|(1:29)|30|31)(14:33|(1:35)|36|37|(1:40)|41|42|(3:44|746|51)|56|(1:58)|59|(1:61)|62|(2:64|65)(2:66|67)))(2:136|(1:138)(1:139)))|153|(12:155|156|157|(1:159)|160|161|163|164|165|166|167|(18:169|(9:171|172|173|(2:175|176)(2:200|(1:202)(3:203|204|205))|177|(1:199)(1:(1:(2:182|(2:184|(1:186)(3:193|194|195))(1:196))(1:197))(1:198))|187|(2:189|190)(1:192)|191)|223|224|226|227|228|(2:246|247)|230|(1:232)|233|(1:235)|236|237|238|135|25|(0)(0))(2:251|252))(2:282|283))|143|144|145|146|147|148|149|(4:337|338|339|340)(1:151)|152)|140|141|142) */
    /* JADX WARN: Can't wrap try/catch for region: R(8:(3:(2:125|(9:127|(1:129)|130|(1:132)|133|134|135|25|(4:27|(1:29)|30|31)(14:33|(1:35)|36|37|(1:40)|41|42|(3:44|746|51)|56|(1:58)|59|(1:61)|62|(2:64|65)(2:66|67)))(2:136|(1:138)(1:139)))|153|(12:155|156|157|(1:159)|160|161|163|164|165|166|167|(18:169|(9:171|172|173|(2:175|176)(2:200|(1:202)(3:203|204|205))|177|(1:199)(1:(1:(2:182|(2:184|(1:186)(3:193|194|195))(1:196))(1:197))(1:198))|187|(2:189|190)(1:192)|191)|223|224|226|227|228|(2:246|247)|230|(1:232)|233|(1:235)|236|237|238|135|25|(0)(0))(2:251|252))(2:282|283))|145|146|147|148|149|(4:337|338|339|340)(1:151)|152) */
    /* JADX WARN: Code restructure failed: missing block: B:348:0x0576, code lost:
    
        r0 = th;
     */
    /* JADX WARN: Code restructure failed: missing block: B:349:0x0577, code lost:
    
        r22 = r4;
        r4 = 4;
     */
    /* JADX WARN: Code restructure failed: missing block: B:353:0x0593, code lost:
    
        r0 = e;
     */
    /* JADX WARN: Code restructure failed: missing block: B:354:0x0594, code lost:
    
        r22 = r4;
        r4 = 4;
     */
    /* JADX WARN: Code restructure failed: missing block: B:355:0x05ec, code lost:
    
        r22 = r4;
        r4 = 4;
     */
    /* JADX WARN: Code restructure failed: missing block: B:357:0x064a, code lost:
    
        r0 = e;
     */
    /* JADX WARN: Code restructure failed: missing block: B:358:0x064b, code lost:
    
        r3 = 6;
        r4 = 4;
     */
    /* JADX WARN: Code restructure failed: missing block: B:359:0x0651, code lost:
    
        r7 = 5;
     */
    /* JADX WARN: Code restructure failed: missing block: B:360:0x0648, code lost:
    
        r0 = e;
     */
    /* JADX WARN: Code restructure failed: missing block: B:362:0x064e, code lost:
    
        r0 = e;
     */
    /* JADX WARN: Code restructure failed: missing block: B:363:0x064f, code lost:
    
        r4 = 4;
        r3 = 6;
     */
    /* JADX WARN: Multi-variable type inference failed */
    /* JADX WARN: Removed duplicated region for block: B:27:0x06bd  */
    /* JADX WARN: Removed duplicated region for block: B:287:0x057d A[EXC_TOP_SPLITTER, SYNTHETIC] */
    /* JADX WARN: Removed duplicated region for block: B:312:0x0688  */
    /* JADX WARN: Removed duplicated region for block: B:315:0x069d  */
    /* JADX WARN: Removed duplicated region for block: B:336:? A[Catch: all -> 0x0587, InvalidProtocolBufferException -> 0x0589, FileNotFoundException -> 0x05ef, SYNTHETIC, TRY_LEAVE, TryCatch #30 {InvalidProtocolBufferException -> 0x0589, FileNotFoundException -> 0x05ef, all -> 0x0587, blocks: (B:295:0x0586, B:294:0x0583), top: B:293:0x0583 }] */
    /* JADX WARN: Removed duplicated region for block: B:33:0x06e7  */
    /* JADX WARN: Type inference failed for: r10v12, types: [java.lang.StringBuilder] */
    /* JADX WARN: Type inference failed for: r4v12 */
    /* JADX WARN: Type inference failed for: r4v13 */
    /* JADX WARN: Type inference failed for: r4v132 */
    /* JADX WARN: Type inference failed for: r4v133 */
    /* JADX WARN: Type inference failed for: r4v134 */
    /* JADX WARN: Type inference failed for: r4v14 */
    /* JADX WARN: Type inference failed for: r4v17, types: [java.lang.String] */
    /* JADX WARN: Type inference failed for: r4v18 */
    /* JADX WARN: Type inference failed for: r4v19 */
    /* JADX WARN: Type inference failed for: r4v20 */
    /* JADX WARN: Type inference failed for: r4v22, types: [android.os.StrictMode$ThreadPolicy] */
    /* JADX WARN: Type inference failed for: r4v23 */
    /* JADX WARN: Type inference failed for: r4v24 */
    /* JADX WARN: Type inference failed for: r4v25 */
    /* JADX WARN: Type inference failed for: r4v26 */
    /* JADX WARN: Type inference failed for: r4v28 */
    /* JADX WARN: Type inference failed for: r4v29 */
    /* JADX WARN: Type inference failed for: r4v30 */
    /* JADX WARN: Type inference failed for: r4v31 */
    /* JADX WARN: Type inference failed for: r4v32 */
    /* JADX WARN: Type inference failed for: r4v33 */
    /* JADX WARN: Type inference failed for: r4v34 */
    /* JADX WARN: Type inference failed for: r4v40 */
    /* JADX WARN: Type inference failed for: r4v41 */
    /* JADX WARN: Type inference failed for: r4v42 */
    /* JADX WARN: Type inference failed for: r4v43 */
    /* JADX WARN: Type inference failed for: r4v44 */
    /* JADX WARN: Type inference failed for: r4v45 */
    /* JADX WARN: Type inference failed for: r4v47, types: [android.os.StrictMode$ThreadPolicy] */
    /* JADX WARN: Type inference failed for: r4v48 */
    /* JADX WARN: Type inference failed for: r4v53 */
    /* JADX WARN: Type inference failed for: r7v10 */
    /* JADX WARN: Type inference failed for: r7v14 */
    /* JADX WARN: Type inference failed for: r7v3 */
    /* JADX WARN: Type inference failed for: r7v4 */
    /* JADX WARN: Type inference failed for: r7v5 */
    /* JADX WARN: Type inference failed for: r7v9, types: [java.lang.String] */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct code enable 'Show inconsistent code' option in preferences
    */
    public final cal.aanl a() {
        /*
            Method dump skipped, instructions count: 2098
            To view this dump change 'Code comments level' option to 'DEBUG'
        */
        throw new UnsupportedOperationException("Method not decompiled: cal.aanm.a():cal.aanl");
    }

    /* JADX INFO: Access modifiers changed from: package-private */
    public final boolean b() {
        aany aanyVar = this.a.i;
        if (this.e) {
            aajz b = aanyVar.b();
            if (b.f && new ampu(b.j, aajz.a).contains(ajvx.PROCESS_STABLE)) {
                return true;
            }
            return false;
        }
        aajw a = aanyVar.a();
        if (a.f && new ampu(a.k, aajw.a).contains(ajvx.PROCESS_STABLE)) {
            return true;
        }
        return false;
    }
}
