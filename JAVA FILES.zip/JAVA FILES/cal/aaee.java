package cal;

/* compiled from: PG */
/* loaded from: classes2.dex */
public final class aaee {
    public static final aaee a = new aaee();
    public int d = 1;
    boolean c = false;
    public final zwm b = new zwm();
}
