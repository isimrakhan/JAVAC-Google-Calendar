package cal;

/* compiled from: PG */
/* loaded from: classes2.dex */
final class aadq {
    /* JADX INFO: Access modifiers changed from: package-private */
    /* JADX WARN: Multi-variable type inference failed */
    /* JADX WARN: Removed duplicated region for block: B:22:0x00bb A[EXC_TOP_SPLITTER, SYNTHETIC] */
    /* JADX WARN: Removed duplicated region for block: B:37:0x0066 A[SYNTHETIC] */
    /* JADX WARN: Type inference failed for: r6v3, types: [java.lang.Object, java.lang.String] */
    /* JADX WARN: Type inference failed for: r6v5, types: [java.util.UUID] */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct code enable 'Show inconsistent code' option in preferences
    */
    public static android.content.pm.PackageStats a(android.content.Context r14) {
        /*
            Method dump skipped, instructions count: 309
            To view this dump change 'Code comments level' option to 'DEBUG'
        */
        throw new UnsupportedOperationException("Method not decompiled: cal.aadq.a(android.content.Context):android.content.pm.PackageStats");
    }
}
