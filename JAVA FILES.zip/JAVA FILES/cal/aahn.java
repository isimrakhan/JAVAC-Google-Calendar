package cal;

/* compiled from: PG */
/* loaded from: classes2.dex */
interface aahn {
    Object a(String str);
}
