package cal;

import android.util.Log;
import java.util.Set;
import java.util.concurrent.CancellationException;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.Executor;

/* compiled from: PG */
/* loaded from: classes2.dex */
public final class aalk {
    public static final aalj a = new aalj();
    public final aaic b;
    public final String c;
    public final aanm h;
    private final Set k;
    private final Object i = new Object();
    public final String d = "";
    public final boolean e = false;
    public final boolean f = false;
    private volatile aanl j = null;
    public final aalq g = new aalq();

    public aalk(aaic aaicVar, String str, boolean z, Set set) {
        this.b = aaicVar;
        this.c = str;
        this.k = set;
        this.h = new aanm(aaicVar, str, "", z);
    }

    /* JADX WARN: Removed duplicated region for block: B:26:0x0092 A[Catch: all -> 0x018f, TryCatch #2 {, blocks: (B:6:0x0009, B:9:0x0188, B:11:0x000f, B:14:0x0019, B:17:0x0045, B:18:0x0047, B:20:0x004f, B:22:0x0059, B:23:0x0186, B:24:0x0078, B:26:0x0092, B:27:0x009e, B:29:0x00ab, B:31:0x00b6, B:32:0x00c0, B:34:0x00c8, B:35:0x00d2, B:36:0x00f3, B:38:0x00f9, B:41:0x0111, B:46:0x0124, B:48:0x013e, B:50:0x0159, B:51:0x015c, B:53:0x0165, B:54:0x0167, B:64:0x0183, B:66:0x0184, B:67:0x00cc, B:68:0x0095, B:69:0x002a, B:71:0x0041, B:74:0x018b, B:75:0x018e, B:56:0x0168, B:58:0x016c, B:59:0x017f, B:13:0x0013), top: B:5:0x0009, inners: #0, #1 }] */
    /* JADX WARN: Removed duplicated region for block: B:34:0x00c8 A[Catch: all -> 0x018f, TryCatch #2 {, blocks: (B:6:0x0009, B:9:0x0188, B:11:0x000f, B:14:0x0019, B:17:0x0045, B:18:0x0047, B:20:0x004f, B:22:0x0059, B:23:0x0186, B:24:0x0078, B:26:0x0092, B:27:0x009e, B:29:0x00ab, B:31:0x00b6, B:32:0x00c0, B:34:0x00c8, B:35:0x00d2, B:36:0x00f3, B:38:0x00f9, B:41:0x0111, B:46:0x0124, B:48:0x013e, B:50:0x0159, B:51:0x015c, B:53:0x0165, B:54:0x0167, B:64:0x0183, B:66:0x0184, B:67:0x00cc, B:68:0x0095, B:69:0x002a, B:71:0x0041, B:74:0x018b, B:75:0x018e, B:56:0x0168, B:58:0x016c, B:59:0x017f, B:13:0x0013), top: B:5:0x0009, inners: #0, #1 }] */
    /* JADX WARN: Removed duplicated region for block: B:38:0x00f9 A[Catch: all -> 0x018f, TryCatch #2 {, blocks: (B:6:0x0009, B:9:0x0188, B:11:0x000f, B:14:0x0019, B:17:0x0045, B:18:0x0047, B:20:0x004f, B:22:0x0059, B:23:0x0186, B:24:0x0078, B:26:0x0092, B:27:0x009e, B:29:0x00ab, B:31:0x00b6, B:32:0x00c0, B:34:0x00c8, B:35:0x00d2, B:36:0x00f3, B:38:0x00f9, B:41:0x0111, B:46:0x0124, B:48:0x013e, B:50:0x0159, B:51:0x015c, B:53:0x0165, B:54:0x0167, B:64:0x0183, B:66:0x0184, B:67:0x00cc, B:68:0x0095, B:69:0x002a, B:71:0x0041, B:74:0x018b, B:75:0x018e, B:56:0x0168, B:58:0x016c, B:59:0x017f, B:13:0x0013), top: B:5:0x0009, inners: #0, #1 }] */
    /* JADX WARN: Removed duplicated region for block: B:48:0x013e A[Catch: all -> 0x018f, TryCatch #2 {, blocks: (B:6:0x0009, B:9:0x0188, B:11:0x000f, B:14:0x0019, B:17:0x0045, B:18:0x0047, B:20:0x004f, B:22:0x0059, B:23:0x0186, B:24:0x0078, B:26:0x0092, B:27:0x009e, B:29:0x00ab, B:31:0x00b6, B:32:0x00c0, B:34:0x00c8, B:35:0x00d2, B:36:0x00f3, B:38:0x00f9, B:41:0x0111, B:46:0x0124, B:48:0x013e, B:50:0x0159, B:51:0x015c, B:53:0x0165, B:54:0x0167, B:64:0x0183, B:66:0x0184, B:67:0x00cc, B:68:0x0095, B:69:0x002a, B:71:0x0041, B:74:0x018b, B:75:0x018e, B:56:0x0168, B:58:0x016c, B:59:0x017f, B:13:0x0013), top: B:5:0x0009, inners: #0, #1 }] */
    /* JADX WARN: Removed duplicated region for block: B:67:0x00cc A[Catch: all -> 0x018f, TryCatch #2 {, blocks: (B:6:0x0009, B:9:0x0188, B:11:0x000f, B:14:0x0019, B:17:0x0045, B:18:0x0047, B:20:0x004f, B:22:0x0059, B:23:0x0186, B:24:0x0078, B:26:0x0092, B:27:0x009e, B:29:0x00ab, B:31:0x00b6, B:32:0x00c0, B:34:0x00c8, B:35:0x00d2, B:36:0x00f3, B:38:0x00f9, B:41:0x0111, B:46:0x0124, B:48:0x013e, B:50:0x0159, B:51:0x015c, B:53:0x0165, B:54:0x0167, B:64:0x0183, B:66:0x0184, B:67:0x00cc, B:68:0x0095, B:69:0x002a, B:71:0x0041, B:74:0x018b, B:75:0x018e, B:56:0x0168, B:58:0x016c, B:59:0x017f, B:13:0x0013), top: B:5:0x0009, inners: #0, #1 }] */
    /* JADX WARN: Removed duplicated region for block: B:68:0x0095 A[Catch: all -> 0x018f, TryCatch #2 {, blocks: (B:6:0x0009, B:9:0x0188, B:11:0x000f, B:14:0x0019, B:17:0x0045, B:18:0x0047, B:20:0x004f, B:22:0x0059, B:23:0x0186, B:24:0x0078, B:26:0x0092, B:27:0x009e, B:29:0x00ab, B:31:0x00b6, B:32:0x00c0, B:34:0x00c8, B:35:0x00d2, B:36:0x00f3, B:38:0x00f9, B:41:0x0111, B:46:0x0124, B:48:0x013e, B:50:0x0159, B:51:0x015c, B:53:0x0165, B:54:0x0167, B:64:0x0183, B:66:0x0184, B:67:0x00cc, B:68:0x0095, B:69:0x002a, B:71:0x0041, B:74:0x018b, B:75:0x018e, B:56:0x0168, B:58:0x016c, B:59:0x017f, B:13:0x0013), top: B:5:0x0009, inners: #0, #1 }] */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct code enable 'Show inconsistent code' option in preferences
    */
    public final cal.aanl a() {
        /*
            Method dump skipped, instructions count: 403
            To view this dump change 'Code comments level' option to 'DEBUG'
        */
        throw new UnsupportedOperationException("Method not decompiled: cal.aalk.a():cal.aanl");
    }

    /* JADX WARN: Code restructure failed: missing block: B:5:0x001a, code lost:
    
        if (r1.isEmpty() == false) goto L13;
     */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct code enable 'Show inconsistent code' option in preferences
    */
    public final cal.ajdo b() {
        /*
            r6 = this;
            cal.aanl r0 = r6.a()
            java.lang.String r1 = r0.a()
            cal.aaic r2 = r6.b
            cal.aany r2 = r2.i
            cal.aajw r2 = r2.a()
            boolean r3 = r2.m
            if (r3 == 0) goto L99
            if (r1 == 0) goto L1d
            boolean r3 = r1.isEmpty()
            if (r3 != 0) goto L1e
            goto L25
        L1d:
            r1 = 0
        L1e:
            boolean r3 = r2.n
            if (r3 != 0) goto L25
            cal.ajdo r0 = cal.ajdj.a
            return r0
        L25:
            cal.aaix r3 = cal.aaix.a
            cal.aaiu r3 = new cal.aaiu
            r3.<init>()
            cal.aaiw r0 = r0.d
            cal.ampm r4 = r3.b
            int r4 = r4.ad
            r5 = -2147483648(0xffffffff80000000, float:-0.0)
            r4 = r4 & r5
            if (r4 != 0) goto L3a
            r3.s()
        L3a:
            cal.ampm r4 = r3.b
            cal.aaix r4 = (cal.aaix) r4
            r0.getClass()
            r4.e = r0
            int r0 = r4.c
            r0 = r0 | 2
            r4.c = r0
            if (r1 == 0) goto L68
            boolean r0 = r1.isEmpty()
            if (r0 == 0) goto L52
            goto L68
        L52:
            cal.ampm r0 = r3.b
            int r0 = r0.ad
            r0 = r0 & r5
            if (r0 != 0) goto L5c
            r3.s()
        L5c:
            cal.ampm r0 = r3.b
            cal.aaix r0 = (cal.aaix) r0
            int r4 = r0.c
            r4 = r4 | 1
            r0.c = r4
            r0.d = r1
        L68:
            boolean r0 = r2.n
            if (r0 == 0) goto L84
            java.lang.String r0 = r6.c
            cal.ampm r1 = r3.b
            int r1 = r1.ad
            r1 = r1 & r5
            if (r1 != 0) goto L78
            r3.s()
        L78:
            cal.ampm r1 = r3.b
            cal.aaix r1 = (cal.aaix) r1
            int r2 = r1.c
            r2 = r2 | 4
            r1.c = r2
            r1.f = r0
        L84:
            cal.aaic r0 = r6.b
            cal.ahum r0 = r0.f
            java.lang.Object r0 = r0.a()
            cal.aajd r0 = (cal.aajd) r0
            cal.ampm r1 = r3.p()
            cal.aaix r1 = (cal.aaix) r1
            cal.ajdo r0 = r0.b(r1)
            goto Lb0
        L99:
            if (r1 == 0) goto Ld7
            boolean r0 = r1.isEmpty()
            if (r0 == 0) goto La2
            goto Ld7
        La2:
            cal.aaic r0 = r6.b
            cal.ahum r0 = r0.f
            java.lang.Object r0 = r0.a()
            cal.aajd r0 = (cal.aajd) r0
            cal.ajdo r0 = r0.a(r1)
        Lb0:
            cal.aalf r1 = new cal.aalf
            r1.<init>()
            cal.aaic r2 = r6.b
            cal.ahum r2 = r2.e
            java.lang.Object r2 = r2.a()
            cal.ajds r2 = (cal.ajds) r2
            cal.aizx r3 = new cal.aizx
            java.lang.Class<com.google.android.libraries.phenotype.client.api.PhenotypeRuntimeException> r4 = com.google.android.libraries.phenotype.client.api.PhenotypeRuntimeException.class
            r3.<init>(r0, r4, r1)
            r2.getClass()
            cal.ajbw r1 = cal.ajbw.a
            if (r2 == r1) goto Ld3
            cal.ajdt r1 = new cal.ajdt
            r1.<init>(r2, r3)
            r2 = r1
        Ld3:
            r0.d(r3, r2)
            return r3
        Ld7:
            cal.ajdo r0 = cal.ajdj.a
            return r0
        */
        throw new UnsupportedOperationException("Method not decompiled: cal.aalk.b():cal.ajdo");
    }

    public final void c() {
        aanm aanmVar = this.h;
        ajdo c = ((aajd) aanmVar.a.f.a()).c(aanmVar.c, this.d);
        aanh aanhVar = new aanh();
        Executor executor = (ajds) aanmVar.a.e.a();
        final ajap ajapVar = new ajap(c, aanhVar);
        executor.getClass();
        if (executor != ajbw.a) {
            executor = new ajdt(executor, ajapVar);
        }
        c.d(ajapVar, executor);
        final aanm aanmVar2 = this.h;
        ajaz ajazVar = new ajaz() { // from class: cal.aalc
            @Override // cal.ajaz
            public final ajdo a(Object obj) {
                aanm aanmVar3 = aanm.this;
                aani aaniVar = new aani(aanmVar3, (aano) obj);
                ajds ajdsVar = (ajds) aanmVar3.a.e.a();
                ajel ajelVar = new ajel(aaniVar);
                ajdsVar.execute(ajelVar);
                return ajelVar;
            }
        };
        Executor executor2 = (ajds) this.b.e.a();
        executor2.getClass();
        ajao ajaoVar = new ajao(ajapVar, ajazVar);
        if (executor2 != ajbw.a) {
            executor2 = new ajdt(executor2, ajaoVar);
        }
        ajapVar.d(ajaoVar, executor2);
        ajaoVar.d(new Runnable() { // from class: cal.aald
            @Override // java.lang.Runnable
            public final void run() {
                aalk.this.d(ajapVar);
            }
        }, (ajds) this.b.e.a());
    }

    /* JADX INFO: Access modifiers changed from: package-private */
    public final /* synthetic */ void d(ajdo ajdoVar) {
        boolean z;
        try {
            if (((ajam) ajdoVar).value != null) {
                z = true;
            } else {
                z = false;
            }
            if ((!(r0 instanceof ajaf)) & z) {
                aanl aanlVar = new aanl((aano) ajem.a(ajdoVar), null, aaiw.a);
                synchronized (this.i) {
                    if (this.j != null) {
                        boolean equals = this.j.c.equals(aanlVar.c);
                        if (!equals) {
                            aaml aamlVar = (aaml) ((ahti) this.b.g.a()).g();
                            if (aamlVar != null) {
                                aamlVar.a();
                                return;
                            }
                            return;
                        }
                    } else {
                        this.j = aanlVar;
                    }
                    this.g.a.incrementAndGet();
                    return;
                }
            }
            throw new IllegalStateException(ahul.a("Future was expected to be done: %s", ajdoVar));
        } catch (CancellationException | ExecutionException e) {
            if (!(e.getCause() instanceof SecurityException)) {
                Log.w("MobStoreFlagStore", "Unable to update local snapshot for " + this.c + ", may result in stale flags.", e);
            }
        }
    }
}
