package cal;

import com.google.protobuf.InvalidProtocolBufferException;
import com.google.protobuf.UninitializedMessageException;
import java.io.IOException;
import java.io.InputStream;

/* compiled from: PG */
/* loaded from: classes2.dex */
public final class aajw extends ampm implements amqu {
    public static final ampt a = new aaju();
    public static final aajw b;
    public static volatile amra c;
    public int d;
    public boolean f;
    public long h;
    public ampw i;
    public ampw j;
    public amps k;
    public aakb l;
    public boolean m;
    public boolean n;
    public amob e = amob.b;
    public String g = "";

    static {
        aajw aajwVar = new aajw();
        b = aajwVar;
        aajwVar.ad &= Integer.MAX_VALUE;
        ampm.ac.put(aajw.class, aajwVar);
    }

    public aajw() {
        amrd amrdVar = amrd.b;
        this.i = amrdVar;
        this.j = amrdVar;
        this.k = ampn.b;
    }

    public static aajw parseFrom(InputStream inputStream) {
        amof amoeVar;
        int i = amof.f;
        if (inputStream == null) {
            byte[] bArr = ampx.b;
            int length = bArr.length;
            amoeVar = new amoc(bArr, 0, 0);
            try {
                amoeVar.d(0);
            } catch (InvalidProtocolBufferException e) {
                throw new IllegalArgumentException(e);
            }
        } else {
            amoeVar = new amoe(inputStream, 4096);
        }
        amov amovVar = amov.a;
        amrc amrcVar = amrc.a;
        amov amovVar2 = amov.b;
        aajw aajwVar = new aajw();
        try {
            amrk a2 = amrc.a.a(aajwVar.getClass());
            amog amogVar = amoeVar.e;
            if (amogVar == null) {
                amogVar = new amog(amoeVar);
            }
            a2.h(aajwVar, amogVar, amovVar2);
            a2.f(aajwVar);
            Byte b2 = (byte) 1;
            b2.getClass();
            return aajwVar;
        } catch (InvalidProtocolBufferException e2) {
            if (e2.a) {
                throw new InvalidProtocolBufferException(e2);
            }
            throw e2;
        } catch (UninitializedMessageException e3) {
            throw new InvalidProtocolBufferException(e3.getMessage());
        } catch (IOException e4) {
            if (e4.getCause() instanceof InvalidProtocolBufferException) {
                throw ((InvalidProtocolBufferException) e4.getCause());
            }
            throw new InvalidProtocolBufferException(e4);
        } catch (RuntimeException e5) {
            if (e5.getCause() instanceof InvalidProtocolBufferException) {
                throw ((InvalidProtocolBufferException) e5.getCause());
            }
            throw e5;
        }
    }

    @Override // cal.ampm
    public final Object a(int i, Object obj) {
        int i2 = i - 1;
        if (i2 != 0) {
            if (i2 != 2) {
                if (i2 != 3) {
                    if (i2 != 4) {
                        if (i2 != 5) {
                            if (i2 != 6) {
                                return null;
                            }
                            amra amraVar = c;
                            if (amraVar == null) {
                                synchronized (aajw.class) {
                                    amraVar = c;
                                    if (amraVar == null) {
                                        amraVar = new amph(b);
                                        c = amraVar;
                                    }
                                }
                            }
                            return amraVar;
                        }
                        return b;
                    }
                    return new aajv();
                }
                return new aajw();
            }
            return new amre(b, "\u0004\n\u0000\u0001\u0001\u000b\n\u0000\u0003\u0000\u0001ည\u0000\u0002ဇ\u0001\u0003ဈ\u0002\u0004ဂ\u0003\u0005\u001a\u0006\u001a\u0007ࠬ\bဉ\u0004\nဇ\u0005\u000bဇ\u0006", new Object[]{"d", "e", "f", "g", "h", "i", "j", "k", ajvw.a, "l", "m", "n"});
        }
        return (byte) 1;
    }
}
