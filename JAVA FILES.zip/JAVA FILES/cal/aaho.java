package cal;

import android.database.ContentObserver;

/* compiled from: PG */
/* loaded from: classes2.dex */
final class aaho extends ContentObserver {
    public aaho() {
        super(null);
    }

    @Override // android.database.ContentObserver
    public final void onChange(boolean z) {
        aaip.a.incrementAndGet();
    }
}
