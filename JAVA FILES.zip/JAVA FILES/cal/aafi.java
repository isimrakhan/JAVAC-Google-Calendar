package cal;

import android.text.TextUtils;
import com.google.android.libraries.stitch.util.ThreadUtil$CalledOnWrongThreadException;
import j$.util.DesugarCollections;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;
import java.util.Random;
import java.util.UUID;
import java.util.concurrent.Executor;
import java.util.concurrent.atomic.AtomicReference;

/* compiled from: PG */
/* loaded from: classes2.dex */
public final class aafi extends aafd implements zwh, aaex {
    public final zwf a;
    public final anyt b;
    public final anyt c;
    public final aafq d;
    public final aafs e;
    public final AtomicReference f;
    private final ajds g;

    public aafi(zwg zwgVar, ajds ajdsVar, final anyt anytVar, anyt anytVar2, apxs apxsVar, aafq aafqVar) {
        AtomicReference atomicReference = new AtomicReference();
        this.f = atomicReference;
        this.g = ajdsVar;
        this.b = anytVar;
        this.c = anytVar2;
        this.d = aafqVar;
        this.a = zwgVar.a(ajdsVar, new anyt() { // from class: cal.aafg
            @Override // cal.anyt
            public final Object b() {
                aaen aaenVar = new aaen();
                aaenVar.a = 0.5f;
                aaenVar.b = (byte) 1;
                aaenVar.c = 3;
                aaez a = aaenVar.a();
                float f = ((aaeo) a).a;
                if (f >= 0.0f && f <= 1.0f) {
                    return a;
                }
                throw new IllegalStateException("Probability shall be between 0 and 1.");
            }
        }, apxsVar);
        this.e = new aafs(new apxs() { // from class: cal.aafh
            @Override // cal.apxs, cal.apxr
            public final Object b() {
                aoaw aoawVar = (aoaw) anyt.this;
                Object obj = aoawVar.b;
                if (obj == aoaw.a) {
                    obj = aoawVar.c();
                }
                ((aaew) obj).e();
                return 10;
            }
        });
        Random random = (Random) aafqVar.a.b();
        random.getClass();
        atomicReference.set(new aafp(random, 1.0f));
    }

    @Override // cal.aaex
    public final void a(String str, long j, long j2) {
        aafc aafcVar;
        if (!TextUtils.isEmpty(str) && j2 > 0 && (aafcVar = (aafc) aafj.c.get()) != null && aafcVar.b.c <= j) {
            aaet aaetVar = new aaet(str, j, j + j2, Thread.currentThread().getId(), 4);
            synchronized (aafcVar.e) {
                aafcVar.e.add(aaetVar);
            }
            aafcVar.a.incrementAndGet();
        }
    }

    @Override // cal.aaex
    public final boolean b() {
        aafp aafpVar = (aafp) this.f.get();
        if (aafpVar.b.nextFloat() >= aafpVar.a || aafj.c.get() != null) {
            return false;
        }
        AtomicReference atomicReference = aafj.c;
        aafc aafcVar = new aafc();
        while (!atomicReference.compareAndSet(null, aafcVar)) {
            if (atomicReference.get() != null) {
                return false;
            }
        }
        aafj.a = 5;
        aafj.b = 1000;
        return true;
    }

    @Override // cal.aaex
    public final ajdo c(String str) {
        if (true != TextUtils.isEmpty(null)) {
            str = null;
        }
        if (!TextUtils.isEmpty(str)) {
            final aafc aafcVar = (aafc) aafj.c.getAndSet(null);
            if (aafcVar != null) {
                aafcVar.b.b = str;
            }
            if (aafcVar == null) {
                return ajdj.a;
            }
            ajay ajayVar = new ajay() { // from class: cal.aaff
                @Override // cal.ajay
                public final ajdo a() {
                    List unmodifiableList;
                    aafi aafiVar = aafi.this;
                    if (((aaez) aafiVar.c.b()).d() == 3) {
                        aoaw aoawVar = (aoaw) aafiVar.b;
                        Object obj = aoawVar.b;
                        if (obj == aoaw.a) {
                            obj = aoawVar.c();
                        }
                        ((aaew) obj).e();
                        aafs aafsVar = aafiVar.e;
                        if (aafsVar.b(((Integer) aafsVar.a.b()).intValue())) {
                            return ajdj.a;
                        }
                        aafiVar.e.a();
                        if (!abyh.b(Thread.currentThread())) {
                            aafc aafcVar2 = aafcVar;
                            String str2 = null;
                            if (aafcVar2.a.get() != 0) {
                                Comparator comparator = new Comparator() { // from class: cal.aafa
                                    @Override // java.util.Comparator
                                    public final int compare(Object obj2, Object obj3) {
                                        return (int) (((aaet) obj2).c - ((aaet) obj3).c);
                                    }
                                };
                                synchronized (aafcVar2.e) {
                                    Collections.sort(aafcVar2.e, comparator);
                                    aafcVar2.b.a(aafcVar2.e);
                                }
                                ArrayList arrayList = new ArrayList(aafcVar2.c.keySet());
                                Collections.sort(arrayList, comparator);
                                aafcVar2.b.a(arrayList);
                                aaeu aaeuVar = new aaeu(aafcVar2.b);
                                ArrayList arrayList2 = new ArrayList();
                                aaeuVar.a(aaeuVar.a, 0L, arrayList2);
                                if (arrayList2.size() != 1) {
                                    unmodifiableList = DesugarCollections.unmodifiableList(arrayList2);
                                    if (unmodifiableList == null && !unmodifiableList.isEmpty()) {
                                        aqvr aqvrVar = aqvr.a;
                                        aqvp aqvpVar = new aqvp();
                                        long leastSignificantBits = UUID.randomUUID().getLeastSignificantBits();
                                        if ((aqvpVar.b.ad & Integer.MIN_VALUE) == 0) {
                                            aqvpVar.s();
                                        }
                                        aqvr aqvrVar2 = (aqvr) aqvpVar.b;
                                        aqvrVar2.c = 1 | aqvrVar2.c;
                                        aqvrVar2.d = leastSignificantBits;
                                        if ((aqvpVar.b.ad & Integer.MIN_VALUE) == 0) {
                                            aqvpVar.s();
                                        }
                                        aqvr aqvrVar3 = (aqvr) aqvpVar.b;
                                        ampw ampwVar = aqvrVar3.f;
                                        if (!ampwVar.b()) {
                                            int size = ampwVar.size();
                                            aqvrVar3.f = ampwVar.c(size + size);
                                        }
                                        amni.h(unmodifiableList, aqvrVar3.f);
                                        aqvr aqvrVar4 = (aqvr) aqvpVar.p();
                                        if (aqvrVar4.f.size() > 0) {
                                            str2 = ((aqvu) aqvrVar4.f.get(0)).d;
                                        }
                                        long a = aafiVar.a.a(str2);
                                        if (a == -1) {
                                            return ajdj.a;
                                        }
                                        aqyd aqydVar = aqyd.a;
                                        aqyc aqycVar = new aqyc();
                                        if ((aqycVar.b.ad & Integer.MIN_VALUE) == 0) {
                                            aqycVar.s();
                                        }
                                        aqyd aqydVar2 = (aqyd) aqycVar.b;
                                        aqvrVar4.getClass();
                                        aqydVar2.n = aqvrVar4;
                                        aqydVar2.c |= 2048;
                                        aqyd aqydVar3 = (aqyd) aqycVar.p();
                                        long j = aqvrVar4.d;
                                        zwf zwfVar = aafiVar.a;
                                        zvq zvqVar = new zvq();
                                        zvqVar.b = false;
                                        zvqVar.g = false;
                                        zvqVar.i = 0;
                                        zvqVar.j = (byte) 7;
                                        if (aqydVar3 != null) {
                                            zvqVar.c = aqydVar3;
                                            zvqVar.f = Long.valueOf(a);
                                            zvx a2 = zvqVar.a();
                                            if (zwfVar.a.a) {
                                                ajdh ajdhVar = ajdh.a;
                                                if (ajdhVar == null) {
                                                    return new ajdh();
                                                }
                                                return ajdhVar;
                                            }
                                            zwc zwcVar = new zwc(zwfVar, a2);
                                            Executor executor = zwfVar.d;
                                            ajel ajelVar = new ajel(zwcVar);
                                            executor.execute(ajelVar);
                                            return ajelVar;
                                        }
                                        throw new NullPointerException("Null metric");
                                    }
                                    return ajdj.a;
                                }
                            }
                            unmodifiableList = null;
                            if (unmodifiableList == null) {
                            }
                            return ajdj.a;
                        }
                        throw new ThreadUtil$CalledOnWrongThreadException("Must be called on a background thread");
                    }
                    return ajdj.a;
                }
            };
            ajds ajdsVar = this.g;
            ajel ajelVar = new ajel(ajayVar);
            ajdsVar.execute(ajelVar);
            return ajelVar;
        }
        throw new IllegalStateException();
    }

    @Override // cal.zwh
    public final void u() {
        this.g.execute(new Runnable() { // from class: cal.aafe
            @Override // java.lang.Runnable
            public final void run() {
                float f;
                aafi aafiVar = aafi.this;
                try {
                    AtomicReference atomicReference = aafiVar.f;
                    aafq aafqVar = aafiVar.d;
                    if (((aaez) aafiVar.c.b()).d() == 3) {
                        f = ((aaez) aafiVar.c.b()).c();
                    } else {
                        f = 0.0f;
                    }
                    Random random = (Random) aafqVar.a.b();
                    random.getClass();
                    atomicReference.set(new aafp(random, f));
                } catch (Throwable unused) {
                    AtomicReference atomicReference2 = aafiVar.f;
                    Random random2 = (Random) aafiVar.d.a.b();
                    random2.getClass();
                    atomicReference2.set(new aafp(random2, 0.0f));
                }
            }
        });
    }
}
