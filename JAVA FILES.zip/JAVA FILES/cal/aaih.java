package cal;

import android.util.Log;

/* compiled from: PG */
/* loaded from: classes2.dex */
public final class aaih extends aaip {
    public aaih(aain aainVar, String str, Long l) {
        super(aainVar, str, l, true);
    }

    @Override // cal.aaip
    public final /* bridge */ /* synthetic */ Object a(Object obj) {
        String concat;
        if (obj instanceof Long) {
            return (Long) obj;
        }
        if (obj instanceof String) {
            try {
                return Long.valueOf(Long.parseLong((String) obj));
            } catch (NumberFormatException unused) {
            }
        }
        String str = this.b.d;
        if (str.isEmpty()) {
            concat = this.c;
        } else {
            concat = str.concat(this.c);
        }
        Log.e("PhenotypeFlag", a.r(obj, concat, "Invalid long value for ", ": "));
        return null;
    }
}
