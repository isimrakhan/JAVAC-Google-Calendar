package cal;

import com.google.android.libraries.phenotype.client.PhenotypeContextTestMode$FirstFlagReadHere;

/* compiled from: PG */
/* loaded from: classes2.dex */
public final class aaid {
    public static final Object a = new Object();
    public static volatile PhenotypeContextTestMode$FirstFlagReadHere b = null;
    public static volatile boolean c = false;
    public static volatile PhenotypeContextTestMode$FirstFlagReadHere d = null;
    private static volatile boolean e = false;
}
