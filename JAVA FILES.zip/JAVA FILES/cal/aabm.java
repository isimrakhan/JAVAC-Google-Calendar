package cal;

import android.app.ActivityManager;
import android.content.Context;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.concurrent.Executor;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.atomic.AtomicInteger;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import org.chromium.net.UrlRequest;

/* compiled from: PG */
/* loaded from: classes2.dex */
public final class aabm extends aabh implements ztq, zwh {
    public final Context a;
    public final anyt b;
    public final anyt d;
    public final apxs e;
    public final zul h;
    private final zwf i;
    private final ajds j;
    public final Object c = new Object();
    public ArrayList f = new ArrayList(0);
    public final AtomicInteger g = new AtomicInteger();

    public aabm(zwg zwgVar, Context context, ztw ztwVar, ajds ajdsVar, anyt anytVar, anyt anytVar2, apxs apxsVar, Executor executor, zul zulVar) {
        this.h = zulVar;
        this.i = zwgVar.a(executor, anytVar, apxsVar);
        this.a = context;
        this.j = ajdsVar;
        this.b = anytVar;
        this.d = anytVar2;
        this.e = apxsVar;
        ztwVar.c.b.add(this);
    }

    @Override // cal.aabh
    public final ajdo a() {
        if (this.g.get() > 0) {
            ajay ajayVar = new ajay() { // from class: cal.aabk
                @Override // cal.ajay
                public final ajdo a() {
                    return aabm.this.a();
                }
            };
            ajds ajdsVar = this.j;
            TimeUnit timeUnit = TimeUnit.SECONDS;
            ajel ajelVar = new ajel(ajayVar);
            ajelVar.d(new ajcq(ajdsVar.schedule(ajelVar, 1L, timeUnit)), ajbw.a);
            return ajelVar;
        }
        synchronized (this.c) {
            if (this.f.isEmpty()) {
                return ajdj.a;
            }
            final ArrayList arrayList = this.f;
            this.f = new ArrayList(0);
            ajay ajayVar2 = new ajay() { // from class: cal.aabl
                @Override // cal.ajay
                public final ajdo a() {
                    aabm aabmVar = aabm.this;
                    return aabmVar.c(((aabf) aabmVar.d.b()).a(arrayList));
                }
            };
            ajds ajdsVar2 = this.j;
            ajel ajelVar2 = new ajel(ajayVar2);
            ajdsVar2.execute(ajelVar2);
            return ajelVar2;
        }
    }

    @Override // cal.aabh
    public final void b(final aabe aabeVar) {
        String str;
        String str2;
        if (aabeVar.b <= 0 && aabeVar.c <= 0 && aabeVar.d <= 0 && aabeVar.e <= 0 && aabeVar.q <= 0 && aabeVar.s <= 0) {
            ((aimj) ((aimj) zsj.a.d()).k("com/google/android/libraries/performance/primes/metrics/network/NetworkMetricServiceImpl", "recordAsFuture", 98, "NetworkMetricServiceImpl.java")).s("skip logging NetworkEvent due to empty bandwidth/latency data");
            ajdo ajdoVar = ajdj.a;
            return;
        }
        zwf zwfVar = this.i;
        String str3 = aabeVar.g;
        if (str3 != null && aabeVar.h) {
            str = str3 + "/" + aabeVar.f;
        } else {
            str = aabeVar.f;
        }
        String str4 = aabeVar.k;
        Pattern pattern = aabf.a;
        if (str != null && !str.isEmpty()) {
            Matcher matcher = aabf.a.matcher(str);
            if (matcher.find()) {
                str = matcher.group(1);
            } else {
                Matcher matcher2 = aabf.c.matcher(str);
                if (matcher2.find()) {
                    str = matcher2.group(1);
                } else {
                    Matcher matcher3 = aabf.b.matcher(str);
                    if (matcher3.find() && str4 != null && !str4.startsWith("application/")) {
                        str = matcher3.group(1);
                    }
                }
            }
        } else {
            str = "";
        }
        int i = aabeVar.u;
        if (i == 0) {
            str2 = null;
        } else {
            switch (i) {
                case 1:
                    str2 = "NONE";
                    break;
                case 2:
                    str2 = "MOBILE";
                    break;
                case 3:
                    str2 = "WIFI";
                    break;
                case 4:
                    str2 = "MOBILE_MMS";
                    break;
                case 5:
                    str2 = "MOBILE_SUPL";
                    break;
                case 6:
                    str2 = "MOBILE_DUN";
                    break;
                case 7:
                    str2 = "MOBILE_HIPRI";
                    break;
                case 8:
                    str2 = "WIMAX";
                    break;
                case 9:
                    str2 = "BLUETOOTH";
                    break;
                case 10:
                    str2 = "DUMMY";
                    break;
                case 11:
                    str2 = "ETHERNET";
                    break;
                case UrlRequest.Status.SENDING_REQUEST /* 12 */:
                    str2 = "MOBILE_FOTA";
                    break;
                case UrlRequest.Status.WAITING_FOR_RESPONSE /* 13 */:
                    str2 = "MOBILE_IMS";
                    break;
                case UrlRequest.Status.READING_RESPONSE /* 14 */:
                    str2 = "MOBILE_CBS";
                    break;
                case 15:
                    str2 = "WIFI_P2P";
                    break;
                case 16:
                    str2 = "MOBILE_IA";
                    break;
                case 17:
                    str2 = "MOBILE_EMERGENCY";
                    break;
                case 18:
                    str2 = "PROXY";
                    break;
                default:
                    str2 = "VPN";
                    break;
            }
        }
        ahsy ahsyVar = new ahsy(new ahtc(":"));
        Iterator it = new ahta(new Object[]{str2, null}, str, aabeVar.k).iterator();
        StringBuilder sb = new StringBuilder();
        try {
            ahsyVar.c(sb, it);
            final long a = zwfVar.a(sb.toString());
            if (a == -1) {
                ajdo ajdoVar2 = ajdj.a;
            } else {
                this.g.incrementAndGet();
                this.j.execute(new ajel(new ajay() { // from class: cal.aabj
                    @Override // cal.ajay
                    public final ajdo a() {
                        zuh zuhVar;
                        ArrayList arrayList;
                        ajdo c;
                        NetworkInfo activeNetworkInfo;
                        aabm aabmVar = aabm.this;
                        long j = a;
                        try {
                            int a2 = aqwk.a(((aqwl) aabmVar.e.b()).e);
                            aabe aabeVar2 = aabeVar;
                            if (a2 != 0 && a2 == 5) {
                                aabeVar2.t = new ahts(Long.valueOf(j));
                            }
                            Context context = aabmVar.a;
                            zul zulVar = aabmVar.h;
                            Context context2 = zulVar.b;
                            String str5 = zuk.a;
                            Object systemService = context2.getSystemService("activity");
                            systemService.getClass();
                            List<ActivityManager.RunningAppProcessInfo> runningAppProcesses = ((ActivityManager) systemService).getRunningAppProcesses();
                            int i2 = 1;
                            if (runningAppProcesses == null) {
                                ailt ailtVar = aick.e;
                                zuhVar = new zuh(false, aikm.b);
                            } else {
                                zuhVar = new zuh(true, aick.h(runningAppProcesses));
                            }
                            aabeVar2.l = zul.a(zulVar.a.a(zuhVar), zuhVar);
                            int i3 = -1;
                            try {
                                ConnectivityManager connectivityManager = (ConnectivityManager) context.getSystemService("connectivity");
                                if (connectivityManager != null && (activeNetworkInfo = connectivityManager.getActiveNetworkInfo()) != null) {
                                    i3 = activeNetworkInfo.getType();
                                }
                            } catch (SecurityException e) {
                                ((aimj) ((aimj) ((aimj) zsj.a.d()).j(e)).k("com/google/android/libraries/performance/primes/metrics/network/NetworkCapture", "getNetworkType", '$', "NetworkCapture.java")).s("Failed to get network type, Please add: android.permission.ACCESS_NETWORK_STATE to AndroidManifest.xml");
                            }
                            int a3 = aqux.a(i3);
                            if (a3 != 0) {
                                i2 = a3;
                            }
                            aabeVar2.u = i2;
                            int c2 = ((aabd) aabmVar.b.b()).c();
                            synchronized (aabmVar.c) {
                                aabmVar.f.ensureCapacity(c2);
                                aabmVar.f.add(aabeVar2);
                                if (aabmVar.f.size() >= c2) {
                                    arrayList = aabmVar.f;
                                    aabmVar.f = new ArrayList(0);
                                } else {
                                    arrayList = null;
                                }
                            }
                            if (arrayList == null) {
                                c = ajdj.a;
                            } else {
                                c = aabmVar.c(((aabf) aabmVar.d.b()).a(arrayList));
                            }
                            return c;
                        } finally {
                            aabmVar.g.decrementAndGet();
                        }
                    }
                }));
            }
        } catch (IOException e) {
            throw new AssertionError(e);
        }
    }

    public final ajdo c(aqyd aqydVar) {
        aquh aquhVar;
        try {
            aquhVar = (aquh) ((aabg) ((aabd) this.b.b()).d().f(new aabg() { // from class: cal.aabi
                @Override // cal.aabg
                public final ahti a() {
                    return ahre.a;
                }
            })).a().g();
        } catch (Exception e) {
            a.p(zsj.a.d(), "Exception while getting network metric extension!", "com/google/android/libraries/performance/primes/metrics/network/NetworkMetricServiceImpl", "recordMetric", (char) 191, "NetworkMetricServiceImpl.java", e);
            aquhVar = null;
        }
        zwf zwfVar = this.i;
        zvq zvqVar = new zvq();
        zvqVar.b = false;
        zvqVar.g = false;
        zvqVar.i = 0;
        zvqVar.j = (byte) 7;
        if (aqydVar != null) {
            zvqVar.c = aqydVar;
            zvqVar.d = aquhVar;
            zvx a = zvqVar.a();
            if (zwfVar.a.a) {
                ajdh ajdhVar = ajdh.a;
                if (ajdhVar == null) {
                    return new ajdh();
                }
                return ajdhVar;
            }
            zwc zwcVar = new zwc(zwfVar, a);
            Executor executor = zwfVar.d;
            ajel ajelVar = new ajel(zwcVar);
            executor.execute(ajelVar);
            return ajelVar;
        }
        throw new NullPointerException("Null metric");
    }

    @Override // cal.ztq
    public final void i(zry zryVar) {
        a();
    }

    @Override // cal.zwh
    public final /* synthetic */ void u() {
    }

    @Override // cal.ztq
    public final /* synthetic */ void j(zry zryVar) {
    }
}
