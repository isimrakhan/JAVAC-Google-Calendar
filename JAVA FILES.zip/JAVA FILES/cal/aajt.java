package cal;

/* compiled from: PG */
/* loaded from: classes2.dex */
public final class aajt {
    public static final aajt a = new aajt(aajp.a, aajl.a);
    public final aajp b;
    public final aajl c;

    public aajt(aajp aajpVar, aajl aajlVar) {
        aajpVar.getClass();
        this.b = aajpVar;
        this.c = aajlVar;
    }
}
