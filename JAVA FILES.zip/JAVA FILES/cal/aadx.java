package cal;

/* compiled from: PG */
/* loaded from: classes2.dex */
public final class aadx extends aaec {
    public int a;
    public float b;
    public ahti c = ahre.a;
    public byte d;
    public int e;

    @Override // cal.aaec
    public final aaed a() {
        int i;
        if (this.d == 3 && (i = this.e) != 0) {
            return new aady(i, this.a, this.b, this.c);
        }
        StringBuilder sb = new StringBuilder();
        if (this.e == 0) {
            sb.append(" enablement");
        }
        if ((this.d & 1) == 0) {
            sb.append(" rateLimitPerSecond");
        }
        if ((this.d & 2) == 0) {
            sb.append(" samplingProbability");
        }
        throw new IllegalStateException("Missing required properties:".concat(sb.toString()));
    }
}
