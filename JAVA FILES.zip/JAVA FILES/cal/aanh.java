package cal;

/* compiled from: PG */
/* loaded from: classes2.dex */
public final /* synthetic */ class aanh implements ahsr {
    @Override // cal.ahsr
    /* renamed from: a */
    public final Object b(Object obj) {
        long j;
        boolean z;
        double d;
        String str;
        amob amobVar;
        aaiz aaizVar = (aaiz) obj;
        aano aanoVar = aano.a;
        aann aannVar = new aann();
        if (aaizVar == null) {
            return (aano) aannVar.p();
        }
        for (aajc aajcVar : aaizVar.g) {
            aanq aanqVar = aanq.a;
            aanp aanpVar = new aanp();
            String str2 = aajcVar.f;
            if ((aanpVar.b.ad & Integer.MIN_VALUE) == 0) {
                aanpVar.s();
            }
            aanq aanqVar2 = (aanq) aanpVar.b;
            str2.getClass();
            aanqVar2.c |= 1;
            aanqVar2.f = str2;
            int i = aajcVar.d;
            int a = aajb.a(i);
            if (a != 0) {
                int i2 = a - 1;
                if (i2 != 0) {
                    if (i2 != 1) {
                        if (i2 != 2) {
                            if (i2 != 3) {
                                if (i2 == 4) {
                                    if (i == 5) {
                                        amobVar = (amob) aajcVar.e;
                                    } else {
                                        amobVar = amob.b;
                                    }
                                    if ((aanpVar.b.ad & Integer.MIN_VALUE) == 0) {
                                        aanpVar.s();
                                    }
                                    aanq aanqVar3 = (aanq) aanpVar.b;
                                    amobVar.getClass();
                                    aanqVar3.d = 6;
                                    aanqVar3.e = amobVar;
                                } else {
                                    throw new IllegalStateException("No known flag type");
                                }
                            } else {
                                if (i == 4) {
                                    str = (String) aajcVar.e;
                                } else {
                                    str = "";
                                }
                                if ((aanpVar.b.ad & Integer.MIN_VALUE) == 0) {
                                    aanpVar.s();
                                }
                                aanq aanqVar4 = (aanq) aanpVar.b;
                                str.getClass();
                                aanqVar4.d = 5;
                                aanqVar4.e = str;
                            }
                        } else {
                            if (i == 3) {
                                d = ((Double) aajcVar.e).doubleValue();
                            } else {
                                d = 0.0d;
                            }
                            if ((aanpVar.b.ad & Integer.MIN_VALUE) == 0) {
                                aanpVar.s();
                            }
                            aanq aanqVar5 = (aanq) aanpVar.b;
                            aanqVar5.d = 4;
                            aanqVar5.e = Double.valueOf(d);
                        }
                    } else {
                        if (i == 2) {
                            z = ((Boolean) aajcVar.e).booleanValue();
                        } else {
                            z = false;
                        }
                        if ((aanpVar.b.ad & Integer.MIN_VALUE) == 0) {
                            aanpVar.s();
                        }
                        aanq aanqVar6 = (aanq) aanpVar.b;
                        aanqVar6.d = 3;
                        aanqVar6.e = Boolean.valueOf(z);
                    }
                } else {
                    if (i == 1) {
                        j = ((Long) aajcVar.e).longValue();
                    } else {
                        j = 0;
                    }
                    if ((aanpVar.b.ad & Integer.MIN_VALUE) == 0) {
                        aanpVar.s();
                    }
                    aanq aanqVar7 = (aanq) aanpVar.b;
                    aanqVar7.d = 2;
                    aanqVar7.e = Long.valueOf(j);
                }
                aanq aanqVar8 = (aanq) aanpVar.p();
                if ((aannVar.b.ad & Integer.MIN_VALUE) == 0) {
                    aannVar.s();
                }
                aano aanoVar2 = (aano) aannVar.b;
                aanqVar8.getClass();
                ampw ampwVar = aanoVar2.h;
                if (!ampwVar.b()) {
                    int size = ampwVar.size();
                    aanoVar2.h = ampwVar.c(size + size);
                }
                aanoVar2.h.add(aanqVar8);
            } else {
                throw null;
            }
        }
        String str3 = aaizVar.f;
        if ((aannVar.b.ad & Integer.MIN_VALUE) == 0) {
            aannVar.s();
        }
        aano aanoVar3 = (aano) aannVar.b;
        str3.getClass();
        aanoVar3.c = 4 | aanoVar3.c;
        aanoVar3.f = str3;
        String str4 = aaizVar.d;
        if ((aannVar.b.ad & Integer.MIN_VALUE) == 0) {
            aannVar.s();
        }
        aano aanoVar4 = (aano) aannVar.b;
        str4.getClass();
        aanoVar4.c = 1 | aanoVar4.c;
        aanoVar4.d = str4;
        long j2 = aaizVar.j;
        if ((aannVar.b.ad & Integer.MIN_VALUE) == 0) {
            aannVar.s();
        }
        aano aanoVar5 = (aano) aannVar.b;
        aanoVar5.c |= 8;
        aanoVar5.g = j2;
        if ((aaizVar.c & 2) != 0) {
            amob amobVar2 = aaizVar.e;
            if ((aannVar.b.ad & Integer.MIN_VALUE) == 0) {
                aannVar.s();
            }
            aano aanoVar6 = (aano) aannVar.b;
            amobVar2.getClass();
            aanoVar6.c |= 2;
            aanoVar6.e = amobVar2;
        }
        return (aano) aannVar.p();
    }
}
