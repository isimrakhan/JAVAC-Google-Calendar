package cal;

/* compiled from: PG */
/* loaded from: classes2.dex */
public final class aagp extends ampg implements amqu {
    public aagp() {
        super(aagq.a);
    }
}
