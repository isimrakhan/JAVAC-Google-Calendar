package cal;

import android.content.Context;
import android.net.Uri;

/* compiled from: PG */
/* loaded from: classes2.dex */
public final class aahs {
    public static final /* synthetic */ int a = 0;
    private static final aaz b = new aaz();

    public static synchronized Uri a(String str) {
        Object obj;
        synchronized (aahs.class) {
            aaz aazVar = b;
            int d = aazVar.d(str, str.hashCode());
            if (d >= 0) {
                obj = aazVar.e[d + d + 1];
            } else {
                obj = null;
            }
            Uri uri = (Uri) obj;
            if (uri == null) {
                Uri parse = Uri.parse("content://com.google.android.gms.phenotype/".concat(String.valueOf(Uri.encode(str))));
                aazVar.put(str, parse);
                return parse;
            }
            return uri;
        }
    }

    public static String b(Context context, String str) {
        if (!str.contains("#")) {
            return str + "#" + context.getPackageName();
        }
        throw new IllegalArgumentException("The passed in package cannot already have a subpackage: ".concat(String.valueOf(str)));
    }
}
