package cal;

/* compiled from: PG */
/* loaded from: classes2.dex */
final class aahb implements aahe {
    @Override // cal.aahe
    public final /* synthetic */ String a(amqs amqsVar) {
        return ((aqyd) ((aqyc) amqsVar).b).f;
    }

    @Override // cal.aahe
    public final /* synthetic */ String b(amqs amqsVar) {
        return ((aqyd) ((aqyc) amqsVar).b).e;
    }

    @Override // cal.aahe
    public final /* synthetic */ void c(amqs amqsVar, Long l) {
        aqyc aqycVar = (aqyc) amqsVar;
        if (l != null) {
            long longValue = l.longValue();
            if ((aqycVar.b.ad & Integer.MIN_VALUE) == 0) {
                aqycVar.s();
            }
            aqyd aqydVar = (aqyd) aqycVar.b;
            aqyd aqydVar2 = aqyd.a;
            aqydVar.c |= 1;
            aqydVar.d = longValue;
            return;
        }
        if ((aqycVar.b.ad & Integer.MIN_VALUE) == 0) {
            aqycVar.s();
        }
        aqyd aqydVar3 = (aqyd) aqycVar.b;
        aqyd aqydVar4 = aqyd.a;
        aqydVar3.c &= -2;
        aqydVar3.d = 0L;
    }

    @Override // cal.aahe
    public final /* synthetic */ void d(amqs amqsVar) {
        aqyc aqycVar = (aqyc) amqsVar;
        if ((aqycVar.b.ad & Integer.MIN_VALUE) == 0) {
            aqycVar.s();
        }
        aqyd aqydVar = (aqyd) aqycVar.b;
        aqyd aqydVar2 = aqyd.a;
        aqydVar.c &= -3;
        aqydVar.e = aqyd.a.e;
    }
}
