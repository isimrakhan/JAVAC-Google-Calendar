package cal;

/* compiled from: PG */
/* loaded from: classes2.dex */
public enum aaon {
    ASYNC_TASK,
    UNCAUGHT_EXCEPTION_HANDLER,
    PRIMES,
    APP_DOCTOR,
    JVM_LOG_FORMAT,
    LOGGING,
    STRICT_MODE,
    SSLGUARD,
    CRONET_URLSTREAMHANDLER,
    STARTUP_LISTENERS
}
