package cal;

import com.google.android.libraries.social.connections.schema.InteractionsDocument;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Comparator;
import java.util.EnumMap;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import java.util.concurrent.TimeUnit;

/* compiled from: PG */
/* loaded from: classes2.dex */
public final class aapq {
    public static aics a(Map map) {
        EnumMap enumMap = new EnumMap(aaqk.class);
        for (Map.Entry entry : map.entrySet()) {
            aaqk aaqkVar = (aaqk) entry.getKey();
            aapw aapwVar = (aapw) entry.getValue();
            aaqp aaqpVar = aapwVar.b;
            HashMap hashMap = aapwVar.c;
            Comparator comparator = aieb.e;
            Collection entrySet = hashMap.entrySet();
            Map.Entry[] entryArr = aieb.a;
            if (!(entrySet instanceof Collection)) {
                Iterator it = entrySet.iterator();
                Collection arrayList = new ArrayList();
                aifa.j(arrayList, it);
                entrySet = arrayList;
            }
            Map.Entry[] entryArr2 = (Map.Entry[]) entrySet.toArray(entryArr);
            aieb p = aieb.p(comparator, entryArr2, entryArr2.length);
            HashMap hashMap2 = aapwVar.d;
            Comparator comparator2 = aieb.e;
            Collection entrySet2 = hashMap2.entrySet();
            Map.Entry[] entryArr3 = aieb.a;
            if (!(entrySet2 instanceof Collection)) {
                Iterator it2 = entrySet2.iterator();
                Collection arrayList2 = new ArrayList();
                aifa.j(arrayList2, it2);
                entrySet2 = arrayList2;
            }
            Map.Entry[] entryArr4 = (Map.Entry[]) entrySet2.toArray(entryArr3);
            enumMap.put((EnumMap) aaqkVar, (aaqk) new aapx(aaqpVar, p, aieb.p(comparator2, entryArr4, entryArr4.length)));
        }
        return aics.i(enumMap);
    }

    public static void b(InteractionsDocument interactionsDocument, aaqq aaqqVar, Map map) {
        aaqk aaqkVar;
        try {
            int parseInt = Integer.parseInt(interactionsDocument.f);
            if (parseInt != 0) {
                if (parseInt != 1) {
                    if (parseInt != 2) {
                        if (parseInt != 3) {
                            if (parseInt != 4) {
                                if (parseInt != 5) {
                                    aaqkVar = null;
                                } else {
                                    aaqkVar = aaqk.CONTACTS_DIRECTION;
                                }
                            } else {
                                aaqkVar = aaqk.CONTACTS_EMAIL;
                            }
                        } else {
                            aaqkVar = aaqk.CONTACTS_VIDEO_CALL;
                        }
                    } else {
                        aaqkVar = aaqk.CONTACTS_TEXT;
                    }
                } else {
                    aaqkVar = aaqk.CONTACTS_CALL;
                }
            } else {
                aaqkVar = aaqk.INTERACTION_TYPE_UNSPECIFIED;
            }
            if (aaqkVar == null) {
                aaqkVar = aaqk.INTERACTION_TYPE_UNSPECIFIED;
            }
        } catch (NumberFormatException unused) {
            aaqkVar = aaqk.INTERACTION_TYPE_UNSPECIFIED;
        }
        aapw aapwVar = (aapw) map.get(aaqkVar);
        if (aapwVar == null) {
            aapwVar = new aapw(aaqqVar);
            map.put(aaqkVar, aapwVar);
        }
        Iterator it = interactionsDocument.m.iterator();
        while (it.hasNext()) {
            aaqq aaqqVar2 = new aaqq(((Long) it.next()).longValue());
            aaqq aaqqVar3 = aapwVar.a;
            aaqp aaqpVar = new aaqp(aaqqVar3.a - aaqqVar2.a);
            long days = TimeUnit.MILLISECONDS.toDays(aaqpVar.a);
            long a = ((aoqx) ((ahur) aoqw.a.b).a).a();
            if (a <= 0 || days <= a) {
                aaqp aaqpVar2 = aapwVar.b;
                if (aaqpVar2 == null || aaqpVar.a < aaqpVar2.a) {
                    aapwVar.b = aaqpVar;
                }
                aapw.a(aapwVar.c, Long.valueOf(days), 1);
                if (days == 0) {
                    aapw.a(aapwVar.d, Long.valueOf(TimeUnit.MILLISECONDS.toHours(aaqpVar.a)), 1);
                }
            }
        }
    }
}
