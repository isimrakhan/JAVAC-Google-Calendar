package cal;

import android.content.Context;
import java.util.concurrent.atomic.AtomicInteger;
import java.util.concurrent.atomic.AtomicReference;

/* compiled from: PG */
/* loaded from: classes2.dex */
public abstract class aaip {
    public static final AtomicInteger a;
    private static final Object d = new Object();
    private static volatile aaio e = null;
    private static volatile boolean f = false;
    private static final aajh g;
    final aain b;
    final String c;
    private Object h;
    private volatile int i = -1;
    private volatile Object j;
    private final boolean k;
    private volatile boolean l;

    static {
        new AtomicReference();
        g = new aajh(new aaji() { // from class: cal.aaig
            @Override // cal.aaji
            public final void a() {
                AtomicInteger atomicInteger = aaip.a;
            }
        });
        a = new AtomicInteger();
    }

    public aaip(aain aainVar, String str, Object obj, boolean z) {
        String str2 = aainVar.a;
        if (str2 == null && aainVar.b == null) {
            throw new IllegalArgumentException("Must pass a valid SharedPreferences file name or ContentProvider URI");
        }
        if (str2 != null && aainVar.b != null) {
            throw new IllegalArgumentException("Must pass one of SharedPreferences file name or ContentProvider URI");
        }
        this.b = aainVar;
        this.c = str;
        this.h = obj;
        this.k = z;
        this.l = false;
    }

    public static void d(final Context context) {
        if (e == null && context != null) {
            Object obj = d;
            synchronized (obj) {
                if (e == null) {
                    synchronized (obj) {
                        aaio aaioVar = e;
                        Context applicationContext = context.getApplicationContext();
                        if (applicationContext != null) {
                            context = applicationContext;
                        }
                        if (aaioVar == null || ((aahi) aaioVar).a != context) {
                            if (aaioVar != null) {
                                aahk.c();
                                aait.b();
                                aahp.c();
                            }
                            e = new aahi(context, ahus.a(new ahum() { // from class: cal.aaif
                                @Override // cal.ahum
                                public final Object a() {
                                    AtomicInteger atomicInteger = aaip.a;
                                    return aahq.a(context);
                                }
                            }));
                            a.incrementAndGet();
                        }
                    }
                }
            }
        }
    }

    public abstract Object a(Object obj);

    /* JADX WARN: Can't wrap try/catch for region: R(10:110|(7:112|(1:114)(1:122)|115|(1:117)|119|120|121)|123|124|125|126|(1:128)|119|120|121) */
    /* JADX WARN: Code restructure failed: missing block: B:118:0x00ce, code lost:
    
        if ("com.google.android.gms".equals(r8.packageName) != false) goto L43;
     */
    /* JADX WARN: Code restructure failed: missing block: B:165:0x0165, code lost:
    
        if (cal.vvg.a(r6) != false) goto L80;
     */
    /* JADX WARN: Removed duplicated region for block: B:166:0x026b A[Catch: all -> 0x0273, TryCatch #1 {, blocks: (B:8:0x0013, B:10:0x0017, B:12:0x001e, B:14:0x002f, B:17:0x0049, B:19:0x0050, B:21:0x0063, B:24:0x01cd, B:26:0x01d7, B:27:0x01e0, B:29:0x01e6, B:31:0x01ee, B:33:0x01f4, B:34:0x01fa, B:45:0x0223, B:48:0x023c, B:50:0x0242, B:51:0x022b, B:53:0x0233, B:54:0x0236, B:58:0x0249, B:61:0x024c, B:63:0x0252, B:66:0x025a, B:67:0x025f, B:68:0x0263, B:69:0x01da, B:71:0x0074, B:73:0x007c, B:75:0x00fb, B:76:0x010c, B:101:0x0144, B:102:0x008a, B:103:0x008c, B:121:0x00ed, B:133:0x0147, B:134:0x0148, B:138:0x016b, B:163:0x026a, B:164:0x0161, B:166:0x026b, B:167:0x0270, B:169:0x0271, B:78:0x010d, B:80:0x0111, B:82:0x0126, B:83:0x0130, B:89:0x0134, B:91:0x0139, B:85:0x013f, B:98:0x0119, B:105:0x008d, B:107:0x0095, B:108:0x00a1, B:110:0x00a3, B:112:0x00b0, B:115:0x00c0, B:117:0x00c6, B:119:0x00e1, B:120:0x00ec, B:123:0x00d0, B:125:0x00d4, B:126:0x00da, B:36:0x01fb, B:38:0x01ff, B:40:0x0213, B:41:0x021e, B:42:0x0219, B:43:0x0220, B:44:0x0222, B:140:0x016c, B:142:0x0170, B:144:0x0185, B:145:0x018f, B:147:0x0193, B:152:0x01b1, B:153:0x01bc, B:156:0x01c6, B:157:0x01c9, B:158:0x01ca, B:160:0x0178), top: B:7:0x0013, inners: #0, #3, #4, #5 }] */
    /* JADX WARN: Removed duplicated region for block: B:17:0x0049 A[Catch: all -> 0x0273, TryCatch #1 {, blocks: (B:8:0x0013, B:10:0x0017, B:12:0x001e, B:14:0x002f, B:17:0x0049, B:19:0x0050, B:21:0x0063, B:24:0x01cd, B:26:0x01d7, B:27:0x01e0, B:29:0x01e6, B:31:0x01ee, B:33:0x01f4, B:34:0x01fa, B:45:0x0223, B:48:0x023c, B:50:0x0242, B:51:0x022b, B:53:0x0233, B:54:0x0236, B:58:0x0249, B:61:0x024c, B:63:0x0252, B:66:0x025a, B:67:0x025f, B:68:0x0263, B:69:0x01da, B:71:0x0074, B:73:0x007c, B:75:0x00fb, B:76:0x010c, B:101:0x0144, B:102:0x008a, B:103:0x008c, B:121:0x00ed, B:133:0x0147, B:134:0x0148, B:138:0x016b, B:163:0x026a, B:164:0x0161, B:166:0x026b, B:167:0x0270, B:169:0x0271, B:78:0x010d, B:80:0x0111, B:82:0x0126, B:83:0x0130, B:89:0x0134, B:91:0x0139, B:85:0x013f, B:98:0x0119, B:105:0x008d, B:107:0x0095, B:108:0x00a1, B:110:0x00a3, B:112:0x00b0, B:115:0x00c0, B:117:0x00c6, B:119:0x00e1, B:120:0x00ec, B:123:0x00d0, B:125:0x00d4, B:126:0x00da, B:36:0x01fb, B:38:0x01ff, B:40:0x0213, B:41:0x021e, B:42:0x0219, B:43:0x0220, B:44:0x0222, B:140:0x016c, B:142:0x0170, B:144:0x0185, B:145:0x018f, B:147:0x0193, B:152:0x01b1, B:153:0x01bc, B:156:0x01c6, B:157:0x01c9, B:158:0x01ca, B:160:0x0178), top: B:7:0x0013, inners: #0, #3, #4, #5 }] */
    /* JADX WARN: Removed duplicated region for block: B:24:0x01cd A[Catch: all -> 0x0273, TRY_ENTER, TryCatch #1 {, blocks: (B:8:0x0013, B:10:0x0017, B:12:0x001e, B:14:0x002f, B:17:0x0049, B:19:0x0050, B:21:0x0063, B:24:0x01cd, B:26:0x01d7, B:27:0x01e0, B:29:0x01e6, B:31:0x01ee, B:33:0x01f4, B:34:0x01fa, B:45:0x0223, B:48:0x023c, B:50:0x0242, B:51:0x022b, B:53:0x0233, B:54:0x0236, B:58:0x0249, B:61:0x024c, B:63:0x0252, B:66:0x025a, B:67:0x025f, B:68:0x0263, B:69:0x01da, B:71:0x0074, B:73:0x007c, B:75:0x00fb, B:76:0x010c, B:101:0x0144, B:102:0x008a, B:103:0x008c, B:121:0x00ed, B:133:0x0147, B:134:0x0148, B:138:0x016b, B:163:0x026a, B:164:0x0161, B:166:0x026b, B:167:0x0270, B:169:0x0271, B:78:0x010d, B:80:0x0111, B:82:0x0126, B:83:0x0130, B:89:0x0134, B:91:0x0139, B:85:0x013f, B:98:0x0119, B:105:0x008d, B:107:0x0095, B:108:0x00a1, B:110:0x00a3, B:112:0x00b0, B:115:0x00c0, B:117:0x00c6, B:119:0x00e1, B:120:0x00ec, B:123:0x00d0, B:125:0x00d4, B:126:0x00da, B:36:0x01fb, B:38:0x01ff, B:40:0x0213, B:41:0x021e, B:42:0x0219, B:43:0x0220, B:44:0x0222, B:140:0x016c, B:142:0x0170, B:144:0x0185, B:145:0x018f, B:147:0x0193, B:152:0x01b1, B:153:0x01bc, B:156:0x01c6, B:157:0x01c9, B:158:0x01ca, B:160:0x0178), top: B:7:0x0013, inners: #0, #3, #4, #5 }] */
    /* JADX WARN: Removed duplicated region for block: B:31:0x01ee A[Catch: all -> 0x0273, TryCatch #1 {, blocks: (B:8:0x0013, B:10:0x0017, B:12:0x001e, B:14:0x002f, B:17:0x0049, B:19:0x0050, B:21:0x0063, B:24:0x01cd, B:26:0x01d7, B:27:0x01e0, B:29:0x01e6, B:31:0x01ee, B:33:0x01f4, B:34:0x01fa, B:45:0x0223, B:48:0x023c, B:50:0x0242, B:51:0x022b, B:53:0x0233, B:54:0x0236, B:58:0x0249, B:61:0x024c, B:63:0x0252, B:66:0x025a, B:67:0x025f, B:68:0x0263, B:69:0x01da, B:71:0x0074, B:73:0x007c, B:75:0x00fb, B:76:0x010c, B:101:0x0144, B:102:0x008a, B:103:0x008c, B:121:0x00ed, B:133:0x0147, B:134:0x0148, B:138:0x016b, B:163:0x026a, B:164:0x0161, B:166:0x026b, B:167:0x0270, B:169:0x0271, B:78:0x010d, B:80:0x0111, B:82:0x0126, B:83:0x0130, B:89:0x0134, B:91:0x0139, B:85:0x013f, B:98:0x0119, B:105:0x008d, B:107:0x0095, B:108:0x00a1, B:110:0x00a3, B:112:0x00b0, B:115:0x00c0, B:117:0x00c6, B:119:0x00e1, B:120:0x00ec, B:123:0x00d0, B:125:0x00d4, B:126:0x00da, B:36:0x01fb, B:38:0x01ff, B:40:0x0213, B:41:0x021e, B:42:0x0219, B:43:0x0220, B:44:0x0222, B:140:0x016c, B:142:0x0170, B:144:0x0185, B:145:0x018f, B:147:0x0193, B:152:0x01b1, B:153:0x01bc, B:156:0x01c6, B:157:0x01c9, B:158:0x01ca, B:160:0x0178), top: B:7:0x0013, inners: #0, #3, #4, #5 }] */
    /* JADX WARN: Removed duplicated region for block: B:65:0x0258  */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct code enable 'Show inconsistent code' option in preferences
    */
    public final java.lang.Object b() {
        /*
            Method dump skipped, instructions count: 633
            To view this dump change 'Code comments level' option to 'DEBUG'
        */
        throw new UnsupportedOperationException("Method not decompiled: cal.aaip.b():java.lang.Object");
    }

    public final Object c() {
        if (this.l) {
            synchronized (this) {
                if (this.l) {
                    Object a2 = a(this.h);
                    a2.getClass();
                    this.h = a2;
                    this.l = false;
                }
            }
        }
        return this.h;
    }

    public aaip(aain aainVar) {
        String str = aainVar.a;
        if (str == null && aainVar.b == null) {
            throw new IllegalArgumentException("Must pass a valid SharedPreferences file name or ContentProvider URI");
        }
        if (str != null && aainVar.b != null) {
            throw new IllegalArgumentException("Must pass one of SharedPreferences file name or ContentProvider URI");
        }
        this.b = aainVar;
        this.c = "getTokenRefactor__blocked_packages";
        this.h = "ChNjb20uYW5kcm9pZC52ZW5kaW5nCiBjb20uZ29vZ2xlLmFuZHJvaWQuYXBwcy5tZWV0aW5ncwohY29tLmdvb2dsZS5hbmRyb2lkLmFwcHMubWVzc2FnaW5n";
        this.k = true;
        this.l = true;
    }
}
