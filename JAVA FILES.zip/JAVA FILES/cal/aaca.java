package cal;

import android.os.SystemClock;
import j$.time.Duration;

/* compiled from: PG */
/* loaded from: classes2.dex */
public final /* synthetic */ class aaca implements Runnable {
    public final /* synthetic */ aacd a;

    public /* synthetic */ aaca(aacd aacdVar) {
        this.a = aacdVar;
    }

    @Override // java.lang.Runnable
    public final void run() {
        long millis = Duration.ofMillis(SystemClock.uptimeMillis()).toMillis();
        final aacd aacdVar = this.a;
        aacdVar.e = millis;
        aacdVar.b.post(new Runnable() { // from class: cal.aacc
            @Override // java.lang.Runnable
            public final void run() {
                aacd.this.f = Duration.ofMillis(SystemClock.uptimeMillis()).toMillis();
            }
        });
        aacdVar.a(new aacb(aacdVar), aacdVar.a.c());
    }
}
