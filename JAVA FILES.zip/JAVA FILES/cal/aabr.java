package cal;

/* compiled from: PG */
/* loaded from: classes2.dex */
public abstract class aabr implements zun {
    public static final aabq i() {
        aabo aaboVar = new aabo();
        aaboVar.g = 1;
        aaboVar.a = 250;
        aaboVar.b = 250;
        aaboVar.c = 250;
        aaboVar.d = 10000;
        aaboVar.f = (byte) 15;
        ailt ailtVar = aick.e;
        Object[] objArr = {1000, 2500, 5000};
        for (int i = 0; i < 3; i++) {
            if (objArr[i] == null) {
                throw new NullPointerException("at index " + i);
            }
        }
        aaboVar.e = aick.h(new aikm(objArr, 3));
        return aaboVar;
    }

    @Override // cal.zun
    public final /* synthetic */ int a() {
        return Integer.MAX_VALUE;
    }

    @Override // cal.zun
    public final boolean b() {
        if (h() == 3 || h() == 1) {
            return true;
        }
        return false;
    }

    public abstract int c();

    public abstract int d();

    public abstract int e();

    public abstract int f();

    public abstract aick g();

    public abstract int h();
}
