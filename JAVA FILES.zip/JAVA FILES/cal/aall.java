package cal;

/* compiled from: PG */
/* loaded from: classes2.dex */
public final class aall extends ampg implements amqu {
    public aall() {
        super(aalm.a);
    }
}
