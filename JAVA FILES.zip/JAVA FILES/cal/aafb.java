package cal;

import android.os.Looper;
import android.os.SystemClock;
import java.lang.ref.WeakReference;
import java.util.ArrayDeque;

/* compiled from: PG */
/* loaded from: classes2.dex */
final class aafb extends ThreadLocal {
    final /* synthetic */ aafc a;

    public aafb(aafc aafcVar) {
        this.a = aafcVar;
    }

    @Override // java.lang.ThreadLocal
    protected final /* bridge */ /* synthetic */ Object initialValue() {
        String concat;
        long id = Thread.currentThread().getId();
        if (Looper.myLooper() == Looper.getMainLooper()) {
            concat = "UI Thread";
        } else {
            concat = "Thread: ".concat(String.valueOf(Thread.currentThread().getName()));
        }
        aaet aaetVar = new aaet(concat, SystemClock.elapsedRealtime(), -1L, id, 1);
        ArrayDeque arrayDeque = new ArrayDeque();
        arrayDeque.push(aaetVar);
        this.a.a.incrementAndGet();
        this.a.c.put(aaetVar, arrayDeque);
        return new WeakReference(arrayDeque);
    }
}
