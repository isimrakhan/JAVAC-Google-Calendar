package cal;

import android.content.Intent;
import android.content.pm.PackageManager;
import android.content.pm.ResolveInfo;
import android.content.res.Resources;
import android.util.Log;
import com.google.protobuf.InvalidProtocolBufferException;
import com.google.protobuf.UninitializedMessageException;
import java.io.IOException;
import java.io.InputStream;
import java.util.List;

/* compiled from: PG */
/* loaded from: classes2.dex */
public final class aaog {
    public final String a;
    final ahum b;
    final ahum c;
    public Resources d;
    public final /* synthetic */ aaoh e;

    public aaog(final aaoh aaohVar, final String str, ahum ahumVar) {
        this.e = aaohVar;
        this.a = str;
        this.b = new aaoc(new ahum() { // from class: cal.aaod
            @Override // cal.ahum
            public final Object a() {
                ajvu ajvuVar;
                amof amoeVar;
                String str2 = str;
                aaoh aaohVar2 = aaohVar;
                aaog aaogVar = aaog.this;
                try {
                    PackageManager packageManager = aaohVar2.a;
                    ajvu ajvuVar2 = ajvv.a;
                    if (packageManager != null) {
                        if (str2 != null) {
                            Intent intent = new Intent("com.google.android.build.data.Properties");
                            intent.setPackage(str2);
                            List<ResolveInfo> queryIntentServices = packageManager.queryIntentServices(intent, 787072);
                            if (queryIntentServices.isEmpty()) {
                                ajvuVar = ajvv.a;
                            } else if (queryIntentServices.size() <= 1) {
                                int i = queryIntentServices.get(0).serviceInfo.metaData.getInt("com.google.android.build.data.properties");
                                if (i == 0) {
                                    ajvuVar = ajvv.a;
                                } else {
                                    try {
                                        Resources resources = aaogVar.d;
                                        if (resources == null) {
                                            resources = aaogVar.e.a.getResourcesForApplication(aaogVar.a);
                                            aaogVar.d = resources;
                                        }
                                        InputStream openRawResource = resources.openRawResource(i);
                                        amov amovVar = amov.a;
                                        amrc amrcVar = amrc.a;
                                        amov amovVar2 = amov.b;
                                        ajvu ajvuVar3 = ajvu.a;
                                        int i2 = amof.f;
                                        if (openRawResource == null) {
                                            byte[] bArr = ampx.b;
                                            int length = bArr.length;
                                            amoeVar = new amoc(bArr, 0, 0);
                                            try {
                                                amoeVar.d(0);
                                            } catch (InvalidProtocolBufferException e) {
                                                throw new IllegalArgumentException(e);
                                            }
                                        } else {
                                            amoeVar = new amoe(openRawResource, 4096);
                                        }
                                        ajvuVar = new ajvu();
                                        try {
                                            amrk a = amrc.a.a(ajvuVar.getClass());
                                            amog amogVar = amoeVar.e;
                                            if (amogVar == null) {
                                                amogVar = new amog(amoeVar);
                                            }
                                            a.h(ajvuVar, amogVar, amovVar2);
                                            a.f(ajvuVar);
                                            Byte b = (byte) 1;
                                            b.getClass();
                                        } catch (InvalidProtocolBufferException e2) {
                                            if (e2.a) {
                                                throw new InvalidProtocolBufferException(e2);
                                            }
                                            throw e2;
                                        } catch (UninitializedMessageException e3) {
                                            throw new InvalidProtocolBufferException(e3.getMessage());
                                        } catch (IOException e4) {
                                            if (e4.getCause() instanceof InvalidProtocolBufferException) {
                                                throw ((InvalidProtocolBufferException) e4.getCause());
                                            }
                                            throw new InvalidProtocolBufferException(e4);
                                        } catch (RuntimeException e5) {
                                            if (e5.getCause() instanceof InvalidProtocolBufferException) {
                                                throw ((InvalidProtocolBufferException) e5.getCause());
                                            }
                                            throw e5;
                                        }
                                    } catch (PackageManager.NameNotFoundException unused) {
                                        ajvuVar = ajvv.a;
                                    }
                                }
                            } else {
                                throw new IOException("Failed to resolve target AndroidBuildData");
                            }
                            return Long.valueOf(ajvuVar.c);
                        }
                        throw null;
                    }
                    throw null;
                } catch (IOException e6) {
                    Log.e("PhenotypeResourceReader", "Failed to read baseline CL for package ".concat(String.valueOf(str2)), e6);
                    return -1L;
                }
            }
        });
        this.c = ahumVar;
    }
}
