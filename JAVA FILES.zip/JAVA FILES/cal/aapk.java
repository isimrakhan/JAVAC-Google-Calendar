package cal;

import android.net.Uri;

/* compiled from: PG */
/* loaded from: classes2.dex */
public final class aapk {
    public final Uri a;

    public aapk(Uri uri) {
        this.a = uri;
    }
}
