package cal;

import android.content.Context;
import android.content.pm.ApplicationInfo;
import android.content.pm.PackageManager;
import j$.util.concurrent.ConcurrentHashMap;
import java.util.ArrayList;
import java.util.Collections;

/* compiled from: PG */
/* loaded from: classes2.dex */
public final class aaia {
    public Context a;
    public ahum b;
    private ahum c;
    private ahum d;
    private ahum e;
    private ahum f;

    public final aaic a() {
        this.a.getClass();
        if (this.b == null) {
            this.b = aaic.b;
        }
        if (this.c == null) {
            final Context context = this.a;
            this.c = ahus.a(new ahum() { // from class: cal.aahv
                @Override // cal.ahum
                public final Object a() {
                    return new aajg(new vbc(context));
                }
            });
        }
        if (this.d == null) {
            this.d = new ahum() { // from class: cal.aahy
                @Override // cal.ahum
                public final Object a() {
                    return new ahts(new aamc(aaia.this.b));
                }
            };
        }
        if (this.e == null) {
            Context context2 = this.a;
            final ArrayList arrayList = new ArrayList();
            Collections.addAll(arrayList, new abyp(new abyo(context2)), new abyv(new abzb(new ConcurrentHashMap())));
            this.e = ahus.a(new ahum() { // from class: cal.aahw
                @Override // cal.ahum
                public final Object a() {
                    return new abym(arrayList, Collections.emptyList(), Collections.emptyList());
                }
            });
        }
        if (this.f == null) {
            this.f = new ahum() { // from class: cal.aahz
                @Override // cal.ahum
                public final Object a() {
                    Context context3 = aaia.this.a;
                    Context context4 = aaic.a;
                    try {
                        ApplicationInfo applicationInfo = context3.getPackageManager().getApplicationInfo("com.google.android.gms", 0);
                        applicationInfo.getClass();
                        return new ahts(applicationInfo);
                    } catch (PackageManager.NameNotFoundException unused) {
                        return ahre.a;
                    }
                }
            };
        }
        return new aaic(this.a, this.b, this.c, this.d, this.e, this.f);
    }
}
