package cal;

import android.content.ActivityNotFoundException;
import android.content.Context;
import android.content.Intent;
import android.graphics.Color;
import android.net.Uri;
import com.google.android.libraries.privacy.policy.BrowserNotFoundException;

/* compiled from: PG */
/* loaded from: classes2.dex */
public final class aaoj {
    public static final void a(Context context) {
        try {
            aaj aajVar = new aaj();
            int parseColor = Color.parseColor("#eeeeee");
            aajVar.b.a = Integer.valueOf(parseColor | (-16777216));
            aak a = aajVar.a();
            a.a.setData(Uri.parse("https://www.google.com/policies/privacy/"));
            context.startActivity(a.a, a.b);
        } catch (ActivityNotFoundException unused) {
            throw new BrowserNotFoundException();
        }
    }

    public static final void b(aaoi aaoiVar, Context context, String str) {
        if (str != null && !str.isEmpty()) {
            Intent putExtra = new Intent("com.google.android.gms.accountsettings.action.VIEW_SETTINGS").setPackage("com.google.android.gms").putExtra("extra.accountName", str).putExtra("extra.screenId", 500);
            if (putExtra.resolveActivity(context.getPackageManager()) == null) {
                a(context);
                return;
            } else {
                aaoiVar.a.startActivityForResult(putExtra, 0);
                return;
            }
        }
        a(context);
    }
}
