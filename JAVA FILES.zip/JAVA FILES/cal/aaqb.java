package cal;

/* compiled from: PG */
/* loaded from: classes2.dex */
final class aaqb implements ajco {
    @Override // cal.ajco
    public final void a(Throwable th) {
        ((aimj) ((aimj) ((aimj) aaqc.a.c()).j(th)).k("com/google/android/libraries/social/connections/dataloaders/AppSearchInteractionLoader$3", "onFailure", (char) 304, "AppSearchInteractionLoader.java")).s("Failed to resolve AppSearch search session.");
    }

    @Override // cal.ajco
    public final /* synthetic */ void b(Object obj) {
        ((xw) obj).a.close();
    }
}
