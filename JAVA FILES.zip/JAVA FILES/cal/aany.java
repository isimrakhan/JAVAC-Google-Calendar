package cal;

import android.accounts.Account;
import android.content.Context;
import android.net.Uri;
import android.os.StrictMode;
import com.google.android.libraries.phenotype.client.api.PhenotypeRuntimeException;
import java.io.IOException;
import java.util.concurrent.Callable;
import java.util.concurrent.Executor;
import java.util.concurrent.TimeUnit;

/* compiled from: PG */
/* loaded from: classes2.dex */
public final class aany {
    public static final Object a = new Object();
    public static final Object b = new Object();
    public final Context c;
    public final ahum d;
    public final ahum e;
    public final ahum f;
    public final ahum g;
    public final Uri h;
    public volatile aajw i;
    public final Uri j;
    public volatile aajz k;
    private final ahum l;

    public aany(Context context, final ahum ahumVar, ahum ahumVar2, ahum ahumVar3) {
        this.c = context;
        this.e = ahumVar;
        this.d = ahumVar3;
        this.f = ahumVar2;
        Account account = abys.a;
        Account account2 = abys.a;
        aicf aicfVar = new aicf(4);
        String packageName = context.getPackageName();
        abys.a("phenotype_storage_info");
        this.h = abyr.a(packageName, "files", "phenotype_storage_info", account2, "storage-info.pb", aicfVar);
        Account account3 = abys.a;
        aicf aicfVar2 = new aicf(4);
        String packageName2 = context.getPackageName();
        abys.a("phenotype_storage_info");
        int i = vvg.a;
        boolean contains = abys.b.contains("directboot-files");
        Object[] objArr = {abys.b, "directboot-files"};
        if (contains) {
            this.j = abyr.a(packageName2, "directboot-files", "phenotype_storage_info", account3, "device-encrypted-storage-info.pb", aicfVar2);
            this.g = ahus.a(new ahum() { // from class: cal.aanv
                @Override // cal.ahum
                public final Object a() {
                    Executor ajdtVar;
                    Executor ajdtVar2;
                    final aany aanyVar = aany.this;
                    Executor executor = (ajds) aanyVar.e.a();
                    executor.getClass();
                    aajd aajdVar = (aajd) aanyVar.d.a();
                    aajdVar.getClass();
                    ajdo d = aajdVar.d();
                    aizy aizyVar = new aizy(d, PhenotypeRuntimeException.class, new ahsr() { // from class: cal.aanr
                        @Override // cal.ahsr
                        /* renamed from: a */
                        public final Object b(Object obj) {
                            PhenotypeRuntimeException phenotypeRuntimeException = (PhenotypeRuntimeException) obj;
                            if (phenotypeRuntimeException.a == 29514) {
                                aakd aakdVar = aakd.a;
                                aakc aakcVar = new aakc();
                                ampt amptVar = aajw.a;
                                aajv aajvVar = new aajv();
                                long currentTimeMillis = System.currentTimeMillis();
                                if ((aajvVar.b.ad & Integer.MIN_VALUE) == 0) {
                                    aajvVar.s();
                                }
                                aajw aajwVar = (aajw) aajvVar.b;
                                aajwVar.d |= 8;
                                aajwVar.h = currentTimeMillis;
                                if ((aakcVar.b.ad & Integer.MIN_VALUE) == 0) {
                                    aakcVar.s();
                                }
                                aakd aakdVar2 = (aakd) aakcVar.b;
                                aajw aajwVar2 = (aajw) aajvVar.p();
                                aajwVar2.getClass();
                                aakdVar2.d = aajwVar2;
                                aakdVar2.c |= 1;
                                return (aakd) aakcVar.p();
                            }
                            throw phenotypeRuntimeException;
                        }
                    });
                    if (executor == ajbw.a) {
                        ajdtVar = executor;
                    } else {
                        ajdtVar = new ajdt(executor, aizyVar);
                    }
                    d.d(aizyVar, ajdtVar);
                    final ajap ajapVar = new ajap(aizyVar, new ahsr() { // from class: cal.aans
                        @Override // cal.ahsr
                        /* renamed from: a */
                        public final Object b(Object obj) {
                            aakd aakdVar = (aakd) obj;
                            abyw abywVar = new abyw();
                            StrictMode.ThreadPolicy threadPolicy = StrictMode.getThreadPolicy();
                            StrictMode.setThreadPolicy(new StrictMode.ThreadPolicy.Builder(threadPolicy).permitDiskWrites().build());
                            aany aanyVar2 = aany.this;
                            try {
                                try {
                                    synchronized (aany.a) {
                                        abym abymVar = (abym) aanyVar2.f.a();
                                        Uri uri = aanyVar2.h;
                                        aajw aajwVar = aakdVar.d;
                                        if (aajwVar == null) {
                                            aajwVar = aajw.b;
                                        }
                                        abzp.a(abymVar.a(uri), aajwVar, new abyw[]{abywVar});
                                        aajw aajwVar2 = aakdVar.d;
                                        if (aajwVar2 == null) {
                                            aajwVar2 = aajw.b;
                                        }
                                        aanyVar2.i = aajwVar2;
                                    }
                                    synchronized (aany.b) {
                                        abym abymVar2 = (abym) aanyVar2.f.a();
                                        Uri uri2 = aanyVar2.j;
                                        aajz aajzVar = aakdVar.e;
                                        if (aajzVar == null) {
                                            aajzVar = aajz.b;
                                        }
                                        abzp.a(abymVar2.a(uri2), aajzVar, new abyw[]{abywVar});
                                        aajz aajzVar2 = aakdVar.e;
                                        if (aajzVar2 == null) {
                                            aajzVar2 = aajz.b;
                                        }
                                        aanyVar2.k = aajzVar2;
                                    }
                                    StrictMode.setThreadPolicy(threadPolicy);
                                    return null;
                                } catch (IOException e) {
                                    throw new RuntimeException(e);
                                }
                            } catch (Throwable th) {
                                StrictMode.setThreadPolicy(threadPolicy);
                                throw th;
                            }
                        }
                    });
                    if (executor == ajbw.a) {
                        ajdtVar2 = executor;
                    } else {
                        ajdtVar2 = new ajdt(executor, ajapVar);
                    }
                    aizyVar.d(ajapVar, ajdtVar2);
                    ajapVar.d(new Runnable() { // from class: cal.aant
                        @Override // java.lang.Runnable
                        public final void run() {
                            boolean z;
                            ajdo ajdoVar = ajdo.this;
                            try {
                                Object obj = ((ajam) ajdoVar).value;
                                boolean z2 = !(obj instanceof ajaf);
                                if (obj != null) {
                                    z = true;
                                } else {
                                    z = false;
                                }
                                if (z & z2) {
                                    ajem.a(ajdoVar);
                                    return;
                                }
                                throw new IllegalStateException(ahul.a("Future was expected to be done: %s", ajdoVar));
                            } catch (Exception unused) {
                            }
                        }
                    }, executor);
                    return ajapVar;
                }
            });
            this.l = ahus.a(new ahum() { // from class: cal.aanw
                @Override // cal.ahum
                public final Object a() {
                    ajds ajdsVar = (ajds) ahum.this.a();
                    ajdsVar.getClass();
                    return ajdsVar.schedule(new Callable() { // from class: cal.aanx
                        @Override // java.util.concurrent.Callable
                        public final Object call() {
                            return null;
                        }
                    }, 10000L, TimeUnit.MILLISECONDS);
                }
            });
            return;
        }
        throw new IllegalArgumentException(String.format("The only supported locations are %s: %s", objArr));
    }

    public final aajw a() {
        amra amraVar;
        aajw aajwVar = this.i;
        if (aajwVar == null) {
            synchronized (a) {
                aajwVar = this.i;
                if (aajwVar == null) {
                    aajwVar = aajw.b;
                    amra amraVar2 = aajw.c;
                    if (amraVar2 == null) {
                        synchronized (aajw.class) {
                            amraVar = aajw.c;
                            if (amraVar == null) {
                                amraVar = new amph(aajw.b);
                                aajw.c = amraVar;
                            }
                        }
                        amraVar2 = amraVar;
                    }
                    amov amovVar = amov.a;
                    amrc amrcVar = amrc.a;
                    amov amovVar2 = amov.b;
                    StrictMode.ThreadPolicy threadPolicy = StrictMode.getThreadPolicy();
                    StrictMode.setThreadPolicy(new StrictMode.ThreadPolicy.Builder(threadPolicy).permitDiskReads().build());
                    try {
                        try {
                            aajw aajwVar2 = (aajw) abzn.a(((abym) this.f.a()).a(this.h), amraVar2, amovVar2);
                            StrictMode.setThreadPolicy(threadPolicy);
                            aajwVar = aajwVar2;
                        } finally {
                            StrictMode.setThreadPolicy(threadPolicy);
                        }
                    } catch (IOException unused) {
                    }
                    this.i = aajwVar;
                }
            }
        }
        return aajwVar;
    }

    public final aajz b() {
        amra amraVar;
        aajz aajzVar = this.k;
        if (aajzVar == null) {
            synchronized (b) {
                aajzVar = this.k;
                if (aajzVar == null) {
                    aajzVar = aajz.b;
                    amra amraVar2 = aajz.c;
                    if (amraVar2 == null) {
                        synchronized (aajz.class) {
                            amraVar = aajz.c;
                            if (amraVar == null) {
                                amraVar = new amph(aajz.b);
                                aajz.c = amraVar;
                            }
                        }
                        amraVar2 = amraVar;
                    }
                    amov amovVar = amov.a;
                    amrc amrcVar = amrc.a;
                    amov amovVar2 = amov.b;
                    StrictMode.ThreadPolicy threadPolicy = StrictMode.getThreadPolicy();
                    StrictMode.setThreadPolicy(new StrictMode.ThreadPolicy.Builder(threadPolicy).permitDiskReads().build());
                    try {
                        try {
                            aajz aajzVar2 = (aajz) abzn.a(((abym) this.f.a()).a(this.j), amraVar2, amovVar2);
                            StrictMode.setThreadPolicy(threadPolicy);
                            aajzVar = aajzVar2;
                        } finally {
                            StrictMode.setThreadPolicy(threadPolicy);
                        }
                    } catch (IOException unused) {
                    }
                    this.k = aajzVar;
                }
            }
        }
        return aajzVar;
    }

    public final ajdo c(boolean z) {
        ajdo ajdoVar;
        ajch ajcjVar;
        Executor executor = (ajds) this.e.a();
        executor.getClass();
        if (z) {
            ajdoVar = (ajdo) this.l.a();
            if (!ajdoVar.isDone()) {
                ajcx ajcxVar = new ajcx(ajdoVar);
                ajdoVar.d(ajcxVar, ajbw.a);
                ajdoVar = ajcxVar;
            }
        } else {
            ajdoVar = ajdj.a;
        }
        int i = ajch.d;
        if (ajdoVar instanceof ajch) {
            ajcjVar = (ajch) ajdoVar;
        } else {
            ajcjVar = new ajcj(ajdoVar);
        }
        ajao ajaoVar = new ajao(ajcjVar, new ajaz() { // from class: cal.aanu
            @Override // cal.ajaz
            public final ajdo a(Object obj) {
                ajdo ajdoVar2 = (ajdo) aany.this.g.a();
                if (ajdoVar2.isDone()) {
                    return ajdoVar2;
                }
                ajcx ajcxVar2 = new ajcx(ajdoVar2);
                ajdoVar2.d(ajcxVar2, ajbw.a);
                return ajcxVar2;
            }
        });
        if (executor != ajbw.a) {
            executor = new ajdt(executor, ajaoVar);
        }
        ajcjVar.d(ajaoVar, executor);
        return ajaoVar;
    }
}
