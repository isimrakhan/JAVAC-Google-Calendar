package cal;

/* JADX INFO: Access modifiers changed from: package-private */
/* compiled from: PG */
/* loaded from: classes2.dex */
public final class aaqu implements Runnable {
    final /* synthetic */ aaqt a;

    public aaqu(aaqt aaqtVar) {
        this.a = aaqtVar;
    }

    @Override // java.lang.Runnable
    public final void run() {
        aaqv.a.add(this.a);
        int i = aaqv.b;
        if (i != -1) {
            this.a.b(i);
        }
    }
}
