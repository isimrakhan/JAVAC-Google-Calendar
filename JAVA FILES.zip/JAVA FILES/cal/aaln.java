package cal;

import android.content.Context;
import android.util.Log;
import com.google.protobuf.InvalidProtocolBufferException;
import com.google.protobuf.UninitializedMessageException;
import java.io.IOException;
import java.io.InputStream;
import java.util.Map;

/* compiled from: PG */
/* loaded from: classes2.dex */
public final class aaln {
    private static final Object f = new Object();
    private static volatile Map g;
    public final String a;
    public final ajvx b;
    public final boolean c;
    public final boolean d;
    public final boolean e;

    public aaln(Context context, aalp aalpVar) {
        String str;
        if (aalpVar.d) {
            str = aahs.b(context, aalpVar.c);
        } else {
            str = aalpVar.c;
        }
        this.a = str;
        ajvx b = ajvx.b(aalpVar.e);
        this.b = b == null ? ajvx.UNKNOWN : b;
        this.c = aalpVar.h;
        this.d = aalpVar.f;
        this.e = aalpVar.g;
    }

    public static Map a(Context context) {
        amof amoeVar;
        Map map = g;
        if (map == null) {
            synchronized (f) {
                map = g;
                if (map == null) {
                    aico aicoVar = new aico(4);
                    try {
                        String[] list = context.getAssets().list("phenotype");
                        if (list != null) {
                            for (String str : list) {
                                if (str.endsWith("_package_metadata.binarypb")) {
                                    try {
                                        InputStream open = context.getAssets().open(a.j(str, "phenotype/"));
                                        try {
                                            amov amovVar = amov.a;
                                            amrc amrcVar = amrc.a;
                                            amov amovVar2 = amov.b;
                                            aalp aalpVar = aalp.a;
                                            int i = amof.f;
                                            if (open == null) {
                                                byte[] bArr = ampx.b;
                                                int length = bArr.length;
                                                amoeVar = new amoc(bArr, 0, 0);
                                                try {
                                                    amoeVar.d(0);
                                                } catch (InvalidProtocolBufferException e) {
                                                    throw new IllegalArgumentException(e);
                                                }
                                            } else {
                                                amoeVar = new amoe(open, 4096);
                                            }
                                            aalp aalpVar2 = new aalp();
                                            try {
                                                try {
                                                    try {
                                                        amrk a = amrc.a.a(aalpVar2.getClass());
                                                        amog amogVar = amoeVar.e;
                                                        if (amogVar == null) {
                                                            amogVar = new amog(amoeVar);
                                                        }
                                                        a.h(aalpVar2, amogVar, amovVar2);
                                                        a.f(aalpVar2);
                                                        Byte b = (byte) 1;
                                                        b.getClass();
                                                        aaln aalnVar = new aaln(context, aalpVar2);
                                                        aicoVar.f(aalnVar.a, aalnVar);
                                                        if (open != null) {
                                                            open.close();
                                                        }
                                                    } catch (UninitializedMessageException e2) {
                                                        throw new InvalidProtocolBufferException(e2.getMessage());
                                                    } catch (IOException e3) {
                                                        if (e3.getCause() instanceof InvalidProtocolBufferException) {
                                                            throw ((InvalidProtocolBufferException) e3.getCause());
                                                        }
                                                        throw new InvalidProtocolBufferException(e3);
                                                    }
                                                } catch (InvalidProtocolBufferException e4) {
                                                    if (e4.a) {
                                                        throw new InvalidProtocolBufferException(e4);
                                                    }
                                                    throw e4;
                                                }
                                            } catch (RuntimeException e5) {
                                                if (e5.getCause() instanceof InvalidProtocolBufferException) {
                                                    throw ((InvalidProtocolBufferException) e5.getCause());
                                                }
                                                throw e5;
                                            }
                                        } catch (Throwable th) {
                                            if (open != null) {
                                                try {
                                                    open.close();
                                                } catch (Throwable th2) {
                                                    th.addSuppressed(th2);
                                                }
                                            }
                                            throw th;
                                            break;
                                        }
                                    } catch (InvalidProtocolBufferException e6) {
                                        Log.e("PackageInfo", a.j(str, "Unable to read Phenotype PackageMetadata for "), e6);
                                    }
                                }
                            }
                        }
                    } catch (IOException e7) {
                        Log.e("PackageInfo", "Unable to read Phenotype PackageMetadata from assets.", e7);
                    }
                    aics d = aicoVar.d(true);
                    g = d;
                    map = d;
                }
            }
        }
        return map;
    }
}
