package cal;

import java.util.concurrent.TimeUnit;

/* compiled from: PG */
/* loaded from: classes2.dex */
public final class aamc implements aaml {
    private static boolean a;
    private final ahum b;
    private final int c = Math.max(5, 10);

    public aamc(ahum ahumVar) {
        this.b = ahumVar;
    }

    @Override // cal.aaml
    public final void a() {
        synchronized (aamc.class) {
            if (!a) {
                long j = this.c;
                TimeUnit timeUnit = TimeUnit.MINUTES;
                ajds ajdsVar = (ajds) this.b.a();
                ajdq e = ajdsVar.e(new aamb(ajdsVar, j, timeUnit), j, timeUnit);
                e.d(new aalx(e), ajbw.a);
                a = true;
            }
        }
    }
}
