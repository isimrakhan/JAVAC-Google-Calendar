package cal;

import android.util.Base64;
import java.util.Set;

/* compiled from: PG */
/* loaded from: classes2.dex */
public final class aana {
    @Deprecated
    public static final aamn a(String str, String str2, String str3, Set set, boolean z, boolean z2) {
        return new aamn(str3, "__phenotype_server_token", "", new aakp(z, false, set, new aamz() { // from class: cal.aamq
            @Override // cal.aamz
            public final Object a(Object obj) {
                return (String) obj;
            }
        }, new aamy(String.class)), false);
    }

    public static final aamn b(String str, double d, String str2, Set set, boolean z, boolean z2) {
        Double valueOf = Double.valueOf(d);
        final Class<Double> cls = Double.class;
        return new aamn("com.google.android.calendar", str, valueOf, new aakp(false, false, set, new aamz() { // from class: cal.aamr
            @Override // cal.aamz
            public final Object a(Object obj) {
                return Double.valueOf(Double.parseDouble((String) obj));
            }
        }, new aamz() { // from class: cal.aams
            @Override // cal.aamz
            public final Object a(Object obj) {
                return (Double) cls.cast(obj);
            }
        }), true);
    }

    public static final aamn c(String str, long j, String str2, Set set, boolean z, boolean z2) {
        final Class<Long> cls = Long.class;
        return new aamn(str2, str, Long.valueOf(j), new aakp(z, z2, set, new aamz() { // from class: cal.aamo
            @Override // cal.aamz
            public final Object a(Object obj) {
                return Long.valueOf(Long.parseLong((String) obj));
            }
        }, new aamz() { // from class: cal.aamp
            @Override // cal.aamz
            public final Object a(Object obj) {
                return (Long) cls.cast(obj);
            }
        }), true);
    }

    public static final aamn d(String str, String str2, String str3, Set set, boolean z, boolean z2) {
        return new aamn(str3, str, str2, new aakp(z, false, set, new aamz() { // from class: cal.aamx
            @Override // cal.aamz
            public final Object a(Object obj) {
                return (String) obj;
            }
        }, new aamy(String.class)), true);
    }

    public static final aamn e(String str, boolean z, String str2, Set set, boolean z2, boolean z3) {
        final Class<Boolean> cls = Boolean.class;
        return new aamn(str2, str, Boolean.valueOf(z), new aakp(z2, z3, set, new aamz() { // from class: cal.aamv
            @Override // cal.aamz
            public final Object a(Object obj) {
                return Boolean.valueOf(Boolean.parseBoolean((String) obj));
            }
        }, new aamz() { // from class: cal.aamw
            @Override // cal.aamz
            public final Object a(Object obj) {
                return (Boolean) cls.cast(obj);
            }
        }), true);
    }

    public static final aamn f(String str, final aamz aamzVar, String str2, String str3, Set set, boolean z, boolean z2) {
        return new aamn(str3, str, new aakp(z, z2, set, new aamz() { // from class: cal.aamt
            @Override // cal.aamz
            public final Object a(Object obj) {
                return aamz.this.a(Base64.decode((String) obj, 3));
            }
        }, new aamz() { // from class: cal.aamu
            @Override // cal.aamz
            public final Object a(Object obj) {
                return aamz.this.a((byte[]) obj);
            }
        }), str2);
    }
}
