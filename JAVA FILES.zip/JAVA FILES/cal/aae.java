package cal;

import java.util.Iterator;
import java.util.WeakHashMap;

/* compiled from: PG */
/* loaded from: classes.dex */
public class aae implements Iterable {
    public aaa b;
    public aaa c;
    public final WeakHashMap d = new WeakHashMap();
    public int e = 0;

    public aaa a(Object obj) {
        aaa aaaVar = this.b;
        while (aaaVar != null && !aaaVar.a.equals(obj)) {
            aaaVar = aaaVar.c;
        }
        return aaaVar;
    }

    public Object b(Object obj) {
        aaa a = a(obj);
        if (a == null) {
            return null;
        }
        this.e--;
        if (!this.d.isEmpty()) {
            Iterator it = this.d.keySet().iterator();
            while (it.hasNext()) {
                ((aad) it.next()).bi(a);
            }
        }
        aaa aaaVar = a.d;
        aaa aaaVar2 = a.c;
        if (aaaVar != null) {
            aaaVar.c = aaaVar2;
        } else {
            this.b = aaaVar2;
        }
        aaa aaaVar3 = a.c;
        if (aaaVar3 != null) {
            aaaVar3.d = aaaVar;
        } else {
            this.c = aaaVar;
        }
        a.c = null;
        a.d = null;
        return a.b;
    }

    public final aaa c(Object obj, Object obj2) {
        aaa aaaVar = new aaa(obj, obj2);
        this.e++;
        aaa aaaVar2 = this.c;
        if (aaaVar2 == null) {
            this.b = aaaVar;
        } else {
            aaaVar2.c = aaaVar;
            aaaVar.d = aaaVar2;
        }
        this.c = aaaVar;
        return aaaVar;
    }

    public final boolean equals(Object obj) {
        aaa aaaVar;
        aaa aaaVar2;
        aaa aaaVar3;
        if (obj == this) {
            return true;
        }
        if (!(obj instanceof aae)) {
            return false;
        }
        aae aaeVar = (aae) obj;
        if (this.e == aaeVar.e) {
            zy zyVar = new zy(this.b, this.c);
            this.d.put(zyVar, false);
            zy zyVar2 = new zy(aaeVar.b, aaeVar.c);
            aaeVar.d.put(zyVar2, false);
            do {
                aaaVar = zyVar.b;
                if (aaaVar != null && zyVar2.b != null) {
                    aaa aaaVar4 = zyVar.a;
                    aaa aaaVar5 = null;
                    if (aaaVar != aaaVar4 && aaaVar4 != null) {
                        aaaVar2 = aaaVar.c;
                    } else {
                        aaaVar2 = null;
                    }
                    zyVar.b = aaaVar2;
                    aaaVar3 = zyVar2.b;
                    aaa aaaVar6 = zyVar2.a;
                    if (aaaVar3 != aaaVar6 && aaaVar6 != null) {
                        aaaVar5 = aaaVar3.c;
                    }
                    zyVar2.b = aaaVar5;
                } else if (aaaVar == null && zyVar2.b == null) {
                    return true;
                }
            } while (aaaVar.equals(aaaVar3));
            return false;
        }
        return false;
    }

    public final int hashCode() {
        zy zyVar = new zy(this.b, this.c);
        int i = 0;
        this.d.put(zyVar, false);
        while (true) {
            aaa aaaVar = zyVar.b;
            if (aaaVar != null) {
                aaa aaaVar2 = zyVar.a;
                aaa aaaVar3 = null;
                if (aaaVar != aaaVar2 && aaaVar2 != null) {
                    aaaVar3 = aaaVar.c;
                }
                zyVar.b = aaaVar3;
                i += aaaVar.a.hashCode() ^ aaaVar.b.hashCode();
            } else {
                return i;
            }
        }
    }

    @Override // java.lang.Iterable
    public final Iterator iterator() {
        zy zyVar = new zy(this.b, this.c);
        this.d.put(zyVar, false);
        return zyVar;
    }

    public final String toString() {
        StringBuilder sb = new StringBuilder("[");
        zy zyVar = new zy(this.b, this.c);
        this.d.put(zyVar, false);
        while (true) {
            aaa aaaVar = zyVar.b;
            if (aaaVar != null) {
                aaa aaaVar2 = zyVar.a;
                aaa aaaVar3 = null;
                if (aaaVar != aaaVar2 && aaaVar2 != null) {
                    aaaVar3 = aaaVar.c;
                }
                zyVar.b = aaaVar3;
                sb.append(aaaVar.a + "=" + aaaVar.b);
                if (zyVar.b != null) {
                    sb.append(", ");
                }
            } else {
                sb.append("]");
                return sb.toString();
            }
        }
    }
}
