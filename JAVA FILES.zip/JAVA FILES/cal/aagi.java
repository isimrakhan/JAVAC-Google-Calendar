package cal;

/* compiled from: PG */
/* loaded from: classes2.dex */
public interface aagi {
    ajdo a(aqyd aqydVar);

    void b();
}
