package cal;

import android.os.Handler;
import android.os.Looper;

/* compiled from: PG */
/* loaded from: classes.dex */
public final class aah extends ae {
    public aah() {
        new Handler(Looper.getMainLooper());
    }
}
