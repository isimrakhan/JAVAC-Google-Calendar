package cal;

/* compiled from: PG */
/* loaded from: classes2.dex */
public final /* synthetic */ class aadf implements apxs {
    public final /* synthetic */ anyt a;

    public /* synthetic */ aadf(anyt anytVar) {
        this.a = anytVar;
    }

    @Override // cal.apxs, cal.apxr
    public final Object b() {
        ahti ahtiVar = (ahti) this.a.b();
        zvo zvoVar = new zvo();
        zvoVar.a = (byte) 3;
        return false;
    }
}
