package cal;

/* compiled from: PG */
/* loaded from: classes2.dex */
public final class aahr {
    static volatile ahti a = ahre.a;
    public static final Object b = new Object();
}
