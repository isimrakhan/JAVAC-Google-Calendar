package cal;

/* compiled from: PG */
/* loaded from: classes2.dex */
public final class aabe {
    public final long a;
    public long b;
    public long c;
    public int d;
    public int e;
    final String f;
    final String g;
    final boolean h;
    String i;
    int j;
    public String k;
    aqwf l;
    int m;
    aquh n;
    int o;
    int p;
    public int q;
    public int r;
    public ahti t;
    int u;
    public int v;
    final int w = 1;
    public int s = -1;

    public aabe(String str, String str2, boolean z, long j) {
        this.g = (str == null || str.isEmpty()) ? null : str;
        this.f = (str2 == null || str2.isEmpty()) ? null : str2;
        this.h = z;
        this.a = j;
        this.t = ahre.a;
    }
}
