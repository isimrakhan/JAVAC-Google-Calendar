package cal;

/* compiled from: PG */
/* loaded from: classes2.dex */
interface aaak {
    void a(int i, String str);
}
