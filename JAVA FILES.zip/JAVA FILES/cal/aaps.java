package cal;

/* compiled from: PG */
/* loaded from: classes2.dex */
public final class aaps {
    public final aics a;
    public final aics b;

    public aaps(aics aicsVar, aics aicsVar2) {
        this.a = aicsVar;
        this.b = aicsVar2;
    }
}
