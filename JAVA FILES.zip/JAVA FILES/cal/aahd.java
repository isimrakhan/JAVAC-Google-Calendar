package cal;

/* compiled from: PG */
/* loaded from: classes2.dex */
final class aahd implements aahe {
    @Override // cal.aahe
    public final /* synthetic */ String a(amqs amqsVar) {
        return ((aqvu) ((aqvs) amqsVar).b).d;
    }

    @Override // cal.aahe
    public final /* synthetic */ String b(amqs amqsVar) {
        return ((aqvu) ((aqvs) amqsVar).b).f;
    }

    @Override // cal.aahe
    public final /* synthetic */ void c(amqs amqsVar, Long l) {
        aqvs aqvsVar = (aqvs) amqsVar;
        if (l == null) {
            if ((aqvsVar.b.ad & Integer.MIN_VALUE) == 0) {
                aqvsVar.s();
            }
            aqvu aqvuVar = (aqvu) aqvsVar.b;
            aqvu aqvuVar2 = aqvu.a;
            aqvuVar.c &= -3;
            aqvuVar.e = 0L;
            return;
        }
        long longValue = l.longValue();
        if ((aqvsVar.b.ad & Integer.MIN_VALUE) == 0) {
            aqvsVar.s();
        }
        aqvu aqvuVar3 = (aqvu) aqvsVar.b;
        aqvu aqvuVar4 = aqvu.a;
        aqvuVar3.c |= 2;
        aqvuVar3.e = longValue;
    }

    @Override // cal.aahe
    public final /* synthetic */ void d(amqs amqsVar) {
        aqvs aqvsVar = (aqvs) amqsVar;
        if ((aqvsVar.b.ad & Integer.MIN_VALUE) == 0) {
            aqvsVar.s();
        }
        aqvu aqvuVar = (aqvu) aqvsVar.b;
        aqvu aqvuVar2 = aqvu.a;
        aqvuVar.c &= -5;
        aqvuVar.f = aqvu.a.f;
    }
}
