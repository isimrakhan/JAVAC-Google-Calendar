package cal;

/* compiled from: PG */
/* loaded from: classes2.dex */
public final class aamn implements ahum {
    public static final /* synthetic */ int a = 0;
    private static volatile aajh b = new aajh(new aaji() { // from class: cal.aamm
        @Override // cal.aaji
        public final void a() {
            int i = aamn.a;
        }
    });
    private final String c;
    private final String d;
    private Object e;
    private volatile aalq f;
    private volatile int g;
    private volatile Object h;
    private final boolean i;
    private volatile boolean j;
    private final aakp k;

    public aamn(String str, String str2, aakp aakpVar, String str3) {
        this.g = -1;
        this.c = str;
        this.d = str2;
        this.e = str3;
        this.k = aakpVar;
        this.i = true;
        this.j = true;
    }

    @Override // cal.ahum
    public final Object a() {
        return b(aaic.a());
    }

    /* JADX WARN: Removed duplicated region for block: B:51:0x00c4 A[Catch: all -> 0x0173, TryCatch #2 {, blocks: (B:10:0x0015, B:12:0x0019, B:13:0x0021, B:16:0x0023, B:18:0x0027, B:20:0x002b, B:21:0x0032, B:23:0x0036, B:24:0x003c, B:28:0x0052, B:29:0x0053, B:31:0x005f, B:33:0x006d, B:34:0x0071, B:35:0x007b, B:38:0x007d, B:40:0x0081, B:42:0x0085, B:43:0x008c, B:45:0x0099, B:48:0x00aa, B:49:0x00c0, B:51:0x00c4, B:52:0x00ca, B:57:0x012a, B:61:0x0135, B:63:0x0139, B:79:0x0166, B:80:0x0167, B:81:0x0169, B:84:0x0114, B:87:0x011e, B:90:0x00b4, B:95:0x016e, B:96:0x016f, B:97:0x0171, B:15:0x0022, B:65:0x013a, B:67:0x013e, B:69:0x0146, B:70:0x015b, B:73:0x0150, B:74:0x0162, B:37:0x007c), top: B:9:0x0015, inners: #0, #3, #8 }] */
    /* JADX WARN: Removed duplicated region for block: B:54:0x010f  */
    /* JADX WARN: Removed duplicated region for block: B:59:0x0131  */
    /* JADX WARN: Removed duplicated region for block: B:61:0x0135 A[Catch: all -> 0x0173, TryCatch #2 {, blocks: (B:10:0x0015, B:12:0x0019, B:13:0x0021, B:16:0x0023, B:18:0x0027, B:20:0x002b, B:21:0x0032, B:23:0x0036, B:24:0x003c, B:28:0x0052, B:29:0x0053, B:31:0x005f, B:33:0x006d, B:34:0x0071, B:35:0x007b, B:38:0x007d, B:40:0x0081, B:42:0x0085, B:43:0x008c, B:45:0x0099, B:48:0x00aa, B:49:0x00c0, B:51:0x00c4, B:52:0x00ca, B:57:0x012a, B:61:0x0135, B:63:0x0139, B:79:0x0166, B:80:0x0167, B:81:0x0169, B:84:0x0114, B:87:0x011e, B:90:0x00b4, B:95:0x016e, B:96:0x016f, B:97:0x0171, B:15:0x0022, B:65:0x013a, B:67:0x013e, B:69:0x0146, B:70:0x015b, B:73:0x0150, B:74:0x0162, B:37:0x007c), top: B:9:0x0015, inners: #0, #3, #8 }] */
    /* JADX WARN: Removed duplicated region for block: B:82:0x0132  */
    /* JADX WARN: Removed duplicated region for block: B:83:0x0114 A[EXC_TOP_SPLITTER, SYNTHETIC] */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct code enable 'Show inconsistent code' option in preferences
    */
    public final java.lang.Object b(final cal.aaic r11) {
        /*
            Method dump skipped, instructions count: 374
            To view this dump change 'Code comments level' option to 'DEBUG'
        */
        throw new UnsupportedOperationException("Method not decompiled: cal.aamn.b(cal.aaic):java.lang.Object");
    }

    public aamn(String str, String str2, Object obj, aakp aakpVar, boolean z) {
        this.g = -1;
        this.c = str;
        this.d = str2;
        this.e = obj;
        this.k = aakpVar;
        this.i = z;
        this.j = false;
    }
}
