package cal;

import java.util.concurrent.Executor;

/* compiled from: PG */
/* loaded from: classes2.dex */
public final class aadc {
    public final zwf a;
    public final anyt b;
    public final ajds c;

    public aadc(zwg zwgVar, ajds ajdsVar, Executor executor, anyt anytVar, apxs apxsVar) {
        this.b = anytVar;
        this.c = ajdsVar;
        this.a = zwgVar.a(executor, anytVar, apxsVar);
    }
}
