package cal;

/* compiled from: PG */
/* loaded from: classes2.dex */
public final class aaeo extends aaez {
    public final float a;
    private final int b;

    public aaeo(int i, float f) {
        this.b = i;
        this.a = f;
    }

    @Override // cal.aaez
    public final float c() {
        return this.a;
    }

    @Override // cal.aaez
    public final int d() {
        return this.b;
    }

    public final boolean equals(Object obj) {
        if (obj == this) {
            return true;
        }
        if (obj instanceof aaez) {
            aaez aaezVar = (aaez) obj;
            if (this.b == aaezVar.d() && Float.floatToIntBits(this.a) == Float.floatToIntBits(aaezVar.c())) {
                return true;
            }
        }
        return false;
    }

    public final int hashCode() {
        return ((this.b ^ 1000003) * 1000003) ^ Float.floatToIntBits(this.a);
    }

    public final String toString() {
        String str;
        int i = this.b;
        if (i != 1) {
            if (i != 2) {
                str = "EXPLICITLY_ENABLED";
            } else {
                str = "EXPLICITLY_DISABLED";
            }
        } else {
            str = "DEFAULT";
        }
        return "TraceConfigurations{enablement=" + str + ", samplingProbability=" + this.a + "}";
    }
}
