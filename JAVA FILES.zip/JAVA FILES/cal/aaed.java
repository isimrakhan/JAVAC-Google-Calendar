package cal;

/* compiled from: PG */
/* loaded from: classes2.dex */
public abstract class aaed implements zun {
    @Override // cal.zun
    public abstract int a();

    @Override // cal.zun
    public final boolean b() {
        if (e() == 3) {
            return true;
        }
        return false;
    }

    public abstract float c();

    public abstract ahti d();

    public abstract int e();
}
