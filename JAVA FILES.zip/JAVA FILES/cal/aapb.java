package cal;

import java.util.List;

/* compiled from: PG */
/* loaded from: classes2.dex */
public final class aapb {
    public static final void a(String str, Object[] objArr, StringBuilder sb, List list) {
        sb.append(str);
        if (objArr != null) {
            if (list.size() + objArr.length <= 999) {
                for (Object obj : objArr) {
                    if (obj != null) {
                        list.add(obj.toString());
                    } else {
                        throw new IllegalArgumentException("Bind argument can't be null for query".concat(str));
                    }
                }
                return;
            }
            throw new IllegalArgumentException("Single SQL statements support at most 999 parameters.");
        }
    }
}
