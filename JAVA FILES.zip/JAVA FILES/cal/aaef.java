package cal;

/* compiled from: PG */
/* loaded from: classes2.dex */
public abstract class aaef {
    public abstract aaee a();

    public abstract void b(aaee aaeeVar, zry zryVar, aquh aquhVar, int i);

    @Deprecated
    public abstract void c(aaee aaeeVar, String str, aquh aquhVar);
}
