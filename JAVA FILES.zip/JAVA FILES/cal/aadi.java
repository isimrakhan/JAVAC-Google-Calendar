package cal;

/* compiled from: PG */
/* loaded from: classes2.dex */
public final class aadi {
    public static aqvw a(aqvw aqvwVar, long j) {
        aqvv aqvvVar = new aqvv();
        ampm ampmVar = aqvvVar.a;
        if (ampmVar != aqvwVar && (aqvwVar == null || ampmVar.getClass() != aqvwVar.getClass() || !amrc.a.a(ampmVar.getClass()).k(ampmVar, aqvwVar))) {
            if ((aqvvVar.b.ad & Integer.MIN_VALUE) == 0) {
                aqvvVar.s();
            }
            ampm ampmVar2 = aqvvVar.b;
            amrc.a.a(ampmVar2.getClass()).g(ampmVar2, aqvwVar);
        }
        aqvw aqvwVar2 = (aqvw) aqvvVar.b;
        if ((aqvwVar2.c & 2) != 0) {
            long j2 = aqvwVar2.e - j;
            if ((aqvvVar.b.ad & Integer.MIN_VALUE) == 0) {
                aqvvVar.s();
            }
            aqvw aqvwVar3 = (aqvw) aqvvVar.b;
            aqvwVar3.c |= 2;
            aqvwVar3.e = j2;
        }
        aqvw aqvwVar4 = (aqvw) aqvvVar.b;
        if ((aqvwVar4.c & 4) != 0) {
            long j3 = aqvwVar4.f - j;
            if ((aqvvVar.b.ad & Integer.MIN_VALUE) == 0) {
                aqvvVar.s();
            }
            aqvw aqvwVar5 = (aqvw) aqvvVar.b;
            aqvwVar5.c |= 4;
            aqvwVar5.f = j3;
        }
        aqvw aqvwVar6 = (aqvw) aqvvVar.b;
        if ((aqvwVar6.c & 8) != 0) {
            long j4 = aqvwVar6.g - j;
            if ((aqvvVar.b.ad & Integer.MIN_VALUE) == 0) {
                aqvvVar.s();
            }
            aqvw aqvwVar7 = (aqvw) aqvvVar.b;
            aqvwVar7.c |= 8;
            aqvwVar7.g = j4;
        }
        return (aqvw) aqvvVar.p();
    }
}
