package cal;

/* JADX INFO: Access modifiers changed from: package-private */
/* compiled from: PG */
/* loaded from: classes2.dex */
public interface aahe {
    String a(amqs amqsVar);

    String b(amqs amqsVar);

    void c(amqs amqsVar, Long l);

    void d(amqs amqsVar);
}
