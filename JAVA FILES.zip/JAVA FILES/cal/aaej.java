package cal;

import android.os.SystemClock;
import j$.time.Duration;
import j$.util.concurrent.ConcurrentHashMap;
import java.util.Locale;
import java.util.Random;
import java.util.concurrent.Executor;

/* compiled from: PG */
/* loaded from: classes2.dex */
public final class aaej extends aaef implements zwh, aadz {
    static final aidr a = aidr.p("Cold startup", "Cold startup interactive", "Cold startup interactive before onDraw", "Warm startup", "Warm startup interactive", "Warm startup interactive before onDraw", "Warm startup activity onStart", "Cold startup class loading", "Cold startup from process creation", "Cold startup interactive before onDraw from process creation", "Cold startup interactive from process creation");
    public static final /* synthetic */ int f = 0;
    public final zwf b;
    public final anyt c;
    public final anyt d;
    public final ahum e;
    private final Executor g;

    public aaej(zwg zwgVar, Executor executor, final anyt anytVar, anyt anytVar2, apxs apxsVar, final aafq aafqVar) {
        new ConcurrentHashMap();
        this.b = zwgVar.a(ajbw.a, anytVar, apxsVar);
        this.g = executor;
        this.c = anytVar;
        this.d = anytVar2;
        this.e = ahus.a(new ahum() { // from class: cal.aaei
            @Override // cal.ahum
            public final Object a() {
                int i = aaej.f;
                aoaw aoawVar = (aoaw) anytVar;
                Object obj = aoawVar.b;
                if (obj == aoaw.a) {
                    obj = aoawVar.c();
                }
                aafq aafqVar2 = aafq.this;
                float c = ((aaed) obj).c();
                Random random = (Random) aafqVar2.a.b();
                random.getClass();
                return new aafp(random, c);
            }
        });
    }

    @Override // cal.aaef
    public final aaee a() {
        aafw aafwVar = this.b.e;
        boolean z = aafwVar.b;
        aagb aagbVar = aafwVar.a;
        if (z && aagbVar.d()) {
            return new aaee();
        }
        return aaee.a;
    }

    @Override // cal.aaef
    public final void b(aaee aaeeVar, zry zryVar, aquh aquhVar, int i) {
        d(aaeeVar, zryVar.a, true, aquhVar, i);
    }

    @Override // cal.aaef
    public final void c(aaee aaeeVar, String str, aquh aquhVar) {
        d(aaeeVar, str, false, aquhVar, 1);
    }

    public final synchronized ajdo d(final aaee aaeeVar, final String str, final boolean z, final aquh aquhVar, int i) {
        ajah ajahVar;
        aaee aaeeVar2 = aaee.a;
        if (aaeeVar != null && aaeeVar != aaee.a) {
            final long a2 = this.b.a(str);
            if (a2 != -1) {
                aaeeVar.b.b = new zvs(SystemClock.elapsedRealtime(), Duration.ofMillis(SystemClock.uptimeMillis()).toMillis());
                aaeeVar.d = i;
                if (aaeeVar != aaee.a && str != null && !str.isEmpty()) {
                    if (a.contains(str)) {
                        ajahVar = new ajdi(new IllegalArgumentException(String.format(Locale.US, "%s is reserved event. Dropping timer.", str)));
                    } else {
                        ajay ajayVar = new ajay() { // from class: cal.aaeh
                            @Override // cal.ajay
                            public final ajdo a() {
                                long j;
                                long j2;
                                aaej aaejVar = aaej.this;
                                aafp aafpVar = (aafp) aaejVar.e.a();
                                if (aafpVar.b.nextFloat() < aafpVar.a) {
                                    aoaw aoawVar = (aoaw) aaejVar.c;
                                    Object obj = aoawVar.b;
                                    if (obj == aoaw.a) {
                                        obj = aoawVar.c();
                                    }
                                    aaee aaeeVar3 = aaeeVar;
                                    long j3 = a2;
                                    boolean z2 = z;
                                    ((aaed) obj).d();
                                    zwf zwfVar = aaejVar.b;
                                    zvq zvqVar = new zvq();
                                    zvqVar.g = false;
                                    zvqVar.i = 0;
                                    zvqVar.b = z2;
                                    zvqVar.j = (byte) 7;
                                    zvqVar.f = Long.valueOf(j3);
                                    ahti ahtiVar = (ahti) aaejVar.d.b();
                                    aqyd aqydVar = aqyd.a;
                                    aqyc aqycVar = new aqyc();
                                    boolean booleanValue = ((Boolean) ahtiVar.b(new ahsr() { // from class: cal.aaeg
                                        @Override // cal.ahsr
                                        /* renamed from: a */
                                        public final Object b(Object obj2) {
                                            ((zvu) obj2).c();
                                            return false;
                                        }
                                    }).f(false)).booleanValue();
                                    aqyf aqyfVar = aqyf.a;
                                    aqye aqyeVar = new aqye();
                                    if (booleanValue) {
                                        zwm zwmVar = aaeeVar3.b;
                                        j = ((zvs) zwmVar.b).b;
                                        j2 = ((zvs) zwmVar.a).b;
                                    } else {
                                        zwm zwmVar2 = aaeeVar3.b;
                                        j = ((zvs) zwmVar2.b).a;
                                        j2 = ((zvs) zwmVar2.a).a;
                                    }
                                    long j4 = j - j2;
                                    if ((aqyeVar.b.ad & Integer.MIN_VALUE) == 0) {
                                        aqyeVar.s();
                                    }
                                    aqyf aqyfVar2 = (aqyf) aqyeVar.b;
                                    int i2 = 1;
                                    aqyfVar2.c |= 1;
                                    aqyfVar2.d = j4;
                                    int i3 = aaeeVar3.d - 1;
                                    if (i3 != 0) {
                                        if (i3 != 1) {
                                            if (i3 != 2) {
                                                if (i3 == 3) {
                                                    i2 = 4;
                                                }
                                            } else {
                                                i2 = 3;
                                            }
                                        } else {
                                            i2 = 2;
                                        }
                                    }
                                    if ((aqyeVar.b.ad & Integer.MIN_VALUE) == 0) {
                                        aqyeVar.s();
                                    }
                                    aqyf aqyfVar3 = (aqyf) aqyeVar.b;
                                    aqyfVar3.e = i2 - 1;
                                    aqyfVar3.c = 2 | aqyfVar3.c;
                                    aqyf aqyfVar4 = (aqyf) aqyeVar.p();
                                    if ((aqycVar.b.ad & Integer.MIN_VALUE) == 0) {
                                        aqycVar.s();
                                    }
                                    aqyd aqydVar2 = (aqyd) aqycVar.b;
                                    aqyfVar4.getClass();
                                    aqydVar2.h = aqyfVar4;
                                    aqydVar2.c |= 16;
                                    aqyd aqydVar3 = (aqyd) aqycVar.p();
                                    if (aqydVar3 != null) {
                                        aquh aquhVar2 = aquhVar;
                                        String str2 = str;
                                        zvqVar.c = aqydVar3;
                                        zvqVar.a = str2;
                                        zvqVar.d = aquhVar2;
                                        zvx a3 = zvqVar.a();
                                        if (zwfVar.a.a) {
                                            ajdh ajdhVar = ajdh.a;
                                            if (ajdhVar == null) {
                                                return new ajdh();
                                            }
                                            return ajdhVar;
                                        }
                                        zwc zwcVar = new zwc(zwfVar, a3);
                                        Executor executor = zwfVar.d;
                                        ajel ajelVar = new ajel(zwcVar);
                                        executor.execute(ajelVar);
                                        return ajelVar;
                                    }
                                    throw new NullPointerException("Null metric");
                                }
                                return ajdj.a;
                            }
                        };
                        Executor executor = this.g;
                        ajel ajelVar = new ajel(ajayVar);
                        executor.execute(ajelVar);
                        ajahVar = ajelVar;
                    }
                    return ajahVar;
                }
                ajahVar = new ajdi(new IllegalArgumentException("Can't record an event that was never started or has been stopped already"));
                return ajahVar;
            }
            return ajdj.a;
        }
        return ajdj.a;
    }

    @Override // cal.zwh
    public final /* synthetic */ void u() {
    }
}
