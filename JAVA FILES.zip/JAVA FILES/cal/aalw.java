package cal;

import android.accounts.Account;
import android.net.Uri;
import j$.util.concurrent.ConcurrentHashMap;
import java.util.HashMap;
import java.util.concurrent.ConcurrentMap;

/* compiled from: PG */
/* loaded from: classes2.dex */
public final class aalw {
    public static final ConcurrentMap a = new ConcurrentHashMap();
    private static final acdl b = new acdl(aakl.a);
    private static final Object c = new Object();
    private static volatile acbk d = null;

    public static acbg a(aaic aaicVar) {
        abzx abzxVar = new abzx();
        abzxVar.f = acci.a;
        abzxVar.g = true;
        abzxVar.h = (byte) 3;
        Account account = abys.a;
        Account account2 = abys.a;
        aicf aicfVar = new aicf(4);
        String packageName = aaicVar.d.getPackageName();
        abys.a("phenotype");
        Uri a2 = abyr.a(packageName, "files", "phenotype", account2, "all_accounts.pb", aicfVar);
        if (a2 != null) {
            abzxVar.a = a2;
            aakl aaklVar = aakl.a;
            if (aaklVar != null) {
                abzxVar.b = aaklVar;
                acdl acdlVar = b;
                acdlVar.getClass();
                abzxVar.c = new ahts(acdlVar);
                abzxVar.h = (byte) (abzxVar.h | 2);
                acbi a3 = abzxVar.a();
                acbk acbkVar = d;
                if (acbkVar == null) {
                    synchronized (c) {
                        acbkVar = d;
                        if (acbkVar == null) {
                            acdm acdmVar = acdm.a;
                            HashMap hashMap = new HashMap();
                            ajds ajdsVar = (ajds) aaicVar.e.a();
                            abym abymVar = (abym) aaicVar.h.a();
                            acdi acdiVar = accs.a;
                            if (!hashMap.containsKey("singleproc")) {
                                hashMap.put("singleproc", acdiVar);
                                acbk acbkVar2 = new acbk(ajdsVar, abymVar, acdmVar, hashMap);
                                d = acbkVar2;
                                acbkVar = acbkVar2;
                            } else {
                                throw new IllegalArgumentException(ahul.a("There is already a factory registered for the ID %s", "singleproc"));
                            }
                        }
                    }
                }
                return acbkVar.a(a3);
            }
            throw new NullPointerException("Null schema");
        }
        throw new NullPointerException("Null uri");
    }

    /* JADX WARN: Code restructure failed: missing block: B:18:0x0023, code lost:
    
        if (r4 != false) goto L17;
     */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct code enable 'Show inconsistent code' option in preferences
    */
    public static boolean b(java.io.File r6) {
        /*
            boolean r0 = r6.isDirectory()
            r1 = 1
            r2 = 0
            if (r0 == 0) goto L25
            java.io.File[] r0 = r6.listFiles()
            if (r0 == 0) goto L25
            r4 = r1
            r3 = r2
        L10:
            int r5 = r0.length
            if (r3 >= r5) goto L23
            r5 = r0[r3]
            if (r4 == 0) goto L1f
            boolean r4 = b(r5)
            if (r4 == 0) goto L1f
            r4 = r1
            goto L20
        L1f:
            r4 = r2
        L20:
            int r3 = r3 + 1
            goto L10
        L23:
            if (r4 == 0) goto L2c
        L25:
            boolean r6 = r6.delete()
            if (r6 == 0) goto L2c
            return r1
        L2c:
            return r2
        */
        throw new UnsupportedOperationException("Method not decompiled: cal.aalw.b(java.io.File):boolean");
    }
}
