package androidx.coordinatorlayout.widget;

import android.content.Context;
import android.content.res.Resources;
import android.content.res.TypedArray;
import android.graphics.Canvas;
import android.graphics.Rect;
import android.graphics.drawable.ColorDrawable;
import android.graphics.drawable.Drawable;
import android.os.Build;
import android.os.Parcelable;
import android.os.SystemClock;
import android.util.AttributeSet;
import android.util.Log;
import android.util.SparseArray;
import android.view.Gravity;
import android.view.KeyEvent;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup;
import cal.aep;
import cal.aeq;
import cal.aer;
import cal.aes;
import cal.aet;
import cal.aeu;
import cal.aev;
import cal.aew;
import cal.aey;
import cal.aez;
import cal.afa;
import cal.afb;
import cal.ake;
import cal.akg;
import cal.ald;
import cal.ale;
import cal.alf;
import cal.alg;
import cal.als;
import cal.alu;
import cal.alz;
import cal.ame;
import cal.anq;
import com.google.android.calendar.R;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;

/* compiled from: PG */
/* loaded from: classes.dex */
public class CoordinatorLayout extends ViewGroup implements ald, ale {
    public static final String a;
    public static final Class[] b;
    public static final ThreadLocal c;
    static final Comparator d;
    public static final ake e;
    public final afa f;
    public anq g;
    public boolean h;
    public ViewGroup.OnHierarchyChangeListener i;
    private final List j;
    private final List k;
    private final int[] l;
    private final int[] m;
    private final int[] n;
    private boolean o;
    private boolean p;
    private int[] q;
    private View r;
    private View s;
    private aew t;
    private boolean u;
    private Drawable v;
    private alg w;
    private final alf x;

    static {
        String str;
        Package r0 = CoordinatorLayout.class.getPackage();
        if (r0 != null) {
            str = r0.getName();
        } else {
            str = null;
        }
        a = str;
        d = new aez();
        b = new Class[]{Context.class, AttributeSet.class};
        c = new ThreadLocal();
        e = new akg(12);
    }

    public CoordinatorLayout(Context context) {
        this(context, null);
    }

    /* JADX WARN: Multi-variable type inference failed */
    static final aev j(View view) {
        aev aevVar = (aev) view.getLayoutParams();
        if (!aevVar.b) {
            if (view instanceof aer) {
                aevVar.a(((aer) view).a());
                aevVar.b = true;
            } else {
                aet aetVar = null;
                for (Class<?> cls = view.getClass(); cls != null; cls = cls.getSuperclass()) {
                    aetVar = (aet) cls.getAnnotation(aet.class);
                    if (aetVar != null) {
                        break;
                    }
                }
                if (aetVar != null) {
                    try {
                        aevVar.a((aes) aetVar.a().getDeclaredConstructor(null).newInstance(null));
                    } catch (Exception e2) {
                        Log.e("CoordinatorLayout", "Default behavior class " + aetVar.a().getName() + " could not be instantiated. Did you forget a default constructor?", e2);
                    }
                }
                aevVar.b = true;
            }
        }
        return aevVar;
    }

    private final int l() {
        int i = 0;
        for (int i2 = 0; i2 < getChildCount(); i2++) {
            View childAt = getChildAt(i2);
            aev aevVar = (aev) childAt.getLayoutParams();
            i += childAt.getHeight() + aevVar.topMargin + aevVar.bottomMargin;
        }
        return i;
    }

    private final int m(int i) {
        int[] iArr = this.q;
        if (iArr == null) {
            Log.e("CoordinatorLayout", "No keylines defined for " + this + " - attempted index lookup " + i);
            return 0;
        }
        if (i >= 0 && i < iArr.length) {
            return iArr[i];
        }
        Log.e("CoordinatorLayout", "Keyline index " + i + " out of range for " + this);
        return 0;
    }

    private static int n(int i) {
        if ((i & 7) == 0) {
            i |= 8388611;
        }
        if ((i & 112) == 0) {
            return i | 48;
        }
        return i;
    }

    private final void o(aev aevVar, Rect rect, int i, int i2) {
        int width = getWidth();
        int height = getHeight();
        int max = Math.max(getPaddingLeft() + aevVar.leftMargin, Math.min(rect.left, ((width - getPaddingRight()) - i) - aevVar.rightMargin));
        int max2 = Math.max(getPaddingTop() + aevVar.topMargin, Math.min(rect.top, ((height - getPaddingBottom()) - i2) - aevVar.bottomMargin));
        rect.set(max, max2, i + max, i2 + max2);
    }

    private final void p() {
        View view = this.r;
        if (view != null) {
            aes aesVar = ((aev) view.getLayoutParams()).a;
            if (aesVar != null) {
                long uptimeMillis = SystemClock.uptimeMillis();
                MotionEvent obtain = MotionEvent.obtain(uptimeMillis, uptimeMillis, 3, 0.0f, 0.0f, 0);
                aesVar.e(this, this.r, obtain);
                obtain.recycle();
            }
            this.r = null;
        }
        int childCount = getChildCount();
        for (int i = 0; i < childCount; i++) {
            ((aev) getChildAt(i).getLayoutParams()).m = false;
        }
        this.o = false;
    }

    private final void r() {
        int[] iArr = ame.a;
        if (getFitsSystemWindows()) {
            if (this.w == null) {
                this.w = new aeq(this);
            }
            alu.k(this, this.w);
            setSystemUiVisibility(1280);
            return;
        }
        alu.k(this, null);
    }

    private final boolean s(View view, int i) {
        q(this, view, 2, 1);
        int[] iArr = this.n;
        iArr[0] = 0;
        iArr[1] = 0;
        e(view, 0, 0, 0, i, 1, iArr);
        g(view, 1);
        if (this.n[1] > 0) {
            return true;
        }
        return false;
    }

    private final boolean t(MotionEvent motionEvent, int i) {
        int i2;
        int actionMasked = motionEvent.getActionMasked();
        List list = this.k;
        list.clear();
        boolean isChildrenDrawingOrderEnabled = isChildrenDrawingOrderEnabled();
        int childCount = getChildCount();
        for (int i3 = childCount - 1; i3 >= 0; i3--) {
            if (isChildrenDrawingOrderEnabled) {
                i2 = getChildDrawingOrder(childCount, i3);
            } else {
                i2 = i3;
            }
            list.add(getChildAt(i2));
        }
        Comparator comparator = d;
        if (comparator != null) {
            Collections.sort(list, comparator);
        }
        int size = list.size();
        MotionEvent motionEvent2 = null;
        boolean z = false;
        for (int i4 = 0; i4 < size; i4++) {
            View view = (View) list.get(i4);
            aev aevVar = (aev) view.getLayoutParams();
            aes aesVar = aevVar.a;
            if (z && actionMasked != 0) {
                if (aesVar != null) {
                    if (motionEvent2 == null) {
                        motionEvent2 = MotionEvent.obtain(motionEvent);
                        motionEvent2.setAction(3);
                    }
                    if (i != 0) {
                        aesVar.e(this, view, motionEvent2);
                    } else {
                        aesVar.c(this, view, motionEvent2);
                    }
                }
            } else {
                if (!z && aesVar != null) {
                    if (i != 0) {
                        z = aesVar.e(this, view, motionEvent);
                    } else {
                        z = aesVar.c(this, view, motionEvent);
                    }
                    if (z) {
                        this.r = view;
                        if (actionMasked != 3 && actionMasked != 1) {
                            for (int i5 = 0; i5 < i4; i5++) {
                                View view2 = (View) list.get(i5);
                                aes aesVar2 = ((aev) view2.getLayoutParams()).a;
                                if (aesVar2 != null) {
                                    if (motionEvent2 == null) {
                                        motionEvent2 = MotionEvent.obtain(motionEvent);
                                        motionEvent2.setAction(3);
                                    }
                                    if (i != 0) {
                                        aesVar2.e(this, view2, motionEvent2);
                                    } else {
                                        aesVar2.c(this, view2, motionEvent2);
                                    }
                                }
                            }
                        }
                    }
                }
                if (aevVar.a == null) {
                    aevVar.m = false;
                }
                boolean z2 = aevVar.m;
            }
        }
        list.clear();
        if (motionEvent2 != null) {
            motionEvent2.recycle();
        }
        return z;
    }

    private static final View u(View view) {
        while (view != null) {
            if (view.isFocused()) {
                return view;
            }
            if (view instanceof ViewGroup) {
                view = ((ViewGroup) view).getFocusedChild();
            } else {
                view = null;
            }
        }
        return null;
    }

    private static final void v(int i, Rect rect, Rect rect2, aev aevVar, int i2, int i3) {
        int width;
        int height;
        int i4 = aevVar.c;
        if (i4 == 0) {
            i4 = 17;
        }
        int absoluteGravity = Gravity.getAbsoluteGravity(i4, i);
        int i5 = absoluteGravity & 7;
        int i6 = absoluteGravity & 112;
        int absoluteGravity2 = Gravity.getAbsoluteGravity(n(aevVar.d), i);
        int i7 = absoluteGravity2 & 7;
        int i8 = absoluteGravity2 & 112;
        if (i7 != 1) {
            if (i7 != 5) {
                width = rect.left;
            } else {
                width = rect.right;
            }
        } else {
            width = rect.left + (rect.width() / 2);
        }
        if (i8 != 16) {
            if (i8 != 80) {
                height = rect.top;
            } else {
                height = rect.bottom;
            }
        } else {
            height = rect.top + (rect.height() / 2);
        }
        if (i5 != 1) {
            if (i5 != 5) {
                width -= i2;
            }
        } else {
            width -= i2 / 2;
        }
        if (i6 != 16) {
            if (i6 != 80) {
                height -= i3;
            }
        } else {
            height -= i3 / 2;
        }
        rect2.set(width, height, i2 + width, i3 + height);
    }

    public final void a(View view, boolean z, Rect rect) {
        if (!view.isLayoutRequested() && view.getVisibility() != 8) {
            if (z) {
                int i = afb.a;
                rect.set(0, 0, view.getWidth(), view.getHeight());
                afb.a(this, view, rect);
                return;
            }
            rect.set(view.getLeft(), view.getTop(), view.getRight(), view.getBottom());
            return;
        }
        rect.setEmpty();
    }

    /* JADX WARN: Multi-variable type inference failed */
    /* JADX WARN: Type inference failed for: r13v13 */
    /* JADX WARN: Type inference failed for: r13v2, types: [int, boolean] */
    /* JADX WARN: Type inference failed for: r13v8 */
    public final void b(int i) {
        Rect rect;
        int i2;
        boolean z;
        boolean z2;
        boolean z3;
        aev aevVar;
        int i3;
        boolean z4;
        aev aevVar2;
        int i4;
        int width;
        int i5;
        int height;
        int i6;
        int i7;
        int i8;
        Rect rect2;
        aev aevVar3;
        int i9;
        int i10;
        aev aevVar4;
        boolean z5;
        aes aesVar;
        int layoutDirection = getLayoutDirection();
        int size = this.j.size();
        ake akeVar = e;
        Rect rect3 = (Rect) akeVar.a();
        if (rect3 == null) {
            rect3 = new Rect();
        }
        Rect rect4 = rect3;
        Rect rect5 = (Rect) akeVar.a();
        if (rect5 == null) {
            rect5 = new Rect();
        }
        Rect rect6 = rect5;
        Rect rect7 = (Rect) akeVar.a();
        if (rect7 == null) {
            rect7 = new Rect();
        }
        Rect rect8 = rect7;
        boolean z6 = false;
        int i11 = 0;
        while (i11 < size) {
            View view = (View) this.j.get(i11);
            aev aevVar5 = (aev) view.getLayoutParams();
            if (i == 0 && view.getVisibility() == 8) {
                i2 = size;
                rect = rect8;
                z = z6 ? 1 : 0;
            } else {
                int i12 = z6 ? 1 : 0;
                ?? r13 = z6;
                while (i12 < i11) {
                    if (aevVar5.l == ((View) this.j.get(i12))) {
                        aev aevVar6 = (aev) view.getLayoutParams();
                        if (aevVar6.k != null) {
                            ake akeVar2 = e;
                            Rect rect9 = (Rect) akeVar2.a();
                            Rect rect10 = rect9;
                            if (rect9 == null) {
                                rect10 = new Rect();
                            }
                            Rect rect11 = (Rect) akeVar2.a();
                            if (rect11 == null) {
                                rect11 = new Rect();
                            }
                            Rect rect12 = rect11;
                            Rect rect13 = (Rect) akeVar2.a();
                            if (rect13 == null) {
                                rect13 = new Rect();
                            }
                            Rect rect14 = rect13;
                            View view2 = aevVar6.k;
                            int i13 = afb.a;
                            rect10.set(r13, r13, view2.getWidth(), view2.getHeight());
                            afb.a(this, view2, rect10);
                            a(view, r13, rect12);
                            int measuredWidth = view.getMeasuredWidth();
                            int measuredHeight = view.getMeasuredHeight();
                            Rect rect15 = rect10;
                            i8 = size;
                            i7 = i12;
                            rect2 = rect8;
                            aevVar3 = aevVar5;
                            v(layoutDirection, rect15, rect14, aevVar6, measuredWidth, measuredHeight);
                            if (rect14.left == rect12.left && rect14.top == rect12.top) {
                                i9 = measuredHeight;
                                i10 = measuredWidth;
                                aevVar4 = aevVar6;
                                z5 = false;
                            } else {
                                i9 = measuredHeight;
                                i10 = measuredWidth;
                                aevVar4 = aevVar6;
                                z5 = true;
                            }
                            o(aevVar4, rect14, i10, i9);
                            int i14 = rect14.left - rect12.left;
                            int i15 = rect14.top - rect12.top;
                            if (i14 != 0) {
                                int[] iArr = ame.a;
                                view.offsetLeftAndRight(i14);
                            }
                            if (i15 != 0) {
                                int[] iArr2 = ame.a;
                                view.offsetTopAndBottom(i15);
                            }
                            if (z5 && (aesVar = aevVar4.a) != null) {
                                aesVar.g(this, view, aevVar4.k);
                            }
                            rect15.setEmpty();
                            akeVar2.b(rect15);
                            rect12.setEmpty();
                            akeVar2.b(rect12);
                            rect14.setEmpty();
                            akeVar2.b(rect14);
                            i12 = i7 + 1;
                            aevVar5 = aevVar3;
                            size = i8;
                            rect8 = rect2;
                            r13 = 0;
                        }
                    }
                    i7 = i12;
                    i8 = size;
                    rect2 = rect8;
                    aevVar3 = aevVar5;
                    i12 = i7 + 1;
                    aevVar5 = aevVar3;
                    size = i8;
                    rect8 = rect2;
                    r13 = 0;
                }
                int i16 = size;
                Rect rect16 = rect8;
                aev aevVar7 = aevVar5;
                a(view, true, rect6);
                if (aevVar7.g != 0 && !rect6.isEmpty()) {
                    int absoluteGravity = Gravity.getAbsoluteGravity(aevVar7.g, layoutDirection);
                    int i17 = absoluteGravity & 112;
                    if (i17 != 48) {
                        if (i17 == 80) {
                            rect4.bottom = Math.max(rect4.bottom, getHeight() - rect6.top);
                        }
                    } else {
                        rect4.top = Math.max(rect4.top, rect6.bottom);
                    }
                    int i18 = absoluteGravity & 7;
                    if (i18 != 3) {
                        if (i18 == 5) {
                            rect4.right = Math.max(rect4.right, getWidth() - rect6.left);
                        }
                    } else {
                        rect4.left = Math.max(rect4.left, rect6.right);
                    }
                }
                if (aevVar7.h != 0 && view.getVisibility() == 0 && view.isLaidOut() && view.getWidth() > 0 && view.getHeight() > 0) {
                    aev aevVar8 = (aev) view.getLayoutParams();
                    aes aesVar2 = aevVar8.a;
                    ake akeVar3 = e;
                    Rect rect17 = (Rect) akeVar3.a();
                    if (rect17 == null) {
                        rect17 = new Rect();
                    }
                    Rect rect18 = (Rect) akeVar3.a();
                    if (rect18 == null) {
                        rect18 = new Rect();
                    }
                    rect18.set(view.getLeft(), view.getTop(), view.getRight(), view.getBottom());
                    if (aesVar2 != null && aesVar2.r(view, rect17)) {
                        if (!rect18.contains(rect17)) {
                            throw new IllegalArgumentException("Rect should be within the child's bounds. Rect:" + rect17.toShortString() + " | Bounds:" + rect18.toShortString());
                        }
                    } else {
                        rect17.set(rect18);
                    }
                    rect18.setEmpty();
                    akeVar3.b(rect18);
                    if (rect17.isEmpty()) {
                        rect17.setEmpty();
                        akeVar3.b(rect17);
                    } else {
                        int absoluteGravity2 = Gravity.getAbsoluteGravity(aevVar8.h, layoutDirection);
                        if ((absoluteGravity2 & 48) == 48 && (i6 = (rect17.top - aevVar8.topMargin) - aevVar8.j) < rect4.top) {
                            int i19 = rect4.top - i6;
                            aev aevVar9 = (aev) view.getLayoutParams();
                            int i20 = aevVar9.j;
                            if (i20 != i19) {
                                int[] iArr3 = ame.a;
                                view.offsetTopAndBottom(i19 - i20);
                                aevVar9.j = i19;
                            }
                            z3 = true;
                        } else {
                            z3 = false;
                        }
                        if ((absoluteGravity2 & 80) == 80 && (height = ((getHeight() - rect17.bottom) - aevVar8.bottomMargin) + aevVar8.j) < rect4.bottom) {
                            int i21 = height - rect4.bottom;
                            aev aevVar10 = (aev) view.getLayoutParams();
                            int i22 = aevVar10.j;
                            if (i22 != i21) {
                                int[] iArr4 = ame.a;
                                view.offsetTopAndBottom(i21 - i22);
                                aevVar10.j = i21;
                            }
                        } else if (!z3 && (i3 = (aevVar = (aev) view.getLayoutParams()).j) != 0) {
                            int[] iArr5 = ame.a;
                            view.offsetTopAndBottom(-i3);
                            aevVar.j = 0;
                        }
                        if ((absoluteGravity2 & 3) == 3 && (i5 = (rect17.left - aevVar8.leftMargin) - aevVar8.i) < rect4.left) {
                            int i23 = rect4.left - i5;
                            aev aevVar11 = (aev) view.getLayoutParams();
                            int i24 = aevVar11.i;
                            if (i24 != i23) {
                                int[] iArr6 = ame.a;
                                view.offsetLeftAndRight(i23 - i24);
                                aevVar11.i = i23;
                            }
                            z4 = true;
                        } else {
                            z4 = false;
                        }
                        if ((absoluteGravity2 & 5) == 5 && (width = ((getWidth() - rect17.right) - aevVar8.rightMargin) + aevVar8.i) < rect4.right) {
                            int i25 = width - rect4.right;
                            aev aevVar12 = (aev) view.getLayoutParams();
                            int i26 = aevVar12.i;
                            if (i26 != i25) {
                                int[] iArr7 = ame.a;
                                view.offsetLeftAndRight(i25 - i26);
                                aevVar12.i = i25;
                            }
                        } else if (!z4 && (i4 = (aevVar2 = (aev) view.getLayoutParams()).i) != 0) {
                            int[] iArr8 = ame.a;
                            view.offsetLeftAndRight(-i4);
                            aevVar2.i = 0;
                        }
                        rect17.setEmpty();
                        akeVar3.b(rect17);
                    }
                }
                if (i != 2) {
                    rect = rect16;
                    rect.set(((aev) view.getLayoutParams()).q);
                    if (!rect.equals(rect6)) {
                        ((aev) view.getLayoutParams()).q.set(rect6);
                    } else {
                        i2 = i16;
                        z = false;
                    }
                } else {
                    rect = rect16;
                }
                i2 = i16;
                for (int i27 = i11 + 1; i27 < i2; i27++) {
                    View view3 = (View) this.j.get(i27);
                    aev aevVar13 = (aev) view3.getLayoutParams();
                    aes aesVar3 = aevVar13.a;
                    if (aesVar3 != null && aesVar3.f(view)) {
                        if (i == 0 && aevVar13.p) {
                            aevVar13.p = false;
                        } else {
                            if (i != 2) {
                                aesVar3.g(this, view3, view);
                                z2 = false;
                            } else {
                                aesVar3.h(this, view);
                                z2 = true;
                            }
                            if (i == 1) {
                                aevVar13.p = z2;
                            }
                        }
                    }
                }
                z = false;
            }
            i11++;
            size = i2;
            z6 = z;
            rect8 = rect;
        }
        Rect rect19 = rect8;
        rect4.setEmpty();
        ake akeVar4 = e;
        akeVar4.b(rect4);
        rect6.setEmpty();
        akeVar4.b(rect6);
        rect19.setEmpty();
        akeVar4.b(rect19);
    }

    @Override // cal.ald
    public final void c(View view, int i, int i2, int[] iArr, int i3) {
        boolean z;
        aes aesVar;
        int childCount = getChildCount();
        int i4 = 0;
        int i5 = 0;
        boolean z2 = false;
        for (int i6 = 0; i6 < childCount; i6++) {
            View childAt = getChildAt(i6);
            if (childAt.getVisibility() != 8) {
                aev aevVar = (aev) childAt.getLayoutParams();
                if (i3 != 0) {
                    z = aevVar.o;
                } else {
                    z = aevVar.n;
                }
                if (z && (aesVar = aevVar.a) != null) {
                    int[] iArr2 = this.l;
                    iArr2[0] = 0;
                    iArr2[1] = 0;
                    aesVar.k(childAt, view, i2, iArr2, i3);
                    if (i > 0) {
                        i4 = Math.max(i4, this.l[0]);
                    } else {
                        i4 = Math.min(i4, this.l[0]);
                    }
                    if (i2 > 0) {
                        i5 = Math.max(i5, this.l[1]);
                    } else {
                        i5 = Math.min(i5, this.l[1]);
                    }
                    z2 = true;
                }
            }
        }
        iArr[0] = i4;
        iArr[1] = i5;
        if (z2) {
            b(1);
        }
    }

    @Override // android.view.ViewGroup
    protected final boolean checkLayoutParams(ViewGroup.LayoutParams layoutParams) {
        if ((layoutParams instanceof aev) && super.checkLayoutParams(layoutParams)) {
            return true;
        }
        return false;
    }

    @Override // cal.ald
    public final void d(View view, int i, int i2, int i3, int i4, int i5) {
        e(view, i, i2, i3, i4, 0, this.m);
    }

    @Override // android.view.ViewGroup, android.view.View
    public final boolean dispatchKeyEvent(KeyEvent keyEvent) {
        boolean dispatchKeyEvent = super.dispatchKeyEvent(keyEvent);
        if (!dispatchKeyEvent && keyEvent.getAction() == 0) {
            int keyCode = keyEvent.getKeyCode();
            if (keyCode != 19) {
                if (keyCode != 20) {
                    if (keyCode != 62) {
                        if (keyCode != 92) {
                            if (keyCode != 93) {
                                if (keyCode != 122) {
                                    if (keyCode == 123) {
                                        return s(u(this), l() - getHeight());
                                    }
                                    return dispatchKeyEvent;
                                }
                                return s(u(this), -l());
                            }
                            return s(u(this), getHeight());
                        }
                        return s(u(this), -getHeight());
                    }
                    if (keyEvent.isShiftPressed()) {
                        return s(u(this), -l());
                    }
                    return s(u(this), l() - getHeight());
                }
                if (keyEvent.isAltPressed()) {
                    return s(u(this), getHeight());
                }
                return s(u(this), (int) (getHeight() * 0.1f));
            }
            if (keyEvent.isAltPressed()) {
                return s(u(this), -getHeight());
            }
            return s(u(this), -((int) (getHeight() * 0.1f)));
        }
        return dispatchKeyEvent;
    }

    @Override // android.view.ViewGroup
    protected final boolean drawChild(Canvas canvas, View view, long j) {
        aes aesVar = ((aev) view.getLayoutParams()).a;
        return super.drawChild(canvas, view, j);
    }

    @Override // android.view.ViewGroup, android.view.View
    protected final void drawableStateChanged() {
        super.drawableStateChanged();
        int[] drawableState = getDrawableState();
        Drawable drawable = this.v;
        if (drawable != null && drawable.isStateful() && drawable.setState(drawableState)) {
            invalidate();
        }
    }

    @Override // cal.ale
    public final void e(View view, int i, int i2, int i3, int i4, int i5, int[] iArr) {
        boolean z;
        aes aesVar;
        int min;
        int min2;
        int childCount = getChildCount();
        boolean z2 = false;
        int i6 = 0;
        int i7 = 0;
        for (int i8 = 0; i8 < childCount; i8++) {
            View childAt = getChildAt(i8);
            if (childAt.getVisibility() != 8) {
                aev aevVar = (aev) childAt.getLayoutParams();
                if (i5 != 0) {
                    z = aevVar.o;
                } else {
                    z = aevVar.n;
                }
                if (z && (aesVar = aevVar.a) != null) {
                    int[] iArr2 = this.l;
                    iArr2[0] = 0;
                    iArr2[1] = 0;
                    aesVar.l(this, childAt, view, i2, i3, i4, iArr2);
                    if (i3 > 0) {
                        min = Math.max(i6, this.l[0]);
                    } else {
                        min = Math.min(i6, this.l[0]);
                    }
                    i6 = min;
                    if (i4 > 0) {
                        min2 = Math.max(i7, this.l[1]);
                    } else {
                        min2 = Math.min(i7, this.l[1]);
                    }
                    i7 = min2;
                    z2 = true;
                }
            }
        }
        iArr[0] = iArr[0] + i6;
        iArr[1] = iArr[1] + i7;
        if (z2) {
            b(1);
        }
    }

    @Override // cal.ald
    public final void f(View view, View view2, int i, int i2) {
        boolean z;
        alf alfVar = this.x;
        if (i2 == 1) {
            alfVar.b = i;
        } else {
            alfVar.a = i;
        }
        this.s = view2;
        int childCount = getChildCount();
        for (int i3 = 0; i3 < childCount; i3++) {
            aev aevVar = (aev) getChildAt(i3).getLayoutParams();
            if (i2 != 0) {
                z = aevVar.o;
            } else {
                z = aevVar.n;
            }
            if (z) {
                aes aesVar = aevVar.a;
            }
        }
    }

    @Override // cal.ald
    public final void g(View view, int i) {
        boolean z;
        alf alfVar = this.x;
        if (i == 1) {
            alfVar.b = 0;
        } else {
            alfVar.a = 0;
        }
        int childCount = getChildCount();
        for (int i2 = 0; i2 < childCount; i2++) {
            View childAt = getChildAt(i2);
            aev aevVar = (aev) childAt.getLayoutParams();
            if (i != 0) {
                z = aevVar.o;
            } else {
                z = aevVar.n;
            }
            if (z) {
                aes aesVar = aevVar.a;
                if (aesVar != null) {
                    aesVar.q(childAt, view, i);
                }
                if (i != 0) {
                    aevVar.o = false;
                } else {
                    aevVar.n = false;
                }
                aevVar.p = false;
            }
        }
        this.s = null;
    }

    @Override // android.view.ViewGroup
    protected final /* synthetic */ ViewGroup.LayoutParams generateDefaultLayoutParams() {
        return new aev(-2, -2);
    }

    @Override // android.view.ViewGroup
    public final /* synthetic */ ViewGroup.LayoutParams generateLayoutParams(AttributeSet attributeSet) {
        return new aev(getContext(), attributeSet);
    }

    @Override // android.view.ViewGroup
    public final int getNestedScrollAxes() {
        alf alfVar = this.x;
        return alfVar.b | alfVar.a;
    }

    @Override // android.view.View
    protected final int getSuggestedMinimumHeight() {
        return Math.max(super.getSuggestedMinimumHeight(), getPaddingTop() + getPaddingBottom());
    }

    @Override // android.view.View
    protected final int getSuggestedMinimumWidth() {
        return Math.max(super.getSuggestedMinimumWidth(), getPaddingLeft() + getPaddingRight());
    }

    public final void h(View view, int i) {
        aev aevVar = (aev) view.getLayoutParams();
        View view2 = aevVar.k;
        if (view2 == null && aevVar.f != -1) {
            throw new IllegalStateException("An anchor may not be changed after CoordinatorLayout measurement begins before layout is complete.");
        }
        int i2 = 0;
        if (view2 != null) {
            ake akeVar = e;
            Rect rect = (Rect) akeVar.a();
            if (rect == null) {
                rect = new Rect();
            }
            Rect rect2 = (Rect) akeVar.a();
            if (rect2 == null) {
                rect2 = new Rect();
            }
            Rect rect3 = rect2;
            try {
                int i3 = afb.a;
                rect.set(0, 0, view2.getWidth(), view2.getHeight());
                afb.a(this, view2, rect);
                aev aevVar2 = (aev) view.getLayoutParams();
                int measuredWidth = view.getMeasuredWidth();
                int measuredHeight = view.getMeasuredHeight();
                v(i, rect, rect3, aevVar2, measuredWidth, measuredHeight);
                o(aevVar2, rect3, measuredWidth, measuredHeight);
                view.layout(rect3.left, rect3.top, rect3.right, rect3.bottom);
                rect.setEmpty();
                akeVar.b(rect);
                rect3.setEmpty();
                akeVar.b(rect3);
                return;
            } catch (Throwable th) {
                rect.setEmpty();
                ake akeVar2 = e;
                akeVar2.b(rect);
                rect3.setEmpty();
                akeVar2.b(rect3);
                throw th;
            }
        }
        int i4 = aevVar.e;
        if (i4 >= 0) {
            aev aevVar3 = (aev) view.getLayoutParams();
            int i5 = aevVar3.c;
            if (i5 == 0) {
                i5 = 8388661;
            }
            int absoluteGravity = Gravity.getAbsoluteGravity(i5, i);
            int i6 = absoluteGravity & 7;
            int i7 = absoluteGravity & 112;
            int width = getWidth();
            int height = getHeight();
            int measuredWidth2 = view.getMeasuredWidth();
            int measuredHeight2 = view.getMeasuredHeight();
            if (i == 1) {
                i4 = width - i4;
            }
            int m = m(i4) - measuredWidth2;
            if (i6 != 1) {
                if (i6 == 5) {
                    m += measuredWidth2;
                }
            } else {
                m += measuredWidth2 / 2;
            }
            if (i7 != 16) {
                if (i7 == 80) {
                    i2 = measuredHeight2;
                }
            } else {
                i2 = measuredHeight2 / 2;
            }
            int max = Math.max(getPaddingLeft() + aevVar3.leftMargin, Math.min(m, ((width - getPaddingRight()) - measuredWidth2) - aevVar3.rightMargin));
            int max2 = Math.max(getPaddingTop() + aevVar3.topMargin, Math.min(i2, ((height - getPaddingBottom()) - measuredHeight2) - aevVar3.bottomMargin));
            view.layout(max, max2, measuredWidth2 + max, measuredHeight2 + max2);
            return;
        }
        aev aevVar4 = (aev) view.getLayoutParams();
        ake akeVar3 = e;
        Rect rect4 = (Rect) akeVar3.a();
        if (rect4 == null) {
            rect4 = new Rect();
        }
        rect4.set(getPaddingLeft() + aevVar4.leftMargin, getPaddingTop() + aevVar4.topMargin, (getWidth() - getPaddingRight()) - aevVar4.rightMargin, (getHeight() - getPaddingBottom()) - aevVar4.bottomMargin);
        if (this.g != null) {
            int[] iArr = ame.a;
            if (getFitsSystemWindows() && !view.getFitsSystemWindows()) {
                rect4.left += this.g.b.c().b;
                rect4.top += this.g.b.c().c;
                rect4.right -= this.g.b.c().d;
                rect4.bottom -= this.g.b.c().e;
            }
        }
        Rect rect5 = (Rect) akeVar3.a();
        if (rect5 == null) {
            rect5 = new Rect();
        }
        Rect rect6 = rect5;
        Gravity.apply(n(aevVar4.c), view.getMeasuredWidth(), view.getMeasuredHeight(), rect4, rect6, i);
        view.layout(rect6.left, rect6.top, rect6.right, rect6.bottom);
        rect4.setEmpty();
        akeVar3.b(rect4);
        rect6.setEmpty();
        akeVar3.b(rect6);
    }

    public final void i(Drawable drawable) {
        boolean z;
        Drawable drawable2 = this.v;
        if (drawable2 != drawable) {
            Drawable drawable3 = null;
            if (drawable2 != null) {
                drawable2.setCallback(null);
            }
            if (drawable != null) {
                drawable3 = drawable.mutate();
            }
            this.v = drawable3;
            if (drawable3 != null) {
                if (drawable3.isStateful()) {
                    this.v.setState(getDrawableState());
                }
                this.v.setLayoutDirection(getLayoutDirection());
                Drawable drawable4 = this.v;
                if (getVisibility() == 0) {
                    z = true;
                } else {
                    z = false;
                }
                drawable4.setVisible(z, false);
                this.v.setCallback(this);
            }
            postInvalidateOnAnimation();
        }
    }

    public final void k(View view, int i, int i2, int i3) {
        measureChildWithMargins(view, i, i2, i3, 0);
    }

    @Override // android.view.ViewGroup, android.view.View
    public final void onAttachedToWindow() {
        super.onAttachedToWindow();
        p();
        if (this.u) {
            if (this.t == null) {
                this.t = new aew(this);
            }
            getViewTreeObserver().addOnPreDrawListener(this.t);
        }
        if (this.g == null) {
            int[] iArr = ame.a;
            if (getFitsSystemWindows()) {
                als.c(this);
            }
        }
        this.p = true;
    }

    @Override // android.view.ViewGroup, android.view.View
    public final void onDetachedFromWindow() {
        super.onDetachedFromWindow();
        p();
        if (this.u && this.t != null) {
            getViewTreeObserver().removeOnPreDrawListener(this.t);
        }
        View view = this.s;
        if (view != null) {
            g(view, 0);
        }
        this.p = false;
    }

    @Override // android.view.View
    public final void onDraw(Canvas canvas) {
        int i;
        super.onDraw(canvas);
        if (this.h && this.v != null) {
            anq anqVar = this.g;
            if (anqVar != null) {
                i = anqVar.b.c().c;
            } else {
                i = 0;
            }
            if (i > 0) {
                this.v.setBounds(0, 0, getWidth(), i);
                this.v.draw(canvas);
            }
        }
    }

    @Override // android.view.ViewGroup
    public final boolean onInterceptTouchEvent(MotionEvent motionEvent) {
        int actionMasked = motionEvent.getActionMasked();
        if (actionMasked == 0) {
            p();
            actionMasked = 0;
        }
        boolean t = t(motionEvent, 0);
        if (actionMasked == 1 || actionMasked == 3) {
            this.r = null;
            p();
        }
        return t;
    }

    @Override // android.view.ViewGroup, android.view.View
    protected final void onLayout(boolean z, int i, int i2, int i3, int i4) {
        aes aesVar;
        int layoutDirection = getLayoutDirection();
        int size = this.j.size();
        for (int i5 = 0; i5 < size; i5++) {
            View view = (View) this.j.get(i5);
            if (view.getVisibility() != 8 && ((aesVar = ((aev) view.getLayoutParams()).a) == null || !aesVar.d(this, view, layoutDirection))) {
                h(view, layoutDirection);
            }
        }
    }

    /* JADX WARN: Code restructure failed: missing block: B:212:0x03d2, code lost:
    
        if (r0.i(r30, r20, r7, r21, r24) == false) goto L209;
     */
    /* JADX WARN: Removed duplicated region for block: B:186:0x0302  */
    /* JADX WARN: Removed duplicated region for block: B:206:0x036d  */
    /* JADX WARN: Removed duplicated region for block: B:211:0x03b7  */
    /* JADX WARN: Removed duplicated region for block: B:217:0x03d5  */
    @Override // android.view.View
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct code enable 'Show inconsistent code' option in preferences
    */
    protected final void onMeasure(int r31, int r32) {
        /*
            Method dump skipped, instructions count: 1103
            To view this dump change 'Code comments level' option to 'DEBUG'
        */
        throw new UnsupportedOperationException("Method not decompiled: androidx.coordinatorlayout.widget.CoordinatorLayout.onMeasure(int, int):void");
    }

    @Override // android.view.ViewGroup, android.view.ViewParent
    public final boolean onNestedFling(View view, float f, float f2, boolean z) {
        int childCount = getChildCount();
        for (int i = 0; i < childCount; i++) {
            View childAt = getChildAt(i);
            if (childAt.getVisibility() != 8) {
                aev aevVar = (aev) childAt.getLayoutParams();
                if (aevVar.n) {
                    aes aesVar = aevVar.a;
                }
            }
        }
        return false;
    }

    @Override // android.view.ViewGroup, android.view.ViewParent
    public final boolean onNestedPreFling(View view, float f, float f2) {
        aes aesVar;
        int childCount = getChildCount();
        boolean z = false;
        for (int i = 0; i < childCount; i++) {
            View childAt = getChildAt(i);
            if (childAt.getVisibility() != 8) {
                aev aevVar = (aev) childAt.getLayoutParams();
                if (aevVar.n && (aesVar = aevVar.a) != null) {
                    z |= aesVar.j(view);
                }
            }
        }
        return z;
    }

    @Override // android.view.ViewGroup, android.view.ViewParent
    public final void onNestedPreScroll(View view, int i, int i2, int[] iArr) {
        c(view, i, i2, iArr, 0);
    }

    @Override // android.view.ViewGroup, android.view.ViewParent
    public final void onNestedScroll(View view, int i, int i2, int i3, int i4) {
        e(view, i, i2, i3, i4, 0, this.m);
    }

    @Override // android.view.ViewGroup, android.view.ViewParent
    public final void onNestedScrollAccepted(View view, View view2, int i) {
        f(view, view2, i, 0);
    }

    @Override // android.view.View
    protected final void onRestoreInstanceState(Parcelable parcelable) {
        Parcelable parcelable2;
        if (!(parcelable instanceof aey)) {
            super.onRestoreInstanceState(parcelable);
            return;
        }
        aey aeyVar = (aey) parcelable;
        super.onRestoreInstanceState(aeyVar.d);
        SparseArray sparseArray = aeyVar.a;
        int childCount = getChildCount();
        for (int i = 0; i < childCount; i++) {
            View childAt = getChildAt(i);
            int id = childAt.getId();
            aes aesVar = j(childAt).a;
            if (id != -1 && aesVar != null && (parcelable2 = (Parcelable) sparseArray.get(id)) != null) {
                aesVar.n(childAt, parcelable2);
            }
        }
    }

    @Override // android.view.View
    protected final Parcelable onSaveInstanceState() {
        Parcelable o;
        aey aeyVar = new aey(super.onSaveInstanceState());
        SparseArray sparseArray = new SparseArray();
        int childCount = getChildCount();
        for (int i = 0; i < childCount; i++) {
            View childAt = getChildAt(i);
            int id = childAt.getId();
            aes aesVar = ((aev) childAt.getLayoutParams()).a;
            if (id != -1 && aesVar != null && (o = aesVar.o(childAt)) != null) {
                sparseArray.append(id, o);
            }
        }
        aeyVar.a = sparseArray;
        return aeyVar;
    }

    @Override // android.view.ViewGroup, android.view.ViewParent
    public final boolean onStartNestedScroll(View view, View view2, int i) {
        return q(view, view2, i, 0);
    }

    @Override // android.view.ViewGroup, android.view.ViewParent
    public final void onStopNestedScroll(View view) {
        g(view, 0);
    }

    @Override // android.view.View
    public final boolean onTouchEvent(MotionEvent motionEvent) {
        boolean t;
        int actionMasked = motionEvent.getActionMasked();
        View view = this.r;
        boolean z = false;
        if (view != null) {
            aes aesVar = ((aev) view.getLayoutParams()).a;
            t = aesVar != null ? aesVar.e(this, this.r, motionEvent) : false;
        } else {
            t = t(motionEvent, 1);
            if (actionMasked != 0 && t) {
                z = true;
            }
        }
        if (this.r != null && actionMasked != 3) {
            if (z) {
                MotionEvent obtain = MotionEvent.obtain(motionEvent);
                obtain.setAction(3);
                super.onTouchEvent(obtain);
                obtain.recycle();
            }
        } else {
            t |= super.onTouchEvent(motionEvent);
        }
        if (actionMasked == 1 || actionMasked == 3) {
            this.r = null;
            p();
        }
        return t;
    }

    @Override // cal.ald
    public final boolean q(View view, View view2, int i, int i2) {
        int childCount = getChildCount();
        boolean z = false;
        for (int i3 = 0; i3 < childCount; i3++) {
            View childAt = getChildAt(i3);
            if (childAt.getVisibility() != 8) {
                aev aevVar = (aev) childAt.getLayoutParams();
                aes aesVar = aevVar.a;
                if (aesVar != null) {
                    boolean p = aesVar.p(childAt, i, i2);
                    z |= p;
                    if (i2 != 0) {
                        aevVar.o = p;
                    } else {
                        aevVar.n = p;
                    }
                } else if (i2 != 0) {
                    aevVar.o = false;
                } else {
                    aevVar.n = false;
                }
            }
        }
        return z;
    }

    @Override // android.view.ViewGroup, android.view.ViewParent
    public final boolean requestChildRectangleOnScreen(View view, Rect rect, boolean z) {
        aes aesVar = ((aev) view.getLayoutParams()).a;
        if (aesVar != null) {
            aesVar.m(this, view, rect);
        }
        return super.requestChildRectangleOnScreen(view, rect, z);
    }

    @Override // android.view.ViewGroup, android.view.ViewParent
    public final void requestDisallowInterceptTouchEvent(boolean z) {
        super.requestDisallowInterceptTouchEvent(z);
        if (z && !this.o) {
            if (this.r == null) {
                int childCount = getChildCount();
                MotionEvent motionEvent = null;
                for (int i = 0; i < childCount; i++) {
                    View childAt = getChildAt(i);
                    aes aesVar = ((aev) childAt.getLayoutParams()).a;
                    if (aesVar != null) {
                        if (motionEvent == null) {
                            long uptimeMillis = SystemClock.uptimeMillis();
                            motionEvent = MotionEvent.obtain(uptimeMillis, uptimeMillis, 3, 0.0f, 0.0f, 0);
                        }
                        aesVar.c(this, childAt, motionEvent);
                    }
                }
                if (motionEvent != null) {
                    motionEvent.recycle();
                }
            }
            p();
            this.o = true;
        }
    }

    @Override // android.view.View
    public final void setFitsSystemWindows(boolean z) {
        super.setFitsSystemWindows(z);
        r();
    }

    @Override // android.view.ViewGroup
    public final void setOnHierarchyChangeListener(ViewGroup.OnHierarchyChangeListener onHierarchyChangeListener) {
        this.i = onHierarchyChangeListener;
    }

    public void setStatusBarBackgroundColor(int i) {
        i(new ColorDrawable(i));
    }

    public void setStatusBarBackgroundResource(int i) {
        Drawable drawable;
        if (i != 0) {
            drawable = getContext().getDrawable(i);
        } else {
            drawable = null;
        }
        i(drawable);
    }

    @Override // android.view.View
    public void setVisibility(int i) {
        boolean z;
        super.setVisibility(i);
        Drawable drawable = this.v;
        if (drawable != null) {
            if (i == 0) {
                z = true;
            } else {
                z = false;
            }
            if (drawable.isVisible() != z) {
                this.v.setVisible(z, false);
            }
        }
    }

    @Override // android.view.View
    protected final boolean verifyDrawable(Drawable drawable) {
        if (!super.verifyDrawable(drawable) && drawable != this.v) {
            return false;
        }
        return true;
    }

    public CoordinatorLayout(Context context, AttributeSet attributeSet) {
        this(context, attributeSet, R.attr.coordinatorLayoutStyle);
    }

    @Override // android.view.ViewGroup
    protected final /* bridge */ /* synthetic */ ViewGroup.LayoutParams generateLayoutParams(ViewGroup.LayoutParams layoutParams) {
        if (layoutParams instanceof aev) {
            return new aev((aev) layoutParams);
        }
        if (layoutParams instanceof ViewGroup.MarginLayoutParams) {
            return new aev((ViewGroup.MarginLayoutParams) layoutParams);
        }
        return new aev(layoutParams);
    }

    public CoordinatorLayout(Context context, AttributeSet attributeSet, int i) {
        super(context, attributeSet, i);
        TypedArray obtainStyledAttributes;
        this.j = new ArrayList();
        this.f = new afa();
        this.k = new ArrayList();
        this.l = new int[2];
        this.m = new int[2];
        this.n = new int[2];
        this.x = new alf();
        if (i == 0) {
            obtainStyledAttributes = context.obtainStyledAttributes(attributeSet, aep.a, 0, R.style.Widget_Support_CoordinatorLayout);
        } else {
            obtainStyledAttributes = context.obtainStyledAttributes(attributeSet, aep.a, i, 0);
        }
        if (i == 0) {
            int i2 = Build.VERSION.SDK_INT;
            int[] iArr = aep.a;
            if (i2 >= 29) {
                alz.b(this, context, iArr, attributeSet, obtainStyledAttributes, 0, R.style.Widget_Support_CoordinatorLayout);
            }
        } else {
            int i3 = Build.VERSION.SDK_INT;
            int[] iArr2 = aep.a;
            if (i3 >= 29) {
                alz.b(this, context, iArr2, attributeSet, obtainStyledAttributes, i, 0);
            }
        }
        int resourceId = obtainStyledAttributes.getResourceId(0, 0);
        if (resourceId != 0) {
            Resources resources = context.getResources();
            this.q = resources.getIntArray(resourceId);
            float f = resources.getDisplayMetrics().density;
            int length = this.q.length;
            for (int i4 = 0; i4 < length; i4++) {
                this.q[i4] = (int) (r12[i4] * f);
            }
        }
        this.v = obtainStyledAttributes.getDrawable(1);
        obtainStyledAttributes.recycle();
        r();
        super.setOnHierarchyChangeListener(new aeu(this));
        if (getImportantForAccessibility() == 0) {
            setImportantForAccessibility(1);
        }
    }
}
