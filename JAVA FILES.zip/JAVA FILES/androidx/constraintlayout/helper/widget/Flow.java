package androidx.constraintlayout.helper.widget;

import android.content.Context;
import android.content.res.TypedArray;
import android.util.AttributeSet;
import android.view.View;
import cal.acu;
import cal.acx;
import cal.adb;
import cal.aen;
import cal.aeo;

/* compiled from: PG */
/* loaded from: classes.dex */
public class Flow extends aeo {
    private acx a;

    public Flow(Context context) {
        super(context);
    }

    /* JADX INFO: Access modifiers changed from: protected */
    @Override // cal.aeo, cal.adw
    public final void a(AttributeSet attributeSet) {
        super.a(attributeSet);
        this.a = new acx();
        if (attributeSet != null) {
            TypedArray obtainStyledAttributes = getContext().obtainStyledAttributes(attributeSet, aen.b);
            int indexCount = obtainStyledAttributes.getIndexCount();
            for (int i = 0; i < indexCount; i++) {
                int index = obtainStyledAttributes.getIndex(i);
                if (index == 0) {
                    this.a.aG = obtainStyledAttributes.getInt(0, 0);
                } else if (index == 1) {
                    acx acxVar = this.a;
                    int dimensionPixelSize = obtainStyledAttributes.getDimensionPixelSize(1, 0);
                    acxVar.aL = dimensionPixelSize;
                    acxVar.aM = dimensionPixelSize;
                    acxVar.aN = dimensionPixelSize;
                    acxVar.aO = dimensionPixelSize;
                } else if (index == 18) {
                    acx acxVar2 = this.a;
                    int dimensionPixelSize2 = obtainStyledAttributes.getDimensionPixelSize(18, 0);
                    acxVar2.aN = dimensionPixelSize2;
                    acxVar2.aP = dimensionPixelSize2;
                    acxVar2.aQ = dimensionPixelSize2;
                } else if (index == 19) {
                    this.a.aO = obtainStyledAttributes.getDimensionPixelSize(19, 0);
                } else if (index == 2) {
                    this.a.aP = obtainStyledAttributes.getDimensionPixelSize(2, 0);
                } else if (index == 3) {
                    this.a.aL = obtainStyledAttributes.getDimensionPixelSize(3, 0);
                } else if (index == 4) {
                    this.a.aQ = obtainStyledAttributes.getDimensionPixelSize(4, 0);
                } else if (index == 5) {
                    this.a.aM = obtainStyledAttributes.getDimensionPixelSize(5, 0);
                } else if (index == 54) {
                    this.a.aE = obtainStyledAttributes.getInt(54, 0);
                } else if (index == 44) {
                    this.a.a = obtainStyledAttributes.getInt(44, 0);
                } else if (index == 53) {
                    this.a.b = obtainStyledAttributes.getInt(53, 0);
                } else if (index == 38) {
                    this.a.c = obtainStyledAttributes.getInt(38, 0);
                } else if (index == 46) {
                    this.a.as = obtainStyledAttributes.getInt(46, 0);
                } else if (index == 40) {
                    this.a.d = obtainStyledAttributes.getInt(40, 0);
                } else if (index == 48) {
                    this.a.at = obtainStyledAttributes.getInt(48, 0);
                } else if (index == 42) {
                    this.a.au = obtainStyledAttributes.getFloat(42, 0.5f);
                } else if (index == 37) {
                    this.a.aw = obtainStyledAttributes.getFloat(37, 0.5f);
                } else if (index == 45) {
                    this.a.ay = obtainStyledAttributes.getFloat(45, 0.5f);
                } else if (index == 39) {
                    this.a.ax = obtainStyledAttributes.getFloat(39, 0.5f);
                } else if (index == 47) {
                    this.a.az = obtainStyledAttributes.getFloat(47, 0.5f);
                } else if (index == 51) {
                    this.a.av = obtainStyledAttributes.getFloat(51, 0.5f);
                } else if (index == 41) {
                    this.a.aC = obtainStyledAttributes.getInt(41, 2);
                } else if (index == 50) {
                    this.a.aD = obtainStyledAttributes.getInt(50, 2);
                } else if (index == 43) {
                    this.a.aA = obtainStyledAttributes.getDimensionPixelSize(43, 0);
                } else if (index == 52) {
                    this.a.aB = obtainStyledAttributes.getDimensionPixelSize(52, 0);
                } else if (index == 49) {
                    this.a.aF = obtainStyledAttributes.getInt(49, -1);
                }
            }
            obtainStyledAttributes.recycle();
        }
        this.i = this.a;
        j();
    }

    @Override // cal.aeo
    public final void b(adb adbVar, int i, int i2) {
        int mode = View.MeasureSpec.getMode(i);
        int size = View.MeasureSpec.getSize(i);
        int mode2 = View.MeasureSpec.getMode(i2);
        int size2 = View.MeasureSpec.getSize(i2);
        if (adbVar != null) {
            adbVar.z(mode, size, mode2, size2);
            setMeasuredDimension(adbVar.aS, adbVar.aT);
        } else {
            setMeasuredDimension(0, 0);
        }
    }

    @Override // cal.adw
    public final void c(acu acuVar, boolean z) {
        acx acxVar = this.a;
        int i = acxVar.aN;
        if (i <= 0 && acxVar.aO <= 0) {
            return;
        }
        if (z) {
            acxVar.aP = acxVar.aO;
            acxVar.aQ = i;
        } else {
            acxVar.aP = i;
            acxVar.aQ = acxVar.aO;
        }
    }

    @Override // cal.adw, android.view.View
    protected final void onMeasure(int i, int i2) {
        b(this.a, i, i2);
    }

    public void setFirstHorizontalBias(float f) {
        this.a.aw = f;
        requestLayout();
    }

    public void setFirstHorizontalStyle(int i) {
        this.a.c = i;
        requestLayout();
    }

    public void setFirstVerticalBias(float f) {
        this.a.ax = f;
        requestLayout();
    }

    public void setFirstVerticalStyle(int i) {
        this.a.d = i;
        requestLayout();
    }

    public void setHorizontalAlign(int i) {
        this.a.aC = i;
        requestLayout();
    }

    public void setHorizontalBias(float f) {
        this.a.au = f;
        requestLayout();
    }

    public void setHorizontalGap(int i) {
        this.a.aA = i;
        requestLayout();
    }

    public void setHorizontalStyle(int i) {
        this.a.a = i;
        requestLayout();
    }

    public void setLastHorizontalBias(float f) {
        this.a.ay = f;
        requestLayout();
    }

    public void setLastHorizontalStyle(int i) {
        this.a.as = i;
        requestLayout();
    }

    public void setLastVerticalBias(float f) {
        this.a.az = f;
        requestLayout();
    }

    public void setLastVerticalStyle(int i) {
        this.a.at = i;
        requestLayout();
    }

    public void setMaxElementsWrap(int i) {
        this.a.aF = i;
        requestLayout();
    }

    public void setOrientation(int i) {
        this.a.aG = i;
        requestLayout();
    }

    public void setPadding(int i) {
        acx acxVar = this.a;
        acxVar.aL = i;
        acxVar.aM = i;
        acxVar.aN = i;
        acxVar.aO = i;
        requestLayout();
    }

    public void setPaddingBottom(int i) {
        this.a.aM = i;
        requestLayout();
    }

    public void setPaddingLeft(int i) {
        this.a.aP = i;
        requestLayout();
    }

    public void setPaddingRight(int i) {
        this.a.aQ = i;
        requestLayout();
    }

    public void setPaddingTop(int i) {
        this.a.aL = i;
        requestLayout();
    }

    public void setVerticalAlign(int i) {
        this.a.aD = i;
        requestLayout();
    }

    public void setVerticalBias(float f) {
        this.a.av = f;
        requestLayout();
    }

    public void setVerticalGap(int i) {
        this.a.aB = i;
        requestLayout();
    }

    public void setVerticalStyle(int i) {
        this.a.b = i;
        requestLayout();
    }

    public void setWrapMode(int i) {
        this.a.aE = i;
        requestLayout();
    }

    public Flow(Context context, AttributeSet attributeSet) {
        super(context, attributeSet);
    }

    public Flow(Context context, AttributeSet attributeSet, int i) {
        super(context, attributeSet, i);
    }
}
