package androidx.constraintlayout.widget;

import android.content.Context;
import android.graphics.Canvas;
import android.util.AttributeSet;
import android.view.View;
import cal.ady;

/* compiled from: PG */
/* loaded from: classes.dex */
public class Guideline extends View {
    private final boolean a;

    public Guideline(Context context) {
        super(context);
        this.a = true;
        super.setVisibility(8);
    }

    @Override // android.view.View
    protected final void onMeasure(int i, int i2) {
        setMeasuredDimension(0, 0);
    }

    public void setGuidelineBegin(int i) {
        ady adyVar = (ady) getLayoutParams();
        if (this.a && adyVar.a == i) {
            return;
        }
        adyVar.a = i;
        setLayoutParams(adyVar);
    }

    public void setGuidelineEnd(int i) {
        ady adyVar = (ady) getLayoutParams();
        if (this.a && adyVar.b == i) {
            return;
        }
        adyVar.b = i;
        setLayoutParams(adyVar);
    }

    public void setGuidelinePercent(float f) {
        ady adyVar = (ady) getLayoutParams();
        if (this.a && adyVar.c == f) {
            return;
        }
        adyVar.c = f;
        setLayoutParams(adyVar);
    }

    public Guideline(Context context, AttributeSet attributeSet) {
        super(context, attributeSet);
        this.a = true;
        super.setVisibility(8);
    }

    public Guideline(Context context, AttributeSet attributeSet, int i) {
        super(context, attributeSet, i);
        this.a = true;
        super.setVisibility(8);
    }

    public Guideline(Context context, AttributeSet attributeSet, int i, int i2) {
        super(context, attributeSet, i);
        this.a = true;
        super.setVisibility(8);
    }

    @Override // android.view.View
    public final void draw(Canvas canvas) {
    }

    @Override // android.view.View
    public void setVisibility(int i) {
    }
}
