package androidx.constraintlayout.widget;

import android.content.Context;
import android.content.res.Resources;
import android.content.res.TypedArray;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.util.AttributeSet;
import android.util.SparseArray;
import android.view.View;
import android.view.ViewGroup;
import cal.acj;
import cal.acu;
import cal.acv;
import cal.acy;
import cal.adw;
import cal.ady;
import cal.adz;
import cal.aec;
import cal.aej;
import cal.ael;
import cal.aen;
import java.util.ArrayList;
import java.util.HashMap;

/* compiled from: PG */
/* loaded from: classes.dex */
public class ConstraintLayout extends ViewGroup {
    public final SparseArray a;
    public final ArrayList b;
    protected final acv c;
    protected boolean d;
    public int e;
    public aej f;
    final adz g;
    private int h;
    private int i;
    private int j;
    private int k;
    private int l;
    private HashMap m;
    private final SparseArray n;

    public ConstraintLayout(Context context) {
        super(context);
        this.a = new SparseArray();
        this.b = new ArrayList(4);
        this.c = new acv();
        this.h = 0;
        this.i = 0;
        this.j = Integer.MAX_VALUE;
        this.k = Integer.MAX_VALUE;
        this.d = true;
        this.e = 257;
        this.f = null;
        this.l = -1;
        this.m = new HashMap();
        this.n = new SparseArray();
        this.g = new adz(this, this);
        c(null, 0, 0);
    }

    private final void c(AttributeSet attributeSet, int i, int i2) {
        acv acvVar = this.c;
        acvVar.ah = this;
        adz adzVar = this.g;
        acvVar.aI = adzVar;
        acvVar.b.g = adzVar;
        this.a.put(getId(), this);
        this.f = null;
        boolean z = false;
        if (attributeSet != null) {
            TypedArray obtainStyledAttributes = getContext().obtainStyledAttributes(attributeSet, aen.b, i, i2);
            int indexCount = obtainStyledAttributes.getIndexCount();
            for (int i3 = 0; i3 < indexCount; i3++) {
                int index = obtainStyledAttributes.getIndex(i3);
                if (index == 16) {
                    this.h = obtainStyledAttributes.getDimensionPixelOffset(16, this.h);
                } else if (index == 17) {
                    this.i = obtainStyledAttributes.getDimensionPixelOffset(17, this.i);
                } else if (index == 14) {
                    this.j = obtainStyledAttributes.getDimensionPixelOffset(14, this.j);
                } else if (index == 15) {
                    this.k = obtainStyledAttributes.getDimensionPixelOffset(15, this.k);
                } else if (index == 113) {
                    this.e = obtainStyledAttributes.getInt(113, this.e);
                } else if (index == 56) {
                    int resourceId = obtainStyledAttributes.getResourceId(56, 0);
                    if (resourceId != 0) {
                        try {
                            aec.a(getContext(), resourceId, new SparseArray(), new SparseArray());
                        } catch (Resources.NotFoundException unused) {
                        }
                    }
                } else if (index == 34) {
                    int resourceId2 = obtainStyledAttributes.getResourceId(34, 0);
                    try {
                        aej aejVar = new aej();
                        this.f = aejVar;
                        aejVar.c(getContext(), resourceId2);
                    } catch (Resources.NotFoundException unused2) {
                        this.f = null;
                    }
                    this.l = resourceId2;
                }
            }
            obtainStyledAttributes.recycle();
        }
        acv acvVar2 = this.c;
        int i4 = this.e;
        acvVar2.az = i4;
        if ((i4 & 512) == 512) {
            z = true;
        }
        acj.a = z;
    }

    /* JADX WARN: Removed duplicated region for block: B:271:0x02a0  */
    /* JADX WARN: Removed duplicated region for block: B:276:0x02d3  */
    /* JADX WARN: Removed duplicated region for block: B:281:0x0311  */
    /* JADX WARN: Removed duplicated region for block: B:286:0x034f  */
    /* JADX WARN: Removed duplicated region for block: B:290:0x0377  */
    /* JADX WARN: Removed duplicated region for block: B:293:0x037f  */
    /* JADX WARN: Removed duplicated region for block: B:294:0x0359  */
    /* JADX WARN: Removed duplicated region for block: B:300:0x032c  */
    /* JADX WARN: Removed duplicated region for block: B:305:0x02ed  */
    /* JADX WARN: Removed duplicated region for block: B:310:0x02b7  */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct code enable 'Show inconsistent code' option in preferences
    */
    private final void d() {
        /*
            Method dump skipped, instructions count: 1356
            To view this dump change 'Code comments level' option to 'DEBUG'
        */
        throw new UnsupportedOperationException("Method not decompiled: androidx.constraintlayout.widget.ConstraintLayout.d():void");
    }

    private final void e(acu acuVar, ady adyVar, SparseArray sparseArray, int i, int i2) {
        View view = (View) this.a.get(i);
        acu acuVar2 = (acu) sparseArray.get(i);
        if (acuVar2 != null && view != null && (view.getLayoutParams() instanceof ady)) {
            adyVar.ag = true;
            if (i2 == 6) {
                ady adyVar2 = (ady) view.getLayoutParams();
                adyVar2.ag = true;
                adyVar2.av.G = true;
            }
            acuVar.v(6).g(acuVar2.v(i2), adyVar.D, adyVar.C, true);
            acuVar.G = true;
            acuVar.v(3).d();
            acuVar.v(5).d();
        }
    }

    public final acu a(View view) {
        if (view == this) {
            return this.c;
        }
        if (view != null) {
            if (view.getLayoutParams() instanceof ady) {
                return ((ady) view.getLayoutParams()).av;
            }
            view.setLayoutParams(new ady(view.getLayoutParams()));
            if (view.getLayoutParams() instanceof ady) {
                return ((ady) view.getLayoutParams()).av;
            }
            return null;
        }
        return null;
    }

    public final Object cW(Object obj) {
        HashMap hashMap;
        if ((obj instanceof String) && (hashMap = this.m) != null && hashMap.containsKey(obj)) {
            return this.m.get(obj);
        }
        return null;
    }

    @Override // android.view.ViewGroup
    protected final boolean checkLayoutParams(ViewGroup.LayoutParams layoutParams) {
        return layoutParams instanceof ady;
    }

    @Override // android.view.ViewGroup, android.view.View
    protected final void dispatchDraw(Canvas canvas) {
        Object tag;
        int size;
        ArrayList arrayList = this.b;
        if (arrayList != null && (size = arrayList.size()) > 0) {
            for (int i = 0; i < size; i++) {
            }
        }
        super.dispatchDraw(canvas);
        if (isInEditMode()) {
            float width = getWidth();
            float height = getHeight();
            int childCount = getChildCount();
            for (int i2 = 0; i2 < childCount; i2++) {
                View childAt = getChildAt(i2);
                if (childAt.getVisibility() != 8 && (tag = childAt.getTag()) != null && (tag instanceof String)) {
                    String[] split = ((String) tag).split(",");
                    if (split.length == 4) {
                        int parseInt = Integer.parseInt(split[0]);
                        int parseInt2 = Integer.parseInt(split[1]);
                        int parseInt3 = Integer.parseInt(split[2]);
                        Paint paint = new Paint();
                        paint.setColor(-65536);
                        int i3 = (int) ((parseInt2 / 1920.0f) * height);
                        int i4 = (int) ((parseInt / 1080.0f) * width);
                        float f = ((int) ((parseInt3 / 1080.0f) * width)) + i4;
                        float f2 = i4;
                        float f3 = i3;
                        canvas.drawLine(f2, f3, f, f3, paint);
                        float parseInt4 = i3 + ((int) ((Integer.parseInt(split[3]) / 1920.0f) * height));
                        canvas.drawLine(f, f3, f, parseInt4, paint);
                        canvas.drawLine(f, parseInt4, f2, parseInt4, paint);
                        canvas.drawLine(f2, parseInt4, f2, f3, paint);
                        paint.setColor(-16711936);
                        canvas.drawLine(f2, f3, f, parseInt4, paint);
                        canvas.drawLine(f2, parseInt4, f, f3, paint);
                    }
                }
            }
        }
    }

    @Override // android.view.View
    public final void forceLayout() {
        this.d = true;
        super.forceLayout();
    }

    @Override // android.view.ViewGroup
    protected final /* synthetic */ ViewGroup.LayoutParams generateDefaultLayoutParams() {
        return new ady();
    }

    @Override // android.view.ViewGroup
    public final /* synthetic */ ViewGroup.LayoutParams generateLayoutParams(AttributeSet attributeSet) {
        return new ady(getContext(), attributeSet);
    }

    /* JADX INFO: Access modifiers changed from: protected */
    @Override // android.view.ViewGroup, android.view.View
    public void onLayout(boolean z, int i, int i2, int i3, int i4) {
        int i5;
        int i6;
        int i7;
        int i8;
        int childCount = getChildCount();
        boolean isInEditMode = isInEditMode();
        for (int i9 = 0; i9 < childCount; i9++) {
            View childAt = getChildAt(i9);
            ady adyVar = (ady) childAt.getLayoutParams();
            acu acuVar = adyVar.av;
            if (childAt.getVisibility() == 8 && !adyVar.ah && !adyVar.ai) {
                boolean z2 = adyVar.ak;
                if (!isInEditMode) {
                    continue;
                }
            }
            boolean z3 = adyVar.aj;
            acu acuVar2 = acuVar.V;
            if (acuVar2 != null) {
                i5 = ((acv) acuVar2).at + acuVar.aa;
            } else {
                i5 = acuVar.aa;
            }
            if (acuVar2 != null) {
                i6 = ((acv) acuVar2).au + acuVar.ab;
            } else {
                i6 = acuVar.ab;
            }
            int i10 = acuVar.ai;
            if (i10 == 8) {
                i7 = 0;
            } else {
                i7 = acuVar.W;
            }
            int i11 = i7 + i5;
            if (i10 == 8) {
                i8 = 0;
            } else {
                i8 = acuVar.X;
            }
            childAt.layout(i5, i6, i11, i8 + i6);
            if (childAt instanceof ael) {
                throw null;
            }
        }
        int size = this.b.size();
        if (size > 0) {
            for (int i12 = 0; i12 < size; i12++) {
            }
        }
    }

    /* JADX INFO: Access modifiers changed from: protected */
    /* JADX WARN: Removed duplicated region for block: B:113:0x024b  */
    /* JADX WARN: Removed duplicated region for block: B:117:0x025c  */
    /* JADX WARN: Removed duplicated region for block: B:120:0x0262  */
    /* JADX WARN: Removed duplicated region for block: B:201:0x0448  */
    /* JADX WARN: Removed duplicated region for block: B:212:0x046f  */
    /* JADX WARN: Removed duplicated region for block: B:228:0x0574  */
    /* JADX WARN: Removed duplicated region for block: B:233:0x08ca  */
    /* JADX WARN: Removed duplicated region for block: B:235:0x08d0  */
    /* JADX WARN: Removed duplicated region for block: B:238:0x0902  */
    /* JADX WARN: Removed duplicated region for block: B:240:0x0905  */
    /* JADX WARN: Removed duplicated region for block: B:244:0x08d2  */
    /* JADX WARN: Removed duplicated region for block: B:245:0x08cc  */
    /* JADX WARN: Removed duplicated region for block: B:248:0x0580  */
    /* JADX WARN: Removed duplicated region for block: B:278:0x05df  */
    /* JADX WARN: Removed duplicated region for block: B:331:0x066d  */
    /* JADX WARN: Removed duplicated region for block: B:333:0x0675  */
    /* JADX WARN: Removed duplicated region for block: B:41:0x013a  */
    /* JADX WARN: Removed duplicated region for block: B:47:0x016f  */
    /* JADX WARN: Removed duplicated region for block: B:496:0x08bb  */
    /* JADX WARN: Removed duplicated region for block: B:498:0x08bd  */
    /* JADX WARN: Removed duplicated region for block: B:499:0x0672  */
    /* JADX WARN: Removed duplicated region for block: B:49:0x0175  */
    /* JADX WARN: Removed duplicated region for block: B:518:0x03fa  */
    /* JADX WARN: Removed duplicated region for block: B:526:0x0425  */
    /* JADX WARN: Removed duplicated region for block: B:528:0x0427  */
    /* JADX WARN: Removed duplicated region for block: B:529:0x03fc  */
    /* JADX WARN: Removed duplicated region for block: B:562:0x056e  */
    /* JADX WARN: Removed duplicated region for block: B:563:0x025e  */
    /* JADX WARN: Removed duplicated region for block: B:565:0x0258  */
    /* JADX WARN: Removed duplicated region for block: B:567:0x01ea  */
    /* JADX WARN: Removed duplicated region for block: B:568:0x01e0  */
    /* JADX WARN: Removed duplicated region for block: B:569:0x01d9  */
    /* JADX WARN: Removed duplicated region for block: B:56:0x01ac  */
    /* JADX WARN: Removed duplicated region for block: B:572:0x0171  */
    /* JADX WARN: Removed duplicated region for block: B:578:0x015b  */
    /* JADX WARN: Removed duplicated region for block: B:59:0x01b4  */
    /* JADX WARN: Removed duplicated region for block: B:62:0x01bb  */
    /* JADX WARN: Removed duplicated region for block: B:65:0x01c2  */
    /* JADX WARN: Removed duplicated region for block: B:68:0x01d6  */
    /* JADX WARN: Removed duplicated region for block: B:70:0x01de  */
    /* JADX WARN: Removed duplicated region for block: B:73:0x01e8  */
    /* JADX WARN: Removed duplicated region for block: B:76:0x01ef  */
    /* JADX WARN: Removed duplicated region for block: B:81:0x01fa  */
    @Override // android.view.View
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct code enable 'Show inconsistent code' option in preferences
    */
    public void onMeasure(int r27, int r28) {
        /*
            Method dump skipped, instructions count: 2314
            To view this dump change 'Code comments level' option to 'DEBUG'
        */
        throw new UnsupportedOperationException("Method not decompiled: androidx.constraintlayout.widget.ConstraintLayout.onMeasure(int, int):void");
    }

    @Override // android.view.ViewGroup
    public final void onViewAdded(View view) {
        super.onViewAdded(view);
        boolean z = view instanceof Guideline;
        acu a = a(view);
        if (z && !(a instanceof acy)) {
            ady adyVar = (ady) view.getLayoutParams();
            adyVar.av = new acy();
            adyVar.ah = true;
            ((acy) adyVar.av).b(adyVar.Z);
        }
        if (view instanceof adw) {
            adw adwVar = (adw) view;
            adwVar.j();
            ((ady) view.getLayoutParams()).ai = true;
            if (!this.b.contains(adwVar)) {
                this.b.add(adwVar);
            }
        }
        this.a.put(view.getId(), view);
        this.d = true;
    }

    @Override // android.view.ViewGroup
    public void onViewRemoved(View view) {
        super.onViewRemoved(view);
        this.a.remove(view.getId());
        acu a = a(view);
        this.c.aJ.remove(a);
        a.k();
        this.b.remove(view);
        this.d = true;
    }

    @Override // android.view.View, android.view.ViewParent
    public final void requestLayout() {
        this.d = true;
        super.requestLayout();
    }

    @Override // android.view.View
    public void setId(int i) {
        this.a.remove(getId());
        super.setId(i);
        this.a.put(getId(), this);
    }

    public void setMaxHeight(int i) {
        if (i == this.k) {
            return;
        }
        this.k = i;
        this.d = true;
        super.requestLayout();
    }

    public void setMaxWidth(int i) {
        if (i == this.j) {
            return;
        }
        this.j = i;
        this.d = true;
        super.requestLayout();
    }

    public void setMinHeight(int i) {
        if (i == this.i) {
            return;
        }
        this.i = i;
        this.d = true;
        super.requestLayout();
    }

    public void setMinWidth(int i) {
        if (i == this.h) {
            return;
        }
        this.h = i;
        this.d = true;
        super.requestLayout();
    }

    public void setOptimizationLevel(int i) {
        boolean z;
        this.e = i;
        this.c.az = i;
        if ((i & 512) == 512) {
            z = true;
        } else {
            z = false;
        }
        acj.a = z;
    }

    @Override // android.view.ViewGroup
    public final boolean shouldDelayChildPressedState() {
        return false;
    }

    @Override // android.view.ViewGroup
    protected final ViewGroup.LayoutParams generateLayoutParams(ViewGroup.LayoutParams layoutParams) {
        return new ady(layoutParams);
    }

    public ConstraintLayout(Context context, AttributeSet attributeSet) {
        super(context, attributeSet);
        this.a = new SparseArray();
        this.b = new ArrayList(4);
        this.c = new acv();
        this.h = 0;
        this.i = 0;
        this.j = Integer.MAX_VALUE;
        this.k = Integer.MAX_VALUE;
        this.d = true;
        this.e = 257;
        this.f = null;
        this.l = -1;
        this.m = new HashMap();
        this.n = new SparseArray();
        this.g = new adz(this, this);
        c(attributeSet, 0, 0);
    }

    public ConstraintLayout(Context context, AttributeSet attributeSet, int i) {
        super(context, attributeSet, i);
        this.a = new SparseArray();
        this.b = new ArrayList(4);
        this.c = new acv();
        this.h = 0;
        this.i = 0;
        this.j = Integer.MAX_VALUE;
        this.k = Integer.MAX_VALUE;
        this.d = true;
        this.e = 257;
        this.f = null;
        this.l = -1;
        this.m = new HashMap();
        this.n = new SparseArray();
        this.g = new adz(this, this);
        c(attributeSet, i, 0);
    }

    public ConstraintLayout(Context context, AttributeSet attributeSet, int i, int i2) {
        super(context, attributeSet, i, i2);
        this.a = new SparseArray();
        this.b = new ArrayList(4);
        this.c = new acv();
        this.h = 0;
        this.i = 0;
        this.j = Integer.MAX_VALUE;
        this.k = Integer.MAX_VALUE;
        this.d = true;
        this.e = 257;
        this.f = null;
        this.l = -1;
        this.m = new HashMap();
        this.n = new SparseArray();
        this.g = new adz(this, this);
        c(attributeSet, i, i2);
    }
}
