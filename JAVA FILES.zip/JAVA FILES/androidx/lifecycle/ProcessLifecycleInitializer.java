package androidx.lifecycle;

import android.content.Context;
import cal.auu;
import cal.bid;
import java.util.Collections;
import java.util.List;

/* compiled from: PG */
/* loaded from: classes.dex */
public final class ProcessLifecycleInitializer implements bid<auu> {
    @Override // cal.bid
    public final /* synthetic */ Object a(Context context) {
        throw new UnsupportedOperationException("Cannot use ProcessLifecycleInitializer. Use ProcessLifecycleOwnerInitializer instead.");
    }

    @Override // cal.bid
    public final List b() {
        return Collections.emptyList();
    }
}
