package androidx.sqlite.db.framework;

/* compiled from: PG */
/* loaded from: classes.dex */
public final class FrameworkSQLiteOpenHelper$OpenHelper$CallbackException extends RuntimeException {
    public final Throwable a;
    public final int b;

    public FrameworkSQLiteOpenHelper$OpenHelper$CallbackException(int i, Throwable th) {
        super(th);
        this.b = i;
        this.a = th;
    }

    @Override // java.lang.Throwable
    public final Throwable getCause() {
        return this.a;
    }
}
