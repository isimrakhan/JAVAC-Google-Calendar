package androidx.media;

/* compiled from: PG */
/* loaded from: classes.dex */
public class AudioAttributesImplApi26 extends AudioAttributesImplApi21 {
}
