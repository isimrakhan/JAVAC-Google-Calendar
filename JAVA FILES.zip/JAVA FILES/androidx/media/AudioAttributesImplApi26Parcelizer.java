package androidx.media;

import android.media.AudioAttributes;
import android.os.Parcelable;
import cal.blw;

/* compiled from: PG */
/* loaded from: classes.dex */
public class AudioAttributesImplApi26Parcelizer {
    public static AudioAttributesImplApi26 read(blw blwVar) {
        AudioAttributesImplApi26 audioAttributesImplApi26 = new AudioAttributesImplApi26();
        Parcelable parcelable = audioAttributesImplApi26.a;
        if (blwVar.r(1)) {
            parcelable = blwVar.b();
        }
        audioAttributesImplApi26.a = (AudioAttributes) parcelable;
        int i = audioAttributesImplApi26.b;
        if (blwVar.r(2)) {
            i = blwVar.a();
        }
        audioAttributesImplApi26.b = i;
        return audioAttributesImplApi26;
    }

    public static void write(AudioAttributesImplApi26 audioAttributesImplApi26, blw blwVar) {
        AudioAttributes audioAttributes = audioAttributesImplApi26.a;
        blwVar.h(1);
        blwVar.m(audioAttributes);
        int i = audioAttributesImplApi26.b;
        blwVar.h(2);
        blwVar.l(i);
    }
}
