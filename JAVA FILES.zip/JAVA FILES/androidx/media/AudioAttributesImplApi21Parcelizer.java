package androidx.media;

import android.media.AudioAttributes;
import android.os.Parcelable;
import cal.blw;

/* compiled from: PG */
/* loaded from: classes.dex */
public class AudioAttributesImplApi21Parcelizer {
    public static AudioAttributesImplApi21 read(blw blwVar) {
        AudioAttributesImplApi21 audioAttributesImplApi21 = new AudioAttributesImplApi21();
        Parcelable parcelable = audioAttributesImplApi21.a;
        if (blwVar.r(1)) {
            parcelable = blwVar.b();
        }
        audioAttributesImplApi21.a = (AudioAttributes) parcelable;
        int i = audioAttributesImplApi21.b;
        if (blwVar.r(2)) {
            i = blwVar.a();
        }
        audioAttributesImplApi21.b = i;
        return audioAttributesImplApi21;
    }

    public static void write(AudioAttributesImplApi21 audioAttributesImplApi21, blw blwVar) {
        AudioAttributes audioAttributes = audioAttributesImplApi21.a;
        blwVar.h(1);
        blwVar.m(audioAttributes);
        int i = audioAttributesImplApi21.b;
        blwVar.h(2);
        blwVar.l(i);
    }
}
