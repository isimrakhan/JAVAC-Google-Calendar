package androidx.media;

import cal.bly;

/* compiled from: PG */
/* loaded from: classes.dex */
public interface AudioAttributesImpl extends bly {
}
