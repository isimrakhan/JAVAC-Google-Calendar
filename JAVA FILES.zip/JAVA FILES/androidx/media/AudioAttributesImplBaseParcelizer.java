package androidx.media;

import cal.blw;

/* compiled from: PG */
/* loaded from: classes.dex */
public class AudioAttributesImplBaseParcelizer {
    public static AudioAttributesImplBase read(blw blwVar) {
        AudioAttributesImplBase audioAttributesImplBase = new AudioAttributesImplBase();
        int i = audioAttributesImplBase.a;
        if (blwVar.r(1)) {
            i = blwVar.a();
        }
        audioAttributesImplBase.a = i;
        int i2 = audioAttributesImplBase.b;
        if (blwVar.r(2)) {
            i2 = blwVar.a();
        }
        audioAttributesImplBase.b = i2;
        int i3 = audioAttributesImplBase.c;
        if (blwVar.r(3)) {
            i3 = blwVar.a();
        }
        audioAttributesImplBase.c = i3;
        int i4 = audioAttributesImplBase.d;
        if (blwVar.r(4)) {
            i4 = blwVar.a();
        }
        audioAttributesImplBase.d = i4;
        return audioAttributesImplBase;
    }

    public static void write(AudioAttributesImplBase audioAttributesImplBase, blw blwVar) {
        int i = audioAttributesImplBase.a;
        blwVar.h(1);
        blwVar.l(i);
        int i2 = audioAttributesImplBase.b;
        blwVar.h(2);
        blwVar.l(i2);
        int i3 = audioAttributesImplBase.c;
        blwVar.h(3);
        blwVar.l(i3);
        int i4 = audioAttributesImplBase.d;
        blwVar.h(4);
        blwVar.l(i4);
    }
}
