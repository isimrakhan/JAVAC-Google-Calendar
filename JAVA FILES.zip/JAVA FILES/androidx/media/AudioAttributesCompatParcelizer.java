package androidx.media;

import cal.blw;
import cal.bly;

/* compiled from: PG */
/* loaded from: classes.dex */
public class AudioAttributesCompatParcelizer {
    public static AudioAttributesCompat read(blw blwVar) {
        AudioAttributesCompat audioAttributesCompat = new AudioAttributesCompat();
        bly blyVar = audioAttributesCompat.a;
        if (blwVar.r(1)) {
            String f = blwVar.f();
            if (f == null) {
                blyVar = null;
            } else {
                blyVar = blwVar.d(f, blwVar.c());
            }
        }
        audioAttributesCompat.a = (AudioAttributesImpl) blyVar;
        return audioAttributesCompat;
    }

    public static void write(AudioAttributesCompat audioAttributesCompat, blw blwVar) {
        AudioAttributesImpl audioAttributesImpl = audioAttributesCompat.a;
        blwVar.h(1);
        if (audioAttributesImpl == null) {
            blwVar.n(null);
            return;
        }
        blwVar.p(audioAttributesImpl);
        blw c = blwVar.c();
        blwVar.o(audioAttributesImpl, c);
        c.g();
    }
}
