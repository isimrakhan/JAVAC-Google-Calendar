package androidx.appsearch.exceptions;

/* compiled from: PG */
/* loaded from: classes.dex */
public class IllegalSchemaException extends IllegalArgumentException {
    public IllegalSchemaException(String str) {
        super(str);
    }
}
