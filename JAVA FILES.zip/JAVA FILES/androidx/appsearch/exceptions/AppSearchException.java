package androidx.appsearch.exceptions;

/* compiled from: PG */
/* loaded from: classes.dex */
public class AppSearchException extends Exception {
    public final int a;

    public AppSearchException(int i, String str, Throwable th) {
        super(str, th);
        this.a = i;
    }
}
