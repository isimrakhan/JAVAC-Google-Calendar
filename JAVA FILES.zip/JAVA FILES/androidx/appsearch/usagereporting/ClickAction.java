package androidx.appsearch.usagereporting;

/* compiled from: PG */
/* loaded from: classes.dex */
public class ClickAction extends TakenAction {
    public final String a;
    public final String b;
    public final int c;
    public final int d;
    public final long e;

    public ClickAction(String str, String str2, long j, long j2, int i, String str3, String str4, int i2, int i3, long j3) {
        super(str, str2, j, j2, i);
        this.a = str3;
        this.b = str4;
        this.c = i2;
        this.d = i3;
        this.e = j3;
    }
}
