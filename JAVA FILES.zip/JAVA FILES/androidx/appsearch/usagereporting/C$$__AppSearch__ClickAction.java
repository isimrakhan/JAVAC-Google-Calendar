package androidx.appsearch.usagereporting;

import cal.akh;
import cal.wi;
import cal.wo;
import cal.wq;
import cal.ws;
import cal.wu;
import cal.wx;
import cal.wy;
import cal.zd;
import cal.ze;
import cal.zk;
import cal.zn;
import cal.zo;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Map;

/* compiled from: PG */
/* renamed from: androidx.appsearch.usagereporting.$$__AppSearch__ClickAction, reason: invalid class name */
/* loaded from: classes.dex */
public final class C$$__AppSearch__ClickAction implements wu<ClickAction> {
    public static final String SCHEMA_NAME = "builtin:ClickAction";

    /* JADX WARN: Can't rename method to resolve collision */
    @Override // cal.wu
    public ClickAction fromGenericDocument(wy wyVar, Map<String, List<String>> map) {
        long j;
        long j2;
        String str;
        long j3;
        long[] jArr;
        long j4;
        int length;
        int length2;
        int length3;
        ze zeVar = wyVar.a;
        String str2 = zeVar.a;
        String str3 = zeVar.b;
        long j5 = zeVar.e;
        long j6 = zeVar.d;
        long[] jArr2 = (long[]) wy.c("actionType", wyVar.b("actionType"), long[].class);
        if (jArr2 == null || (length3 = jArr2.length) == 0) {
            j = 0;
        } else {
            wy.e("Long", "actionType", length3);
            j = jArr2[0];
        }
        String[] strArr = (String[]) wy.c("query", wyVar.b("query"), String[].class);
        String str4 = (strArr == null || strArr.length == 0) ? null : strArr[0];
        String[] strArr2 = (String[]) wy.c("referencedQualifiedId", wyVar.b("referencedQualifiedId"), String[].class);
        String str5 = (strArr2 == null || strArr2.length == 0) ? null : strArr2[0];
        long[] jArr3 = (long[]) wy.c("resultRankInBlock", wyVar.b("resultRankInBlock"), long[].class);
        if (jArr3 == null || (length2 = jArr3.length) == 0) {
            j2 = 0;
        } else {
            wy.e("Long", "resultRankInBlock", length2);
            j2 = jArr3[0];
        }
        String str6 = str5;
        long[] jArr4 = (long[]) wy.c("resultRankGlobal", wyVar.b("resultRankGlobal"), long[].class);
        if (jArr4 != null) {
            str = str4;
            int length4 = jArr4.length;
            if (length4 != 0) {
                wy.e("Long", "resultRankGlobal", length4);
                j3 = jArr4[0];
                jArr = (long[]) wy.c("timeStayOnResultMillis", wyVar.b("timeStayOnResultMillis"), long[].class);
                if (jArr != null || (length = jArr.length) == 0) {
                    j4 = 0;
                } else {
                    wy.e("Long", "timeStayOnResultMillis", length);
                    j4 = jArr[0];
                }
                return new ClickAction(str2, str3, j5, j6, (int) j, str, str6, (int) j2, (int) j3, j4);
            }
        } else {
            str = str4;
        }
        j3 = 0;
        jArr = (long[]) wy.c("timeStayOnResultMillis", wyVar.b("timeStayOnResultMillis"), long[].class);
        if (jArr != null) {
        }
        j4 = 0;
        return new ClickAction(str2, str3, j5, j6, (int) j, str, str6, (int) j2, (int) j3, j4);
    }

    @Override // cal.wu
    public List<Class<?>> getDependencyDocumentClasses() {
        return Collections.emptyList();
    }

    @Override // cal.wu
    public ws getSchema() {
        wi wiVar = new wi(SCHEMA_NAME);
        akh.a(2, 1, 3, "cardinality");
        akh.a(0, 0, 1, "indexingType");
        wiVar.a(new wo(new zn("actionType", 2, 2, null, null, null, new zk(), null)));
        akh.a(2, 1, 3, "cardinality");
        akh.a(1, 0, 3, "tokenizerType");
        akh.a(2, 0, 2, "indexingType");
        akh.a(0, 0, 1, "joinableValueType");
        wiVar.a(wq.a("query", 2, 2, 1, 0));
        akh.a(2, 1, 3, "cardinality");
        akh.a(0, 0, 3, "tokenizerType");
        akh.a(0, 0, 2, "indexingType");
        akh.a(1, 0, 1, "joinableValueType");
        wiVar.a(wq.a("referencedQualifiedId", 2, 0, 0, 1));
        akh.a(2, 1, 3, "cardinality");
        akh.a(0, 0, 1, "indexingType");
        wiVar.a(new wo(new zn("resultRankInBlock", 2, 2, null, null, null, new zk(), null)));
        akh.a(2, 1, 3, "cardinality");
        akh.a(0, 0, 1, "indexingType");
        wiVar.a(new wo(new zn("resultRankGlobal", 2, 2, null, null, null, new zk(), null)));
        akh.a(2, 1, 3, "cardinality");
        akh.a(0, 0, 1, "indexingType");
        wiVar.a(new wo(new zn("timeStayOnResultMillis", 2, 2, null, null, null, new zk(), null)));
        wiVar.d = true;
        return new ws(wiVar.a, wiVar.b, new ArrayList(wiVar.c));
    }

    @Override // cal.wu
    public String getSchemaName() {
        return SCHEMA_NAME;
    }

    @Override // cal.wu
    public wy toGenericDocument(ClickAction clickAction) {
        wx wxVar = new wx(clickAction.f, clickAction.g, SCHEMA_NAME);
        zd zdVar = wxVar.a;
        zdVar.b = clickAction.h;
        zdVar.a = clickAction.i;
        zdVar.d.put("actionType", new zo("actionType", null, new long[]{clickAction.j}, null, null, null, null, null));
        String str = clickAction.a;
        if (str != null) {
            wxVar.b("query", str);
        }
        String str2 = clickAction.b;
        if (str2 != null) {
            wxVar.b("referencedQualifiedId", str2);
        }
        wxVar.a.d.put("resultRankInBlock", new zo("resultRankInBlock", null, new long[]{clickAction.c}, null, null, null, null, null));
        wxVar.a.d.put("resultRankGlobal", new zo("resultRankGlobal", null, new long[]{clickAction.d}, null, null, null, null, null));
        wxVar.a.d.put("timeStayOnResultMillis", new zo("timeStayOnResultMillis", null, new long[]{clickAction.e}, null, null, null, null, null));
        return new wy(wxVar.a.a());
    }

    @Override // cal.wu
    public /* bridge */ /* synthetic */ ClickAction fromGenericDocument(wy wyVar, Map map) {
        return fromGenericDocument(wyVar, (Map<String, List<String>>) map);
    }
}
