package androidx.appsearch.usagereporting;

import cal.akh;
import cal.wi;
import cal.wo;
import cal.ws;
import cal.wu;
import cal.wx;
import cal.wy;
import cal.zd;
import cal.ze;
import cal.zk;
import cal.zn;
import cal.zo;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Map;

/* compiled from: PG */
/* renamed from: androidx.appsearch.usagereporting.$$__AppSearch__TakenAction, reason: invalid class name */
/* loaded from: classes.dex */
public final class C$$__AppSearch__TakenAction implements wu<TakenAction> {
    public static final String SCHEMA_NAME = "builtin:TakenAction";

    /* JADX WARN: Can't rename method to resolve collision */
    @Override // cal.wu
    public TakenAction fromGenericDocument(wy wyVar, Map<String, List<String>> map) {
        int length;
        ze zeVar = wyVar.a;
        long[] jArr = (long[]) wy.c("actionType", wyVar.b("actionType"), long[].class);
        if (jArr != null && (length = jArr.length) != 0) {
            wy.e("Long", "actionType", length);
            long j = jArr[0];
        }
        throw new UnsupportedOperationException();
    }

    @Override // cal.wu
    public List<Class<?>> getDependencyDocumentClasses() {
        return Collections.emptyList();
    }

    @Override // cal.wu
    public ws getSchema() {
        wi wiVar = new wi(SCHEMA_NAME);
        akh.a(2, 1, 3, "cardinality");
        akh.a(0, 0, 1, "indexingType");
        wiVar.a(new wo(new zn("actionType", 2, 2, null, null, null, new zk(), null)));
        wiVar.d = true;
        return new ws(wiVar.a, wiVar.b, new ArrayList(wiVar.c));
    }

    @Override // cal.wu
    public String getSchemaName() {
        return SCHEMA_NAME;
    }

    @Override // cal.wu
    public wy toGenericDocument(TakenAction takenAction) {
        wx wxVar = new wx(takenAction.f, takenAction.g, SCHEMA_NAME);
        zd zdVar = wxVar.a;
        zdVar.b = takenAction.h;
        zdVar.a = takenAction.i;
        zdVar.d.put("actionType", new zo("actionType", null, new long[]{takenAction.j}, null, null, null, null, null));
        return new wy(wxVar.a.a());
    }

    @Override // cal.wu
    public /* bridge */ /* synthetic */ TakenAction fromGenericDocument(wy wyVar, Map map) {
        return fromGenericDocument(wyVar, (Map<String, List<String>>) map);
    }
}
