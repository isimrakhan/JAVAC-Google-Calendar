package androidx.appsearch.usagereporting;

/* compiled from: PG */
/* loaded from: classes.dex */
public class SearchAction extends TakenAction {
    public final String a;
    public final int b;

    public SearchAction(String str, String str2, long j, long j2, int i, String str3, int i2) {
        super(str, str2, j, j2, i);
        this.a = str3;
        this.b = i2;
    }
}
