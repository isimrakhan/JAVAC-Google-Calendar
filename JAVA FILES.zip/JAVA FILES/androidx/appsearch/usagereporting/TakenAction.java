package androidx.appsearch.usagereporting;

/* compiled from: PG */
/* loaded from: classes.dex */
public abstract class TakenAction {
    public final String f;
    public final String g;
    public final long h;
    public final long i;
    public final int j;

    public TakenAction(String str, String str2, long j, long j2, int i) {
        this.f = str;
        this.g = str2;
        this.h = j;
        this.i = j2;
        this.j = i;
    }
}
