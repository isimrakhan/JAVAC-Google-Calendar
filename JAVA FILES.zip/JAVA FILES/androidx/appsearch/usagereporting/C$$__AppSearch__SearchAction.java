package androidx.appsearch.usagereporting;

import cal.akh;
import cal.wi;
import cal.wo;
import cal.wq;
import cal.ws;
import cal.wu;
import cal.wx;
import cal.wy;
import cal.zd;
import cal.ze;
import cal.zk;
import cal.zn;
import cal.zo;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Map;

/* compiled from: PG */
/* renamed from: androidx.appsearch.usagereporting.$$__AppSearch__SearchAction, reason: invalid class name */
/* loaded from: classes.dex */
public final class C$$__AppSearch__SearchAction implements wu<SearchAction> {
    public static final String SCHEMA_NAME = "builtin:SearchAction";

    /* JADX WARN: Can't rename method to resolve collision */
    @Override // cal.wu
    public SearchAction fromGenericDocument(wy wyVar, Map<String, List<String>> map) {
        long j;
        long j2;
        int length;
        int length2;
        ze zeVar = wyVar.a;
        String str = zeVar.a;
        String str2 = zeVar.b;
        long j3 = zeVar.e;
        long j4 = zeVar.d;
        long[] jArr = (long[]) wy.c("actionType", wyVar.b("actionType"), long[].class);
        if (jArr == null || (length2 = jArr.length) == 0) {
            j = 0;
        } else {
            wy.e("Long", "actionType", length2);
            j = jArr[0];
        }
        String[] strArr = (String[]) wy.c("query", wyVar.b("query"), String[].class);
        String str3 = null;
        if (strArr != null && strArr.length != 0) {
            str3 = strArr[0];
        }
        long[] jArr2 = (long[]) wy.c("fetchedResultCount", wyVar.b("fetchedResultCount"), long[].class);
        if (jArr2 == null || (length = jArr2.length) == 0) {
            j2 = 0;
        } else {
            wy.e("Long", "fetchedResultCount", length);
            j2 = jArr2[0];
        }
        return new SearchAction(str, str2, j3, j4, (int) j, str3, (int) j2);
    }

    @Override // cal.wu
    public List<Class<?>> getDependencyDocumentClasses() {
        return Collections.emptyList();
    }

    @Override // cal.wu
    public ws getSchema() {
        wi wiVar = new wi(SCHEMA_NAME);
        akh.a(2, 1, 3, "cardinality");
        akh.a(0, 0, 1, "indexingType");
        wiVar.a(new wo(new zn("actionType", 2, 2, null, null, null, new zk(), null)));
        akh.a(2, 1, 3, "cardinality");
        akh.a(1, 0, 3, "tokenizerType");
        akh.a(2, 0, 2, "indexingType");
        akh.a(0, 0, 1, "joinableValueType");
        wiVar.a(wq.a("query", 2, 2, 1, 0));
        akh.a(2, 1, 3, "cardinality");
        akh.a(0, 0, 1, "indexingType");
        wiVar.a(new wo(new zn("fetchedResultCount", 2, 2, null, null, null, new zk(), null)));
        wiVar.d = true;
        return new ws(wiVar.a, wiVar.b, new ArrayList(wiVar.c));
    }

    @Override // cal.wu
    public String getSchemaName() {
        return SCHEMA_NAME;
    }

    @Override // cal.wu
    public wy toGenericDocument(SearchAction searchAction) {
        wx wxVar = new wx(searchAction.f, searchAction.g, SCHEMA_NAME);
        zd zdVar = wxVar.a;
        zdVar.b = searchAction.h;
        zdVar.a = searchAction.i;
        zdVar.d.put("actionType", new zo("actionType", null, new long[]{searchAction.j}, null, null, null, null, null));
        String str = searchAction.a;
        if (str != null) {
            wxVar.b("query", str);
        }
        wxVar.a.d.put("fetchedResultCount", new zo("fetchedResultCount", null, new long[]{searchAction.b}, null, null, null, null, null));
        return new wy(wxVar.a.a());
    }

    @Override // cal.wu
    public /* bridge */ /* synthetic */ SearchAction fromGenericDocument(wy wyVar, Map map) {
        return fromGenericDocument(wyVar, (Map<String, List<String>>) map);
    }
}
