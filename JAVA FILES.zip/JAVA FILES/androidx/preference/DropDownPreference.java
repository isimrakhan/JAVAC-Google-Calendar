package androidx.preference;

import android.content.Context;
import android.text.TextUtils;
import android.util.AttributeSet;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Spinner;
import android.widget.SpinnerAdapter;
import cal.ayh;
import cal.azx;
import cal.baf;
import cal.qq;
import com.google.android.calendar.R;

/* compiled from: PG */
/* loaded from: classes.dex */
public class DropDownPreference extends ListPreference {
    private final Context O;
    private final ArrayAdapter P;
    private Spinner Q;
    private final AdapterView.OnItemSelectedListener R;

    public DropDownPreference(Context context, AttributeSet attributeSet) {
        super(context, attributeSet, R.attr.dropdownPreferenceStyle);
        this.R = new ayh(this);
        this.O = context;
        this.P = new ArrayAdapter(context, android.R.layout.simple_spinner_dropdown_item);
        E();
    }

    private final void E() {
        this.P.clear();
        CharSequence[] charSequenceArr = ((ListPreference) this).g;
        if (charSequenceArr != null) {
            for (CharSequence charSequence : charSequenceArr) {
                this.P.add(charSequence.toString());
            }
        }
    }

    @Override // androidx.preference.DialogPreference, androidx.preference.Preference
    protected final void c() {
        this.Q.performClick();
    }

    @Override // androidx.preference.Preference
    public final void cL(baf bafVar) {
        Spinner spinner = (Spinner) bafVar.a.findViewById(R.id.spinner);
        this.Q = spinner;
        spinner.setAdapter((SpinnerAdapter) this.P);
        this.Q.setOnItemSelectedListener(this.R);
        Spinner spinner2 = this.Q;
        String str = ((ListPreference) this).i;
        CharSequence[] charSequenceArr = ((ListPreference) this).h;
        int i = -1;
        if (str != null && charSequenceArr != null) {
            int length = charSequenceArr.length - 1;
            while (true) {
                if (length < 0) {
                    break;
                }
                if (TextUtils.equals(charSequenceArr[length].toString(), str)) {
                    i = length;
                    break;
                }
                length--;
            }
        }
        spinner2.setSelection(i);
        super.cL(bafVar);
    }

    @Override // androidx.preference.Preference
    public final void d() {
        int indexOf;
        Object obj = this.J;
        if (obj != null && (indexOf = ((azx) obj).a.indexOf(this)) != -1) {
            ((qq) obj).b.c(indexOf, 1, this);
        }
        ArrayAdapter arrayAdapter = this.P;
        if (arrayAdapter != null) {
            arrayAdapter.notifyDataSetChanged();
        }
    }

    @Override // androidx.preference.ListPreference
    public final void e(CharSequence[] charSequenceArr) {
        ((ListPreference) this).g = charSequenceArr;
        E();
    }
}
