package androidx.preference;

import android.content.Context;
import android.os.Build;
import android.util.AttributeSet;
import cal.baf;

/* compiled from: PG */
/* loaded from: classes.dex */
public class PreferenceCategory extends PreferenceGroup {
    public PreferenceCategory(Context context) {
        this(context, null);
    }

    @Override // androidx.preference.Preference
    public final boolean B() {
        return false;
    }

    @Override // androidx.preference.Preference
    public void cL(baf bafVar) {
        super.cL(bafVar);
        if (Build.VERSION.SDK_INT < 28) {
            return;
        }
        bafVar.a.setAccessibilityHeading(true);
    }

    @Override // androidx.preference.Preference
    public final boolean i() {
        if (this.y && this.D && this.E) {
            return false;
        }
        return true;
    }

    /* JADX WARN: Illegal instructions before constructor call */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct code enable 'Show inconsistent code' option in preferences
    */
    public PreferenceCategory(android.content.Context r5, android.util.AttributeSet r6) {
        /*
            r4 = this;
            android.util.TypedValue r0 = new android.util.TypedValue
            r0.<init>()
            android.content.res.Resources$Theme r1 = r5.getTheme()
            r2 = 1
            r3 = 2130969872(0x7f040510, float:1.7548438E38)
            r1.resolveAttribute(r3, r0, r2)
            int r0 = r0.resourceId
            if (r0 == 0) goto L15
            goto L18
        L15:
            r3 = 16842892(0x101008c, float:2.369395E-38)
        L18:
            r4.<init>(r5, r6, r3)
            return
        */
        throw new UnsupportedOperationException("Method not decompiled: androidx.preference.PreferenceCategory.<init>(android.content.Context, android.util.AttributeSet):void");
    }

    public PreferenceCategory(Context context, AttributeSet attributeSet, int i) {
        this(context, attributeSet, i, 0);
    }

    public PreferenceCategory(Context context, AttributeSet attributeSet, int i, int i2) {
        super(context, attributeSet, i, i2);
    }
}
