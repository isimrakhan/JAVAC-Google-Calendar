package androidx.preference;

import android.content.res.TypedArray;
import android.os.Parcelable;
import android.text.TextUtils;
import android.view.AbsSavedState;
import cal.ayj;
import cal.ayz;

/* compiled from: PG */
/* loaded from: classes.dex */
public class EditTextPreference extends DialogPreference {
    public String g;

    /* JADX WARN: Illegal instructions before constructor call */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct code enable 'Show inconsistent code' option in preferences
    */
    public EditTextPreference(android.content.Context r5, android.util.AttributeSet r6) {
        /*
            r4 = this;
            android.util.TypedValue r0 = new android.util.TypedValue
            r0.<init>()
            android.content.res.Resources$Theme r1 = r5.getTheme()
            r2 = 1
            r3 = 2130969164(0x7f04024c, float:1.7547002E38)
            r1.resolveAttribute(r3, r0, r2)
            int r0 = r0.resourceId
            if (r0 == 0) goto L15
            goto L18
        L15:
            r3 = 16842898(0x1010092, float:2.3693967E-38)
        L18:
            r4.<init>(r5, r6, r3)
            int[] r0 = cal.bag.d
            r1 = 0
            android.content.res.TypedArray r5 = r5.obtainStyledAttributes(r6, r0, r3, r1)
            boolean r6 = r5.getBoolean(r1, r1)
            boolean r6 = r5.getBoolean(r1, r6)
            if (r6 == 0) goto L3e
            cal.ayk r6 = cal.ayk.a
            if (r6 != 0) goto L37
            cal.ayk r6 = new cal.ayk
            r6.<init>()
            cal.ayk.a = r6
        L37:
            cal.ayk r6 = cal.ayk.a
            r4.N = r6
            r4.d()
        L3e:
            r5.recycle()
            return
        */
        throw new UnsupportedOperationException("Method not decompiled: androidx.preference.EditTextPreference.<init>(android.content.Context, android.util.AttributeSet):void");
    }

    @Override // androidx.preference.Preference
    protected final Parcelable bk() {
        this.M = true;
        AbsSavedState absSavedState = ayz.EMPTY_STATE;
        if (this.B) {
            return absSavedState;
        }
        ayj ayjVar = new ayj(absSavedState);
        ayjVar.a = this.g;
        return ayjVar;
    }

    @Override // androidx.preference.Preference
    protected final Object f(TypedArray typedArray, int i) {
        return typedArray.getString(i);
    }

    @Override // androidx.preference.Preference
    protected final void g(Parcelable parcelable) {
        boolean z;
        boolean z2 = true;
        if (!parcelable.getClass().equals(ayj.class)) {
            this.M = true;
            if (parcelable == ayz.EMPTY_STATE) {
                return;
            } else {
                throw new IllegalArgumentException("Wrong state class -- expecting Preference State");
            }
        }
        ayj ayjVar = (ayj) parcelable;
        Parcelable superState = ayjVar.getSuperState();
        this.M = true;
        if (superState != ayz.EMPTY_STATE && superState != null) {
            throw new IllegalArgumentException("Wrong state class -- expecting Preference State");
        }
        String str = ayjVar.a;
        if (!TextUtils.isEmpty(this.g) && B()) {
            z = false;
        } else {
            z = true;
        }
        this.g = str;
        C(str);
        if (!TextUtils.isEmpty(this.g) && B()) {
            z2 = false;
        }
        if (z2 != z) {
            u(z2);
        }
        d();
    }

    @Override // androidx.preference.Preference
    protected final void h(Object obj) {
        boolean z;
        String p = p((String) obj);
        boolean z2 = false;
        if (!TextUtils.isEmpty(this.g) && B()) {
            z = false;
        } else {
            z = true;
        }
        this.g = p;
        C(p);
        if (TextUtils.isEmpty(this.g) || !B()) {
            z2 = true;
        }
        if (z2 != z) {
            u(z2);
        }
        d();
    }

    @Override // androidx.preference.Preference
    public final boolean i() {
        if (!TextUtils.isEmpty(this.g) && B()) {
            return false;
        }
        return true;
    }
}
