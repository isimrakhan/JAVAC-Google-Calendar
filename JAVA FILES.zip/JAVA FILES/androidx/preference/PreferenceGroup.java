package androidx.preference;

import android.content.Context;
import android.content.res.TypedArray;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.os.Parcelable;
import android.text.TextUtils;
import android.util.AttributeSet;
import android.util.Log;
import cal.a;
import cal.abh;
import cal.ayz;
import cal.aza;
import cal.azq;
import cal.azt;
import cal.azx;
import cal.bac;
import cal.bag;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

/* compiled from: PG */
/* loaded from: classes.dex */
public abstract class PreferenceGroup extends Preference {
    public final abh a;
    public final List b;
    public int c;
    private final Handler d;
    private boolean e;
    private int f;
    private boolean g;
    private final Runnable h;

    public PreferenceGroup(Context context, AttributeSet attributeSet) {
        this(context, attributeSet, 0);
    }

    public boolean E() {
        return true;
    }

    public final void F(Preference preference) {
        long j;
        Object obj;
        if (!this.b.contains(preference)) {
            if (preference.u != null) {
                PreferenceGroup preferenceGroup = this;
                while (true) {
                    PreferenceGroup preferenceGroup2 = preferenceGroup.L;
                    if (preferenceGroup2 == null) {
                        break;
                    } else {
                        preferenceGroup = preferenceGroup2;
                    }
                }
                String str = preference.u;
                if (preferenceGroup.k(str) != null) {
                    Log.e("PreferenceGroup", a.a(str, "Found duplicated key: \"", "\". This can cause unintended behaviour, please use unique keys for every preference."));
                }
            }
            if (preference.p == Integer.MAX_VALUE) {
                if (this.e) {
                    int i = this.f;
                    this.f = i + 1;
                    if (i != Integer.MAX_VALUE) {
                        preference.p = i;
                        aza azaVar = preference.J;
                        if (azaVar != null) {
                            azx azxVar = (azx) azaVar;
                            azxVar.e.removeCallbacks(azxVar.f);
                            azxVar.e.post(azxVar.f);
                        }
                    }
                }
                if (preference instanceof PreferenceGroup) {
                    ((PreferenceGroup) preference).e = this.e;
                }
            }
            int binarySearch = Collections.binarySearch(this.b, preference);
            if (binarySearch < 0) {
                binarySearch = (-binarySearch) - 1;
            }
            boolean i2 = i();
            if (preference.E == i2) {
                preference.E = !i2;
                preference.u(preference.i());
                preference.d();
            }
            synchronized (this) {
                this.b.add(binarySearch, preference);
            }
            bac bacVar = this.k;
            String str2 = preference.u;
            if (str2 != null && this.a.d(str2, str2.hashCode()) >= 0) {
                abh abhVar = this.a;
                int d = abhVar.d(str2, str2.hashCode());
                if (d >= 0) {
                    obj = abhVar.e[d + d + 1];
                } else {
                    obj = null;
                }
                j = ((Long) obj).longValue();
                abh abhVar2 = this.a;
                int d2 = abhVar2.d(str2, str2.hashCode());
                if (d2 >= 0) {
                    abhVar2.g(d2);
                }
            } else {
                synchronized (bacVar) {
                    j = bacVar.a;
                    bacVar.a = 1 + j;
                }
            }
            preference.l = j;
            preference.m = true;
            try {
                preference.k = bacVar;
                super.t();
                preference.m = false;
                if (preference.L == null) {
                    preference.L = this;
                    if (this.g) {
                        preference.v();
                    }
                    aza azaVar2 = this.J;
                    if (azaVar2 != null) {
                        azx azxVar2 = (azx) azaVar2;
                        azxVar2.e.removeCallbacks(azxVar2.f);
                        azxVar2.e.post(azxVar2.f);
                        return;
                    }
                    return;
                }
                throw new IllegalStateException("This preference already has a parent. You must remove the existing parent before assigning a new one.");
            } catch (Throwable th) {
                preference.m = false;
                throw th;
            }
        }
    }

    public final void G(Preference preference) {
        PreferenceScreen preferenceScreen;
        Preference k;
        List list;
        synchronized (this) {
            String str = preference.C;
            if (str != null) {
                bac bacVar = preference.k;
                if (bacVar != null && (preferenceScreen = bacVar.e) != null) {
                    k = preferenceScreen.k(str);
                    if (k != null && (list = k.K) != null) {
                        list.remove(preference);
                    }
                }
                k = null;
                if (k != null) {
                    list.remove(preference);
                }
            }
            if (preference.L == this) {
                preference.L = null;
            }
            if (this.b.remove(preference)) {
                String str2 = preference.u;
                if (str2 != null) {
                    this.a.put(str2, Long.valueOf(preference.j()));
                    this.d.removeCallbacks(this.h);
                    this.d.post(this.h);
                }
                if (this.g) {
                    preference.w();
                }
            }
        }
    }

    @Override // androidx.preference.Preference
    protected final Parcelable bk() {
        this.M = true;
        return new azt(ayz.EMPTY_STATE, this.c);
    }

    @Override // androidx.preference.Preference
    protected final void g(Parcelable parcelable) {
        if (!parcelable.getClass().equals(azt.class)) {
            this.M = true;
            if (parcelable != ayz.EMPTY_STATE) {
                throw new IllegalArgumentException("Wrong state class -- expecting Preference State");
            }
            return;
        }
        azt aztVar = (azt) parcelable;
        this.c = aztVar.a;
        Parcelable superState = aztVar.getSuperState();
        this.M = true;
        if (superState != ayz.EMPTY_STATE && superState != null) {
            throw new IllegalArgumentException("Wrong state class -- expecting Preference State");
        }
    }

    public final Preference k(CharSequence charSequence) {
        Preference k;
        if (charSequence != null) {
            if (!TextUtils.equals(this.u, charSequence)) {
                int size = this.b.size();
                for (int i = 0; i < size; i++) {
                    Preference preference = (Preference) this.b.get(i);
                    if (TextUtils.equals(preference.u, charSequence)) {
                        return preference;
                    }
                    if ((preference instanceof PreferenceGroup) && (k = ((PreferenceGroup) preference).k(charSequence)) != null) {
                        return k;
                    }
                }
                return null;
            }
            return this;
        }
        throw new IllegalArgumentException("Key cannot be null");
    }

    public final void n() {
        synchronized (this) {
            List list = this.b;
            int size = list.size();
            while (true) {
                size--;
                if (size < 0) {
                    break;
                } else {
                    G((Preference) list.get(0));
                }
            }
        }
        aza azaVar = this.J;
        if (azaVar != null) {
            azx azxVar = (azx) azaVar;
            azxVar.e.removeCallbacks(azxVar.f);
            azxVar.e.post(azxVar.f);
        }
    }

    @Override // androidx.preference.Preference
    public final void r(Bundle bundle) {
        super.r(bundle);
        int size = this.b.size();
        for (int i = 0; i < size; i++) {
            ((Preference) this.b.get(i)).r(bundle);
        }
    }

    @Override // androidx.preference.Preference
    public final void s(Bundle bundle) {
        super.s(bundle);
        int size = this.b.size();
        for (int i = 0; i < size; i++) {
            ((Preference) this.b.get(i)).s(bundle);
        }
    }

    @Override // androidx.preference.Preference
    public final void u(boolean z) {
        super.u(z);
        int size = this.b.size();
        for (int i = 0; i < size; i++) {
            Preference preference = (Preference) this.b.get(i);
            if (preference.E == z) {
                preference.E = !z;
                preference.u(preference.i());
                preference.d();
            }
        }
    }

    @Override // androidx.preference.Preference
    public final void v() {
        super.y();
        this.g = true;
        int size = this.b.size();
        for (int i = 0; i < size; i++) {
            ((Preference) this.b.get(i)).v();
        }
    }

    @Override // androidx.preference.Preference
    public final void w() {
        List list;
        PreferenceScreen preferenceScreen;
        String str = this.C;
        if (str != null) {
            bac bacVar = this.k;
            Preference preference = null;
            if (bacVar != null && (preferenceScreen = bacVar.e) != null) {
                preference = preferenceScreen.k(str);
            }
            if (preference != null && (list = preference.K) != null) {
                list.remove(this);
            }
        }
        this.g = false;
        int size = this.b.size();
        for (int i = 0; i < size; i++) {
            ((Preference) this.b.get(i)).w();
        }
    }

    public PreferenceGroup(Context context, AttributeSet attributeSet, int i) {
        this(context, attributeSet, i, 0);
    }

    public PreferenceGroup(Context context, AttributeSet attributeSet, int i, int i2) {
        super(context, attributeSet, i, i2);
        this.a = new abh(0);
        this.d = new Handler(Looper.getMainLooper());
        this.e = true;
        this.f = 0;
        this.g = false;
        this.c = Integer.MAX_VALUE;
        this.h = new azq(this);
        this.b = new ArrayList();
        TypedArray obtainStyledAttributes = context.obtainStyledAttributes(attributeSet, bag.i, i, i2);
        this.e = obtainStyledAttributes.getBoolean(2, obtainStyledAttributes.getBoolean(2, true));
        if (obtainStyledAttributes.hasValue(1)) {
            int i3 = obtainStyledAttributes.getInt(1, obtainStyledAttributes.getInt(1, Integer.MAX_VALUE));
            if (i3 != Integer.MAX_VALUE && TextUtils.isEmpty(this.u)) {
                Log.e("PreferenceGroup", String.valueOf(getClass().getSimpleName()).concat(" should have a key defined if it contains an expandable preference"));
            }
            this.c = i3;
        }
        obtainStyledAttributes.recycle();
    }
}
