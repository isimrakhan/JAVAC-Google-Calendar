package androidx.preference;

import android.R;
import android.view.View;
import android.view.accessibility.AccessibilityManager;
import android.widget.Checkable;
import android.widget.Switch;
import cal.baf;
import cal.bal;

/* compiled from: PG */
/* loaded from: classes.dex */
public class SwitchPreference extends TwoStatePreference {
    private final bal e;
    private final CharSequence f;
    private final CharSequence g;

    /* JADX WARN: Illegal instructions before constructor call */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct code enable 'Show inconsistent code' option in preferences
    */
    public SwitchPreference(android.content.Context r5, android.util.AttributeSet r6) {
        /*
            r4 = this;
            android.util.TypedValue r0 = new android.util.TypedValue
            r0.<init>()
            android.content.res.Resources$Theme r1 = r5.getTheme()
            r2 = 2130970076(0x7f0405dc, float:1.7548852E38)
            r3 = 1
            r1.resolveAttribute(r2, r0, r3)
            int r0 = r0.resourceId
            if (r0 == 0) goto L15
            goto L18
        L15:
            r2 = 16843629(0x101036d, float:2.3696016E-38)
        L18:
            r4.<init>(r5, r6, r2)
            cal.bal r0 = new cal.bal
            r0.<init>(r4)
            r4.e = r0
            int[] r0 = cal.bag.l
            r1 = 0
            android.content.res.TypedArray r5 = r5.obtainStyledAttributes(r6, r0, r2, r1)
            r6 = 7
            java.lang.String r6 = r5.getString(r6)
            if (r6 != 0) goto L34
            java.lang.String r6 = r5.getString(r1)
        L34:
            r4.b = r6
            boolean r6 = r4.a
            if (r6 == 0) goto L3d
            r4.d()
        L3d:
            r6 = 6
            java.lang.String r6 = r5.getString(r6)
            if (r6 != 0) goto L48
            java.lang.String r6 = r5.getString(r3)
        L48:
            r4.c = r6
            boolean r6 = r4.a
            if (r6 != 0) goto L51
            r4.d()
        L51:
            r6 = 9
            java.lang.String r6 = r5.getString(r6)
            if (r6 != 0) goto L5e
            r6 = 3
            java.lang.String r6 = r5.getString(r6)
        L5e:
            r4.f = r6
            r4.d()
            r6 = 8
            java.lang.String r6 = r5.getString(r6)
            if (r6 != 0) goto L70
            r6 = 4
            java.lang.String r6 = r5.getString(r6)
        L70:
            r4.g = r6
            r4.d()
            r6 = 2
            boolean r6 = r5.getBoolean(r6, r1)
            r0 = 5
            boolean r6 = r5.getBoolean(r0, r6)
            r4.d = r6
            r5.recycle()
            return
        */
        throw new UnsupportedOperationException("Method not decompiled: androidx.preference.SwitchPreference.<init>(android.content.Context, android.util.AttributeSet):void");
    }

    /* JADX WARN: Multi-variable type inference failed */
    private final void E(View view) {
        boolean z = view instanceof Switch;
        if (z) {
            ((Switch) view).setOnCheckedChangeListener(null);
        }
        if (view instanceof Checkable) {
            ((Checkable) view).setChecked(this.a);
        }
        if (z) {
            Switch r4 = (Switch) view;
            r4.setTextOn(this.f);
            r4.setTextOff(this.g);
            r4.setOnCheckedChangeListener(this.e);
        }
    }

    @Override // androidx.preference.Preference
    public final void b(View view) {
        x();
        if (!((AccessibilityManager) this.j.getSystemService("accessibility")).isEnabled()) {
            return;
        }
        E(view.findViewById(R.id.switch_widget));
        n(view.findViewById(R.id.summary));
    }

    @Override // androidx.preference.Preference
    public final void cL(baf bafVar) {
        super.cL(bafVar);
        E(bafVar.g(R.id.switch_widget));
        n(bafVar.g(R.id.summary));
    }
}
