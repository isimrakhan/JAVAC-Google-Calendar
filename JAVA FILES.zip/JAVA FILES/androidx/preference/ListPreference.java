package androidx.preference;

import android.content.Context;
import android.content.res.TypedArray;
import android.os.Parcelable;
import android.text.TextUtils;
import android.util.AttributeSet;
import android.util.Log;
import android.view.AbsSavedState;
import cal.ayp;
import cal.ayq;
import cal.ayz;
import cal.aze;
import cal.bag;

/* compiled from: PG */
/* loaded from: classes.dex */
public class ListPreference extends DialogPreference {
    private String O;
    private boolean P;
    public CharSequence[] g;
    public CharSequence[] h;
    public String i;

    /* JADX WARN: Illegal instructions before constructor call */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct code enable 'Show inconsistent code' option in preferences
    */
    public ListPreference(android.content.Context r5, android.util.AttributeSet r6) {
        /*
            r4 = this;
            android.util.TypedValue r0 = new android.util.TypedValue
            r0.<init>()
            android.content.res.Resources$Theme r1 = r5.getTheme()
            r2 = 1
            r3 = 2130969115(0x7f04021b, float:1.7546903E38)
            r1.resolveAttribute(r3, r0, r2)
            int r0 = r0.resourceId
            if (r0 == 0) goto L15
            goto L18
        L15:
            r3 = 16842897(0x1010091, float:2.3693964E-38)
        L18:
            r4.<init>(r5, r6, r3)
            return
        */
        throw new UnsupportedOperationException("Method not decompiled: androidx.preference.ListPreference.<init>(android.content.Context, android.util.AttributeSet):void");
    }

    /* JADX INFO: Access modifiers changed from: protected */
    @Override // androidx.preference.Preference
    public Parcelable bk() {
        this.M = true;
        AbsSavedState absSavedState = ayz.EMPTY_STATE;
        if (this.B) {
            return absSavedState;
        }
        ayp aypVar = new ayp(absSavedState);
        aypVar.a = this.i;
        return aypVar;
    }

    public void e(CharSequence[] charSequenceArr) {
        this.g = charSequenceArr;
    }

    @Override // androidx.preference.Preference
    protected final Object f(TypedArray typedArray, int i) {
        return typedArray.getString(i);
    }

    /* JADX INFO: Access modifiers changed from: protected */
    @Override // androidx.preference.Preference
    public void g(Parcelable parcelable) {
        if (!parcelable.getClass().equals(ayp.class)) {
            this.M = true;
            if (parcelable == ayz.EMPTY_STATE) {
                return;
            } else {
                throw new IllegalArgumentException("Wrong state class -- expecting Preference State");
            }
        }
        ayp aypVar = (ayp) parcelable;
        Parcelable superState = aypVar.getSuperState();
        this.M = true;
        if (superState != ayz.EMPTY_STATE && superState != null) {
            throw new IllegalArgumentException("Wrong state class -- expecting Preference State");
        }
        n(aypVar.a);
    }

    @Override // androidx.preference.Preference
    protected final void h(Object obj) {
        n(p((String) obj));
    }

    public final int k(String str) {
        CharSequence[] charSequenceArr;
        if (str != null && (charSequenceArr = this.h) != null) {
            for (int length = charSequenceArr.length - 1; length >= 0; length--) {
                if (TextUtils.equals(this.h[length].toString(), str)) {
                    return length;
                }
            }
        }
        return -1;
    }

    @Override // androidx.preference.Preference
    public final CharSequence l() {
        CharSequence charSequence;
        CharSequence[] charSequenceArr;
        aze azeVar = this.N;
        if (azeVar == null) {
            int k = k(this.i);
            CharSequence charSequence2 = null;
            if (k >= 0 && (charSequenceArr = this.g) != null) {
                charSequence2 = charSequenceArr[k];
            }
            aze azeVar2 = this.N;
            if (azeVar2 != null) {
                charSequence = azeVar2.a(this);
            } else {
                charSequence = this.r;
            }
            String str = this.O;
            if (str != null) {
                if (charSequence2 == null) {
                    charSequence2 = "";
                }
                String format = String.format(str, charSequence2);
                if (!TextUtils.equals(format, charSequence)) {
                    Log.w("ListPreference", "Setting a summary with a String formatting marker is no longer supported. You should use a SummaryProvider instead.");
                    return format;
                }
            }
            return charSequence;
        }
        return azeVar.a(this);
    }

    @Override // androidx.preference.Preference
    public final void m(CharSequence charSequence) {
        super.m(charSequence);
        if (charSequence == null) {
            this.O = null;
        } else {
            this.O = charSequence.toString();
        }
    }

    public final void n(String str) {
        boolean equals = TextUtils.equals(this.i, str);
        if (!equals || !this.P) {
            this.i = str;
            this.P = true;
            C(str);
            if (!equals) {
                d();
            }
        }
    }

    public ListPreference(Context context, AttributeSet attributeSet, int i) {
        super(context, attributeSet, i);
        TypedArray obtainStyledAttributes = context.obtainStyledAttributes(attributeSet, bag.e, i, 0);
        CharSequence[] textArray = obtainStyledAttributes.getTextArray(2);
        this.g = textArray == null ? obtainStyledAttributes.getTextArray(0) : textArray;
        CharSequence[] textArray2 = obtainStyledAttributes.getTextArray(3);
        this.h = textArray2 == null ? obtainStyledAttributes.getTextArray(1) : textArray2;
        if (obtainStyledAttributes.getBoolean(4, obtainStyledAttributes.getBoolean(4, false))) {
            if (ayq.a == null) {
                ayq.a = new ayq();
            }
            this.N = ayq.a;
            d();
        }
        obtainStyledAttributes.recycle();
        TypedArray obtainStyledAttributes2 = context.obtainStyledAttributes(attributeSet, bag.g, i, 0);
        String string = obtainStyledAttributes2.getString(33);
        this.O = string == null ? obtainStyledAttributes2.getString(7) : string;
        obtainStyledAttributes2.recycle();
    }
}
