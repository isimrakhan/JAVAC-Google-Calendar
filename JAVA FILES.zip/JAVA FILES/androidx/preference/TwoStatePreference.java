package androidx.preference;

import android.content.Context;
import android.content.SharedPreferences;
import android.content.res.TypedArray;
import android.os.Parcelable;
import android.text.TextUtils;
import android.util.AttributeSet;
import android.view.AbsSavedState;
import android.view.View;
import android.widget.TextView;
import cal.ayz;
import cal.azb;
import cal.azf;
import cal.bac;
import cal.bao;
import cal.rwi;

/* compiled from: PG */
/* loaded from: classes.dex */
public abstract class TwoStatePreference extends Preference {
    public boolean a;
    public CharSequence b;
    public CharSequence c;
    public boolean d;
    private boolean e;

    public TwoStatePreference(Context context, AttributeSet attributeSet) {
        super(context, attributeSet, 0, 0);
    }

    @Override // androidx.preference.Preference
    protected final Parcelable bk() {
        this.M = true;
        AbsSavedState absSavedState = ayz.EMPTY_STATE;
        if (this.B) {
            return absSavedState;
        }
        bao baoVar = new bao(absSavedState);
        baoVar.a = this.a;
        return baoVar;
    }

    @Override // androidx.preference.Preference
    protected final void c() {
        boolean z = !this.a;
        Boolean valueOf = Boolean.valueOf(z);
        azb azbVar = this.n;
        if (azbVar != null && !azbVar.a(this, valueOf)) {
            return;
        }
        k(z);
    }

    @Override // androidx.preference.Preference
    protected final Object f(TypedArray typedArray, int i) {
        return Boolean.valueOf(typedArray.getBoolean(i, false));
    }

    @Override // androidx.preference.Preference
    protected final void g(Parcelable parcelable) {
        if (!parcelable.getClass().equals(bao.class)) {
            this.M = true;
            if (parcelable == ayz.EMPTY_STATE) {
                return;
            } else {
                throw new IllegalArgumentException("Wrong state class -- expecting Preference State");
            }
        }
        bao baoVar = (bao) parcelable;
        Parcelable superState = baoVar.getSuperState();
        this.M = true;
        if (superState != ayz.EMPTY_STATE && superState != null) {
            throw new IllegalArgumentException("Wrong state class -- expecting Preference State");
        }
        k(baoVar.a);
    }

    @Override // androidx.preference.Preference
    protected final void h(Object obj) {
        if (obj == null) {
            obj = false;
        }
        k(A(((Boolean) obj).booleanValue()));
    }

    @Override // androidx.preference.Preference
    public final boolean i() {
        if (this.d) {
            if (this.a) {
                return true;
            }
        } else if (!this.a) {
            return true;
        }
        if (!B()) {
            return true;
        }
        return false;
    }

    public final void k(boolean z) {
        boolean z2;
        azf azfVar;
        if (this.a != z) {
            z2 = true;
        } else {
            z2 = false;
        }
        if (z2 || !this.e) {
            this.a = z;
            this.e = true;
            if (this.k != null && this.B && !TextUtils.isEmpty(this.u) && z != A(!z)) {
                bac bacVar = this.k;
                if (bacVar != null) {
                    azfVar = bacVar.b;
                } else {
                    azfVar = null;
                }
                if (azfVar != null) {
                    ((rwi) azfVar).a.put(this.u, Boolean.valueOf(z));
                } else {
                    SharedPreferences.Editor a = bacVar.a();
                    a.putBoolean(this.u, z);
                    if (!this.k.d) {
                        a.apply();
                    }
                }
            }
            if (z2) {
                u(i());
                d();
            }
        }
    }

    /* JADX INFO: Access modifiers changed from: protected */
    public final void n(View view) {
        if (view instanceof TextView) {
            TextView textView = (TextView) view;
            int i = 0;
            if (this.a && !TextUtils.isEmpty(this.b)) {
                textView.setText(this.b);
            } else if (!this.a && !TextUtils.isEmpty(this.c)) {
                textView.setText(this.c);
            } else {
                CharSequence l = l();
                if (!TextUtils.isEmpty(l)) {
                    textView.setText(l);
                } else {
                    i = 8;
                }
            }
            if (i != textView.getVisibility()) {
                textView.setVisibility(i);
            }
        }
    }

    public TwoStatePreference(Context context, AttributeSet attributeSet, int i) {
        super(context, attributeSet, i, 0);
    }
}
