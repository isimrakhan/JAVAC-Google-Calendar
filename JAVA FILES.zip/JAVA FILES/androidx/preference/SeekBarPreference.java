package androidx.preference;

import android.content.Context;
import android.content.SharedPreferences;
import android.content.res.TypedArray;
import android.os.Parcelable;
import android.text.TextUtils;
import android.util.AttributeSet;
import android.util.Log;
import android.view.AbsSavedState;
import android.view.View;
import android.widget.SeekBar;
import android.widget.TextView;
import cal.ayz;
import cal.azb;
import cal.azf;
import cal.bac;
import cal.baf;
import cal.bag;
import cal.bah;
import cal.bai;
import cal.bak;
import cal.rwi;
import com.google.android.calendar.R;

/* compiled from: PG */
/* loaded from: classes.dex */
public class SeekBarPreference extends Preference {
    private final boolean O;
    private final SeekBar.OnSeekBarChangeListener P;
    private final View.OnKeyListener Q;
    public int a;
    public int b;
    public boolean c;
    public SeekBar d;
    public TextView e;
    public final boolean f;
    public final boolean g;
    private int h;
    private int i;

    public SeekBarPreference(Context context, AttributeSet attributeSet) {
        super(context, attributeSet, R.attr.seekBarPreferenceStyle, 0);
        this.P = new bah(this);
        this.Q = new bai(this);
        TypedArray obtainStyledAttributes = context.obtainStyledAttributes(attributeSet, bag.k, R.attr.seekBarPreferenceStyle, 0);
        this.b = obtainStyledAttributes.getInt(3, 0);
        int i = obtainStyledAttributes.getInt(1, 100);
        int i2 = this.b;
        i = i < i2 ? i2 : i;
        if (i != this.h) {
            this.h = i;
            d();
        }
        int i3 = obtainStyledAttributes.getInt(4, 0);
        if (i3 != this.i) {
            this.i = Math.min(this.h - this.b, Math.abs(i3));
            d();
        }
        this.f = obtainStyledAttributes.getBoolean(2, true);
        this.O = obtainStyledAttributes.getBoolean(5, false);
        this.g = obtainStyledAttributes.getBoolean(6, false);
        obtainStyledAttributes.recycle();
    }

    private final void n(int i, boolean z) {
        azf azfVar;
        int i2 = this.b;
        if (i < i2) {
            i = i2;
        }
        int i3 = this.h;
        if (i > i3) {
            i = i3;
        }
        if (i != this.a) {
            this.a = i;
            TextView textView = this.e;
            if (textView != null) {
                textView.setText(String.valueOf(i));
            }
            if (this.k != null && this.B && !TextUtils.isEmpty(this.u) && i != o(~i)) {
                bac bacVar = this.k;
                if (bacVar != null) {
                    azfVar = bacVar.b;
                } else {
                    azfVar = null;
                }
                if (azfVar != null) {
                    ((rwi) azfVar).a.put(this.u, Integer.valueOf(i));
                } else {
                    SharedPreferences.Editor a = bacVar.a();
                    a.putInt(this.u, i);
                    if (!this.k.d) {
                        a.apply();
                    }
                }
            }
            if (z) {
                d();
            }
        }
    }

    @Override // androidx.preference.Preference
    protected final Parcelable bk() {
        this.M = true;
        AbsSavedState absSavedState = ayz.EMPTY_STATE;
        if (this.B) {
            return absSavedState;
        }
        bak bakVar = new bak(absSavedState);
        bakVar.a = this.a;
        bakVar.b = this.b;
        bakVar.c = this.h;
        return bakVar;
    }

    @Override // androidx.preference.Preference
    public final void cL(baf bafVar) {
        super.cL(bafVar);
        bafVar.a.setOnKeyListener(this.Q);
        this.d = (SeekBar) bafVar.g(R.id.seekbar);
        TextView textView = (TextView) bafVar.g(R.id.seekbar_value);
        this.e = textView;
        if (this.O) {
            textView.setVisibility(0);
        } else {
            textView.setVisibility(8);
            this.e = null;
        }
        SeekBar seekBar = this.d;
        if (seekBar == null) {
            Log.e("SeekBarPreference", "SeekBar view is null in onBindViewHolder.");
            return;
        }
        seekBar.setOnSeekBarChangeListener(this.P);
        this.d.setMax(this.h - this.b);
        int i = this.i;
        if (i != 0) {
            this.d.setKeyProgressIncrement(i);
        } else {
            this.i = this.d.getKeyProgressIncrement();
        }
        this.d.setProgress(this.a - this.b);
        int i2 = this.a;
        TextView textView2 = this.e;
        if (textView2 != null) {
            textView2.setText(String.valueOf(i2));
        }
        this.d.setEnabled(B());
    }

    @Override // androidx.preference.Preference
    protected final Object f(TypedArray typedArray, int i) {
        return Integer.valueOf(typedArray.getInt(i, 0));
    }

    @Override // androidx.preference.Preference
    protected final void g(Parcelable parcelable) {
        if (!parcelable.getClass().equals(bak.class)) {
            this.M = true;
            if (parcelable == ayz.EMPTY_STATE) {
                return;
            } else {
                throw new IllegalArgumentException("Wrong state class -- expecting Preference State");
            }
        }
        bak bakVar = (bak) parcelable;
        Parcelable superState = bakVar.getSuperState();
        this.M = true;
        if (superState != ayz.EMPTY_STATE && superState != null) {
            throw new IllegalArgumentException("Wrong state class -- expecting Preference State");
        }
        this.a = bakVar.a;
        this.b = bakVar.b;
        this.h = bakVar.c;
        d();
    }

    @Override // androidx.preference.Preference
    protected final void h(Object obj) {
        if (obj == null) {
            obj = 0;
        }
        n(o(((Integer) obj).intValue()), true);
    }

    public final void k(SeekBar seekBar) {
        int progress = this.b + seekBar.getProgress();
        if (progress != this.a) {
            Integer valueOf = Integer.valueOf(progress);
            azb azbVar = this.n;
            if (azbVar != null && !azbVar.a(this, valueOf)) {
                seekBar.setProgress(this.a - this.b);
                int i = this.a;
                TextView textView = this.e;
                if (textView != null) {
                    textView.setText(String.valueOf(i));
                    return;
                }
                return;
            }
            n(progress, false);
        }
    }
}
