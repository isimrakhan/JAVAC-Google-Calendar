package androidx.preference;

import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.res.TypedArray;
import android.graphics.drawable.Drawable;
import android.os.Bundle;
import android.os.Parcelable;
import android.text.TextUtils;
import android.util.AttributeSet;
import android.view.View;
import android.view.ViewGroup;
import cal.ayx;
import cal.ayz;
import cal.aza;
import cal.azb;
import cal.azc;
import cal.azd;
import cal.aze;
import cal.azf;
import cal.azx;
import cal.bab;
import cal.bac;
import cal.bag;
import cal.qq;
import cal.rwg;
import cal.rwh;
import cal.rwi;
import com.google.android.calendar.R;
import java.util.ArrayList;
import java.util.List;
import java.util.Set;

/* compiled from: PG */
/* loaded from: classes.dex */
public class Preference implements Comparable<Preference> {
    public boolean A;
    public boolean B;
    public String C;
    public boolean D;
    public boolean E;
    public boolean F;
    public boolean G;
    public int H;
    public int I;
    public aza J;
    public List K;
    public PreferenceGroup L;
    public boolean M;
    public aze N;
    private Object a;
    private boolean b;
    private boolean c;
    private boolean d;
    private boolean e;
    private boolean f;
    private boolean g;
    private azd h;
    private final View.OnClickListener i;
    public final Context j;
    public bac k;
    public long l;
    public boolean m;
    public azb n;
    public azc o;
    public int p;
    public CharSequence q;
    public CharSequence r;
    public int s;
    public Drawable t;
    public String u;
    public Intent v;
    public String w;
    public Bundle x;
    public boolean y;
    public boolean z;

    public Preference(Context context) {
        this(context, null);
    }

    private final void k(View view, boolean z) {
        view.setEnabled(z);
        if (view instanceof ViewGroup) {
            ViewGroup viewGroup = (ViewGroup) view;
            int childCount = viewGroup.getChildCount();
            while (true) {
                childCount--;
                if (childCount >= 0) {
                    k(viewGroup.getChildAt(childCount), z);
                } else {
                    return;
                }
            }
        }
    }

    /* JADX INFO: Access modifiers changed from: protected */
    public final boolean A(boolean z) {
        azf azfVar;
        if (this.k != null && this.B && !TextUtils.isEmpty(this.u)) {
            bac bacVar = this.k;
            if (bacVar != null) {
                azfVar = bacVar.b;
            } else {
                azfVar = null;
            }
            if (azfVar != null) {
                String str = this.u;
                Object valueOf = Boolean.valueOf(z);
                rwi rwiVar = (rwi) azfVar;
                if (rwiVar.a.containsKey(str)) {
                    valueOf = Boolean.class.cast(rwiVar.a.get(str));
                }
                return ((Boolean) valueOf).booleanValue();
            }
            return bacVar.b().getBoolean(this.u, z);
        }
        return z;
    }

    public boolean B() {
        if (this.y && this.D && this.E) {
            return true;
        }
        return false;
    }

    public final void C(String str) {
        if (this.k != null && this.B && !TextUtils.isEmpty(this.u)) {
            azf azfVar = null;
            if (!TextUtils.equals(str, p(null))) {
                bac bacVar = this.k;
                if (bacVar != null) {
                    azfVar = bacVar.b;
                }
                if (azfVar != null) {
                    ((rwi) azfVar).a.put(this.u, str);
                    return;
                }
                SharedPreferences.Editor a = bacVar.a();
                a.putString(this.u, str);
                if (!this.k.d) {
                    a.apply();
                }
            }
        }
    }

    public final void D(Set set) {
        if (this.k != null && this.B && !TextUtils.isEmpty(this.u)) {
            azf azfVar = null;
            if (!set.equals(q(null))) {
                bac bacVar = this.k;
                if (bacVar != null) {
                    azfVar = bacVar.b;
                }
                if (azfVar != null) {
                    ((rwi) azfVar).a.put(this.u, new rwg(set));
                } else {
                    SharedPreferences.Editor a = bacVar.a();
                    a.putStringSet(this.u, set);
                    if (!this.k.d) {
                        a.apply();
                    }
                }
            }
        }
    }

    public void b(View view) {
        x();
    }

    protected Parcelable bk() {
        this.M = true;
        return ayz.EMPTY_STATE;
    }

    /* JADX WARN: Removed duplicated region for block: B:22:0x007c  */
    /* JADX WARN: Removed duplicated region for block: B:29:0x00a0  */
    /* JADX WARN: Removed duplicated region for block: B:30:0x00a4  */
    /* JADX WARN: Removed duplicated region for block: B:43:0x00b7  */
    /* JADX WARN: Removed duplicated region for block: B:45:0x00c0  */
    /* JADX WARN: Removed duplicated region for block: B:54:0x00d5  */
    /* JADX WARN: Removed duplicated region for block: B:61:0x0101  */
    /* JADX WARN: Removed duplicated region for block: B:70:0x0104  */
    /* JADX WARN: Removed duplicated region for block: B:71:0x00dd  */
    /* JADX WARN: Removed duplicated region for block: B:8:0x0041  */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct code enable 'Show inconsistent code' option in preferences
    */
    public void cL(cal.baf r11) {
        /*
            Method dump skipped, instructions count: 275
            To view this dump change 'Code comments level' option to 'DEBUG'
        */
        throw new UnsupportedOperationException("Method not decompiled: androidx.preference.Preference.cL(cal.baf):void");
    }

    @Override // java.lang.Comparable
    public final /* bridge */ /* synthetic */ int compareTo(Preference preference) {
        Preference preference2 = preference;
        int i = this.p;
        int i2 = preference2.p;
        if (i != i2) {
            return i - i2;
        }
        CharSequence charSequence = this.q;
        CharSequence charSequence2 = preference2.q;
        if (charSequence == charSequence2) {
            return 0;
        }
        if (charSequence == null) {
            return 1;
        }
        if (charSequence2 == null) {
            return -1;
        }
        return charSequence.toString().compareToIgnoreCase(preference2.q.toString());
    }

    public void d() {
        int indexOf;
        Object obj = this.J;
        if (obj != null && (indexOf = ((azx) obj).a.indexOf(this)) != -1) {
            ((qq) obj).b.c(indexOf, 1, this);
        }
    }

    protected Object f(TypedArray typedArray, int i) {
        return null;
    }

    protected void g(Parcelable parcelable) {
        this.M = true;
        if (parcelable == ayz.EMPTY_STATE) {
        } else {
            throw new IllegalArgumentException("Wrong state class -- expecting Preference State");
        }
    }

    public boolean i() {
        if (!B()) {
            return true;
        }
        return false;
    }

    public long j() {
        return this.l;
    }

    public CharSequence l() {
        aze azeVar = this.N;
        if (azeVar != null) {
            return azeVar.a(this);
        }
        return this.r;
    }

    public void m(CharSequence charSequence) {
        if (this.N == null) {
            if (!TextUtils.equals(this.r, charSequence)) {
                this.r = charSequence;
                d();
                return;
            }
            return;
        }
        throw new IllegalStateException("Preference already has a SummaryProvider set.");
    }

    /* JADX INFO: Access modifiers changed from: protected */
    public final int o(int i) {
        azf azfVar;
        if (this.k != null && this.B && !TextUtils.isEmpty(this.u)) {
            bac bacVar = this.k;
            if (bacVar != null) {
                azfVar = bacVar.b;
            } else {
                azfVar = null;
            }
            if (azfVar != null) {
                String str = this.u;
                Object valueOf = Integer.valueOf(i);
                rwi rwiVar = (rwi) azfVar;
                if (rwiVar.a.containsKey(str)) {
                    valueOf = Integer.class.cast(rwiVar.a.get(str));
                }
                return ((Integer) valueOf).intValue();
            }
            return bacVar.b().getInt(this.u, i);
        }
        return i;
    }

    /* JADX INFO: Access modifiers changed from: protected */
    public final String p(String str) {
        azf azfVar;
        if (this.k != null && this.B && !TextUtils.isEmpty(this.u)) {
            bac bacVar = this.k;
            if (bacVar != null) {
                azfVar = bacVar.b;
            } else {
                azfVar = null;
            }
            if (azfVar != null) {
                String str2 = this.u;
                rwi rwiVar = (rwi) azfVar;
                Object obj = str;
                if (rwiVar.a.containsKey(str2)) {
                    obj = String.class.cast(rwiVar.a.get(str2));
                }
                return (String) obj;
            }
            return bacVar.b().getString(this.u, str);
        }
        return str;
    }

    public final Set q(final Set set) {
        azf azfVar;
        if (this.k != null && this.B && !TextUtils.isEmpty(this.u)) {
            bac bacVar = this.k;
            if (bacVar != null) {
                azfVar = bacVar.b;
            } else {
                azfVar = null;
            }
            if (azfVar != null) {
                String str = this.u;
                Object obj = new rwh() { // from class: cal.rwf
                    @Override // cal.rwh
                    public final Set a() {
                        return set;
                    }
                };
                rwi rwiVar = (rwi) azfVar;
                if (rwiVar.a.containsKey(str)) {
                    obj = rwh.class.cast(rwiVar.a.get(str));
                }
                return ((rwh) obj).a();
            }
            return bacVar.b().getStringSet(this.u, set);
        }
        return set;
    }

    public void r(Bundle bundle) {
        Parcelable parcelable;
        if (!TextUtils.isEmpty(this.u) && (parcelable = bundle.getParcelable(this.u)) != null) {
            this.M = false;
            g(parcelable);
            if (!this.M) {
                throw new IllegalStateException("Derived class did not call super.onRestoreInstanceState()");
            }
        }
    }

    public void s(Bundle bundle) {
        if (!TextUtils.isEmpty(this.u)) {
            this.M = false;
            Parcelable bk = bk();
            if (this.M) {
                if (bk != null) {
                    bundle.putParcelable(this.u, bk);
                    return;
                }
                return;
            }
            throw new IllegalStateException("Derived class did not call super.onSaveInstanceState()");
        }
    }

    public final void t() {
        azf azfVar;
        SharedPreferences sharedPreferences;
        bac bacVar = this.k;
        if (bacVar != null) {
            azfVar = bacVar.b;
        } else {
            azfVar = null;
        }
        if (azfVar == null) {
            if (bacVar != null && this.B && !TextUtils.isEmpty(this.u)) {
                bac bacVar2 = this.k;
                if (bacVar2 != null && bacVar2.b == null) {
                    sharedPreferences = bacVar2.b();
                } else {
                    sharedPreferences = null;
                }
                if (sharedPreferences.contains(this.u)) {
                    h(null);
                    return;
                }
            }
            Object obj = this.a;
            if (obj != null) {
                h(obj);
                return;
            }
            return;
        }
        h(this.a);
    }

    public final String toString() {
        StringBuilder sb = new StringBuilder();
        CharSequence charSequence = this.q;
        if (!TextUtils.isEmpty(charSequence)) {
            sb.append(charSequence);
            sb.append(' ');
        }
        CharSequence l = l();
        if (!TextUtils.isEmpty(l)) {
            sb.append(l);
            sb.append(' ');
        }
        if (sb.length() > 0) {
            sb.setLength(sb.length() - 1);
        }
        return sb.toString();
    }

    public void u(boolean z) {
        List list = this.K;
        if (list != null) {
            int size = list.size();
            for (int i = 0; i < size; i++) {
                Preference preference = (Preference) list.get(i);
                if (preference.D == z) {
                    preference.D = !z;
                    preference.u(preference.i());
                    preference.d();
                }
            }
        }
    }

    public void v() {
        y();
    }

    public void w() {
        List list;
        PreferenceScreen preferenceScreen;
        String str = this.C;
        if (str != null) {
            bac bacVar = this.k;
            Preference preference = null;
            if (bacVar != null && (preferenceScreen = bacVar.e) != null) {
                preference = preferenceScreen.k(str);
            }
            if (preference != null && (list = preference.K) != null) {
                list.remove(this);
            }
        }
    }

    public final void x() {
        Intent intent;
        bab babVar;
        if (B() && this.z) {
            c();
            azc azcVar = this.o;
            if (azcVar == null) {
                bac bacVar = this.k;
                if ((bacVar == null || (babVar = bacVar.f) == null || !babVar.onPreferenceTreeClick(this)) && (intent = this.v) != null) {
                    this.j.startActivity(intent);
                    return;
                }
                return;
            }
            azcVar.a();
        }
    }

    public final void y() {
        PreferenceScreen preferenceScreen;
        if (!TextUtils.isEmpty(this.C)) {
            String str = this.C;
            bac bacVar = this.k;
            Preference preference = null;
            if (bacVar != null && (preferenceScreen = bacVar.e) != null) {
                preference = preferenceScreen.k(str);
            }
            if (preference != null) {
                if (preference.K == null) {
                    preference.K = new ArrayList();
                }
                preference.K.add(this);
                boolean i = preference.i();
                if (this.D == i) {
                    this.D = !i;
                    u(i());
                    d();
                    return;
                }
                return;
            }
            throw new IllegalStateException("Dependency \"" + this.C + "\" not found for preference \"" + this.u + "\" (title: \"" + ((Object) this.q) + "\"");
        }
    }

    public void z(azb azbVar) {
        this.n = azbVar;
    }

    /* JADX WARN: Illegal instructions before constructor call */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct code enable 'Show inconsistent code' option in preferences
    */
    public Preference(android.content.Context r5, android.util.AttributeSet r6) {
        /*
            r4 = this;
            android.util.TypedValue r0 = new android.util.TypedValue
            r0.<init>()
            android.content.res.Resources$Theme r1 = r5.getTheme()
            r2 = 1
            r3 = 2130969880(0x7f040518, float:1.7548454E38)
            r1.resolveAttribute(r3, r0, r2)
            int r0 = r0.resourceId
            if (r0 == 0) goto L15
            goto L18
        L15:
            r3 = 16842894(0x101008e, float:2.3693956E-38)
        L18:
            r4.<init>(r5, r6, r3)
            return
        */
        throw new UnsupportedOperationException("Method not decompiled: androidx.preference.Preference.<init>(android.content.Context, android.util.AttributeSet):void");
    }

    public Preference(Context context, AttributeSet attributeSet, int i) {
        this(context, attributeSet, i, 0);
    }

    public Preference(Context context, AttributeSet attributeSet, int i, int i2) {
        this.p = Integer.MAX_VALUE;
        this.y = true;
        this.z = true;
        this.B = true;
        this.D = true;
        this.E = true;
        this.F = true;
        this.b = true;
        this.c = true;
        this.e = true;
        this.g = true;
        this.H = R.layout.preference;
        this.i = new ayx(this);
        this.j = context;
        TypedArray obtainStyledAttributes = context.obtainStyledAttributes(attributeSet, bag.g, i, i2);
        this.s = obtainStyledAttributes.getResourceId(23, obtainStyledAttributes.getResourceId(0, 0));
        String string = obtainStyledAttributes.getString(26);
        this.u = string == null ? obtainStyledAttributes.getString(6) : string;
        CharSequence text = obtainStyledAttributes.getText(34);
        this.q = text == null ? obtainStyledAttributes.getText(4) : text;
        CharSequence text2 = obtainStyledAttributes.getText(33);
        this.r = text2 == null ? obtainStyledAttributes.getText(7) : text2;
        this.p = obtainStyledAttributes.getInt(28, obtainStyledAttributes.getInt(8, Integer.MAX_VALUE));
        String string2 = obtainStyledAttributes.getString(22);
        this.w = string2 == null ? obtainStyledAttributes.getString(13) : string2;
        this.H = obtainStyledAttributes.getResourceId(27, obtainStyledAttributes.getResourceId(3, R.layout.preference));
        this.I = obtainStyledAttributes.getResourceId(35, obtainStyledAttributes.getResourceId(9, 0));
        this.y = obtainStyledAttributes.getBoolean(21, obtainStyledAttributes.getBoolean(2, true));
        this.z = obtainStyledAttributes.getBoolean(30, obtainStyledAttributes.getBoolean(5, true));
        this.B = obtainStyledAttributes.getBoolean(29, obtainStyledAttributes.getBoolean(1, true));
        String string3 = obtainStyledAttributes.getString(19);
        this.C = string3 == null ? obtainStyledAttributes.getString(10) : string3;
        this.b = obtainStyledAttributes.getBoolean(16, obtainStyledAttributes.getBoolean(16, this.z));
        this.c = obtainStyledAttributes.getBoolean(17, obtainStyledAttributes.getBoolean(17, this.z));
        if (obtainStyledAttributes.hasValue(18)) {
            this.a = f(obtainStyledAttributes, 18);
        } else if (obtainStyledAttributes.hasValue(11)) {
            this.a = f(obtainStyledAttributes, 11);
        }
        this.g = obtainStyledAttributes.getBoolean(31, obtainStyledAttributes.getBoolean(12, true));
        boolean hasValue = obtainStyledAttributes.hasValue(32);
        this.d = hasValue;
        if (hasValue) {
            this.e = obtainStyledAttributes.getBoolean(32, obtainStyledAttributes.getBoolean(14, true));
        }
        this.f = obtainStyledAttributes.getBoolean(24, obtainStyledAttributes.getBoolean(15, false));
        this.F = obtainStyledAttributes.getBoolean(25, obtainStyledAttributes.getBoolean(25, true));
        this.G = obtainStyledAttributes.getBoolean(20, obtainStyledAttributes.getBoolean(20, false));
        obtainStyledAttributes.recycle();
    }

    protected void c() {
    }

    protected void h(Object obj) {
    }
}
