package androidx.preference;

import android.content.res.TypedArray;
import android.os.Parcelable;
import android.view.AbsSavedState;
import cal.ayu;
import cal.ayz;
import java.util.HashSet;
import java.util.Set;

/* compiled from: PG */
/* loaded from: classes.dex */
public class MultiSelectListPreference extends DialogPreference {
    public CharSequence[] g;
    public CharSequence[] h;
    public final Set i;

    /* JADX WARN: Illegal instructions before constructor call */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct code enable 'Show inconsistent code' option in preferences
    */
    public MultiSelectListPreference(android.content.Context r5, android.util.AttributeSet r6) {
        /*
            r4 = this;
            android.util.TypedValue r0 = new android.util.TypedValue
            r0.<init>()
            android.content.res.Resources$Theme r1 = r5.getTheme()
            r2 = 2130969115(0x7f04021b, float:1.7546903E38)
            r3 = 1
            r1.resolveAttribute(r2, r0, r3)
            int r0 = r0.resourceId
            if (r0 == 0) goto L15
            goto L18
        L15:
            r2 = 16842897(0x1010091, float:2.3693964E-38)
        L18:
            r4.<init>(r5, r6, r2)
            java.util.HashSet r0 = new java.util.HashSet
            r0.<init>()
            r4.i = r0
            int[] r0 = cal.bag.f
            r1 = 0
            android.content.res.TypedArray r5 = r5.obtainStyledAttributes(r6, r0, r2, r1)
            r6 = 2
            java.lang.CharSequence[] r6 = r5.getTextArray(r6)
            if (r6 != 0) goto L34
            java.lang.CharSequence[] r6 = r5.getTextArray(r1)
        L34:
            r4.g = r6
            r6 = 3
            java.lang.CharSequence[] r6 = r5.getTextArray(r6)
            if (r6 != 0) goto L41
            java.lang.CharSequence[] r6 = r5.getTextArray(r3)
        L41:
            r4.h = r6
            r5.recycle()
            return
        */
        throw new UnsupportedOperationException("Method not decompiled: androidx.preference.MultiSelectListPreference.<init>(android.content.Context, android.util.AttributeSet):void");
    }

    @Override // androidx.preference.Preference
    protected final Parcelable bk() {
        this.M = true;
        AbsSavedState absSavedState = ayz.EMPTY_STATE;
        if (this.B) {
            return absSavedState;
        }
        ayu ayuVar = new ayu(absSavedState);
        ayuVar.a = this.i;
        return ayuVar;
    }

    @Override // androidx.preference.Preference
    protected final Object f(TypedArray typedArray, int i) {
        CharSequence[] textArray = typedArray.getTextArray(i);
        HashSet hashSet = new HashSet();
        for (CharSequence charSequence : textArray) {
            hashSet.add(charSequence.toString());
        }
        return hashSet;
    }

    @Override // androidx.preference.Preference
    protected final void g(Parcelable parcelable) {
        if (!parcelable.getClass().equals(ayu.class)) {
            this.M = true;
            if (parcelable == ayz.EMPTY_STATE) {
                return;
            } else {
                throw new IllegalArgumentException("Wrong state class -- expecting Preference State");
            }
        }
        ayu ayuVar = (ayu) parcelable;
        Parcelable superState = ayuVar.getSuperState();
        this.M = true;
        if (superState != ayz.EMPTY_STATE && superState != null) {
            throw new IllegalArgumentException("Wrong state class -- expecting Preference State");
        }
        Set set = ayuVar.a;
        this.i.clear();
        this.i.addAll(set);
        D(set);
        d();
    }

    @Override // androidx.preference.Preference
    protected final void h(Object obj) {
        Set q = q((Set) obj);
        this.i.clear();
        this.i.addAll(q);
        D(q);
        d();
    }
}
