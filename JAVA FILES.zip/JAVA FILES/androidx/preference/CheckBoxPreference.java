package androidx.preference;

import android.R;
import android.view.View;
import android.view.accessibility.AccessibilityManager;
import android.widget.Checkable;
import android.widget.CompoundButton;
import cal.ayf;
import cal.baf;

/* compiled from: PG */
/* loaded from: classes.dex */
public class CheckBoxPreference extends TwoStatePreference {
    private final ayf e;

    /* JADX WARN: Illegal instructions before constructor call */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct code enable 'Show inconsistent code' option in preferences
    */
    public CheckBoxPreference(android.content.Context r5, android.util.AttributeSet r6) {
        /*
            r4 = this;
            android.util.TypedValue r0 = new android.util.TypedValue
            r0.<init>()
            android.content.res.Resources$Theme r1 = r5.getTheme()
            r2 = 2130968842(0x7f04010a, float:1.754635E38)
            r3 = 1
            r1.resolveAttribute(r2, r0, r3)
            int r0 = r0.resourceId
            if (r0 == 0) goto L15
            goto L18
        L15:
            r2 = 16842895(0x101008f, float:2.369396E-38)
        L18:
            r4.<init>(r5, r6, r2)
            cal.ayf r0 = new cal.ayf
            r0.<init>(r4)
            r4.e = r0
            int[] r0 = cal.bag.b
            r1 = 0
            android.content.res.TypedArray r5 = r5.obtainStyledAttributes(r6, r0, r2, r1)
            r6 = 5
            java.lang.String r6 = r5.getString(r6)
            if (r6 != 0) goto L34
            java.lang.String r6 = r5.getString(r1)
        L34:
            r4.b = r6
            boolean r6 = r4.a
            if (r6 == 0) goto L3d
            r4.d()
        L3d:
            r6 = 4
            java.lang.String r6 = r5.getString(r6)
            if (r6 != 0) goto L48
            java.lang.String r6 = r5.getString(r3)
        L48:
            r4.c = r6
            boolean r6 = r4.a
            if (r6 != 0) goto L51
            r4.d()
        L51:
            r6 = 2
            boolean r6 = r5.getBoolean(r6, r1)
            r0 = 3
            boolean r6 = r5.getBoolean(r0, r6)
            r4.d = r6
            r5.recycle()
            return
        */
        throw new UnsupportedOperationException("Method not decompiled: androidx.preference.CheckBoxPreference.<init>(android.content.Context, android.util.AttributeSet):void");
    }

    /* JADX WARN: Multi-variable type inference failed */
    private final void E(View view) {
        boolean z = view instanceof CompoundButton;
        if (z) {
            ((CompoundButton) view).setOnCheckedChangeListener(null);
        }
        if (view instanceof Checkable) {
            ((Checkable) view).setChecked(this.a);
        }
        if (z) {
            ((CompoundButton) view).setOnCheckedChangeListener(this.e);
        }
    }

    @Override // androidx.preference.Preference
    public final void b(View view) {
        x();
        if (!((AccessibilityManager) this.j.getSystemService("accessibility")).isEnabled()) {
            return;
        }
        E(view.findViewById(R.id.checkbox));
        n(view.findViewById(R.id.summary));
    }

    @Override // androidx.preference.Preference
    public final void cL(baf bafVar) {
        super.cL(bafVar);
        E(bafVar.g(R.id.checkbox));
        n(bafVar.g(R.id.summary));
    }
}
