package androidx.preference;

import cal.baa;

/* compiled from: PG */
/* loaded from: classes.dex */
public final class PreferenceScreen extends PreferenceGroup {
    public final boolean d;

    /* JADX WARN: Illegal instructions before constructor call */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct code enable 'Show inconsistent code' option in preferences
    */
    public PreferenceScreen(android.content.Context r5, android.util.AttributeSet r6) {
        /*
            r4 = this;
            android.util.TypedValue r0 = new android.util.TypedValue
            r0.<init>()
            android.content.res.Resources$Theme r1 = r5.getTheme()
            r2 = 2130969879(0x7f040517, float:1.7548452E38)
            r3 = 1
            r1.resolveAttribute(r2, r0, r3)
            int r0 = r0.resourceId
            if (r0 == 0) goto L15
            goto L18
        L15:
            r2 = 16842891(0x101008b, float:2.3693948E-38)
        L18:
            r4.<init>(r5, r6, r2)
            r4.d = r3
            return
        */
        throw new UnsupportedOperationException("Method not decompiled: androidx.preference.PreferenceScreen.<init>(android.content.Context, android.util.AttributeSet):void");
    }

    @Override // androidx.preference.PreferenceGroup
    public final boolean E() {
        return false;
    }

    @Override // androidx.preference.Preference
    protected final void c() {
        baa baaVar;
        if (this.v == null && this.w == null && ((PreferenceGroup) this).b.size() != 0 && (baaVar = this.k.h) != null) {
            baaVar.onNavigateToScreen(this);
        }
    }
}
