package androidx.preference;

import android.content.Context;
import android.content.res.TypedArray;
import android.support.v7.widget.SwitchCompat;
import android.text.method.TransformationMethod;
import android.util.AttributeSet;
import android.view.View;
import android.view.accessibility.AccessibilityManager;
import android.widget.Checkable;
import cal.arv;
import cal.atf;
import cal.atg;
import cal.atk;
import cal.baf;
import cal.bag;
import cal.bam;
import cal.mm;
import com.google.android.calendar.R;

/* compiled from: PG */
/* loaded from: classes.dex */
public class SwitchPreferenceCompat extends TwoStatePreference {
    private final bam e;
    private final CharSequence f;
    private final CharSequence g;

    public SwitchPreferenceCompat(Context context, AttributeSet attributeSet) {
        super(context, attributeSet, R.attr.switchPreferenceCompatStyle);
        this.e = new bam(this);
        TypedArray obtainStyledAttributes = context.obtainStyledAttributes(attributeSet, bag.m, R.attr.switchPreferenceCompatStyle, 0);
        String string = obtainStyledAttributes.getString(7);
        ((TwoStatePreference) this).b = string == null ? obtainStyledAttributes.getString(0) : string;
        if (((TwoStatePreference) this).a) {
            d();
        }
        String string2 = obtainStyledAttributes.getString(6);
        ((TwoStatePreference) this).c = string2 == null ? obtainStyledAttributes.getString(1) : string2;
        if (!((TwoStatePreference) this).a) {
            d();
        }
        String string3 = obtainStyledAttributes.getString(9);
        this.f = string3 == null ? obtainStyledAttributes.getString(3) : string3;
        d();
        String string4 = obtainStyledAttributes.getString(8);
        this.g = string4 == null ? obtainStyledAttributes.getString(4) : string4;
        d();
        ((TwoStatePreference) this).d = obtainStyledAttributes.getBoolean(5, obtainStyledAttributes.getBoolean(2, false));
        obtainStyledAttributes.recycle();
    }

    /* JADX WARN: Multi-variable type inference failed */
    private final void E(View view) {
        boolean z = view instanceof SwitchCompat;
        if (z) {
            ((SwitchCompat) view).setOnCheckedChangeListener(null);
        }
        if (view instanceof Checkable) {
            ((Checkable) view).setChecked(this.a);
        }
        if (z) {
            SwitchCompat switchCompat = (SwitchCompat) view;
            CharSequence charSequence = this.f;
            switchCompat.i = charSequence;
            if (switchCompat.t == null) {
                switchCompat.t = new mm(switchCompat);
            }
            mm mmVar = switchCompat.t;
            TransformationMethod transformationMethod = switchCompat.r;
            atf atfVar = mmVar.a.a;
            if (arv.b != null && ((atg) atfVar).a.b) {
                transformationMethod = new atk(transformationMethod);
            }
            if (transformationMethod != null) {
                charSequence = transformationMethod.getTransformation(charSequence, switchCompat);
            }
            switchCompat.j = charSequence;
            switchCompat.p = null;
            if (switchCompat.m) {
                switchCompat.h();
            }
            switchCompat.requestLayout();
            if (switchCompat.isChecked()) {
                switchCompat.d();
            }
            CharSequence charSequence2 = this.g;
            switchCompat.k = charSequence2;
            if (switchCompat.t == null) {
                switchCompat.t = new mm(switchCompat);
            }
            mm mmVar2 = switchCompat.t;
            TransformationMethod transformationMethod2 = switchCompat.r;
            atf atfVar2 = mmVar2.a.a;
            if (arv.b != null && ((atg) atfVar2).a.b) {
                transformationMethod2 = new atk(transformationMethod2);
            }
            if (transformationMethod2 != null) {
                charSequence2 = transformationMethod2.getTransformation(charSequence2, switchCompat);
            }
            switchCompat.l = charSequence2;
            switchCompat.q = null;
            if (switchCompat.m) {
                switchCompat.h();
            }
            switchCompat.requestLayout();
            if (!switchCompat.isChecked()) {
                switchCompat.c();
            }
            switchCompat.setOnCheckedChangeListener(this.e);
        }
    }

    @Override // androidx.preference.Preference
    public final void b(View view) {
        x();
        if (!((AccessibilityManager) this.j.getSystemService("accessibility")).isEnabled()) {
            return;
        }
        E(view.findViewById(R.id.switchWidget));
        n(view.findViewById(android.R.id.summary));
    }

    @Override // androidx.preference.Preference
    public final void cL(baf bafVar) {
        super.cL(bafVar);
        E(bafVar.g(R.id.switchWidget));
        n(bafVar.g(android.R.id.summary));
    }
}
