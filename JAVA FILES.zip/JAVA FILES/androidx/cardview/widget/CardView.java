package androidx.cardview.widget;

import android.R;
import android.content.Context;
import android.content.res.ColorStateList;
import android.content.res.TypedArray;
import android.graphics.Color;
import android.graphics.Rect;
import android.graphics.drawable.Drawable;
import android.os.Build;
import android.util.AttributeSet;
import android.widget.FrameLayout;
import cal.aao;
import cal.aap;
import cal.aaq;
import cal.aar;
import cal.alz;

/* compiled from: PG */
/* loaded from: classes.dex */
public class CardView extends FrameLayout {
    private static final int[] f = {R.attr.colorBackground};
    public boolean a;
    public boolean b;
    public final Rect c;
    public final Rect d;
    public final aap e;

    public CardView(Context context) {
        this(context, null);
    }

    public void setCardBackgroundColor(int i) {
        aap aapVar = this.e;
        ColorStateList valueOf = ColorStateList.valueOf(i);
        aar aarVar = (aar) aapVar.a;
        aarVar.a(valueOf);
        aarVar.invalidateSelf();
    }

    public void setCardElevation(float f2) {
        this.e.b.setElevation(f2);
    }

    public void setMaxCardElevation(float f2) {
        aap aapVar = this.e;
        CardView cardView = aapVar.b;
        ((aar) aapVar.a).b(f2, cardView.a, cardView.b);
        aaq.a(aapVar);
    }

    @Override // android.view.View
    public void setMinimumHeight(int i) {
        super.setMinimumHeight(i);
    }

    @Override // android.view.View
    public void setMinimumWidth(int i) {
        super.setMinimumWidth(i);
    }

    public void setRadius(float f2) {
        aar aarVar = (aar) this.e.a;
        if (f2 == aarVar.a) {
            return;
        }
        aarVar.a = f2;
        aarVar.c(null);
        aarVar.invalidateSelf();
    }

    public CardView(Context context, AttributeSet attributeSet) {
        this(context, attributeSet, com.google.android.calendar.R.attr.cardViewStyle);
    }

    public CardView(Context context, AttributeSet attributeSet, int i) {
        super(context, attributeSet, i);
        int color;
        ColorStateList valueOf;
        Rect rect = new Rect();
        this.c = rect;
        this.d = new Rect();
        aap aapVar = new aap(this);
        this.e = aapVar;
        TypedArray obtainStyledAttributes = context.obtainStyledAttributes(attributeSet, aao.a, i, com.google.android.calendar.R.style.CardView);
        int i2 = Build.VERSION.SDK_INT;
        int[] iArr = aao.a;
        if (i2 >= 29) {
            alz.b(this, context, iArr, attributeSet, obtainStyledAttributes, i, com.google.android.calendar.R.style.CardView);
        }
        if (obtainStyledAttributes.hasValue(2)) {
            valueOf = obtainStyledAttributes.getColorStateList(2);
        } else {
            TypedArray obtainStyledAttributes2 = getContext().obtainStyledAttributes(f);
            int color2 = obtainStyledAttributes2.getColor(0, 0);
            obtainStyledAttributes2.recycle();
            float[] fArr = new float[3];
            Color.colorToHSV(color2, fArr);
            if (fArr[2] > 0.5f) {
                color = getResources().getColor(com.google.android.calendar.R.color.cardview_light_background);
            } else {
                color = getResources().getColor(com.google.android.calendar.R.color.cardview_dark_background);
            }
            valueOf = ColorStateList.valueOf(color);
        }
        float dimension = obtainStyledAttributes.getDimension(3, 0.0f);
        float dimension2 = obtainStyledAttributes.getDimension(4, 0.0f);
        float dimension3 = obtainStyledAttributes.getDimension(5, 0.0f);
        this.a = obtainStyledAttributes.getBoolean(7, false);
        this.b = obtainStyledAttributes.getBoolean(6, true);
        int dimensionPixelSize = obtainStyledAttributes.getDimensionPixelSize(8, 0);
        rect.left = obtainStyledAttributes.getDimensionPixelSize(10, dimensionPixelSize);
        rect.top = obtainStyledAttributes.getDimensionPixelSize(12, dimensionPixelSize);
        rect.right = obtainStyledAttributes.getDimensionPixelSize(11, dimensionPixelSize);
        rect.bottom = obtainStyledAttributes.getDimensionPixelSize(9, dimensionPixelSize);
        dimension3 = dimension2 > dimension3 ? dimension2 : dimension3;
        obtainStyledAttributes.getDimensionPixelSize(0, 0);
        obtainStyledAttributes.getDimensionPixelSize(1, 0);
        obtainStyledAttributes.recycle();
        aar aarVar = new aar(valueOf, dimension);
        aapVar.a = aarVar;
        aapVar.b.setBackgroundDrawable(aarVar);
        CardView cardView = aapVar.b;
        cardView.setClipToOutline(true);
        cardView.setElevation(dimension2);
        Drawable drawable = aapVar.a;
        CardView cardView2 = aapVar.b;
        ((aar) drawable).b(dimension3, cardView2.a, cardView2.b);
        aaq.a(aapVar);
    }

    @Override // android.view.View
    public final void setPadding(int i, int i2, int i3, int i4) {
    }

    @Override // android.view.View
    public final void setPaddingRelative(int i, int i2, int i3, int i4) {
    }
}
