package androidx.room.coroutines;

/* compiled from: PG */
/* loaded from: classes.dex */
public final class ConnectionPool$RollbackException extends Throwable {
}
