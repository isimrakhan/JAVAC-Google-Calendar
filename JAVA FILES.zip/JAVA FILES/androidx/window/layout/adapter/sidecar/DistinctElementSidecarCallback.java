package androidx.window.layout.adapter.sidecar;

import androidx.window.sidecar.SidecarDeviceState;
import androidx.window.sidecar.SidecarInterface;
import cal.bor;
import cal.bow;
import java.util.Map;
import java.util.WeakHashMap;

/* compiled from: PG */
/* loaded from: classes.dex */
public class DistinctElementSidecarCallback implements SidecarInterface.SidecarCallback {
    private SidecarDeviceState b;
    private final SidecarInterface.SidecarCallback d;
    private final Object a = new Object();
    private final Map c = new WeakHashMap();

    public DistinctElementSidecarCallback(SidecarInterface.SidecarCallback sidecarCallback, byte[] bArr) {
        this.d = sidecarCallback;
    }

    public void onDeviceStateChanged(SidecarDeviceState sidecarDeviceState) {
        if (sidecarDeviceState == null) {
            return;
        }
        synchronized (this.a) {
            SidecarDeviceState sidecarDeviceState2 = this.b;
            if (sidecarDeviceState2 != null && sidecarDeviceState2.equals(sidecarDeviceState)) {
                return;
            }
            int a = bor.a(sidecarDeviceState2);
            int i = 0;
            if (a < 0 || a > 4) {
                a = 0;
            }
            int a2 = bor.a(sidecarDeviceState);
            if (a2 >= 0 && a2 <= 4) {
                i = a2;
            }
            this.b = sidecarDeviceState;
            this.d.onDeviceStateChanged(sidecarDeviceState);
        }
    }

    /* JADX WARN: Removed duplicated region for block: B:19:0x0027 A[Catch: all -> 0x0083, TryCatch #0 {, blocks: (B:4:0x0003, B:8:0x0075, B:13:0x0077, B:14:0x0081, B:17:0x001d, B:19:0x0027, B:21:0x0031, B:23:0x0038, B:28:0x0072, B:31:0x0054, B:33:0x005e, B:39:0x006b, B:47:0x0049, B:52:0x0011), top: B:3:0x0003 }] */
    /* JADX WARN: Removed duplicated region for block: B:35:0x0068  */
    /* JADX WARN: Removed duplicated region for block: B:39:0x006b A[Catch: all -> 0x0083, TryCatch #0 {, blocks: (B:4:0x0003, B:8:0x0075, B:13:0x0077, B:14:0x0081, B:17:0x001d, B:19:0x0027, B:21:0x0031, B:23:0x0038, B:28:0x0072, B:31:0x0054, B:33:0x005e, B:39:0x006b, B:47:0x0049, B:52:0x0011), top: B:3:0x0003 }] */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct code enable 'Show inconsistent code' option in preferences
    */
    public void onWindowLayoutChanged(android.os.IBinder r10, androidx.window.sidecar.SidecarWindowLayoutInfo r11) {
        /*
            r9 = this;
            java.lang.Object r0 = r9.a
            monitor-enter(r0)
            java.util.Map r1 = r9.c     // Catch: java.lang.Throwable -> L83
            java.lang.Object r1 = r1.get(r10)     // Catch: java.lang.Throwable -> L83
            androidx.window.sidecar.SidecarWindowLayoutInfo r1 = (androidx.window.sidecar.SidecarWindowLayoutInfo) r1     // Catch: java.lang.Throwable -> L83
            if (r1 != 0) goto L11
            if (r11 != 0) goto L18
            goto L75
        L11:
            boolean r2 = r1.equals(r11)     // Catch: java.lang.Throwable -> L83
            if (r2 == 0) goto L18
            goto L75
        L18:
            if (r1 != 0) goto L1b
            goto L77
        L1b:
            if (r11 == 0) goto L77
            java.util.List r1 = cal.bor.b(r1)     // Catch: java.lang.Throwable -> L83
            java.util.List r2 = cal.bor.b(r11)     // Catch: java.lang.Throwable -> L83
            if (r1 == r2) goto L75
            int r3 = r1.size()     // Catch: java.lang.Throwable -> L83
            int r4 = r2.size()     // Catch: java.lang.Throwable -> L83
            if (r3 != r4) goto L77
            int r3 = r1.size()     // Catch: java.lang.Throwable -> L83
            r4 = 0
        L36:
            if (r4 >= r3) goto L75
            java.lang.Object r5 = r1.get(r4)     // Catch: java.lang.Throwable -> L83
            androidx.window.sidecar.SidecarDisplayFeature r5 = (androidx.window.sidecar.SidecarDisplayFeature) r5     // Catch: java.lang.Throwable -> L83
            java.lang.Object r6 = r2.get(r4)     // Catch: java.lang.Throwable -> L83
            androidx.window.sidecar.SidecarDisplayFeature r6 = (androidx.window.sidecar.SidecarDisplayFeature) r6     // Catch: java.lang.Throwable -> L83
            if (r5 != 0) goto L49
            if (r6 != 0) goto L50
            goto L72
        L49:
            boolean r7 = r5.equals(r6)     // Catch: java.lang.Throwable -> L83
            if (r7 == 0) goto L50
            goto L72
        L50:
            if (r5 == 0) goto L77
            if (r6 == 0) goto L77
            int r7 = r5.getType()     // Catch: java.lang.Throwable -> L83
            int r8 = r6.getType()     // Catch: java.lang.Throwable -> L83
            if (r7 != r8) goto L77
            android.graphics.Rect r5 = r5.getRect()     // Catch: java.lang.Throwable -> L83
            android.graphics.Rect r6 = r6.getRect()     // Catch: java.lang.Throwable -> L83
            if (r5 != 0) goto L6b
            if (r6 != 0) goto L77
            goto L72
        L6b:
            boolean r5 = r5.equals(r6)     // Catch: java.lang.Throwable -> L83
            if (r5 != 0) goto L72
            goto L77
        L72:
            int r4 = r4 + 1
            goto L36
        L75:
            monitor-exit(r0)     // Catch: java.lang.Throwable -> L83
            return
        L77:
            java.util.Map r1 = r9.c     // Catch: java.lang.Throwable -> L83
            r1.put(r10, r11)     // Catch: java.lang.Throwable -> L83
            androidx.window.sidecar.SidecarInterface$SidecarCallback r1 = r9.d     // Catch: java.lang.Throwable -> L83
            r1.onWindowLayoutChanged(r10, r11)     // Catch: java.lang.Throwable -> L83
            monitor-exit(r0)     // Catch: java.lang.Throwable -> L83
            return
        L83:
            r10 = move-exception
            monitor-exit(r0)     // Catch: java.lang.Throwable -> L83
            throw r10
        */
        throw new UnsupportedOperationException("Method not decompiled: androidx.window.layout.adapter.sidecar.DistinctElementSidecarCallback.onWindowLayoutChanged(android.os.IBinder, androidx.window.sidecar.SidecarWindowLayoutInfo):void");
    }

    public DistinctElementSidecarCallback(SidecarInterface.SidecarCallback sidecarCallback) {
        int i = bow.a;
        this.d = sidecarCallback;
    }
}
