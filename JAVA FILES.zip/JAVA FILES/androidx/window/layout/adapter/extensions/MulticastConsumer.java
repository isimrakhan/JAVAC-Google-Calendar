package androidx.window.layout.adapter.extensions;

import android.content.Context;
import androidx.window.extensions.layout.WindowLayoutInfo;
import cal.akc;
import cal.boe;
import cal.bon;
import java.util.Iterator;
import java.util.LinkedHashSet;
import java.util.Set;
import java.util.concurrent.locks.ReentrantLock;

/* compiled from: PG */
/* loaded from: classes.dex */
public final class MulticastConsumer implements akc<WindowLayoutInfo> {
    public final ReentrantLock a = new ReentrantLock();
    public final Set b = new LinkedHashSet();
    private final Context c;
    private boe d;

    public MulticastConsumer(Context context) {
        this.c = context;
    }

    public final void a(akc akcVar) {
        ReentrantLock reentrantLock = this.a;
        reentrantLock.lock();
        try {
            boe boeVar = this.d;
            if (boeVar != null) {
                akcVar.accept(boeVar);
            }
            this.b.add(akcVar);
        } finally {
            reentrantLock.unlock();
        }
    }

    @Override // cal.akc
    public void accept(WindowLayoutInfo windowLayoutInfo) {
        windowLayoutInfo.getClass();
        ReentrantLock reentrantLock = this.a;
        reentrantLock.lock();
        try {
            boe b = bon.b(this.c, windowLayoutInfo);
            this.d = b;
            Iterator it = this.b.iterator();
            while (it.hasNext()) {
                ((akc) it.next()).accept(b);
            }
        } finally {
            reentrantLock.unlock();
        }
    }
}
