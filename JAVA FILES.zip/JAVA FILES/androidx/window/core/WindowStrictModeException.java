package androidx.window.core;

/* compiled from: PG */
/* loaded from: classes.dex */
public final class WindowStrictModeException extends Exception {
    public WindowStrictModeException(String str) {
        super(str);
    }
}
