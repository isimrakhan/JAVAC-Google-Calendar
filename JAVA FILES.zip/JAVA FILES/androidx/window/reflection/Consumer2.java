package androidx.window.reflection;

import androidx.window.extensions.core.util.function.Consumer;

/* compiled from: PG */
/* loaded from: classes.dex */
public interface Consumer2<T> extends Consumer<T> {
    @Override // androidx.window.extensions.core.util.function.Consumer
    void accept(T t);
}
