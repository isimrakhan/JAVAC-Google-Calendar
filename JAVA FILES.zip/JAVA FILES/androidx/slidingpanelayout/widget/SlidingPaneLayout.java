package androidx.slidingpanelayout.widget;

import android.content.Context;
import android.content.res.TypedArray;
import android.graphics.Canvas;
import android.graphics.Rect;
import android.graphics.drawable.Drawable;
import android.os.Build;
import android.os.Handler;
import android.os.Parcelable;
import android.util.AttributeSet;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup;
import cal.a;
import cal.ahr;
import cal.ais;
import cal.alv;
import cal.alz;
import cal.ame;
import cal.anq;
import cal.apv;
import cal.apzs;
import cal.aqdp;
import cal.aqhr;
import cal.aqiy;
import cal.aqiz;
import cal.aqkh;
import cal.aqln;
import cal.aqlp;
import cal.bgi;
import cal.bgj;
import cal.bgl;
import cal.bgm;
import cal.bgn;
import cal.bgo;
import cal.bgp;
import cal.bgq;
import cal.bgs;
import cal.bgu;
import cal.bgv;
import cal.bgw;
import cal.bgx;
import cal.bhc;
import cal.bni;
import cal.bnu;
import com.google.android.calendar.R;
import java.util.Collections;
import java.util.List;

/* compiled from: PG */
/* loaded from: classes.dex */
public class SlidingPaneLayout extends ViewGroup {
    public static final bgw a = new bgm();
    public static final bgw b = new bgn();
    private final Rect A;
    private final Rect B;
    private final bgj C;
    private aqkh D;
    private boolean E;
    private final Rect F;
    private final Rect G;
    private final List H;
    public boolean c;
    public View d;
    public float e;
    public int f;
    public final bgq g;
    public final bgo h;
    public boolean i;
    public int j;
    public int k;
    public final bnu l;
    public Drawable m;
    public int n;
    public boolean o;
    public boolean p;
    public View.OnClickListener q;
    public bgw r;
    public bni s;
    private Drawable t;
    private Drawable u;
    private float v;
    private final int w;
    private final MotionEvent x;
    private bgv y;
    private boolean z;

    /* JADX WARN: 'this' call moved to the top of the method (can break code semantics) */
    public SlidingPaneLayout(Context context) {
        this(context, null, 0, 6, null);
        context.getClass();
    }

    private final void m(int i) {
        if (i < 0) {
            this.F.setEmpty();
        } else {
            k(this.F, i);
        }
        Rect rect = this.F;
        Rect rect2 = this.G;
        if (rect == null) {
            if (rect2 == null) {
                return;
            }
        } else if (rect.equals(rect2)) {
            return;
        }
        if (this.F.isEmpty()) {
            int i2 = Build.VERSION.SDK_INT;
            apzs apzsVar = apzs.a;
            if (i2 >= 29) {
                alz.c(this, apzsVar);
                return;
            }
            return;
        }
        this.G.set(this.F);
        List list = this.H;
        if (Build.VERSION.SDK_INT >= 29) {
            alz.c(this, list);
        }
    }

    /* JADX WARN: Code restructure failed: missing block: B:10:0x0016, code lost:
    
        if (r9.h.a != false) goto L13;
     */
    /* JADX WARN: Code restructure failed: missing block: B:11:0x0018, code lost:
    
        return r10;
     */
    /* JADX WARN: Code restructure failed: missing block: B:8:0x000c, code lost:
    
        if (r1 >= 0) goto L13;
     */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct code enable 'Show inconsistent code' option in preferences
    */
    private final int[] n(int[] r10) {
        /*
            r9 = this;
            r0 = 0
            r1 = r0
        L2:
            int r2 = r10.length
            r3 = 16842919(0x10100a7, float:2.3694026E-38)
            if (r1 >= r2) goto L12
            r4 = r10[r1]
            if (r4 != r3) goto Lf
            if (r1 < 0) goto L12
            goto L19
        Lf:
            int r1 = r1 + 1
            goto L2
        L12:
            cal.bgo r1 = r9.h
            boolean r1 = r1.a
            if (r1 != 0) goto L19
            return r10
        L19:
            cal.bgo r1 = r9.h
            boolean r1 = r1.a
            r4 = 1
            if (r1 == 0) goto L2e
            int r2 = r2 + r4
            int[] r10 = java.util.Arrays.copyOf(r10, r2)
            r10.getClass()
            int r0 = r10.length
            int r0 = r0 + (-1)
            r10[r0] = r3
            goto L4d
        L2e:
            int r2 = r2 + (-1)
            int[] r1 = new int[r2]
            r5 = r0
            r6 = r5
        L34:
            if (r5 >= r2) goto L4c
            int r7 = r5 + 1
            r8 = r10[r5]
            if (r8 != r3) goto L3e
            r8 = r0
            goto L3f
        L3e:
            r8 = r4
        L3f:
            r8 = r8 ^ r4
            r6 = r6 | r8
            if (r4 == r6) goto L45
            r8 = r5
            goto L46
        L45:
            r8 = r7
        L46:
            r8 = r10[r8]
            r1[r5] = r8
            r5 = r7
            goto L34
        L4c:
            r10 = r1
        L4d:
            return r10
        */
        throw new UnsupportedOperationException("Method not decompiled: androidx.slidingpanelayout.widget.SlidingPaneLayout.n(int[]):int[]");
    }

    private final boolean o(float f) {
        View view;
        int paddingLeft;
        if (this.c && (view = this.d) != null) {
            int layoutDirection = getLayoutDirection();
            ViewGroup.LayoutParams layoutParams = view.getLayoutParams();
            layoutParams.getClass();
            bgp bgpVar = (bgp) layoutParams;
            if (layoutDirection == 1) {
                paddingLeft = (int) (getWidth() - (((getPaddingRight() + bgpVar.rightMargin) + (f * this.f)) + view.getWidth()));
            } else {
                paddingLeft = (int) (getPaddingLeft() + bgpVar.leftMargin + (f * this.f));
            }
            if (this.g.c.j(view, paddingLeft, view.getTop())) {
                d();
                postInvalidateOnAnimation();
                return true;
            }
            return false;
        }
        return false;
    }

    public final int a() {
        View childAt;
        View childAt2;
        if (this.c || !this.o || this.m == null) {
            return -1;
        }
        bgo bgoVar = this.h;
        if (bgoVar.a) {
            return bgoVar.b;
        }
        int i = this.n;
        if (i < 0) {
            if (getLayoutDirection() == 1) {
                childAt = getChildAt(1);
                childAt.getClass();
                childAt2 = getChildAt(0);
                childAt2.getClass();
            } else {
                childAt = getChildAt(0);
                childAt.getClass();
                childAt2 = getChildAt(1);
                childAt2.getClass();
            }
            int right = childAt.getRight();
            ViewGroup.LayoutParams layoutParams = childAt.getLayoutParams();
            layoutParams.getClass();
            int left = right + ((bgp) layoutParams).rightMargin + childAt2.getLeft();
            ViewGroup.LayoutParams layoutParams2 = childAt2.getLayoutParams();
            layoutParams2.getClass();
            return (left - ((bgp) layoutParams2).leftMargin) / 2;
        }
        return i;
    }

    @Override // android.view.ViewGroup
    public final void addView(View view, int i, ViewGroup.LayoutParams layoutParams) {
        view.getClass();
        if (getChildCount() == 1) {
            super.addView(new bgu(this, view), i, layoutParams);
        } else {
            super.addView(view, i, layoutParams);
        }
    }

    public final bgv b() {
        bgv bgvVar;
        if (this.c) {
            bgvVar = this.g;
        } else if (this.o && this.m != null) {
            bgvVar = this.h;
        } else {
            bgvVar = null;
        }
        bgv bgvVar2 = this.y;
        if (bgvVar2 != null ? !bgvVar2.equals(bgvVar) : bgvVar != null) {
            bgv bgvVar3 = this.y;
            if (bgvVar3 != null) {
                MotionEvent motionEvent = this.x;
                motionEvent.getClass();
                bgvVar3.h(motionEvent);
            }
            this.y = bgvVar;
        }
        return this.y;
    }

    public final void c(float f) {
        int layoutDirection = getLayoutDirection();
        int childCount = getChildCount();
        for (int i = 0; i < childCount; i++) {
            View childAt = getChildAt(i);
            if (childAt != this.d) {
                float f2 = 1.0f - this.v;
                float f3 = this.k;
                this.v = f;
                int i2 = ((int) (f2 * f3)) - ((int) ((1.0f - f) * f3));
                if (layoutDirection == 1) {
                    i2 = -i2;
                }
                childAt.offsetLeftAndRight(i2);
            }
        }
    }

    @Override // android.view.ViewGroup
    public final boolean checkLayoutParams(ViewGroup.LayoutParams layoutParams) {
        if ((layoutParams instanceof bgp) && super.checkLayoutParams(layoutParams)) {
            return true;
        }
        return false;
    }

    @Override // android.view.View
    public final void computeScroll() {
        bgq bgqVar = this.g;
        if (bgqVar.c.l()) {
            SlidingPaneLayout slidingPaneLayout = bgqVar.d;
            if (!slidingPaneLayout.c) {
                bgqVar.c.b();
            } else {
                slidingPaneLayout.postInvalidateOnAnimation();
            }
        }
    }

    public final void d() {
        int childCount = getChildCount();
        for (int i = 0; i < childCount; i++) {
            View childAt = getChildAt(i);
            childAt.getClass();
            if (childAt.getVisibility() == 4) {
                childAt.setVisibility(0);
            }
        }
    }

    @Override // android.view.View
    public final void draw(Canvas canvas) {
        Drawable drawable;
        View view;
        Drawable drawable2;
        int i;
        int i2;
        canvas.getClass();
        super.draw(canvas);
        if (getLayoutDirection() == 1) {
            drawable = this.u;
        } else {
            drawable = this.t;
        }
        Drawable drawable3 = null;
        if (getChildCount() > 1) {
            view = getChildAt(1);
        } else {
            view = null;
        }
        if (view != null && drawable != null) {
            int top = view.getTop();
            int bottom = view.getBottom();
            int intrinsicWidth = drawable.getIntrinsicWidth();
            if (getLayoutDirection() == 1) {
                i2 = view.getRight();
                i = intrinsicWidth + i2;
            } else {
                int left = view.getLeft();
                int i3 = left - intrinsicWidth;
                i = left;
                i2 = i3;
            }
            drawable.setBounds(i2, top, i, bottom);
            drawable.draw(canvas);
        }
        Drawable drawable4 = this.m;
        if (drawable4 != null) {
            if (!this.c && this.o) {
                drawable3 = drawable4;
            }
            if (drawable3 != null) {
                int a2 = a();
                if (getWidth() > 0 && getHeight() > 0 && (drawable2 = this.m) != null) {
                    int height = (((getHeight() - getPaddingTop()) - getPaddingBottom()) / 2) + getPaddingTop();
                    int intrinsicWidth2 = a2 - (drawable2.getIntrinsicWidth() / 2);
                    int intrinsicHeight = height - (drawable2.getIntrinsicHeight() / 2);
                    drawable2.setBounds(intrinsicWidth2, intrinsicHeight, drawable2.getIntrinsicWidth() + intrinsicWidth2, drawable2.getIntrinsicHeight() + intrinsicHeight);
                }
                drawable3.draw(canvas);
            }
        }
    }

    @Override // android.view.ViewGroup
    protected final boolean drawChild(Canvas canvas, View view, long j) {
        int a2;
        boolean z;
        boolean z2;
        boolean z3;
        int i;
        int i2;
        anq a3;
        canvas.getClass();
        view.getClass();
        boolean z4 = false;
        if (this.c) {
            ahr ahrVar = null;
            if (bhc.a && (a3 = alv.a(this)) != null) {
                ahrVar = a3.b.r();
            }
            if (getLayoutDirection() == 1) {
                z2 = true;
            } else {
                z2 = false;
            }
            if (this.c && this.e != 0.0f) {
                z3 = false;
            } else {
                z3 = true;
            }
            if (z2 ^ z3) {
                bgq bgqVar = this.g;
                if (ahrVar != null) {
                    i2 = ahrVar.b;
                } else {
                    i2 = 0;
                }
                apv apvVar = bgqVar.c;
                apvVar.m = 1;
                int i3 = apvVar.l;
                if (i2 < i3) {
                    i2 = i3;
                }
                apvVar.k = i2;
            } else {
                bgq bgqVar2 = this.g;
                if (ahrVar != null) {
                    i = ahrVar.d;
                } else {
                    i = 0;
                }
                apv apvVar2 = bgqVar2.c;
                apvVar2.m = 2;
                int i4 = apvVar2.l;
                if (i < i4) {
                    i = i4;
                }
                apvVar2.k = i;
            }
        } else {
            this.g.c.m = 0;
        }
        ViewGroup.LayoutParams layoutParams = view.getLayoutParams();
        layoutParams.getClass();
        bgp bgpVar = (bgp) layoutParams;
        int save = canvas.save();
        if (this.c && !bgpVar.b && this.d != null) {
            canvas.getClipBounds(this.A);
            if (getLayoutDirection() == 1) {
                Rect rect = this.A;
                int i5 = rect.left;
                View view2 = this.d;
                view2.getClass();
                rect.left = Math.max(i5, view2.getRight());
            } else {
                Rect rect2 = this.A;
                int i6 = rect2.right;
                View view3 = this.d;
                view3.getClass();
                rect2.right = Math.min(i6, view3.getLeft());
            }
            canvas.clipRect(this.A);
        }
        if (!this.c && this.p && (a2 = a()) >= 0) {
            Rect rect3 = this.A;
            if (getLayoutDirection() == 1) {
                z = true;
            } else {
                z = false;
            }
            if (view == getChildAt(0)) {
                z4 = true;
            }
            if (z4 ^ z) {
                rect3.left = getPaddingLeft();
                rect3.right = a2;
            } else {
                rect3.left = a2;
                rect3.right = getWidth() - getPaddingRight();
            }
            rect3.top = getPaddingTop();
            rect3.bottom = getHeight() - getPaddingBottom();
            canvas.clipRect(this.A);
        }
        boolean drawChild = super.drawChild(canvas, view, j);
        canvas.restoreToCount(save);
        return drawChild;
    }

    @Override // android.view.View
    public final void drawableHotspotChanged(float f, float f2) {
        super.drawableHotspotChanged(f, f2);
        Drawable drawable = this.m;
        if (drawable != null) {
            drawable.setHotspot(f, f2);
        }
    }

    @Override // android.view.ViewGroup, android.view.View
    public final void drawableStateChanged() {
        super.drawableStateChanged();
        Drawable drawable = this.m;
        if (drawable != null && drawable.isStateful()) {
            int[] drawableState = getDrawableState();
            drawableState.getClass();
            if (drawable.setState(n(drawableState))) {
                invalidateDrawable(drawable);
            }
        }
    }

    public final void e(Drawable drawable) {
        boolean z;
        Drawable drawable2 = this.m;
        if (drawable != drawable2) {
            if (drawable2 != null) {
                drawable2.setCallback(null);
                unscheduleDrawable(drawable2);
            }
            this.m = drawable;
            if (drawable != null) {
                drawable.setCallback(this);
                if (drawable.isStateful()) {
                    int[] drawableState = getDrawableState();
                    drawableState.getClass();
                    drawable.setState(n(drawableState));
                }
                if (getVisibility() == 0) {
                    z = true;
                } else {
                    z = false;
                }
                drawable.setVisible(z, false);
            }
            requestLayout();
        }
    }

    public final void f(View view) {
        boolean z;
        int paddingLeft;
        int width;
        int i;
        int i2;
        int i3;
        int i4;
        boolean z2;
        int i5;
        int i6;
        int i7;
        View view2 = view;
        boolean z3 = true;
        if (getLayoutDirection() == 1) {
            z = true;
        } else {
            z = false;
        }
        if (z) {
            paddingLeft = getWidth() - getPaddingRight();
        } else {
            paddingLeft = getPaddingLeft();
        }
        if (z) {
            width = getPaddingLeft();
        } else {
            width = getWidth() - getPaddingRight();
        }
        int paddingTop = getPaddingTop();
        int height = getHeight() - getPaddingBottom();
        if (view2 != null && view.isOpaque()) {
            i = view.getLeft();
            i2 = view.getRight();
            i3 = view.getTop();
            i4 = view.getBottom();
        } else {
            i = 0;
            i2 = 0;
            i3 = 0;
            i4 = 0;
        }
        int childCount = getChildCount();
        int i8 = 0;
        while (i8 < childCount) {
            View childAt = getChildAt(i8);
            childAt.getClass();
            if (childAt != view2) {
                if (childAt.getVisibility() != 8) {
                    if (z3 != z) {
                        i5 = paddingLeft;
                    } else {
                        i5 = width;
                    }
                    int left = childAt.getLeft();
                    if (i5 < left) {
                        i5 = left;
                    }
                    int top = childAt.getTop();
                    if (paddingTop >= top) {
                        top = paddingTop;
                    }
                    if (z3 != z) {
                        z2 = z;
                        i6 = width;
                    } else {
                        z2 = z;
                        i6 = paddingLeft;
                    }
                    int right = childAt.getRight();
                    if (i6 > right) {
                        i6 = right;
                    }
                    int bottom = childAt.getBottom();
                    if (height <= bottom) {
                        bottom = height;
                    }
                    if (i5 >= i && top >= i3 && i6 <= i2 && bottom <= i4) {
                        i7 = 4;
                    } else {
                        i7 = 0;
                    }
                    childAt.setVisibility(i7);
                } else {
                    z2 = z;
                }
                i8++;
                view2 = view;
                z = z2;
                z3 = true;
            } else {
                return;
            }
        }
    }

    @Override // android.view.ViewGroup
    protected final ViewGroup.LayoutParams generateDefaultLayoutParams() {
        return new bgp();
    }

    @Override // android.view.ViewGroup
    public final ViewGroup.LayoutParams generateLayoutParams(AttributeSet attributeSet) {
        Context context = getContext();
        context.getClass();
        return new bgp(context, attributeSet);
    }

    public final boolean i(View view) {
        if (view == null) {
            return false;
        }
        ViewGroup.LayoutParams layoutParams = view.getLayoutParams();
        layoutParams.getClass();
        bgp bgpVar = (bgp) layoutParams;
        if (!this.c || !bgpVar.c || this.e <= 0.0f) {
            return false;
        }
        return true;
    }

    public final void j() {
        if (!this.c) {
            this.i = false;
        }
        if (!this.z && !o(1.0f)) {
            return;
        }
        this.i = false;
    }

    @Override // android.view.ViewGroup, android.view.View
    public final void jumpDrawablesToCurrentState() {
        super.jumpDrawablesToCurrentState();
        Drawable drawable = this.m;
        if (drawable != null) {
            drawable.jumpToCurrentState();
        }
    }

    public final void k(Rect rect, int i) {
        Drawable drawable = this.m;
        if (drawable == null) {
            rect.setEmpty();
            return;
        }
        int i2 = this.w;
        int intrinsicWidth = drawable.getIntrinsicWidth();
        int intrinsicHeight = drawable.getIntrinsicHeight();
        int max = Math.max(intrinsicWidth, i2);
        int max2 = Math.max(intrinsicHeight, i2);
        int i3 = i - (max / 2);
        int height = ((((getHeight() - getPaddingTop()) - getPaddingBottom()) / 2) + getPaddingTop()) - (max2 / 2);
        rect.set(i3, height, max + i3, max2 + height);
    }

    public final void l() {
        if (!this.c) {
            this.i = true;
        }
        if (!this.z && !o(0.0f)) {
            return;
        }
        this.i = true;
    }

    @Override // android.view.ViewGroup, android.view.View
    protected final void onAttachedToWindow() {
        super.onAttachedToWindow();
        this.z = true;
        aqkh aqkhVar = this.D;
        if (aqkhVar != null) {
            aqkhVar.s(null);
        }
    }

    @Override // android.view.ViewGroup, android.view.View
    protected final void onDetachedFromWindow() {
        aqkh aqkhVar = this.D;
        if (aqkhVar != null) {
            aqkhVar.s(null);
        }
        this.z = true;
        super.onDetachedFromWindow();
    }

    @Override // android.view.ViewGroup
    public boolean onInterceptTouchEvent(MotionEvent motionEvent) {
        motionEvent.getClass();
        bgv b2 = b();
        if (b2 != null) {
            return b2.g(motionEvent);
        }
        return false;
    }

    /* JADX WARN: Removed duplicated region for block: B:104:0x029a  */
    /* JADX WARN: Removed duplicated region for block: B:114:0x019a  */
    /* JADX WARN: Removed duplicated region for block: B:115:0x018f  */
    /* JADX WARN: Removed duplicated region for block: B:116:0x0185  */
    /* JADX WARN: Removed duplicated region for block: B:40:0x0183  */
    /* JADX WARN: Removed duplicated region for block: B:43:0x018a  */
    /* JADX WARN: Removed duplicated region for block: B:45:0x0195  */
    /* JADX WARN: Removed duplicated region for block: B:48:0x01aa  */
    /* JADX WARN: Removed duplicated region for block: B:56:0x01bb  */
    @Override // android.view.ViewGroup, android.view.View
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct code enable 'Show inconsistent code' option in preferences
    */
    protected final void onLayout(boolean r21, int r22, int r23, int r24, int r25) {
        /*
            Method dump skipped, instructions count: 688
            To view this dump change 'Code comments level' option to 'DEBUG'
        */
        throw new UnsupportedOperationException("Method not decompiled: androidx.slidingpanelayout.widget.SlidingPaneLayout.onLayout(boolean, int, int, int, int):void");
    }

    /* JADX WARN: Code restructure failed: missing block: B:136:0x027e, code lost:
    
        if (r4 != 0) goto L165;
     */
    /* JADX WARN: Code restructure failed: missing block: B:46:0x0132, code lost:
    
        if (r4 != 0) goto L75;
     */
    /* JADX WARN: Removed duplicated region for block: B:132:0x025e  */
    /* JADX WARN: Removed duplicated region for block: B:135:0x027c  */
    /* JADX WARN: Removed duplicated region for block: B:140:0x0267  */
    /* JADX WARN: Removed duplicated region for block: B:52:0x013e  */
    /* JADX WARN: Removed duplicated region for block: B:61:0x0150  */
    @Override // android.view.View
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct code enable 'Show inconsistent code' option in preferences
    */
    protected final void onMeasure(int r26, int r27) {
        /*
            Method dump skipped, instructions count: 744
            To view this dump change 'Code comments level' option to 'DEBUG'
        */
        throw new UnsupportedOperationException("Method not decompiled: androidx.slidingpanelayout.widget.SlidingPaneLayout.onMeasure(int, int):void");
    }

    @Override // android.view.View
    protected final void onRestoreInstanceState(Parcelable parcelable) {
        if (!(parcelable instanceof bgs)) {
            super.onRestoreInstanceState(parcelable);
            return;
        }
        bgs bgsVar = (bgs) parcelable;
        super.onRestoreInstanceState(bgsVar.d);
        if (bgsVar.a) {
            l();
        } else {
            j();
        }
        this.i = bgsVar.a;
        this.j = bgsVar.b;
        setSplitDividerPosition(bgsVar.e);
    }

    @Override // android.view.View
    protected final Parcelable onSaveInstanceState() {
        boolean z;
        bgs bgsVar = new bgs(super.onSaveInstanceState());
        if (this.c) {
            if (this.e == 0.0f) {
                z = true;
            } else {
                z = false;
            }
        } else {
            z = this.i;
        }
        bgsVar.a = z;
        bgsVar.b = this.j;
        bgsVar.e = this.n;
        return bgsVar;
    }

    @Override // android.view.View
    protected final void onSizeChanged(int i, int i2, int i3, int i4) {
        super.onSizeChanged(i, i2, i3, i4);
        if (i != i3) {
            this.z = true;
        }
    }

    @Override // android.view.View
    public boolean onTouchEvent(MotionEvent motionEvent) {
        motionEvent.getClass();
        bgv b2 = b();
        if (b2 != null) {
            return b2.h(motionEvent);
        }
        return false;
    }

    @Override // android.view.View
    protected final void onWindowVisibilityChanged(int i) {
        super.onWindowVisibilityChanged(i);
        aqkh aqkhVar = this.D;
        aqkh aqkhVar2 = null;
        if (aqkhVar != null) {
            aqkhVar.s(null);
        } else {
            aqkhVar = null;
        }
        if (i == 0) {
            Handler a2 = ais.a(getHandler().getLooper());
            a2.getClass();
            int i2 = aqlp.a;
            aqkhVar2 = aqhr.b(aqiy.a(new aqln(a2, null, false)), null, aqiz.UNDISPATCHED, new bgx(aqkhVar, this, null), 1);
        }
        this.D = aqkhVar2;
    }

    @Override // android.view.ViewGroup, android.view.ViewManager
    public final void removeView(View view) {
        view.getClass();
        if (view.getParent() instanceof bgu) {
            Object parent = view.getParent();
            parent.getClass();
            super.removeView((View) parent);
            return;
        }
        super.removeView(view);
    }

    @Override // android.view.ViewGroup, android.view.ViewParent
    public final void requestChildFocus(View view, View view2) {
        boolean z;
        super.requestChildFocus(view, view2);
        if (!isInTouchMode() && !this.c) {
            if (view == this.d) {
                z = true;
            } else {
                z = false;
            }
            this.i = z;
        }
    }

    public final void setLockMode(int i) {
        this.j = i;
    }

    public void setParallaxDistance(int i) {
        this.k = i;
        requestLayout();
    }

    public void setShadowResource(int i) {
        setShadowResourceLeft(i);
    }

    public void setShadowResourceLeft(int i) {
        this.t = getContext().getDrawable(i);
    }

    public void setShadowResourceRight(int i) {
        this.u = getContext().getDrawable(i);
    }

    public final void setSplitDividerPosition(int i) {
        if (this.n != i) {
            this.n = i;
            if (!this.c) {
                requestLayout();
            }
        }
    }

    public final void setUserResizingDividerDrawable(int i) {
        e(getContext().getDrawable(i));
    }

    @Override // android.view.View
    protected final boolean verifyDrawable(Drawable drawable) {
        drawable.getClass();
        if (!super.verifyDrawable(drawable) && drawable != this.m) {
            return false;
        }
        return true;
    }

    /* JADX WARN: 'this' call moved to the top of the method (can break code semantics) */
    public SlidingPaneLayout(Context context, AttributeSet attributeSet) {
        this(context, attributeSet, 0, 4, null);
        context.getClass();
    }

    /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
    public SlidingPaneLayout(Context context, AttributeSet attributeSet, int i) {
        super(context, attributeSet, i);
        context.getClass();
        this.e = 1.0f;
        float f = context.getResources().getDisplayMetrics().density * 48.0f;
        if (!Float.isNaN(f)) {
            this.w = Math.round(f);
            this.g = new bgq(this);
            this.h = new bgo(this);
            this.x = MotionEvent.obtain(0L, 0L, 3, 0.0f, 0.0f, 0);
            this.z = true;
            this.A = new Rect();
            this.B = new Rect();
            this.C = new bgj();
            this.E = true;
            this.l = bnu.c.a(context);
            this.F = new Rect();
            Rect rect = new Rect();
            this.G = rect;
            List singletonList = Collections.singletonList(rect);
            singletonList.getClass();
            this.H = singletonList;
            this.n = -1;
            this.p = true;
            bgw bgwVar = a;
            this.r = bgwVar;
            setWillNotDraw(false);
            bgl bglVar = new bgl(this);
            int[] iArr = ame.a;
            if (getImportantForAccessibility() == 0) {
                setImportantForAccessibility(1);
            }
            setAccessibilityDelegate(bglVar.e);
            setImportantForAccessibility(1);
            TypedArray obtainStyledAttributes = context.obtainStyledAttributes(attributeSet, bgi.a, 0, R.style.Widget_SlidingPaneLayout);
            boolean z = obtainStyledAttributes.getBoolean(1, true);
            if (z != this.E) {
                this.E = z;
                requestLayout();
            }
            boolean z2 = obtainStyledAttributes.getBoolean(2, false);
            if (z2 != this.o) {
                this.o = z2;
                requestLayout();
            }
            this.m = obtainStyledAttributes.getDrawable(4);
            boolean z3 = obtainStyledAttributes.getBoolean(0, true);
            if (z3 != this.p) {
                this.p = z3;
                invalidate();
            }
            int i2 = obtainStyledAttributes.getInt(3, 0);
            if (i2 != 0) {
                if (i2 == 1) {
                    bgwVar = b;
                } else {
                    throw new IllegalStateException(a.n(i2, " is not a valid userResizeBehavior value"));
                }
            }
            this.r = bgwVar;
            obtainStyledAttributes.recycle();
            return;
        }
        throw new IllegalArgumentException("Cannot round NaN value.");
    }

    @Override // android.view.ViewGroup
    public final ViewGroup.LayoutParams generateLayoutParams(ViewGroup.LayoutParams layoutParams) {
        return layoutParams instanceof ViewGroup.MarginLayoutParams ? new bgp((ViewGroup.MarginLayoutParams) layoutParams) : new ViewGroup.LayoutParams(layoutParams);
    }

    public void setCoveredFadeColor(int i) {
    }

    public void setSliderFadeColor(int i) {
    }

    public /* synthetic */ SlidingPaneLayout(Context context, AttributeSet attributeSet, int i, int i2, aqdp aqdpVar) {
        this(context, (i2 & 2) != 0 ? null : attributeSet, (i2 & 4) != 0 ? 0 : i);
    }
}
