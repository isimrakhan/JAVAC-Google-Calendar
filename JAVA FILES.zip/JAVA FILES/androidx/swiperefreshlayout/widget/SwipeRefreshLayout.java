package androidx.swiperefreshlayout.widget;

import android.R;
import android.content.Context;
import android.content.res.TypedArray;
import android.os.Parcelable;
import android.util.AttributeSet;
import android.util.DisplayMetrics;
import android.util.Log;
import android.view.KeyEvent;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewConfiguration;
import android.view.ViewGroup;
import android.view.ViewParent;
import android.view.animation.Animation;
import android.view.animation.DecelerateInterpolator;
import android.widget.ListView;
import androidx.swiperefreshlayout.widget.SwipeRefreshLayout;
import cal.alc;
import cal.ald;
import cal.ale;
import cal.alf;
import cal.alu;
import cal.ame;
import cal.amn;
import cal.bif;
import cal.bii;
import cal.bij;
import cal.bil;
import cal.bim;
import cal.bin;
import cal.bio;
import cal.bip;
import cal.biq;
import cal.bir;
import cal.bit;

/* compiled from: PG */
/* loaded from: classes.dex */
public class SwipeRefreshLayout extends ViewGroup implements ale, ald {
    private static final String j = "SwipeRefreshLayout";
    private static final int[] k = {R.attr.enabled};
    private final DecelerateInterpolator A;
    private int B;
    private Animation C;
    private Animation D;
    private Animation E;
    private Animation F;
    private int G;
    private Animation.AnimationListener H;
    private final Animation I;
    private final Animation J;
    public boolean a;
    public int b;
    public bif c;
    public int d;
    public int e;
    public int f;
    int g;
    public bij h;
    public boolean i;
    private View l;
    private int m;
    private float n;
    private float o;
    private final alf p;
    private final alc q;
    private final int[] r;
    private final int[] s;
    private final int[] t;
    private boolean u;
    private int v;
    private float w;
    private float x;
    private boolean y;
    private int z;

    public SwipeRefreshLayout(Context context) {
        this(context, null);
    }

    private final void k(float f) {
        if (f > this.n) {
            i(true);
            return;
        }
        this.a = false;
        bij bijVar = this.h;
        bii biiVar = bijVar.a;
        biiVar.e = 0.0f;
        biiVar.f = 0.0f;
        bijVar.invalidateSelf();
        bip bipVar = new bip(this);
        this.d = this.b;
        this.J.reset();
        this.J.setDuration(200L);
        this.J.setInterpolator(this.A);
        bif bifVar = this.c;
        bifVar.a = bipVar;
        bifVar.clearAnimation();
        this.c.startAnimation(this.J);
        bij bijVar2 = this.h;
        bii biiVar2 = bijVar2.a;
        if (biiVar2.m) {
            biiVar2.m = false;
        }
        bijVar2.invalidateSelf();
    }

    private final void l(float f) {
        Animation animation;
        Animation animation2;
        bij bijVar = this.h;
        bii biiVar = bijVar.a;
        if (!biiVar.m) {
            biiVar.m = true;
        }
        bijVar.invalidateSelf();
        float min = Math.min(1.0f, Math.abs(f / this.n));
        float max = (float) Math.max(min - 0.4d, 0.0d);
        float abs = Math.abs(f) - this.n;
        int i = this.g;
        float f2 = max * 5.0f;
        if (i <= 0) {
            i = this.f;
        }
        float f3 = i;
        double max2 = Math.max(0.0f, Math.min(abs, f3 + f3) / f3) / 4.0f;
        float f4 = min * f3;
        float pow = (float) (max2 - Math.pow(max2, 2.0d));
        float f5 = pow + pow;
        float f6 = f3 * f5;
        int i2 = this.e + ((int) (f4 + f6 + f6));
        if (this.c.getVisibility() != 0) {
            this.c.setVisibility(0);
        }
        this.c.setScaleX(1.0f);
        this.c.setScaleY(1.0f);
        if (f < this.n) {
            if (this.h.a.s > 76 && ((animation2 = this.E) == null || !animation2.hasStarted() || animation2.hasEnded())) {
                bio bioVar = new bio(this, this.h.a.s, 76);
                bioVar.setDuration(300L);
                bif bifVar = this.c;
                bifVar.a = null;
                bifVar.clearAnimation();
                this.c.startAnimation(bioVar);
                this.E = bioVar;
            }
        } else if (this.h.a.s < 255 && ((animation = this.F) == null || !animation.hasStarted() || animation.hasEnded())) {
            bio bioVar2 = new bio(this, this.h.a.s, 255);
            bioVar2.setDuration(300L);
            bif bifVar2 = this.c;
            bifVar2.a = null;
            bifVar2.clearAnimation();
            this.c.startAnimation(bioVar2);
            this.F = bioVar2;
        }
        float f7 = f2 / 3.0f;
        bij bijVar2 = this.h;
        bii biiVar2 = bijVar2.a;
        float min2 = Math.min(0.8f, f7 * 0.8f);
        biiVar2.e = 0.0f;
        biiVar2.f = min2;
        bijVar2.invalidateSelf();
        bij bijVar3 = this.h;
        float min3 = Math.min(1.0f, f7);
        bii biiVar3 = bijVar3.a;
        if (min3 != biiVar3.o) {
            biiVar3.o = min3;
        }
        bijVar3.invalidateSelf();
        bij bijVar4 = this.h;
        bijVar4.a.g = (((f7 * 0.4f) - 0.25f) + f5 + f5) * 0.5f;
        bijVar4.invalidateSelf();
        int i3 = i2 - this.b;
        this.c.bringToFront();
        bif bifVar3 = this.c;
        int[] iArr = ame.a;
        bifVar3.offsetTopAndBottom(i3);
        this.b = this.c.getTop();
    }

    private final void m(MotionEvent motionEvent) {
        int i;
        int actionIndex = motionEvent.getActionIndex();
        if (motionEvent.getPointerId(actionIndex) == this.z) {
            if (actionIndex == 0) {
                i = 1;
            } else {
                i = 0;
            }
            this.z = motionEvent.getPointerId(i);
        }
    }

    private final void n(float f) {
        float f2 = this.x;
        float f3 = f - f2;
        float f4 = this.m;
        if (f3 > f4 && !this.y) {
            this.w = f2 + f4;
            this.y = true;
            bij bijVar = this.h;
            bijVar.a.s = 76;
            bijVar.invalidateSelf();
        }
    }

    public final void a() {
        if (this.l == null) {
            for (int i = 0; i < getChildCount(); i++) {
                View childAt = getChildAt(i);
                if (!childAt.equals(this.c)) {
                    this.l = childAt;
                    return;
                }
            }
        }
    }

    public final void b() {
        this.c.clearAnimation();
        this.h.stop();
        this.c.setVisibility(8);
        this.c.getBackground().setAlpha(255);
        bij bijVar = this.h;
        bijVar.a.s = 255;
        bijVar.invalidateSelf();
        int i = this.e - this.b;
        this.c.bringToFront();
        bif bifVar = this.c;
        int[] iArr = ame.a;
        bifVar.offsetTopAndBottom(i);
        this.b = this.c.getTop();
        this.b = this.c.getTop();
    }

    @Override // cal.ald
    public final void c(View view, int i, int i2, int[] iArr, int i3) {
        if (i3 == 0) {
            onNestedPreScroll(view, i, i2, iArr);
        }
    }

    @Override // cal.ald
    public final void d(View view, int i, int i2, int i3, int i4, int i5) {
        e(view, i, i2, i3, i4, i5, this.t);
    }

    @Override // android.view.ViewGroup, android.view.View
    public final boolean dispatchKeyEvent(KeyEvent keyEvent) {
        if (keyEvent != null && keyEvent.getAction() == 1 && keyEvent.getKeyCode() == 285) {
            j(true);
            return true;
        }
        return super.dispatchKeyEvent(keyEvent);
    }

    @Override // android.view.View
    public final boolean dispatchNestedFling(float f, float f2, boolean z) {
        ViewParent viewParent;
        alc alcVar = this.q;
        if (alcVar.d && (viewParent = alcVar.a) != null) {
            return amn.e(viewParent, alcVar.c, f, f2, z);
        }
        return false;
    }

    @Override // android.view.View
    public final boolean dispatchNestedPreFling(float f, float f2) {
        ViewParent viewParent;
        alc alcVar = this.q;
        if (alcVar.d && (viewParent = alcVar.a) != null) {
            return amn.f(viewParent, alcVar.c, f, f2);
        }
        return false;
    }

    @Override // android.view.View
    public final boolean dispatchNestedPreScroll(int i, int i2, int[] iArr, int[] iArr2) {
        return this.q.a(i, i2, iArr, iArr2, 0);
    }

    @Override // android.view.View
    public final boolean dispatchNestedScroll(int i, int i2, int i3, int i4, int[] iArr) {
        return this.q.b(i, i2, i3, i4, iArr, 0, null);
    }

    @Override // cal.ale
    public final void e(View view, int i, int i2, int i3, int i4, int i5, int[] iArr) {
        int i6;
        boolean canScrollVertically;
        if (i5 == 0) {
            int i7 = iArr[1];
            this.q.b(i, i2, i3, i4, this.s, 0, iArr);
            int i8 = i4 - (iArr[1] - i7);
            if (i8 == 0) {
                i8 = this.s[1] + i4;
                i6 = 0;
            } else {
                i6 = i8;
            }
            if (i8 < 0) {
                View view2 = this.l;
                if (view2 instanceof ListView) {
                    canScrollVertically = ((ListView) view2).canScrollList(-1);
                } else {
                    canScrollVertically = view2.canScrollVertically(-1);
                }
                if (!canScrollVertically) {
                    float abs = this.o + Math.abs(i8);
                    this.o = abs;
                    l(abs);
                    iArr[1] = iArr[1] + i6;
                }
            }
        }
    }

    @Override // cal.ald
    public final void f(View view, View view2, int i, int i2) {
        if (i2 == 0) {
            this.p.a = i;
            this.q.c(i & 2, 0);
            this.o = 0.0f;
            this.u = true;
        }
    }

    @Override // cal.ald
    public final void g(View view, int i) {
        if (i == 0) {
            onStopNestedScroll(view);
        }
    }

    @Override // android.view.ViewGroup
    protected final int getChildDrawingOrder(int i, int i2) {
        int i3 = this.B;
        if (i3 < 0) {
            return i2;
        }
        if (i2 == i - 1) {
            return i3;
        }
        if (i2 >= i3) {
            return i2 + 1;
        }
        return i2;
    }

    @Override // android.view.ViewGroup
    public final int getNestedScrollAxes() {
        alf alfVar = this.p;
        return alfVar.b | alfVar.a;
    }

    public final void h(Animation.AnimationListener animationListener) {
        bin binVar = new bin(this);
        this.D = binVar;
        binVar.setDuration(150L);
        bif bifVar = this.c;
        bifVar.a = animationListener;
        bifVar.clearAnimation();
        this.c.startAnimation(this.D);
    }

    @Override // android.view.View
    public final boolean hasNestedScrollingParent() {
        if (this.q.a != null) {
            return true;
        }
        return false;
    }

    public final void i(boolean z) {
        if (this.a != z) {
            a();
            this.a = z;
            if (z) {
                int i = this.b;
                Animation.AnimationListener animationListener = this.H;
                this.d = i;
                this.I.reset();
                this.I.setDuration(200L);
                this.I.setInterpolator(this.A);
                if (animationListener != null) {
                    this.c.a = animationListener;
                }
                this.c.clearAnimation();
                this.c.startAnimation(this.I);
                return;
            }
            h(this.H);
        }
    }

    @Override // android.view.View
    public final boolean isNestedScrollingEnabled() {
        return this.q.d;
    }

    public final void j(boolean z) {
        if (z) {
            if (!this.a) {
                this.a = true;
                int i = (this.f + this.e) - this.b;
                this.c.bringToFront();
                bif bifVar = this.c;
                int[] iArr = ame.a;
                bifVar.offsetTopAndBottom(i);
                this.b = this.c.getTop();
                Animation.AnimationListener animationListener = this.H;
                this.c.setVisibility(0);
                bij bijVar = this.h;
                bijVar.a.s = 255;
                bijVar.invalidateSelf();
                bim bimVar = new bim(this);
                this.C = bimVar;
                bimVar.setDuration(this.v);
                if (animationListener != null) {
                    this.c.a = animationListener;
                }
                this.c.clearAnimation();
                this.c.startAnimation(this.C);
                return;
            }
            z = true;
        }
        i(z);
    }

    @Override // android.view.ViewGroup, android.view.View
    protected final void onDetachedFromWindow() {
        super.onDetachedFromWindow();
        b();
    }

    @Override // android.view.ViewGroup
    public final boolean onInterceptTouchEvent(MotionEvent motionEvent) {
        boolean canScrollVertically;
        a();
        int actionMasked = motionEvent.getActionMasked();
        if (isEnabled()) {
            View view = this.l;
            if (view instanceof ListView) {
                canScrollVertically = ((ListView) view).canScrollList(-1);
            } else {
                canScrollVertically = view.canScrollVertically(-1);
            }
            if (!canScrollVertically && !this.a && !this.u) {
                if (actionMasked != 0) {
                    if (actionMasked != 1) {
                        if (actionMasked != 2) {
                            if (actionMasked != 3) {
                                if (actionMasked == 6) {
                                    m(motionEvent);
                                }
                            }
                        } else {
                            int i = this.z;
                            if (i == -1) {
                                Log.e(j, "Got ACTION_MOVE event but don't have an active pointer id.");
                                return false;
                            }
                            int findPointerIndex = motionEvent.findPointerIndex(i);
                            if (findPointerIndex >= 0) {
                                n(motionEvent.getY(findPointerIndex));
                            }
                        }
                        return this.y;
                    }
                    this.y = false;
                    this.z = -1;
                    return this.y;
                }
                int top = this.e - this.c.getTop();
                this.c.bringToFront();
                bif bifVar = this.c;
                int[] iArr = ame.a;
                bifVar.offsetTopAndBottom(top);
                this.b = this.c.getTop();
                int pointerId = motionEvent.getPointerId(0);
                this.z = pointerId;
                this.y = false;
                int findPointerIndex2 = motionEvent.findPointerIndex(pointerId);
                if (findPointerIndex2 >= 0) {
                    this.x = motionEvent.getY(findPointerIndex2);
                    return this.y;
                }
            }
        }
        return false;
    }

    @Override // android.view.ViewGroup, android.view.View
    protected final void onLayout(boolean z, int i, int i2, int i3, int i4) {
        int measuredWidth = getMeasuredWidth();
        int measuredHeight = getMeasuredHeight();
        if (getChildCount() != 0) {
            if (this.l == null) {
                a();
            }
            View view = this.l;
            if (view != null) {
                int paddingLeft = getPaddingLeft();
                int paddingTop = getPaddingTop();
                view.layout(paddingLeft, paddingTop, ((measuredWidth - getPaddingLeft()) - getPaddingRight()) + paddingLeft, ((measuredHeight - getPaddingTop()) - getPaddingBottom()) + paddingTop);
                int measuredWidth2 = this.c.getMeasuredWidth();
                int measuredHeight2 = this.c.getMeasuredHeight();
                bif bifVar = this.c;
                int i5 = measuredWidth / 2;
                int i6 = measuredWidth2 / 2;
                int i7 = this.b;
                int i8 = i5 + i6;
                bifVar.layout(i5 - i6, i7, i8, measuredHeight2 + i7);
            }
        }
    }

    @Override // android.view.View
    public final void onMeasure(int i, int i2) {
        super.onMeasure(i, i2);
        if (this.l == null) {
            a();
        }
        View view = this.l;
        if (view != null) {
            view.measure(View.MeasureSpec.makeMeasureSpec((getMeasuredWidth() - getPaddingLeft()) - getPaddingRight(), 1073741824), View.MeasureSpec.makeMeasureSpec((getMeasuredHeight() - getPaddingTop()) - getPaddingBottom(), 1073741824));
            this.c.measure(View.MeasureSpec.makeMeasureSpec(this.G, 1073741824), View.MeasureSpec.makeMeasureSpec(this.G, 1073741824));
            this.B = -1;
            for (int i3 = 0; i3 < getChildCount(); i3++) {
                if (getChildAt(i3) == this.c) {
                    this.B = i3;
                    return;
                }
            }
        }
    }

    @Override // android.view.ViewGroup, android.view.ViewParent
    public final boolean onNestedFling(View view, float f, float f2, boolean z) {
        ViewParent viewParent;
        alc alcVar = this.q;
        if (alcVar.d && (viewParent = alcVar.a) != null) {
            return amn.e(viewParent, alcVar.c, f, f2, z);
        }
        return false;
    }

    @Override // android.view.ViewGroup, android.view.ViewParent
    public final boolean onNestedPreFling(View view, float f, float f2) {
        ViewParent viewParent;
        alc alcVar = this.q;
        if (alcVar.d && (viewParent = alcVar.a) != null) {
            return amn.f(viewParent, alcVar.c, f, f2);
        }
        return false;
    }

    @Override // android.view.ViewGroup, android.view.ViewParent
    public final void onNestedPreScroll(View view, int i, int i2, int[] iArr) {
        if (i2 > 0) {
            float f = this.o;
            float f2 = 0.0f;
            if (f > 0.0f) {
                float f3 = i2;
                if (f3 > f) {
                    iArr[1] = (int) f;
                    this.o = 0.0f;
                } else {
                    f2 = f - f3;
                    this.o = f2;
                    iArr[1] = i2;
                }
                l(f2);
            }
        }
        int[] iArr2 = this.r;
        if (this.q.a(i - iArr[0], i2 - iArr[1], iArr2, null, 0)) {
            iArr[0] = iArr[0] + iArr2[0];
            iArr[1] = iArr[1] + iArr2[1];
        }
    }

    @Override // android.view.ViewGroup, android.view.ViewParent
    public final void onNestedScroll(View view, int i, int i2, int i3, int i4) {
        e(view, i, i2, i3, i4, 0, this.t);
    }

    @Override // android.view.ViewGroup, android.view.ViewParent
    public final void onNestedScrollAccepted(View view, View view2, int i) {
        this.p.a = i;
        this.q.c(i & 2, 0);
        this.o = 0.0f;
        this.u = true;
    }

    @Override // android.view.View
    protected final void onRestoreInstanceState(Parcelable parcelable) {
        bit bitVar = (bit) parcelable;
        super.onRestoreInstanceState(bitVar.getSuperState());
        j(bitVar.a);
    }

    @Override // android.view.View
    protected final Parcelable onSaveInstanceState() {
        return new bit(super.onSaveInstanceState(), this.a);
    }

    @Override // android.view.ViewGroup, android.view.ViewParent
    public final boolean onStartNestedScroll(View view, View view2, int i) {
        if (isEnabled() && !this.a && (i & 2) != 0) {
            return true;
        }
        return false;
    }

    @Override // android.view.ViewGroup, android.view.ViewParent
    public final void onStopNestedScroll(View view) {
        this.p.a = 0;
        this.u = false;
        float f = this.o;
        if (f > 0.0f) {
            k(f);
            this.o = 0.0f;
        } else {
            post(new Runnable() { // from class: cal.bik
                @Override // java.lang.Runnable
                public final void run() {
                    SwipeRefreshLayout.this.b();
                }
            });
        }
        alc alcVar = this.q;
        ViewParent viewParent = alcVar.a;
        if (viewParent != null) {
            amn.d(viewParent, alcVar.c, 0);
            alcVar.a = null;
        }
    }

    @Override // android.view.View
    public final boolean onTouchEvent(MotionEvent motionEvent) {
        boolean canScrollVertically;
        int actionMasked = motionEvent.getActionMasked();
        if (isEnabled()) {
            View view = this.l;
            if (view instanceof ListView) {
                canScrollVertically = ((ListView) view).canScrollList(-1);
            } else {
                canScrollVertically = view.canScrollVertically(-1);
            }
            if (!canScrollVertically && !this.a && !this.u) {
                if (actionMasked != 0) {
                    if (actionMasked != 1) {
                        if (actionMasked != 2) {
                            if (actionMasked == 3) {
                                return false;
                            }
                            if (actionMasked != 5) {
                                if (actionMasked == 6) {
                                    m(motionEvent);
                                }
                            } else {
                                int actionIndex = motionEvent.getActionIndex();
                                if (actionIndex < 0) {
                                    Log.e(j, "Got ACTION_POINTER_DOWN event but have an invalid action index.");
                                    return false;
                                }
                                this.z = motionEvent.getPointerId(actionIndex);
                            }
                        } else {
                            int findPointerIndex = motionEvent.findPointerIndex(this.z);
                            if (findPointerIndex < 0) {
                                Log.e(j, "Got ACTION_MOVE event but have an invalid active pointer id.");
                                return false;
                            }
                            float y = motionEvent.getY(findPointerIndex);
                            n(y);
                            if (this.y) {
                                float f = (y - this.w) * 0.5f;
                                if (f <= 0.0f) {
                                    return false;
                                }
                                getParent().requestDisallowInterceptTouchEvent(true);
                                l(f);
                            }
                        }
                    } else {
                        int findPointerIndex2 = motionEvent.findPointerIndex(this.z);
                        if (findPointerIndex2 < 0) {
                            Log.e(j, "Got ACTION_UP event but don't have an active pointer id.");
                            return false;
                        }
                        if (this.y) {
                            float y2 = (motionEvent.getY(findPointerIndex2) - this.w) * 0.5f;
                            this.y = false;
                            k(y2);
                        }
                        this.z = -1;
                        return false;
                    }
                } else {
                    this.z = motionEvent.getPointerId(0);
                    this.y = false;
                }
                return true;
            }
        }
        return false;
    }

    @Override // cal.ald
    public final boolean q(View view, View view2, int i, int i2) {
        if (i2 != 0 || !isEnabled() || this.a || (i & 2) == 0) {
            return false;
        }
        return true;
    }

    public void setDistanceToTriggerSync(int i) {
        this.n = i;
    }

    @Override // android.view.View
    public final void setEnabled(boolean z) {
        super.setEnabled(z);
        if (!z) {
            b();
        }
    }

    @Override // android.view.View
    public final void setNestedScrollingEnabled(boolean z) {
        alc alcVar = this.q;
        if (alcVar.d) {
            alu.n(alcVar.c);
        }
        alcVar.d = z;
    }

    @Deprecated
    public void setProgressBackgroundColor(int i) {
        setProgressBackgroundColorSchemeResource(i);
    }

    public void setProgressBackgroundColorSchemeColor(int i) {
        this.c.setBackgroundColor(i);
    }

    public void setProgressBackgroundColorSchemeResource(int i) {
        setProgressBackgroundColorSchemeColor(getContext().getColor(i));
    }

    public void setSize(int i) {
        if (i != 0 && i != 1) {
            return;
        }
        DisplayMetrics displayMetrics = getResources().getDisplayMetrics();
        if (i == 0) {
            this.G = (int) (displayMetrics.density * 56.0f);
        } else {
            this.G = (int) (displayMetrics.density * 40.0f);
        }
        this.c.setImageDrawable(null);
        this.h.b(i);
        this.c.setImageDrawable(this.h);
    }

    public void setSlingshotDistance(int i) {
        this.g = i;
    }

    @Override // android.view.View
    public final boolean startNestedScroll(int i) {
        return this.q.c(i, 0);
    }

    @Override // android.view.View
    public final void stopNestedScroll() {
        alc alcVar = this.q;
        ViewParent viewParent = alcVar.a;
        if (viewParent != null) {
            amn.d(viewParent, alcVar.c, 0);
            alcVar.a = null;
        }
    }

    public SwipeRefreshLayout(Context context, AttributeSet attributeSet) {
        super(context, attributeSet);
        this.a = false;
        this.n = -1.0f;
        this.r = new int[2];
        this.s = new int[2];
        this.t = new int[2];
        this.z = -1;
        this.B = -1;
        this.H = new bil(this);
        this.I = new biq(this);
        this.J = new bir(this);
        this.m = ViewConfiguration.get(context).getScaledTouchSlop();
        this.v = getResources().getInteger(R.integer.config_mediumAnimTime);
        setWillNotDraw(false);
        this.A = new DecelerateInterpolator(2.0f);
        DisplayMetrics displayMetrics = getResources().getDisplayMetrics();
        this.G = (int) (displayMetrics.density * 40.0f);
        this.c = new bif(getContext());
        bij bijVar = new bij(getContext());
        this.h = bijVar;
        bijVar.b(1);
        this.c.setImageDrawable(this.h);
        this.c.setVisibility(8);
        addView(this.c);
        setChildrenDrawingOrderEnabled(true);
        int i = (int) (displayMetrics.density * 64.0f);
        this.f = i;
        this.n = i;
        this.p = new alf();
        alc alcVar = new alc(this);
        this.q = alcVar;
        if (alcVar.d) {
            alu.n(alcVar.c);
        }
        alcVar.d = true;
        int i2 = -this.G;
        this.b = i2;
        this.e = i2;
        int top = (this.d + (i2 - r2)) - this.c.getTop();
        this.c.bringToFront();
        bif bifVar = this.c;
        int[] iArr = ame.a;
        bifVar.offsetTopAndBottom(top);
        this.b = this.c.getTop();
        TypedArray obtainStyledAttributes = context.obtainStyledAttributes(attributeSet, k);
        boolean z = obtainStyledAttributes.getBoolean(0, true);
        super.setEnabled(z);
        if (!z) {
            b();
        }
        obtainStyledAttributes.recycle();
    }
}
