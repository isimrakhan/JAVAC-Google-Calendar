package androidx.fragment.app.strictmode;

import cal.ci;
import java.util.Objects;

/* compiled from: PG */
/* loaded from: classes.dex */
public final class GetRetainInstanceUsageViolation extends RetainInstanceUsageViolation {
    /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
    public GetRetainInstanceUsageViolation(ci ciVar) {
        super(ciVar, "Attempting to get retain instance for fragment ".concat(ciVar.toString()));
        Objects.toString(ciVar);
    }
}
