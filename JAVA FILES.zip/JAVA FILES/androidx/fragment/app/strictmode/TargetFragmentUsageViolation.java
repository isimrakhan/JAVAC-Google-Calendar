package androidx.fragment.app.strictmode;

import cal.ci;

/* compiled from: PG */
/* loaded from: classes.dex */
public abstract class TargetFragmentUsageViolation extends Violation {
    public TargetFragmentUsageViolation(ci ciVar, String str) {
        super(str);
    }
}
