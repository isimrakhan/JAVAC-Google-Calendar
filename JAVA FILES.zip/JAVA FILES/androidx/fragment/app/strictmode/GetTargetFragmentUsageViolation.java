package androidx.fragment.app.strictmode;

import cal.ci;
import java.util.Objects;

/* compiled from: PG */
/* loaded from: classes.dex */
public final class GetTargetFragmentUsageViolation extends TargetFragmentUsageViolation {
    /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
    public GetTargetFragmentUsageViolation(ci ciVar) {
        super(ciVar, "Attempting to get target fragment from fragment ".concat(ciVar.toString()));
        Objects.toString(ciVar);
    }
}
