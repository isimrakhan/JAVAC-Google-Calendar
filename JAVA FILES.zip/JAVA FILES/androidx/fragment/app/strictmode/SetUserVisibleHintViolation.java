package androidx.fragment.app.strictmode;

import cal.ci;

/* compiled from: PG */
/* loaded from: classes.dex */
public final class SetUserVisibleHintViolation extends Violation {
    public SetUserVisibleHintViolation(ci ciVar, boolean z) {
        super("Attempting to set user visible hint to " + z + " for fragment " + ciVar);
    }
}
