package androidx.fragment.app.strictmode;

import cal.ci;
import java.util.Objects;

/* compiled from: PG */
/* loaded from: classes.dex */
public final class SetRetainInstanceUsageViolation extends RetainInstanceUsageViolation {
    /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
    public SetRetainInstanceUsageViolation(ci ciVar) {
        super(ciVar, "Attempting to set retain instance for fragment ".concat(ciVar.toString()));
        Objects.toString(ciVar);
    }
}
