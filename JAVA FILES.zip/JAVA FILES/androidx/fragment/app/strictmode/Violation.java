package androidx.fragment.app.strictmode;

/* compiled from: PG */
/* loaded from: classes.dex */
public abstract class Violation extends RuntimeException {
    public Violation(String str) {
        super(str);
    }
}
