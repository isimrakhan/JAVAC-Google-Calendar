package androidx.fragment.app.strictmode;

import cal.ci;

/* compiled from: PG */
/* loaded from: classes.dex */
public final class FragmentReuseViolation extends Violation {
    public FragmentReuseViolation(ci ciVar, String str) {
        super("Attempting to reuse fragment " + ciVar + " with previous ID " + str);
    }
}
