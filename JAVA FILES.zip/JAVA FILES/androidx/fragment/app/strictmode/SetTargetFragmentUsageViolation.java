package androidx.fragment.app.strictmode;

import cal.ci;

/* compiled from: PG */
/* loaded from: classes.dex */
public final class SetTargetFragmentUsageViolation extends TargetFragmentUsageViolation {
    public SetTargetFragmentUsageViolation(ci ciVar, ci ciVar2, int i) {
        super(ciVar, "Attempting to set target fragment " + ciVar2 + " with request code " + i + " for fragment " + ciVar);
    }
}
