package androidx.fragment.app.strictmode;

import android.view.ViewGroup;
import cal.ci;

/* compiled from: PG */
/* loaded from: classes.dex */
public final class WrongFragmentContainerViolation extends Violation {
    public WrongFragmentContainerViolation(ci ciVar, ViewGroup viewGroup) {
        super("Attempting to add fragment " + ciVar + " to container " + viewGroup + " which is not a FragmentContainerView");
    }
}
