package androidx.fragment.app.strictmode;

import cal.ci;

/* compiled from: PG */
/* loaded from: classes.dex */
public final class WrongNestedHierarchyViolation extends Violation {
    public WrongNestedHierarchyViolation(ci ciVar, ci ciVar2, int i) {
        super("Attempting to nest fragment " + ciVar + " within the view of parent fragment " + ciVar2 + " via container with ID " + i + " without using parent's childFragmentManager");
    }
}
