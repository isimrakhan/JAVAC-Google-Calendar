package androidx.fragment.app.strictmode;

import android.view.ViewGroup;
import cal.a;
import cal.ci;

/* compiled from: PG */
/* loaded from: classes.dex */
public final class FragmentTagUsageViolation extends Violation {
    public FragmentTagUsageViolation(ci ciVar, ViewGroup viewGroup) {
        super(a.h(viewGroup, ciVar, "Attempting to use <fragment> tag to add fragment ", " to container "));
    }
}
