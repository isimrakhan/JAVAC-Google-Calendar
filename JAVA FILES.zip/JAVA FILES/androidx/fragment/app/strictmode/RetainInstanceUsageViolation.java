package androidx.fragment.app.strictmode;

import cal.ci;

/* compiled from: PG */
/* loaded from: classes.dex */
public abstract class RetainInstanceUsageViolation extends Violation {
    public RetainInstanceUsageViolation(ci ciVar, String str) {
        super(str);
    }
}
