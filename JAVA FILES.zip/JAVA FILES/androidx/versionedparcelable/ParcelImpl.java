package androidx.versionedparcelable;

import android.os.Parcel;
import android.os.Parcelable;
import cal.abh;
import cal.blv;
import cal.blw;
import cal.blx;
import cal.bly;

/* compiled from: PG */
/* loaded from: classes.dex */
public class ParcelImpl implements Parcelable {
    public static final Parcelable.Creator<ParcelImpl> CREATOR = new blv();
    private final bly a;

    public ParcelImpl(Parcel parcel) {
        bly d;
        blx blxVar = new blx(parcel, parcel.dataPosition(), parcel.dataSize(), "", new abh(0), new abh(0), new abh(0));
        String readString = blxVar.d.readString();
        if (readString == null) {
            d = null;
        } else {
            d = blxVar.d(readString, blxVar.c());
        }
        this.a = d;
    }

    @Override // android.os.Parcelable
    public final int describeContents() {
        return 0;
    }

    @Override // android.os.Parcelable
    public final void writeToParcel(Parcel parcel, int i) {
        blx blxVar = new blx(parcel, parcel.dataPosition(), parcel.dataSize(), "", new abh(0), new abh(0), new abh(0));
        bly blyVar = this.a;
        if (blyVar == null) {
            blxVar.d.writeString(null);
            return;
        }
        blxVar.p(blyVar);
        blw c = blxVar.c();
        blxVar.o(blyVar, c);
        c.g();
    }
}
