package androidx.versionedparcelable;

import cal.bly;

/* compiled from: PG */
/* loaded from: classes.dex */
public abstract class CustomVersionedParcelable implements bly {
}
