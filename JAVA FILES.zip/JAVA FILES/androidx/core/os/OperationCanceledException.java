package androidx.core.os;

/* compiled from: PG */
/* loaded from: classes.dex */
public class OperationCanceledException extends RuntimeException {
}
