package androidx.core.widget;

import android.R;
import android.content.Context;
import android.content.res.TypedArray;
import android.graphics.Canvas;
import android.graphics.Rect;
import android.os.Build;
import android.os.Parcelable;
import android.util.AttributeSet;
import android.util.Log;
import android.util.TypedValue;
import android.view.FocusFinder;
import android.view.KeyEvent;
import android.view.MotionEvent;
import android.view.VelocityTracker;
import android.view.View;
import android.view.ViewConfiguration;
import android.view.ViewGroup;
import android.view.ViewParent;
import android.view.animation.AnimationUtils;
import android.widget.EdgeEffect;
import android.widget.FrameLayout;
import android.widget.OverScroller;
import cal.a;
import cal.aip;
import cal.akt;
import cal.alc;
import cal.ale;
import cal.alf;
import cal.alu;
import cal.ame;
import cal.amn;
import cal.aow;
import cal.aox;
import cal.aoz;
import cal.apa;
import cal.apb;
import cal.apc;
import cal.ape;

/* compiled from: PG */
/* loaded from: classes.dex */
public class NestedScrollView extends FrameLayout implements ale {
    private static final float h = (float) (Math.log(0.78d) / Math.log(0.9d));
    private static final aoz i = new aoz();
    private static final int[] j = {R.attr.fillViewport};
    private final int[] A;
    private int B;
    private int C;
    private ape D;
    private final alf E;
    private float F;
    public OverScroller a;
    public EdgeEffect b;
    public EdgeEffect c;
    public final alc d;
    public apc e;
    final apb f;
    akt g;
    private final float k;
    private long l;
    private final Rect m;
    private int n;
    private boolean o;
    private boolean p;
    private View q;
    private boolean r;
    private VelocityTracker s;
    private boolean t;
    private boolean u;
    private int v;
    private int w;
    private int x;
    private int y;
    private final int[] z;

    public NestedScrollView(Context context) {
        this(context, null);
    }

    private final float p(int i2) {
        double log = Math.log((Math.abs(i2) * 0.35f) / (this.k * 0.015f));
        double d = h;
        return (float) (this.k * 0.015f * Math.exp((d / ((-1.0d) + d)) * log));
    }

    /* JADX WARN: Removed duplicated region for block: B:22:0x008a  */
    /* JADX WARN: Removed duplicated region for block: B:40:0x0107  */
    /* JADX WARN: Removed duplicated region for block: B:47:0x00b6  */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct code enable 'Show inconsistent code' option in preferences
    */
    private final int r(int r19, int r20, int r21, boolean r22) {
        /*
            Method dump skipped, instructions count: 288
            To view this dump change 'Code comments level' option to 'DEBUG'
        */
        throw new UnsupportedOperationException("Method not decompiled: androidx.core.widget.NestedScrollView.r(int, int, int, boolean):int");
    }

    private final void s(MotionEvent motionEvent) {
        int i2;
        int actionIndex = motionEvent.getActionIndex();
        if (motionEvent.getPointerId(actionIndex) == this.y) {
            if (actionIndex == 0) {
                i2 = 1;
            } else {
                i2 = 0;
            }
            this.n = (int) motionEvent.getY(i2);
            this.y = motionEvent.getPointerId(i2);
            VelocityTracker velocityTracker = this.s;
            if (velocityTracker != null) {
                velocityTracker.clear();
            }
        }
    }

    private static boolean t(View view, View view2) {
        if (view == view2) {
            return true;
        }
        Object parent = view.getParent();
        if ((parent instanceof ViewGroup) && t((View) parent, view2)) {
            return true;
        }
        return false;
    }

    private final boolean u(View view, int i2, int i3) {
        view.getDrawingRect(this.m);
        offsetDescendantRectToMyCoords(view, this.m);
        if (this.m.bottom + i2 >= getScrollY() && this.m.top - i2 <= getScrollY() + i3) {
            return true;
        }
        return false;
    }

    /* JADX WARN: Code restructure failed: missing block: B:46:0x0070, code lost:
    
        if (r18 == 33) goto L40;
     */
    /* JADX WARN: Code restructure failed: missing block: B:47:0x0077, code lost:
    
        r2 = r20 - r4;
     */
    /* JADX WARN: Code restructure failed: missing block: B:49:0x0075, code lost:
    
        r2 = r19 - r5;
     */
    /* JADX WARN: Code restructure failed: missing block: B:50:0x0073, code lost:
    
        if (r18 == 33) goto L40;
     */
    /* JADX WARN: Removed duplicated region for block: B:43:0x0084  */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct code enable 'Show inconsistent code' option in preferences
    */
    private final boolean v(int r18, int r19, int r20) {
        /*
            r17 = this;
            r0 = r17
            r1 = r18
            r2 = r19
            r3 = r20
            int r4 = r17.getHeight()
            int r5 = r17.getScrollY()
            int r4 = r4 + r5
            r6 = 2
            java.util.ArrayList r6 = r0.getFocusables(r6)
            int r7 = r6.size()
            r9 = 0
            r10 = 0
            r11 = 0
        L1d:
            r12 = 33
            r13 = 1
            if (r10 >= r7) goto L67
            java.lang.Object r14 = r6.get(r10)
            android.view.View r14 = (android.view.View) r14
            int r15 = r14.getTop()
            int r8 = r14.getBottom()
            if (r2 >= r8) goto L64
            if (r15 >= r3) goto L64
            if (r2 >= r15) goto L3b
            if (r8 >= r3) goto L3b
            r16 = r13
            goto L3d
        L3b:
            r16 = 0
        L3d:
            if (r9 != 0) goto L43
            r9 = r14
            r11 = r16
            goto L64
        L43:
            if (r1 != r12) goto L4c
            int r8 = r9.getTop()
            if (r15 < r8) goto L52
            goto L54
        L4c:
            int r12 = r9.getBottom()
            if (r8 <= r12) goto L54
        L52:
            r8 = r13
            goto L55
        L54:
            r8 = 0
        L55:
            if (r11 == 0) goto L5c
            if (r16 == 0) goto L64
            if (r8 == 0) goto L64
            goto L63
        L5c:
            if (r16 == 0) goto L61
            r11 = r13
        L5f:
            r9 = r14
            goto L64
        L61:
            if (r8 == 0) goto L64
        L63:
            goto L5f
        L64:
            int r10 = r10 + 1
            goto L1d
        L67:
            if (r9 != 0) goto L6a
            r9 = r0
        L6a:
            if (r2 < r5) goto L73
            if (r3 > r4) goto L70
            r8 = 0
            goto L7e
        L70:
            if (r1 != r12) goto L77
            goto L75
        L73:
            if (r1 != r12) goto L77
        L75:
            int r2 = r2 - r5
            goto L79
        L77:
            int r2 = r3 - r4
        L79:
            r3 = 0
            r0.r(r2, r3, r13, r13)
            r8 = r13
        L7e:
            android.view.View r2 = r17.findFocus()
            if (r9 == r2) goto L87
            r9.requestFocus(r1)
        L87:
            return r8
        */
        throw new UnsupportedOperationException("Method not decompiled: androidx.core.widget.NestedScrollView.v(int, int, int):boolean");
    }

    private final boolean w(MotionEvent motionEvent) {
        float f;
        boolean z;
        float f2;
        EdgeEffect edgeEffect = this.b;
        if (Build.VERSION.SDK_INT >= 31) {
            f = aox.a(edgeEffect);
        } else {
            f = 0.0f;
        }
        if (f != 0.0f) {
            EdgeEffect edgeEffect2 = this.b;
            float x = motionEvent.getX() / getWidth();
            if (Build.VERSION.SDK_INT >= 31) {
                aox.b(edgeEffect2, 0.0f, x);
            } else {
                aow.a(edgeEffect2, 0.0f, x);
            }
            z = true;
        } else {
            z = false;
        }
        EdgeEffect edgeEffect3 = this.c;
        if (Build.VERSION.SDK_INT >= 31) {
            f2 = aox.a(edgeEffect3);
        } else {
            f2 = 0.0f;
        }
        if (f2 != 0.0f) {
            EdgeEffect edgeEffect4 = this.c;
            float x2 = 1.0f - (motionEvent.getX() / getWidth());
            if (Build.VERSION.SDK_INT >= 31) {
                aox.b(edgeEffect4, 0.0f, x2);
            } else {
                aow.a(edgeEffect4, 0.0f, x2);
            }
            return true;
        }
        return z;
    }

    public final float a() {
        float f = this.F;
        if (f == 0.0f) {
            TypedValue typedValue = new TypedValue();
            Context context = getContext();
            if (context.getTheme().resolveAttribute(R.attr.listPreferredItemHeight, typedValue, true)) {
                float dimension = typedValue.getDimension(context.getResources().getDisplayMetrics());
                this.F = dimension;
                return dimension;
            }
            throw new IllegalStateException("Expected theme to define listPreferredItemHeight.");
        }
        return f;
    }

    @Override // android.view.ViewGroup
    public final void addView(View view) {
        if (getChildCount() <= 0) {
            super.addView(view);
            return;
        }
        throw new IllegalStateException("ScrollView can host only one direct child");
    }

    protected final int b(Rect rect) {
        int i2;
        int i3;
        int i4;
        if (getChildCount() == 0) {
            return 0;
        }
        int height = getHeight();
        int scrollY = getScrollY();
        int i5 = scrollY + height;
        int verticalFadingEdgeLength = getVerticalFadingEdgeLength();
        if (rect.top > 0) {
            scrollY += verticalFadingEdgeLength;
        }
        View childAt = getChildAt(0);
        FrameLayout.LayoutParams layoutParams = (FrameLayout.LayoutParams) childAt.getLayoutParams();
        if (rect.bottom < childAt.getHeight() + layoutParams.topMargin + layoutParams.bottomMargin) {
            i2 = i5 - verticalFadingEdgeLength;
        } else {
            i2 = i5;
        }
        if (rect.bottom > i2 && rect.top > scrollY) {
            if (rect.height() > height) {
                i4 = rect.top - scrollY;
            } else {
                i4 = rect.bottom - i2;
            }
            return Math.min(i4, (childAt.getBottom() + layoutParams.bottomMargin) - i5);
        }
        if (rect.top >= scrollY || rect.bottom >= i2) {
            return 0;
        }
        if (rect.height() > height) {
            i3 = -(i2 - rect.bottom);
        } else {
            i3 = -(scrollY - rect.top);
        }
        return Math.max(i3, -getScrollY());
    }

    @Override // cal.ald
    public final void c(View view, int i2, int i3, int[] iArr, int i4) {
        this.d.a(i2, i3, iArr, null, i4);
    }

    @Override // android.view.View
    public final int computeHorizontalScrollExtent() {
        return super.computeHorizontalScrollExtent();
    }

    @Override // android.view.View
    public final int computeHorizontalScrollOffset() {
        return super.computeHorizontalScrollOffset();
    }

    @Override // android.view.View
    public final int computeHorizontalScrollRange() {
        return super.computeHorizontalScrollRange();
    }

    /* JADX WARN: Removed duplicated region for block: B:19:0x00af  */
    /* JADX WARN: Removed duplicated region for block: B:21:0x00be  */
    /* JADX WARN: Removed duplicated region for block: B:24:0x00ea  */
    /* JADX WARN: Removed duplicated region for block: B:40:0x0139  */
    /* JADX WARN: Removed duplicated region for block: B:46:0x0147  */
    @Override // android.view.View
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct code enable 'Show inconsistent code' option in preferences
    */
    public final void computeScroll() {
        /*
            Method dump skipped, instructions count: 331
            To view this dump change 'Code comments level' option to 'DEBUG'
        */
        throw new UnsupportedOperationException("Method not decompiled: androidx.core.widget.NestedScrollView.computeScroll():void");
    }

    @Override // android.view.View
    public final int computeVerticalScrollExtent() {
        return super.computeVerticalScrollExtent();
    }

    @Override // android.view.View
    public final int computeVerticalScrollOffset() {
        return Math.max(0, super.computeVerticalScrollOffset());
    }

    @Override // android.view.View
    public final int computeVerticalScrollRange() {
        int childCount = getChildCount();
        int height = (getHeight() - getPaddingBottom()) - getPaddingTop();
        if (childCount == 0) {
            return height;
        }
        View childAt = getChildAt(0);
        int bottom = childAt.getBottom() + ((FrameLayout.LayoutParams) childAt.getLayoutParams()).bottomMargin;
        int scrollY = getScrollY();
        int max = Math.max(0, bottom - height);
        if (scrollY < 0) {
            return bottom - scrollY;
        }
        if (scrollY <= max) {
            return bottom;
        }
        return bottom + (scrollY - max);
    }

    @Override // cal.ald
    public final void d(View view, int i2, int i3, int i4, int i5, int i6) {
        int scrollY = getScrollY();
        scrollBy(0, i5);
        int scrollY2 = getScrollY() - scrollY;
        this.d.b(0, scrollY2, 0, i5 - scrollY2, null, i6, null);
    }

    @Override // android.view.ViewGroup, android.view.View
    public final boolean dispatchKeyEvent(KeyEvent keyEvent) {
        if (!super.dispatchKeyEvent(keyEvent) && !k(keyEvent)) {
            return false;
        }
        return true;
    }

    @Override // android.view.View
    public final boolean dispatchNestedFling(float f, float f2, boolean z) {
        ViewParent viewParent;
        alc alcVar = this.d;
        if (alcVar.d && (viewParent = alcVar.a) != null) {
            return amn.e(viewParent, alcVar.c, f, f2, z);
        }
        return false;
    }

    @Override // android.view.View
    public final boolean dispatchNestedPreFling(float f, float f2) {
        ViewParent viewParent;
        alc alcVar = this.d;
        if (alcVar.d && (viewParent = alcVar.a) != null) {
            return amn.f(viewParent, alcVar.c, f, f2);
        }
        return false;
    }

    @Override // android.view.View
    public final boolean dispatchNestedPreScroll(int i2, int i3, int[] iArr, int[] iArr2) {
        return this.d.a(i2, i3, iArr, iArr2, 0);
    }

    @Override // android.view.View
    public final boolean dispatchNestedScroll(int i2, int i3, int i4, int i5, int[] iArr) {
        return this.d.b(i2, i3, i4, i5, iArr, 0, null);
    }

    @Override // android.view.View
    public final void draw(Canvas canvas) {
        int i2;
        super.draw(canvas);
        int scrollY = getScrollY();
        int i3 = 0;
        if (!this.b.isFinished()) {
            int save = canvas.save();
            int width = getWidth();
            int height = getHeight();
            int min = Math.min(0, scrollY);
            if (getClipToPadding()) {
                width -= getPaddingLeft() + getPaddingRight();
                i2 = getPaddingLeft();
            } else {
                i2 = 0;
            }
            if (getClipToPadding()) {
                height -= getPaddingTop() + getPaddingBottom();
                min += getPaddingTop();
            }
            canvas.translate(i2, min);
            this.b.setSize(width, height);
            if (this.b.draw(canvas)) {
                postInvalidateOnAnimation();
            }
            canvas.restoreToCount(save);
        }
        if (!this.c.isFinished()) {
            int save2 = canvas.save();
            int width2 = getWidth();
            int height2 = getHeight();
            int max = Math.max(h(), scrollY) + height2;
            if (getClipToPadding()) {
                width2 -= getPaddingLeft() + getPaddingRight();
                i3 = getPaddingLeft();
            }
            if (getClipToPadding()) {
                height2 -= getPaddingTop() + getPaddingBottom();
                max -= getPaddingBottom();
            }
            canvas.translate(i3 - width2, max);
            canvas.rotate(180.0f, width2, 0.0f);
            this.c.setSize(width2, height2);
            if (this.c.draw(canvas)) {
                postInvalidateOnAnimation();
            }
            canvas.restoreToCount(save2);
        }
    }

    @Override // cal.ale
    public final void e(View view, int i2, int i3, int i4, int i5, int i6, int[] iArr) {
        int scrollY = getScrollY();
        scrollBy(0, i5);
        int scrollY2 = getScrollY() - scrollY;
        if (iArr != null) {
            iArr[1] = iArr[1] + scrollY2;
        }
        this.d.b(0, scrollY2, 0, i5 - scrollY2, null, i6, iArr);
    }

    @Override // cal.ald
    public final void f(View view, View view2, int i2, int i3) {
        alf alfVar = this.E;
        if (i3 == 1) {
            alfVar.b = i2;
        } else {
            alfVar.a = i2;
        }
        this.d.c(2, i3);
    }

    @Override // cal.ald
    public final void g(View view, int i2) {
        ViewParent viewParent;
        alf alfVar = this.E;
        if (i2 == 1) {
            alfVar.b = 0;
        } else {
            alfVar.a = 0;
        }
        alc alcVar = this.d;
        if (i2 != 0) {
            viewParent = alcVar.b;
        } else {
            viewParent = alcVar.a;
        }
        if (viewParent != null) {
            amn.d(viewParent, alcVar.c, i2);
            if (i2 != 0) {
                alcVar.b = null;
            } else {
                alcVar.a = null;
            }
        }
    }

    @Override // android.view.View
    protected final float getBottomFadingEdgeStrength() {
        if (getChildCount() == 0) {
            return 0.0f;
        }
        View childAt = getChildAt(0);
        FrameLayout.LayoutParams layoutParams = (FrameLayout.LayoutParams) childAt.getLayoutParams();
        int verticalFadingEdgeLength = getVerticalFadingEdgeLength();
        int bottom = ((childAt.getBottom() + layoutParams.bottomMargin) - getScrollY()) - (getHeight() - getPaddingBottom());
        if (bottom < verticalFadingEdgeLength) {
            return bottom / verticalFadingEdgeLength;
        }
        return 1.0f;
    }

    @Override // android.view.ViewGroup
    public final int getNestedScrollAxes() {
        alf alfVar = this.E;
        return alfVar.b | alfVar.a;
    }

    @Override // android.view.View
    protected final float getTopFadingEdgeStrength() {
        if (getChildCount() == 0) {
            return 0.0f;
        }
        int verticalFadingEdgeLength = getVerticalFadingEdgeLength();
        int scrollY = getScrollY();
        if (scrollY < verticalFadingEdgeLength) {
            return scrollY / verticalFadingEdgeLength;
        }
        return 1.0f;
    }

    public final int h() {
        if (getChildCount() <= 0) {
            return 0;
        }
        View childAt = getChildAt(0);
        FrameLayout.LayoutParams layoutParams = (FrameLayout.LayoutParams) childAt.getLayoutParams();
        return Math.max(0, ((childAt.getHeight() + layoutParams.topMargin) + layoutParams.bottomMargin) - ((getHeight() - getPaddingTop()) - getPaddingBottom()));
    }

    @Override // android.view.View
    public final boolean hasNestedScrollingParent() {
        if (this.d.a != null) {
            return true;
        }
        return false;
    }

    public final void i(int i2) {
        if (getChildCount() > 0) {
            this.a.fling(getScrollX(), getScrollY(), 0, i2, 0, 0, Integer.MIN_VALUE, Integer.MAX_VALUE, 0, 0);
            this.d.c(2, 1);
            this.C = getScrollY();
            postInvalidateOnAnimation();
            if (aip.d()) {
                apa.a(this, Math.abs(this.a.getCurrVelocity()));
            }
        }
    }

    @Override // android.view.View
    public final boolean isNestedScrollingEnabled() {
        return this.d.d;
    }

    public final boolean j(int i2) {
        View findFocus = findFocus();
        if (findFocus == this) {
            findFocus = null;
        }
        View findNextFocus = FocusFinder.getInstance().findNextFocus(this, findFocus, i2);
        int height = (int) (getHeight() * 0.5f);
        if (findNextFocus != null && u(findNextFocus, height, getHeight())) {
            findNextFocus.getDrawingRect(this.m);
            offsetDescendantRectToMyCoords(findNextFocus, this.m);
            r(b(this.m), 0, 1, true);
            findNextFocus.requestFocus(i2);
        } else {
            if (i2 == 33 && getScrollY() < height) {
                height = getScrollY();
            } else if (i2 == 130 && getChildCount() > 0) {
                View childAt = getChildAt(0);
                height = Math.min((childAt.getBottom() + ((FrameLayout.LayoutParams) childAt.getLayoutParams()).bottomMargin) - ((getScrollY() + getHeight()) - getPaddingBottom()), height);
            }
            if (height == 0) {
                return false;
            }
            if (i2 != 130) {
                height = -height;
            }
            r(height, 0, 1, true);
        }
        if (findFocus != null && findFocus.isFocused() && !u(findFocus, 0, getHeight())) {
            int descendantFocusability = getDescendantFocusability();
            setDescendantFocusability(131072);
            requestFocus();
            setDescendantFocusability(descendantFocusability);
        }
        return true;
    }

    public final boolean k(KeyEvent keyEvent) {
        this.m.setEmpty();
        int i2 = 130;
        if (getChildCount() > 0) {
            View childAt = getChildAt(0);
            FrameLayout.LayoutParams layoutParams = (FrameLayout.LayoutParams) childAt.getLayoutParams();
            if (childAt.getHeight() + layoutParams.topMargin + layoutParams.bottomMargin > (getHeight() - getPaddingTop()) - getPaddingBottom()) {
                if (keyEvent.getAction() != 0) {
                    return false;
                }
                int keyCode = keyEvent.getKeyCode();
                if (keyCode != 19) {
                    if (keyCode != 20) {
                        if (keyCode != 62) {
                            if (keyCode != 92) {
                                if (keyCode != 93) {
                                    if (keyCode != 122) {
                                        if (keyCode != 123) {
                                            return false;
                                        }
                                        n(130);
                                        return false;
                                    }
                                    n(33);
                                    return false;
                                }
                                return l(130);
                            }
                            return l(33);
                        }
                        if (true == keyEvent.isShiftPressed()) {
                            i2 = 33;
                        }
                        n(i2);
                        return false;
                    }
                    if (keyEvent.isAltPressed()) {
                        return l(130);
                    }
                    return j(130);
                }
                if (keyEvent.isAltPressed()) {
                    return l(33);
                }
                return j(33);
            }
        }
        if (isFocused() && keyEvent.getKeyCode() != 4) {
            View findFocus = findFocus();
            if (findFocus == this) {
                findFocus = null;
            }
            View findNextFocus = FocusFinder.getInstance().findNextFocus(this, findFocus, 130);
            if (findNextFocus != null && findNextFocus != this && findNextFocus.requestFocus(130)) {
                return true;
            }
        }
        return false;
    }

    public final boolean l(int i2) {
        int childCount;
        Rect rect = this.m;
        int height = getHeight();
        rect.top = 0;
        this.m.bottom = height;
        if (i2 == 130 && (childCount = getChildCount()) > 0) {
            View childAt = getChildAt(childCount - 1);
            this.m.bottom = childAt.getBottom() + ((FrameLayout.LayoutParams) childAt.getLayoutParams()).bottomMargin + getPaddingBottom();
            Rect rect2 = this.m;
            rect2.top = rect2.bottom - height;
        }
        Rect rect3 = this.m;
        return v(i2, rect3.top, rect3.bottom);
    }

    final boolean m(int i2, int i3, int i4, int i5) {
        boolean z;
        boolean z2;
        getOverScrollMode();
        super.computeHorizontalScrollRange();
        super.computeHorizontalScrollExtent();
        computeVerticalScrollRange();
        super.computeVerticalScrollExtent();
        if (i3 > 0 || i3 < 0) {
            z = true;
        } else {
            z = false;
        }
        int i6 = i4 + i2;
        if (i6 <= i5) {
            if (i6 < 0) {
                i5 = 0;
            } else {
                i5 = i6;
                z2 = false;
                if (z2 && this.d.b == null) {
                    this.a.springBack(0, i5, 0, 0, 0, h());
                }
                onOverScrolled(0, i5, z, z2);
                if (z && !z2) {
                    return false;
                }
                return true;
            }
        }
        z2 = true;
        if (z2) {
            this.a.springBack(0, i5, 0, 0, 0, h());
        }
        onOverScrolled(0, i5, z, z2);
        if (z) {
        }
        return true;
    }

    @Override // android.view.ViewGroup
    protected void measureChild(View view, int i2, int i3) {
        view.measure(getChildMeasureSpec(i2, getPaddingLeft() + getPaddingRight(), view.getLayoutParams().width), View.MeasureSpec.makeMeasureSpec(0, 0));
    }

    /* JADX INFO: Access modifiers changed from: protected */
    @Override // android.view.ViewGroup
    public void measureChildWithMargins(View view, int i2, int i3, int i4, int i5) {
        ViewGroup.MarginLayoutParams marginLayoutParams = (ViewGroup.MarginLayoutParams) view.getLayoutParams();
        view.measure(getChildMeasureSpec(i2, getPaddingLeft() + getPaddingRight() + marginLayoutParams.leftMargin + marginLayoutParams.rightMargin + i3, marginLayoutParams.width), View.MeasureSpec.makeMeasureSpec(marginLayoutParams.topMargin + marginLayoutParams.bottomMargin, 0));
    }

    public final void n(int i2) {
        int height = getHeight();
        if (i2 == 130) {
            this.m.top = getScrollY() + height;
            int childCount = getChildCount();
            if (childCount > 0) {
                View childAt = getChildAt(childCount - 1);
                int bottom = childAt.getBottom() + ((FrameLayout.LayoutParams) childAt.getLayoutParams()).bottomMargin + getPaddingBottom();
                if (this.m.top + height > bottom) {
                    this.m.top = bottom - height;
                }
            }
        } else {
            this.m.top = getScrollY() - height;
            if (this.m.top < 0) {
                this.m.top = 0;
            }
        }
        Rect rect = this.m;
        rect.bottom = rect.top + height;
        Rect rect2 = this.m;
        v(i2, rect2.top, rect2.bottom);
    }

    public final void o(int i2, int i3, boolean z) {
        if (getChildCount() == 0) {
            return;
        }
        if (AnimationUtils.currentAnimationTimeMillis() - this.l > 250) {
            View childAt = getChildAt(0);
            FrameLayout.LayoutParams layoutParams = (FrameLayout.LayoutParams) childAt.getLayoutParams();
            int height = childAt.getHeight() + layoutParams.topMargin + layoutParams.bottomMargin;
            int height2 = (getHeight() - getPaddingTop()) - getPaddingBottom();
            int scrollY = getScrollY();
            this.a.startScroll(getScrollX(), scrollY, 0, Math.max(0, Math.min(i3 + scrollY, Math.max(0, height - height2))) - scrollY, 250);
            if (z) {
                this.d.c(2, 1);
            } else {
                alc alcVar = this.d;
                ViewParent viewParent = alcVar.b;
                if (viewParent != null) {
                    amn.d(viewParent, alcVar.c, 1);
                    alcVar.b = null;
                }
            }
            this.C = getScrollY();
            postInvalidateOnAnimation();
        } else {
            if (!this.a.isFinished()) {
                this.a.abortAnimation();
                alc alcVar2 = this.d;
                ViewParent viewParent2 = alcVar2.b;
                if (viewParent2 != null) {
                    amn.d(viewParent2, alcVar2.c, 1);
                    alcVar2.b = null;
                }
            }
            scrollBy(i2, i3);
        }
        this.l = AnimationUtils.currentAnimationTimeMillis();
    }

    @Override // android.view.ViewGroup, android.view.View
    public final void onAttachedToWindow() {
        super.onAttachedToWindow();
        this.p = false;
    }

    @Override // android.view.View
    public final boolean onGenericMotionEvent(MotionEvent motionEvent) {
        int i2;
        int i3;
        float f;
        boolean z = false;
        if (motionEvent.getAction() == 8 && !this.r) {
            if ((motionEvent.getSource() & 2) == 2) {
                i2 = 9;
                f = motionEvent.getAxisValue(9);
                i3 = (int) motionEvent.getX();
            } else if ((motionEvent.getSource() & 4194304) == 4194304) {
                i2 = 26;
                float axisValue = motionEvent.getAxisValue(26);
                i3 = getWidth() / 2;
                f = axisValue;
            } else {
                i2 = 0;
                i3 = 0;
                f = 0.0f;
            }
            if (f != 0.0f) {
                float a = f * a();
                if ((motionEvent.getSource() & 8194) == 8194) {
                    z = true;
                }
                r(-((int) a), i3, 1, z);
                this.g.a(motionEvent, i2);
                return true;
            }
        }
        return false;
    }

    @Override // android.view.ViewGroup
    public boolean onInterceptTouchEvent(MotionEvent motionEvent) {
        int action = motionEvent.getAction();
        boolean z = true;
        if (action == 2) {
            if (this.r) {
                return true;
            }
            action = 2;
        }
        int i2 = action & 255;
        if (i2 != 0) {
            if (i2 != 1) {
                if (i2 != 2) {
                    if (i2 != 3) {
                        if (i2 == 6) {
                            s(motionEvent);
                        }
                    }
                } else {
                    int i3 = this.y;
                    if (i3 != -1) {
                        int findPointerIndex = motionEvent.findPointerIndex(i3);
                        if (findPointerIndex == -1) {
                            Log.e("NestedScrollView", a.i(i3, "Invalid pointerId=", " in onInterceptTouchEvent"));
                        } else {
                            int y = (int) motionEvent.getY(findPointerIndex);
                            if (Math.abs(y - this.n) > this.v) {
                                alf alfVar = this.E;
                                if ((2 & (alfVar.b | alfVar.a)) == 0) {
                                    this.r = true;
                                    this.n = y;
                                    if (this.s == null) {
                                        this.s = VelocityTracker.obtain();
                                    }
                                    this.s.addMovement(motionEvent);
                                    this.B = 0;
                                    ViewParent parent = getParent();
                                    if (parent != null) {
                                        parent.requestDisallowInterceptTouchEvent(true);
                                    }
                                }
                            }
                        }
                    }
                }
            }
            this.r = false;
            this.y = -1;
            VelocityTracker velocityTracker = this.s;
            if (velocityTracker != null) {
                velocityTracker.recycle();
                this.s = null;
            }
            if (this.a.springBack(getScrollX(), getScrollY(), 0, 0, 0, h())) {
                postInvalidateOnAnimation();
            }
            alc alcVar = this.d;
            ViewParent viewParent = alcVar.a;
            if (viewParent != null) {
                amn.d(viewParent, alcVar.c, 0);
                alcVar.a = null;
            }
        } else {
            int y2 = (int) motionEvent.getY();
            int x = (int) motionEvent.getX();
            if (getChildCount() > 0) {
                int scrollY = getScrollY();
                View childAt = getChildAt(0);
                if (y2 >= childAt.getTop() - scrollY && y2 < childAt.getBottom() - scrollY && x >= childAt.getLeft() && x < childAt.getRight()) {
                    this.n = y2;
                    this.y = motionEvent.getPointerId(0);
                    VelocityTracker velocityTracker2 = this.s;
                    if (velocityTracker2 == null) {
                        this.s = VelocityTracker.obtain();
                    } else {
                        velocityTracker2.clear();
                    }
                    this.s.addMovement(motionEvent);
                    this.a.computeScrollOffset();
                    if (!w(motionEvent) && this.a.isFinished()) {
                        z = false;
                    }
                    this.r = z;
                    this.d.c(2, 0);
                }
            }
            if (!w(motionEvent) && this.a.isFinished()) {
                z = false;
            }
            this.r = z;
            VelocityTracker velocityTracker3 = this.s;
            if (velocityTracker3 != null) {
                velocityTracker3.recycle();
                this.s = null;
            }
        }
        return this.r;
    }

    @Override // android.widget.FrameLayout, android.view.ViewGroup, android.view.View
    protected final void onLayout(boolean z, int i2, int i3, int i4, int i5) {
        int i6;
        super.onLayout(z, i2, i3, i4, i5);
        int i7 = 0;
        this.o = false;
        View view = this.q;
        if (view != null && t(view, this)) {
            View view2 = this.q;
            view2.getDrawingRect(this.m);
            offsetDescendantRectToMyCoords(view2, this.m);
            int b = b(this.m);
            if (b != 0) {
                scrollBy(0, b);
            }
        }
        this.q = null;
        if (!this.p) {
            if (this.D != null) {
                scrollTo(getScrollX(), this.D.a);
                this.D = null;
            }
            if (getChildCount() > 0) {
                View childAt = getChildAt(0);
                FrameLayout.LayoutParams layoutParams = (FrameLayout.LayoutParams) childAt.getLayoutParams();
                i6 = childAt.getMeasuredHeight() + layoutParams.topMargin + layoutParams.bottomMargin;
            } else {
                i6 = 0;
            }
            int paddingTop = ((i5 - i3) - getPaddingTop()) - getPaddingBottom();
            int scrollY = getScrollY();
            if (paddingTop < i6 && scrollY >= 0) {
                i7 = paddingTop + scrollY > i6 ? i6 - paddingTop : scrollY;
            }
            if (i7 != scrollY) {
                scrollTo(getScrollX(), i7);
            }
        }
        scrollTo(getScrollX(), getScrollY());
        this.p = true;
    }

    @Override // android.widget.FrameLayout, android.view.View
    protected final void onMeasure(int i2, int i3) {
        super.onMeasure(i2, i3);
        if (this.t && View.MeasureSpec.getMode(i3) != 0 && getChildCount() > 0) {
            View childAt = getChildAt(0);
            FrameLayout.LayoutParams layoutParams = (FrameLayout.LayoutParams) childAt.getLayoutParams();
            int measuredHeight = childAt.getMeasuredHeight();
            int measuredHeight2 = (((getMeasuredHeight() - getPaddingTop()) - getPaddingBottom()) - layoutParams.topMargin) - layoutParams.bottomMargin;
            if (measuredHeight < measuredHeight2) {
                childAt.measure(getChildMeasureSpec(i2, getPaddingLeft() + getPaddingRight() + layoutParams.leftMargin + layoutParams.rightMargin, layoutParams.width), View.MeasureSpec.makeMeasureSpec(measuredHeight2, 1073741824));
            }
        }
    }

    @Override // android.view.ViewGroup, android.view.ViewParent
    public final boolean onNestedFling(View view, float f, float f2, boolean z) {
        ViewParent viewParent;
        if (!z) {
            alc alcVar = this.d;
            if (alcVar.d && (viewParent = alcVar.a) != null) {
                amn.e(viewParent, alcVar.c, 0.0f, f2, true);
            }
            i((int) f2);
            return true;
        }
        return false;
    }

    @Override // android.view.ViewGroup, android.view.ViewParent
    public final boolean onNestedPreFling(View view, float f, float f2) {
        ViewParent viewParent;
        alc alcVar = this.d;
        if (alcVar.d && (viewParent = alcVar.a) != null) {
            return amn.f(viewParent, alcVar.c, f, f2);
        }
        return false;
    }

    @Override // android.view.ViewGroup, android.view.ViewParent
    public final void onNestedPreScroll(View view, int i2, int i3, int[] iArr) {
        this.d.a(i2, i3, iArr, null, 0);
    }

    @Override // android.view.ViewGroup, android.view.ViewParent
    public final void onNestedScroll(View view, int i2, int i3, int i4, int i5) {
        int scrollY = getScrollY();
        scrollBy(0, i5);
        int scrollY2 = getScrollY() - scrollY;
        this.d.b(0, scrollY2, 0, i5 - scrollY2, null, 0, null);
    }

    @Override // android.view.ViewGroup, android.view.ViewParent
    public final void onNestedScrollAccepted(View view, View view2, int i2) {
        this.E.a = i2;
        this.d.c(2, 0);
    }

    /* JADX INFO: Access modifiers changed from: protected */
    @Override // android.view.View
    public void onOverScrolled(int i2, int i3, boolean z, boolean z2) {
        super.scrollTo(i2, i3);
    }

    @Override // android.view.ViewGroup
    protected final boolean onRequestFocusInDescendants(int i2, Rect rect) {
        View findNextFocusFromRect;
        if (i2 == 2) {
            i2 = 130;
        } else if (i2 == 1) {
            i2 = 33;
        }
        if (rect == null) {
            findNextFocusFromRect = FocusFinder.getInstance().findNextFocus(this, null, i2);
        } else {
            findNextFocusFromRect = FocusFinder.getInstance().findNextFocusFromRect(this, rect, i2);
        }
        if (findNextFocusFromRect == null || !u(findNextFocusFromRect, 0, getHeight())) {
            return false;
        }
        return findNextFocusFromRect.requestFocus(i2, rect);
    }

    @Override // android.view.View
    protected final void onRestoreInstanceState(Parcelable parcelable) {
        if (!(parcelable instanceof ape)) {
            super.onRestoreInstanceState(parcelable);
            return;
        }
        ape apeVar = (ape) parcelable;
        super.onRestoreInstanceState(apeVar.getSuperState());
        this.D = apeVar;
        this.o = true;
        super.requestLayout();
    }

    @Override // android.view.View
    protected final Parcelable onSaveInstanceState() {
        ape apeVar = new ape(super.onSaveInstanceState());
        apeVar.a = getScrollY();
        return apeVar;
    }

    @Override // android.view.View
    protected final void onScrollChanged(int i2, int i3, int i4, int i5) {
        super.onScrollChanged(i2, i3, i4, i5);
        apc apcVar = this.e;
        if (apcVar != null) {
            apcVar.a(i3);
        }
    }

    @Override // android.view.View
    protected final void onSizeChanged(int i2, int i3, int i4, int i5) {
        super.onSizeChanged(i2, i3, i4, i5);
        View findFocus = findFocus();
        if (findFocus != null && this != findFocus && u(findFocus, 0, i5)) {
            findFocus.getDrawingRect(this.m);
            offsetDescendantRectToMyCoords(findFocus, this.m);
            int b = b(this.m);
            if (b != 0) {
                if (this.u) {
                    o(0, b, false);
                } else {
                    scrollBy(0, b);
                }
            }
        }
    }

    @Override // android.view.ViewGroup, android.view.ViewParent
    public final boolean onStartNestedScroll(View view, View view2, int i2) {
        return q(view, view2, i2, 0);
    }

    @Override // android.view.ViewGroup, android.view.ViewParent
    public final void onStopNestedScroll(View view) {
        this.E.a = 0;
        alc alcVar = this.d;
        ViewParent viewParent = alcVar.a;
        if (viewParent != null) {
            amn.d(viewParent, alcVar.c, 0);
            alcVar.a = null;
        }
    }

    /* JADX WARN: Code restructure failed: missing block: B:138:0x0234, code lost:
    
        if (cal.amn.f(r5, r2.c, 0.0f, r1) == false) goto L132;
     */
    @Override // android.view.View
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct code enable 'Show inconsistent code' option in preferences
    */
    public boolean onTouchEvent(android.view.MotionEvent r19) {
        /*
            Method dump skipped, instructions count: 725
            To view this dump change 'Code comments level' option to 'DEBUG'
        */
        throw new UnsupportedOperationException("Method not decompiled: androidx.core.widget.NestedScrollView.onTouchEvent(android.view.MotionEvent):boolean");
    }

    @Override // cal.ald
    public boolean q(View view, View view2, int i2, int i3) {
        if ((i2 & 2) != 0) {
            return true;
        }
        return false;
    }

    @Override // android.view.ViewGroup, android.view.ViewParent
    public final void requestChildFocus(View view, View view2) {
        if (!this.o) {
            view2.getDrawingRect(this.m);
            offsetDescendantRectToMyCoords(view2, this.m);
            int b = b(this.m);
            if (b != 0) {
                scrollBy(0, b);
            }
        } else {
            this.q = view2;
        }
        super.requestChildFocus(view, view2);
    }

    @Override // android.view.ViewGroup, android.view.ViewParent
    public final boolean requestChildRectangleOnScreen(View view, Rect rect, boolean z) {
        boolean z2;
        rect.offset(view.getLeft() - view.getScrollX(), view.getTop() - view.getScrollY());
        int b = b(rect);
        if (b != 0) {
            z2 = true;
        } else {
            z2 = false;
        }
        if (z2) {
            if (z) {
                scrollBy(0, b);
            } else {
                o(0, b, false);
            }
        }
        return z2;
    }

    @Override // android.view.ViewGroup, android.view.ViewParent
    public final void requestDisallowInterceptTouchEvent(boolean z) {
        VelocityTracker velocityTracker;
        if (z && (velocityTracker = this.s) != null) {
            velocityTracker.recycle();
            this.s = null;
        }
        super.requestDisallowInterceptTouchEvent(z);
    }

    @Override // android.view.View, android.view.ViewParent
    public final void requestLayout() {
        this.o = true;
        super.requestLayout();
    }

    @Override // android.view.View
    public final void scrollTo(int i2, int i3) {
        if (getChildCount() > 0) {
            View childAt = getChildAt(0);
            FrameLayout.LayoutParams layoutParams = (FrameLayout.LayoutParams) childAt.getLayoutParams();
            int width = (getWidth() - getPaddingLeft()) - getPaddingRight();
            int width2 = childAt.getWidth() + layoutParams.leftMargin + layoutParams.rightMargin;
            int height = (getHeight() - getPaddingTop()) - getPaddingBottom();
            int height2 = childAt.getHeight() + layoutParams.topMargin + layoutParams.bottomMargin;
            if (width < width2 && i2 >= 0) {
                if (width + i2 > width2) {
                    i2 = width2 - width;
                }
            } else {
                i2 = 0;
            }
            if (height < height2 && i3 >= 0) {
                if (height + i3 > height2) {
                    i3 = height2 - height;
                }
            } else {
                i3 = 0;
            }
            if (i2 != getScrollX() || i3 != getScrollY()) {
                super.scrollTo(i2, i3);
            }
        }
    }

    @Override // android.view.View
    public final void setNestedScrollingEnabled(boolean z) {
        alc alcVar = this.d;
        if (alcVar.d) {
            alu.n(alcVar.c);
        }
        alcVar.d = z;
    }

    @Override // android.widget.FrameLayout, android.view.ViewGroup
    public final boolean shouldDelayChildPressedState() {
        return true;
    }

    @Override // android.view.View
    public final boolean startNestedScroll(int i2) {
        return this.d.c(i2, 0);
    }

    @Override // android.view.View
    public final void stopNestedScroll() {
        alc alcVar = this.d;
        ViewParent viewParent = alcVar.a;
        if (viewParent != null) {
            amn.d(viewParent, alcVar.c, 0);
            alcVar.a = null;
        }
    }

    public NestedScrollView(Context context, AttributeSet attributeSet) {
        this(context, attributeSet, com.google.android.calendar.R.attr.nestedScrollViewStyle);
    }

    public NestedScrollView(Context context, AttributeSet attributeSet, int i2) {
        super(context, attributeSet, i2);
        EdgeEffect edgeEffect;
        EdgeEffect edgeEffect2;
        this.m = new Rect();
        this.o = true;
        this.p = false;
        this.q = null;
        this.r = false;
        this.u = true;
        this.y = -1;
        this.z = new int[2];
        this.A = new int[2];
        apb apbVar = new apb(this);
        this.f = apbVar;
        this.g = new akt(getContext(), apbVar);
        if (Build.VERSION.SDK_INT >= 31) {
            edgeEffect = aox.c(context, attributeSet);
        } else {
            edgeEffect = new EdgeEffect(context);
        }
        this.b = edgeEffect;
        if (Build.VERSION.SDK_INT >= 31) {
            edgeEffect2 = aox.c(context, attributeSet);
        } else {
            edgeEffect2 = new EdgeEffect(context);
        }
        this.c = edgeEffect2;
        this.k = context.getResources().getDisplayMetrics().density * 160.0f * 386.0878f * 0.84f;
        this.a = new OverScroller(getContext());
        setFocusable(true);
        setDescendantFocusability(262144);
        setWillNotDraw(false);
        ViewConfiguration viewConfiguration = ViewConfiguration.get(getContext());
        this.v = viewConfiguration.getScaledTouchSlop();
        this.w = viewConfiguration.getScaledMinimumFlingVelocity();
        this.x = viewConfiguration.getScaledMaximumFlingVelocity();
        TypedArray obtainStyledAttributes = context.obtainStyledAttributes(attributeSet, j, i2, 0);
        boolean z = obtainStyledAttributes.getBoolean(0, false);
        if (z != this.t) {
            this.t = z;
            this.o = true;
            super.requestLayout();
        }
        obtainStyledAttributes.recycle();
        this.E = new alf();
        alc alcVar = new alc(this);
        this.d = alcVar;
        if (alcVar.d) {
            alu.n(alcVar.c);
        }
        alcVar.d = true;
        ame.g(this, i);
    }

    @Override // android.view.ViewGroup
    public final void addView(View view, int i2) {
        if (getChildCount() <= 0) {
            super.addView(view, i2);
            return;
        }
        throw new IllegalStateException("ScrollView can host only one direct child");
    }

    @Override // android.view.ViewGroup
    public final void addView(View view, int i2, ViewGroup.LayoutParams layoutParams) {
        if (getChildCount() <= 0) {
            super.addView(view, i2, layoutParams);
            return;
        }
        throw new IllegalStateException("ScrollView can host only one direct child");
    }

    @Override // android.view.ViewGroup, android.view.ViewManager
    public final void addView(View view, ViewGroup.LayoutParams layoutParams) {
        if (getChildCount() <= 0) {
            super.addView(view, layoutParams);
            return;
        }
        throw new IllegalStateException("ScrollView can host only one direct child");
    }
}
