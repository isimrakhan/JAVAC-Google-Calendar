package androidx.core.graphics.drawable;

import android.content.res.ColorStateList;
import android.graphics.PorterDuff;
import android.os.Parcelable;
import cal.blw;
import java.nio.charset.Charset;

/* compiled from: PG */
/* loaded from: classes.dex */
public class IconCompatParcelizer {
    /* JADX WARN: Can't fix incorrect switch cases order, some code will duplicate */
    /* JADX WARN: Failed to find 'out' block for switch in B:26:0x008c. Please report as an issue. */
    public static IconCompat read(blw blwVar) {
        Parcelable parcelable;
        IconCompat iconCompat = new IconCompat();
        int i = iconCompat.b;
        if (blwVar.r(1)) {
            i = blwVar.a();
        }
        iconCompat.b = i;
        byte[] bArr = iconCompat.d;
        if (blwVar.r(2)) {
            bArr = blwVar.s();
        }
        iconCompat.d = bArr;
        Parcelable parcelable2 = iconCompat.e;
        if (blwVar.r(3)) {
            parcelable2 = blwVar.b();
        }
        iconCompat.e = parcelable2;
        int i2 = iconCompat.f;
        if (blwVar.r(4)) {
            i2 = blwVar.a();
        }
        iconCompat.f = i2;
        int i3 = iconCompat.g;
        if (blwVar.r(5)) {
            i3 = blwVar.a();
        }
        iconCompat.g = i3;
        Parcelable parcelable3 = iconCompat.h;
        if (blwVar.r(6)) {
            parcelable3 = blwVar.b();
        }
        iconCompat.h = (ColorStateList) parcelable3;
        String str = iconCompat.j;
        if (blwVar.r(7)) {
            str = blwVar.f();
        }
        iconCompat.j = str;
        String str2 = iconCompat.k;
        if (blwVar.r(8)) {
            str2 = blwVar.f();
        }
        iconCompat.k = str2;
        iconCompat.i = PorterDuff.Mode.valueOf(iconCompat.j);
        switch (iconCompat.b) {
            case -1:
                parcelable = iconCompat.e;
                if (parcelable == null) {
                    throw new IllegalArgumentException("Invalid icon");
                }
                iconCompat.c = parcelable;
                return iconCompat;
            case 0:
            default:
                return iconCompat;
            case 1:
            case 5:
                parcelable = iconCompat.e;
                if (parcelable == null) {
                    byte[] bArr2 = iconCompat.d;
                    iconCompat.c = bArr2;
                    iconCompat.b = 3;
                    iconCompat.f = 0;
                    iconCompat.g = bArr2.length;
                    return iconCompat;
                }
                iconCompat.c = parcelable;
                return iconCompat;
            case 2:
            case 4:
            case 6:
                iconCompat.c = new String(iconCompat.d, Charset.forName("UTF-16"));
                if (iconCompat.b == 2 && iconCompat.k == null) {
                    iconCompat.k = ((String) iconCompat.c).split(":", -1)[0];
                }
                return iconCompat;
            case 3:
                iconCompat.c = iconCompat.d;
                return iconCompat;
        }
    }

    public static void write(IconCompat iconCompat, blw blwVar) {
        iconCompat.j = iconCompat.i.name();
        switch (iconCompat.b) {
            case -1:
                iconCompat.e = (Parcelable) iconCompat.c;
                break;
            case 1:
            case 5:
                iconCompat.e = (Parcelable) iconCompat.c;
                break;
            case 2:
                iconCompat.d = ((String) iconCompat.c).getBytes(Charset.forName("UTF-16"));
                break;
            case 3:
                iconCompat.d = (byte[]) iconCompat.c;
                break;
            case 4:
            case 6:
                iconCompat.d = iconCompat.c.toString().getBytes(Charset.forName("UTF-16"));
                break;
        }
        int i = iconCompat.b;
        if (i != -1) {
            blwVar.h(1);
            blwVar.l(i);
        }
        byte[] bArr = iconCompat.d;
        if (bArr != null) {
            blwVar.h(2);
            blwVar.j(bArr);
        }
        Parcelable parcelable = iconCompat.e;
        if (parcelable != null) {
            blwVar.h(3);
            blwVar.m(parcelable);
        }
        int i2 = iconCompat.f;
        if (i2 != 0) {
            blwVar.h(4);
            blwVar.l(i2);
        }
        int i3 = iconCompat.g;
        if (i3 != 0) {
            blwVar.h(5);
            blwVar.l(i3);
        }
        ColorStateList colorStateList = iconCompat.h;
        if (colorStateList != null) {
            blwVar.h(6);
            blwVar.m(colorStateList);
        }
        String str = iconCompat.j;
        if (str != null) {
            blwVar.h(7);
            blwVar.n(str);
        }
        String str2 = iconCompat.k;
        if (str2 != null) {
            blwVar.h(8);
            blwVar.n(str2);
        }
    }
}
