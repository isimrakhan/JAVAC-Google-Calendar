package androidx.core.app;

import android.app.Activity;
import android.app.AppComponentFactory;
import android.app.Application;
import android.app.Service;
import android.content.BroadcastReceiver;
import android.content.ContentProvider;
import android.content.Intent;
import cal.afl;

/* compiled from: PG */
/* loaded from: classes.dex */
public class CoreComponentFactory extends AppComponentFactory {
    public final Activity instantiateActivity(ClassLoader classLoader, String str, Intent intent) {
        Object a;
        Object instantiateActivity = super.instantiateActivity(classLoader, str, intent);
        if ((instantiateActivity instanceof afl) && (a = ((afl) instantiateActivity).a()) != null) {
            instantiateActivity = a;
        }
        return (Activity) instantiateActivity;
    }

    public final Application instantiateApplication(ClassLoader classLoader, String str) {
        Object a;
        Object instantiateApplication = super.instantiateApplication(classLoader, str);
        if ((instantiateApplication instanceof afl) && (a = ((afl) instantiateApplication).a()) != null) {
            instantiateApplication = a;
        }
        return (Application) instantiateApplication;
    }

    public final ContentProvider instantiateProvider(ClassLoader classLoader, String str) {
        Object a;
        Object instantiateProvider = super.instantiateProvider(classLoader, str);
        if ((instantiateProvider instanceof afl) && (a = ((afl) instantiateProvider).a()) != null) {
            instantiateProvider = a;
        }
        return (ContentProvider) instantiateProvider;
    }

    public final BroadcastReceiver instantiateReceiver(ClassLoader classLoader, String str, Intent intent) {
        Object a;
        Object instantiateReceiver = super.instantiateReceiver(classLoader, str, intent);
        if ((instantiateReceiver instanceof afl) && (a = ((afl) instantiateReceiver).a()) != null) {
            instantiateReceiver = a;
        }
        return (BroadcastReceiver) instantiateReceiver;
    }

    public final Service instantiateService(ClassLoader classLoader, String str, Intent intent) {
        Object a;
        Object instantiateService = super.instantiateService(classLoader, str, intent);
        if ((instantiateService instanceof afl) && (a = ((afl) instantiateService).a()) != null) {
            instantiateService = a;
        }
        return (Service) instantiateService;
    }
}
