package androidx.core.app;

import android.app.PendingIntent;
import androidx.core.graphics.drawable.IconCompat;
import cal.bly;

/* compiled from: PG */
/* loaded from: classes.dex */
public final class RemoteActionCompat implements bly {
    public IconCompat a;
    public CharSequence b;
    public CharSequence c;
    public PendingIntent d;
    public boolean e;
    public boolean f;
}
