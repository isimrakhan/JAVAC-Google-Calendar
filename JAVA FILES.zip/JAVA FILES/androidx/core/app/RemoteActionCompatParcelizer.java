package androidx.core.app;

import android.app.PendingIntent;
import android.os.Parcelable;
import androidx.core.graphics.drawable.IconCompat;
import cal.blw;
import cal.bly;

/* compiled from: PG */
/* loaded from: classes.dex */
public class RemoteActionCompatParcelizer {
    public static RemoteActionCompat read(blw blwVar) {
        RemoteActionCompat remoteActionCompat = new RemoteActionCompat();
        bly blyVar = remoteActionCompat.a;
        if (blwVar.r(1)) {
            String f = blwVar.f();
            if (f == null) {
                blyVar = null;
            } else {
                blyVar = blwVar.d(f, blwVar.c());
            }
        }
        remoteActionCompat.a = (IconCompat) blyVar;
        CharSequence charSequence = remoteActionCompat.b;
        if (blwVar.r(2)) {
            charSequence = blwVar.e();
        }
        remoteActionCompat.b = charSequence;
        CharSequence charSequence2 = remoteActionCompat.c;
        if (blwVar.r(3)) {
            charSequence2 = blwVar.e();
        }
        remoteActionCompat.c = charSequence2;
        Parcelable parcelable = remoteActionCompat.d;
        if (blwVar.r(4)) {
            parcelable = blwVar.b();
        }
        remoteActionCompat.d = (PendingIntent) parcelable;
        boolean z = remoteActionCompat.e;
        if (blwVar.r(5)) {
            z = blwVar.q();
        }
        remoteActionCompat.e = z;
        boolean z2 = remoteActionCompat.f;
        if (blwVar.r(6)) {
            z2 = blwVar.q();
        }
        remoteActionCompat.f = z2;
        return remoteActionCompat;
    }

    public static void write(RemoteActionCompat remoteActionCompat, blw blwVar) {
        IconCompat iconCompat = remoteActionCompat.a;
        blwVar.h(1);
        if (iconCompat == null) {
            blwVar.n(null);
        } else {
            blwVar.p(iconCompat);
            blw c = blwVar.c();
            blwVar.o(iconCompat, c);
            c.g();
        }
        CharSequence charSequence = remoteActionCompat.b;
        blwVar.h(2);
        blwVar.k(charSequence);
        CharSequence charSequence2 = remoteActionCompat.c;
        blwVar.h(3);
        blwVar.k(charSequence2);
        PendingIntent pendingIntent = remoteActionCompat.d;
        blwVar.h(4);
        blwVar.m(pendingIntent);
        boolean z = remoteActionCompat.e;
        blwVar.h(5);
        blwVar.i(z);
        boolean z2 = remoteActionCompat.f;
        blwVar.h(6);
        blwVar.i(z2);
    }
}
