package androidx.work.impl.workers;

import android.content.Context;
import android.database.Cursor;
import android.os.Looper;
import androidx.work.Worker;
import androidx.work.WorkerParameters;
import androidx.work.impl.WorkDatabase;
import cal.bcc;
import cal.bcq;
import cal.bcs;
import cal.bep;
import cal.bhg;
import cal.bhn;
import cal.bhq;
import cal.bhr;
import cal.bhu;
import cal.bhw;
import cal.bqc;
import cal.bqh;
import cal.bqk;
import cal.brd;
import cal.bre;
import cal.brg;
import cal.brh;
import cal.brv;
import cal.buf;
import cal.byf;
import cal.byl;
import cal.byu;
import cal.byv;
import cal.bzo;
import cal.bzp;
import cal.bzt;
import cal.cai;
import cal.cbn;
import java.util.ArrayList;
import java.util.List;
import java.util.TreeMap;
import java.util.concurrent.TimeUnit;

/* compiled from: PG */
/* loaded from: classes.dex */
public final class DiagnosticsWorker extends Worker {
    /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
    public DiagnosticsWorker(Context context, WorkerParameters workerParameters) {
        super(context, workerParameters);
        context.getClass();
        workerParameters.getClass();
    }

    @Override // androidx.work.Worker
    public final bre c() {
        bcs bcsVar;
        int a;
        int a2;
        int a3;
        int a4;
        int a5;
        int a6;
        int a7;
        int a8;
        int a9;
        int a10;
        int a11;
        int a12;
        int a13;
        int a14;
        byf byfVar;
        byl bylVar;
        bzp bzpVar;
        int i;
        boolean z;
        String string;
        int i2;
        int i3;
        boolean z2;
        int i4;
        boolean z3;
        int i5;
        boolean z4;
        int i6;
        boolean z5;
        buf a15 = buf.a(this.a);
        WorkDatabase workDatabase = a15.c;
        workDatabase.getClass();
        byv t = workDatabase.t();
        byl r = workDatabase.r();
        bzp u = workDatabase.u();
        byf q = workDatabase.q();
        brv brvVar = a15.b.f;
        long currentTimeMillis = System.currentTimeMillis() - TimeUnit.DAYS.toMillis(1L);
        TreeMap treeMap = bcs.a;
        bcs a16 = bcq.a("SELECT * FROM workspec WHERE last_enqueue_time >= ? AND state IN (2, 3, 5) ORDER BY last_enqueue_time DESC", 1);
        a16.h[1] = 2;
        a16.d[1] = currentTimeMillis;
        bzo bzoVar = (bzo) t;
        bcc bccVar = bzoVar.a;
        if (!((bhr) ((bhu) ((bhw) bccVar.B()).f.a()).a()).d.inTransaction() && bccVar.k.get() != null) {
            throw new IllegalStateException("Cannot access database on a different coroutine context inherited from a suspending transaction.");
        }
        bcc bccVar2 = bzoVar.a;
        if (bccVar2.i || Looper.getMainLooper().getThread() != Thread.currentThread()) {
            if (!((bhr) ((bhu) ((bhw) bccVar2.B()).f.a()).a()).d.inTransaction() && bccVar2.k.get() != null) {
                throw new IllegalStateException("Cannot access database on a different coroutine context inherited from a suspending transaction.");
            }
            bhg a17 = ((bhu) ((bhw) bccVar2.B()).f.a()).a();
            bhn bhnVar = new bhn(new bhq(a16));
            String str = a16.c;
            if (str != null) {
                Cursor rawQueryWithFactory = ((bhr) a17).d.rawQueryWithFactory(bhnVar, str, bhr.a, null);
                rawQueryWithFactory.getClass();
                try {
                    a = bep.a(rawQueryWithFactory, "id");
                    a2 = bep.a(rawQueryWithFactory, "state");
                    a3 = bep.a(rawQueryWithFactory, "worker_class_name");
                    a4 = bep.a(rawQueryWithFactory, "input_merger_class_name");
                    a5 = bep.a(rawQueryWithFactory, "input");
                    a6 = bep.a(rawQueryWithFactory, "output");
                    a7 = bep.a(rawQueryWithFactory, "initial_delay");
                    a8 = bep.a(rawQueryWithFactory, "interval_duration");
                    a9 = bep.a(rawQueryWithFactory, "flex_duration");
                    a10 = bep.a(rawQueryWithFactory, "run_attempt_count");
                    a11 = bep.a(rawQueryWithFactory, "backoff_policy");
                    a12 = bep.a(rawQueryWithFactory, "backoff_delay_duration");
                    a13 = bep.a(rawQueryWithFactory, "last_enqueue_time");
                    a14 = bep.a(rawQueryWithFactory, "minimum_retention_duration");
                } catch (Throwable th) {
                    th = th;
                    bcsVar = a16;
                }
                try {
                    int a18 = bep.a(rawQueryWithFactory, "schedule_requested_at");
                    int a19 = bep.a(rawQueryWithFactory, "run_in_foreground");
                    int a20 = bep.a(rawQueryWithFactory, "out_of_quota_policy");
                    int a21 = bep.a(rawQueryWithFactory, "period_count");
                    int a22 = bep.a(rawQueryWithFactory, "generation");
                    int a23 = bep.a(rawQueryWithFactory, "next_schedule_time_override");
                    int a24 = bep.a(rawQueryWithFactory, "next_schedule_time_override_generation");
                    int a25 = bep.a(rawQueryWithFactory, "stop_reason");
                    int a26 = bep.a(rawQueryWithFactory, "trace_tag");
                    int a27 = bep.a(rawQueryWithFactory, "required_network_type");
                    int a28 = bep.a(rawQueryWithFactory, "required_network_request");
                    int a29 = bep.a(rawQueryWithFactory, "requires_charging");
                    int a30 = bep.a(rawQueryWithFactory, "requires_device_idle");
                    int a31 = bep.a(rawQueryWithFactory, "requires_battery_not_low");
                    int a32 = bep.a(rawQueryWithFactory, "requires_storage_not_low");
                    int a33 = bep.a(rawQueryWithFactory, "trigger_content_update_delay");
                    int a34 = bep.a(rawQueryWithFactory, "trigger_max_content_delay");
                    int a35 = bep.a(rawQueryWithFactory, "content_uri_triggers");
                    int i7 = a14;
                    ArrayList arrayList = new ArrayList(rawQueryWithFactory.getCount());
                    while (rawQueryWithFactory.moveToNext()) {
                        String string2 = rawQueryWithFactory.getString(a);
                        int j = bzt.j(rawQueryWithFactory.getInt(a2));
                        String string3 = rawQueryWithFactory.getString(a3);
                        String string4 = rawQueryWithFactory.getString(a4);
                        byte[] blob = rawQueryWithFactory.getBlob(a5);
                        bqk bqkVar = bqk.a;
                        bqk a36 = bqh.a(blob);
                        bqk a37 = bqh.a(rawQueryWithFactory.getBlob(a6));
                        long j2 = rawQueryWithFactory.getLong(a7);
                        long j3 = rawQueryWithFactory.getLong(a8);
                        long j4 = rawQueryWithFactory.getLong(a9);
                        int i8 = rawQueryWithFactory.getInt(a10);
                        int g = bzt.g(rawQueryWithFactory.getInt(a11));
                        long j5 = rawQueryWithFactory.getLong(a12);
                        long j6 = rawQueryWithFactory.getLong(a13);
                        int i9 = i7;
                        long j7 = rawQueryWithFactory.getLong(i9);
                        int i10 = a;
                        int i11 = a18;
                        long j8 = rawQueryWithFactory.getLong(i11);
                        a18 = i11;
                        int i12 = a19;
                        if (rawQueryWithFactory.getInt(i12) != 0) {
                            a19 = i12;
                            i = a20;
                            z = true;
                        } else {
                            a19 = i12;
                            i = a20;
                            z = false;
                        }
                        int i13 = bzt.i(rawQueryWithFactory.getInt(i));
                        a20 = i;
                        int i14 = a21;
                        int i15 = rawQueryWithFactory.getInt(i14);
                        a21 = i14;
                        int i16 = a22;
                        int i17 = rawQueryWithFactory.getInt(i16);
                        a22 = i16;
                        int i18 = a23;
                        long j9 = rawQueryWithFactory.getLong(i18);
                        a23 = i18;
                        int i19 = a24;
                        int i20 = rawQueryWithFactory.getInt(i19);
                        a24 = i19;
                        int i21 = a25;
                        int i22 = rawQueryWithFactory.getInt(i21);
                        a25 = i21;
                        int i23 = a26;
                        if (rawQueryWithFactory.isNull(i23)) {
                            a26 = i23;
                            i2 = a27;
                            string = null;
                        } else {
                            string = rawQueryWithFactory.getString(i23);
                            a26 = i23;
                            i2 = a27;
                        }
                        int h = bzt.h(rawQueryWithFactory.getInt(i2));
                        a27 = i2;
                        int i24 = a28;
                        cai a38 = bzt.a(rawQueryWithFactory.getBlob(i24));
                        a28 = i24;
                        int i25 = a29;
                        if (rawQueryWithFactory.getInt(i25) != 0) {
                            a29 = i25;
                            i3 = a30;
                            z2 = true;
                        } else {
                            a29 = i25;
                            i3 = a30;
                            z2 = false;
                        }
                        if (rawQueryWithFactory.getInt(i3) != 0) {
                            a30 = i3;
                            i4 = a31;
                            z3 = true;
                        } else {
                            a30 = i3;
                            i4 = a31;
                            z3 = false;
                        }
                        if (rawQueryWithFactory.getInt(i4) != 0) {
                            a31 = i4;
                            i5 = a32;
                            z4 = true;
                        } else {
                            a31 = i4;
                            i5 = a32;
                            z4 = false;
                        }
                        if (rawQueryWithFactory.getInt(i5) != 0) {
                            a32 = i5;
                            i6 = a33;
                            z5 = true;
                        } else {
                            a32 = i5;
                            i6 = a33;
                            z5 = false;
                        }
                        long j10 = rawQueryWithFactory.getLong(i6);
                        a33 = i6;
                        int i26 = a34;
                        long j11 = rawQueryWithFactory.getLong(i26);
                        a34 = i26;
                        int i27 = a35;
                        a35 = i27;
                        arrayList.add(new byu(string2, j, string3, string4, a36, a37, j2, j3, j4, new bqc(a38, h, z2, z3, z4, z5, j10, j11, bzt.b(rawQueryWithFactory.getBlob(i27))), i8, g, j5, j6, j7, j8, z, i13, i15, i17, j9, i20, i22, string));
                        a = i10;
                        i7 = i9;
                    }
                    rawQueryWithFactory.close();
                    synchronized (bcs.a) {
                        bcs.a.put(Integer.valueOf(a16.b), a16);
                        bcq.b();
                    }
                    List b = t.b();
                    List k = t.k();
                    if (!arrayList.isEmpty()) {
                        synchronized (brh.a) {
                            if (brh.b == null) {
                                brh.b = new brg();
                            }
                            brh brhVar = brh.b;
                        }
                        int i28 = cbn.a;
                        synchronized (brh.a) {
                            if (brh.b == null) {
                                brh.b = new brg();
                            }
                            brh brhVar2 = brh.b;
                        }
                        byfVar = q;
                        bylVar = r;
                        bzpVar = u;
                        cbn.a(bylVar, bzpVar, byfVar, arrayList);
                    } else {
                        byfVar = q;
                        bylVar = r;
                        bzpVar = u;
                    }
                    if (!b.isEmpty()) {
                        synchronized (brh.a) {
                            if (brh.b == null) {
                                brh.b = new brg();
                            }
                            brh brhVar3 = brh.b;
                        }
                        int i29 = cbn.a;
                        synchronized (brh.a) {
                            if (brh.b == null) {
                                brh.b = new brg();
                            }
                            brh brhVar4 = brh.b;
                        }
                        cbn.a(bylVar, bzpVar, byfVar, b);
                    }
                    if (!k.isEmpty()) {
                        synchronized (brh.a) {
                            if (brh.b == null) {
                                brh.b = new brg();
                            }
                            brh brhVar5 = brh.b;
                        }
                        int i30 = cbn.a;
                        synchronized (brh.a) {
                            if (brh.b == null) {
                                brh.b = new brg();
                            }
                            brh brhVar6 = brh.b;
                        }
                        cbn.a(bylVar, bzpVar, byfVar, k);
                    }
                    return new brd(bqk.a);
                } catch (Throwable th2) {
                    th = th2;
                    bcsVar = a16;
                    rawQueryWithFactory.close();
                    synchronized (bcs.a) {
                        bcs.a.put(Integer.valueOf(bcsVar.b), bcsVar);
                        bcq.b();
                    }
                    throw th;
                }
            }
            throw new IllegalStateException("Required value was null.");
        }
        throw new IllegalStateException("Cannot access database on the main thread since it may potentially lock the UI for a long period of time.");
    }
}
