package androidx.work.impl.workers;

import android.content.Context;
import androidx.work.CoroutineWorker;
import androidx.work.WorkerParameters;
import cal.aqbe;
import cal.aqhr;
import cal.aqjz;
import cal.cbb;
import java.util.concurrent.CancellationException;

/* compiled from: PG */
/* loaded from: classes.dex */
public final class ConstraintTrackingWorker extends CoroutineWorker {
    private final WorkerParameters e;

    /* compiled from: PG */
    /* loaded from: classes.dex */
    public final class ConstraintUnsatisfiedException extends CancellationException {
        public final int a;

        public ConstraintUnsatisfiedException(int i) {
            this.a = i;
        }
    }

    /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
    public ConstraintTrackingWorker(Context context, WorkerParameters workerParameters) {
        super(context, workerParameters);
        context.getClass();
        workerParameters.getClass();
        this.e = workerParameters;
    }

    @Override // androidx.work.CoroutineWorker
    public final Object c(aqbe aqbeVar) {
        return aqhr.a(aqjz.a(this.b.d), new cbb(this, null), aqbeVar);
    }

    /* JADX WARN: Code restructure failed: missing block: B:10:0x0025, code lost:
    
        if ((r8 instanceof cal.apyb) == false) goto L21;
     */
    /* JADX WARN: Removed duplicated region for block: B:18:0x0030  */
    /* JADX WARN: Removed duplicated region for block: B:8:0x0021  */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct code enable 'Show inconsistent code' option in preferences
    */
    public final java.lang.Object d(cal.brf r5, cal.bwl r6, cal.byu r7, cal.aqbe r8) {
        /*
            r4 = this;
            boolean r0 = r8 instanceof cal.cbc
            if (r0 == 0) goto L13
            r0 = r8
            cal.cbc r0 = (cal.cbc) r0
            int r1 = r0.c
            r2 = -2147483648(0xffffffff80000000, float:-0.0)
            r3 = r1 & r2
            if (r3 == 0) goto L13
            int r1 = r1 - r2
            r0.c = r1
            goto L18
        L13:
            cal.cbc r0 = new cal.cbc
            r0.<init>(r4, r8)
        L18:
            java.lang.Object r8 = r0.a
            cal.aqbm r1 = cal.aqbm.COROUTINE_SUSPENDED
            int r2 = r0.c
            r3 = 1
            if (r2 == 0) goto L30
            if (r2 != r3) goto L28
            boolean r5 = r8 instanceof cal.apyb
            if (r5 != 0) goto L51
            goto L4d
        L28:
            java.lang.IllegalStateException r5 = new java.lang.IllegalStateException
            java.lang.String r6 = "call to 'resume' before 'invoke' with coroutine"
            r5.<init>(r6)
            throw r5
        L30:
            boolean r2 = r8 instanceof cal.apyb
            if (r2 != 0) goto L51
            cal.cbe r8 = new cal.cbe
            r2 = 0
            r8.<init>(r5, r6, r7, r2)
            r0.c = r3
            cal.aqbk r5 = r0.r
            cal.aqra r6 = new cal.aqra
            r5.getClass()
            r6.<init>(r5, r0)
            java.lang.Object r8 = cal.aqrq.a(r6, r6, r8)
            if (r8 != r1) goto L4d
            return r1
        L4d:
            r8.getClass()
            return r8
        L51:
            cal.apyb r8 = (cal.apyb) r8
            java.lang.Throwable r5 = r8.a
            throw r5
        */
        throw new UnsupportedOperationException("Method not decompiled: androidx.work.impl.workers.ConstraintTrackingWorker.d(cal.brf, cal.bwl, cal.byu, cal.aqbe):java.lang.Object");
    }

    /* JADX WARN: Removed duplicated region for block: B:26:0x013a  */
    /* JADX WARN: Removed duplicated region for block: B:28:0x0140  */
    /* JADX WARN: Removed duplicated region for block: B:31:0x010b  */
    /* JADX WARN: Removed duplicated region for block: B:33:0x010e  */
    /* JADX WARN: Removed duplicated region for block: B:43:0x003d  */
    /* JADX WARN: Removed duplicated region for block: B:8:0x0021  */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct code enable 'Show inconsistent code' option in preferences
    */
    public final java.lang.Object e(cal.aqbe r13) {
        /*
            Method dump skipped, instructions count: 392
            To view this dump change 'Code comments level' option to 'DEBUG'
        */
        throw new UnsupportedOperationException("Method not decompiled: androidx.work.impl.workers.ConstraintTrackingWorker.e(cal.aqbe):java.lang.Object");
    }
}
