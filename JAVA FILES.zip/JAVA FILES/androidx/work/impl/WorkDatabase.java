package androidx.work.impl;

import cal.bcc;
import cal.bxw;
import cal.bya;
import cal.byf;
import cal.byl;
import cal.byo;
import cal.byv;
import cal.bzp;

/* compiled from: PG */
/* loaded from: classes.dex */
public abstract class WorkDatabase extends bcc {
    public abstract bxw o();

    public abstract bya p();

    public abstract byf q();

    public abstract byl r();

    public abstract byo s();

    public abstract byv t();

    public abstract bzp u();
}
