package androidx.work.impl;

import cal.bas;
import cal.bbi;
import cal.bcn;
import cal.bhi;
import cal.bhk;
import cal.btt;
import cal.btu;
import cal.btv;
import cal.btw;
import cal.btx;
import cal.bty;
import cal.btz;
import cal.bua;
import cal.bub;
import cal.bxw;
import cal.bxy;
import cal.bya;
import cal.byc;
import cal.byd;
import cal.byf;
import cal.byj;
import cal.byl;
import cal.byn;
import cal.byo;
import cal.bys;
import cal.byv;
import cal.bzo;
import cal.bzp;
import cal.bzs;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;

/* compiled from: PG */
/* loaded from: classes.dex */
public final class WorkDatabase_Impl extends WorkDatabase {
    private volatile byv m;
    private volatile bxw n;
    private volatile bzp o;
    private volatile byf p;
    private volatile byl q;
    private volatile byo r;
    private volatile bya s;

    /* JADX INFO: Access modifiers changed from: protected */
    @Override // cal.bcc
    public final bhk A(bas basVar) {
        return basVar.c.a(new bhi(basVar.a, basVar.b, new bcn(basVar, new bub(this)), false, false));
    }

    /* JADX INFO: Access modifiers changed from: protected */
    @Override // cal.bcc
    public final bbi a() {
        return new bbi(this, new HashMap(0), new HashMap(0), "Dependency", "WorkSpec", "WorkTag", "SystemIdInfo", "WorkName", "WorkProgress", "Preference");
    }

    @Override // cal.bcc
    protected final Map g() {
        HashMap hashMap = new HashMap();
        hashMap.put(byv.class, Collections.emptyList());
        hashMap.put(bxw.class, Collections.emptyList());
        hashMap.put(bzp.class, Collections.emptyList());
        hashMap.put(byf.class, Collections.emptyList());
        hashMap.put(byl.class, Collections.emptyList());
        hashMap.put(byo.class, Collections.emptyList());
        hashMap.put(bya.class, Collections.emptyList());
        hashMap.put(byd.class, Collections.emptyList());
        return hashMap;
    }

    @Override // cal.bcc
    public final Set i() {
        return new HashSet();
    }

    @Override // cal.bcc
    public final List n() {
        ArrayList arrayList = new ArrayList();
        arrayList.add(new btt());
        arrayList.add(new btu());
        arrayList.add(new btv());
        arrayList.add(new btw());
        arrayList.add(new btx());
        arrayList.add(new bty());
        arrayList.add(new btz());
        arrayList.add(new bua());
        return arrayList;
    }

    @Override // androidx.work.impl.WorkDatabase
    public final bxw o() {
        bxw bxwVar;
        if (this.n != null) {
            return this.n;
        }
        synchronized (this) {
            if (this.n == null) {
                this.n = new bxy(this);
            }
            bxwVar = this.n;
        }
        return bxwVar;
    }

    @Override // androidx.work.impl.WorkDatabase
    public final bya p() {
        bya byaVar;
        if (this.s != null) {
            return this.s;
        }
        synchronized (this) {
            if (this.s == null) {
                this.s = new byc(this);
            }
            byaVar = this.s;
        }
        return byaVar;
    }

    @Override // androidx.work.impl.WorkDatabase
    public final byf q() {
        byf byfVar;
        if (this.p != null) {
            return this.p;
        }
        synchronized (this) {
            if (this.p == null) {
                this.p = new byj(this);
            }
            byfVar = this.p;
        }
        return byfVar;
    }

    @Override // androidx.work.impl.WorkDatabase
    public final byl r() {
        byl bylVar;
        if (this.q != null) {
            return this.q;
        }
        synchronized (this) {
            if (this.q == null) {
                this.q = new byn(this);
            }
            bylVar = this.q;
        }
        return bylVar;
    }

    @Override // androidx.work.impl.WorkDatabase
    public final byo s() {
        byo byoVar;
        if (this.r != null) {
            return this.r;
        }
        synchronized (this) {
            if (this.r == null) {
                this.r = new bys(this);
            }
            byoVar = this.r;
        }
        return byoVar;
    }

    @Override // androidx.work.impl.WorkDatabase
    public final byv t() {
        byv byvVar;
        if (this.m != null) {
            return this.m;
        }
        synchronized (this) {
            if (this.m == null) {
                this.m = new bzo(this);
            }
            byvVar = this.m;
        }
        return byvVar;
    }

    @Override // androidx.work.impl.WorkDatabase
    public final bzp u() {
        bzp bzpVar;
        if (this.o != null) {
            return this.o;
        }
        synchronized (this) {
            if (this.o == null) {
                this.o = new bzs(this);
            }
            bzpVar = this.o;
        }
        return bzpVar;
    }
}
