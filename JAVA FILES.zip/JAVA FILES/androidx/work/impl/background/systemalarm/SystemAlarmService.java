package androidx.work.impl.background.systemalarm;

import android.content.Intent;
import android.os.PowerManager;
import android.util.Log;
import cal.auy;
import cal.brg;
import cal.brh;
import cal.bta;
import cal.bvr;
import cal.bvt;
import cal.cap;
import cal.caq;
import java.util.LinkedHashMap;
import java.util.Map;

/* compiled from: PG */
/* loaded from: classes.dex */
public class SystemAlarmService extends auy implements bvr {
    private bvt a;
    private boolean b;

    static {
        brh.a("SystemAlarmService");
    }

    @Override // cal.bvr
    public final void a() {
        this.b = true;
        synchronized (brh.a) {
            if (brh.b == null) {
                brh.b = new brg();
            }
            brh brhVar = brh.b;
        }
        LinkedHashMap linkedHashMap = new LinkedHashMap();
        synchronized (caq.a) {
            linkedHashMap.putAll(caq.b);
        }
        for (Map.Entry entry : linkedHashMap.entrySet()) {
            PowerManager.WakeLock wakeLock = (PowerManager.WakeLock) entry.getKey();
            String str = (String) entry.getValue();
            if (wakeLock != null && wakeLock.isHeld()) {
                synchronized (brh.a) {
                    if (brh.b == null) {
                        brh.b = new brg();
                    }
                    brh brhVar2 = brh.b;
                }
                Log.w(cap.a, "WakeLock held for ".concat(String.valueOf(str)));
            }
        }
        stopSelf();
    }

    @Override // cal.auy, android.app.Service
    public final void onCreate() {
        super.onCreate();
        bvt bvtVar = new bvt(this);
        this.a = bvtVar;
        if (bvtVar.i != null) {
            synchronized (brh.a) {
                if (brh.b == null) {
                    brh.b = new brg();
                }
                brh brhVar = brh.b;
            }
            Log.e(bvt.a, "A completion listener for SystemAlarmDispatcher already exists.");
        } else {
            bvtVar.i = this;
        }
        this.b = false;
    }

    @Override // cal.auy, android.app.Service
    public final void onDestroy() {
        super.onDestroy();
        this.b = true;
        bvt bvtVar = this.a;
        synchronized (brh.a) {
            if (brh.b == null) {
                brh.b = new brg();
            }
            brh brhVar = brh.b;
        }
        bta btaVar = bvtVar.d;
        synchronized (btaVar.j) {
            btaVar.i.remove(bvtVar);
        }
        bvtVar.i = null;
    }

    @Override // android.app.Service
    public final int onStartCommand(Intent intent, int i, int i2) {
        super.onStartCommand(intent, i, i2);
        if (this.b) {
            synchronized (brh.a) {
                if (brh.b == null) {
                    brh.b = new brg();
                }
                brh brhVar = brh.b;
            }
            bvt bvtVar = this.a;
            synchronized (brh.a) {
                if (brh.b == null) {
                    brh.b = new brg();
                }
                brh brhVar2 = brh.b;
            }
            bta btaVar = bvtVar.d;
            synchronized (btaVar.j) {
                btaVar.i.remove(bvtVar);
            }
            bvtVar.i = null;
            bvt bvtVar2 = new bvt(this);
            this.a = bvtVar2;
            if (bvtVar2.i != null) {
                synchronized (brh.a) {
                    if (brh.b == null) {
                        brh.b = new brg();
                    }
                    brh brhVar3 = brh.b;
                }
                Log.e(bvt.a, "A completion listener for SystemAlarmDispatcher already exists.");
            } else {
                bvtVar2.i = this;
            }
            this.b = false;
        }
        if (intent != null) {
            this.a.c(intent, i2);
            return 3;
        }
        return 3;
    }
}
