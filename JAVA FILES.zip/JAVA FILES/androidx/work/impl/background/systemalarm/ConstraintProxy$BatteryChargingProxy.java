package androidx.work.impl.background.systemalarm;

import cal.bvj;

/* compiled from: PG */
/* loaded from: classes.dex */
public class ConstraintProxy$BatteryChargingProxy extends bvj {
}
