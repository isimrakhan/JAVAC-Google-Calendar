package androidx.work.impl.background.systemalarm;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import cal.brg;
import cal.brh;
import cal.buf;
import cal.bvk;
import cal.cba;

/* compiled from: PG */
/* loaded from: classes.dex */
public class ConstraintProxyUpdateReceiver extends BroadcastReceiver {
    public static final /* synthetic */ int a = 0;

    static {
        brh.a("ConstrntProxyUpdtRecvr");
    }

    @Override // android.content.BroadcastReceiver
    public final void onReceive(Context context, Intent intent) {
        String str;
        if (intent != null) {
            str = intent.getAction();
        } else {
            str = null;
        }
        if (!"androidx.work.impl.background.systemalarm.UpdateProxies".equals(str)) {
            synchronized (brh.a) {
                if (brh.b == null) {
                    brh.b = new brg();
                }
                brh brhVar = brh.b;
            }
            return;
        }
        BroadcastReceiver.PendingResult goAsync = goAsync();
        cba cbaVar = buf.a(context).j;
        cbaVar.a.execute(new bvk(intent, context, goAsync));
    }
}
