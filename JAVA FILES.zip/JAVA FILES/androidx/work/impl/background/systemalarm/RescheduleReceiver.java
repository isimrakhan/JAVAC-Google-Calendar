package androidx.work.impl.background.systemalarm;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.util.Log;
import cal.brg;
import cal.brh;
import cal.buf;
import java.util.Objects;

/* compiled from: PG */
/* loaded from: classes.dex */
public class RescheduleReceiver extends BroadcastReceiver {
    private static final String a = brh.a("RescheduleReceiver");

    @Override // android.content.BroadcastReceiver
    public final void onReceive(Context context, Intent intent) {
        synchronized (brh.a) {
            if (brh.b == null) {
                brh.b = new brg();
            }
            brh brhVar = brh.b;
        }
        Objects.toString(intent);
        try {
            buf a2 = buf.a(context);
            BroadcastReceiver.PendingResult goAsync = goAsync();
            synchronized (buf.a) {
                BroadcastReceiver.PendingResult pendingResult = a2.h;
                if (pendingResult != null) {
                    pendingResult.finish();
                }
                a2.h = goAsync;
                if (a2.g) {
                    a2.h.finish();
                    a2.h = null;
                }
            }
        } catch (IllegalStateException e) {
            synchronized (brh.a) {
                if (brh.b == null) {
                    brh.b = new brg();
                }
                brh brhVar2 = brh.b;
                Log.e(a, "Cannot reschedule jobs. WorkManager needs to be initialized via a ContentProvider#onCreate() or an Application#onCreate().", e);
            }
        }
    }
}
