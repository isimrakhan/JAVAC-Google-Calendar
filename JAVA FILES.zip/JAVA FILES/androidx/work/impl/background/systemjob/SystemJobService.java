package androidx.work.impl.background.systemjob;

import android.app.Application;
import android.app.job.JobParameters;
import android.app.job.JobService;
import android.net.Uri;
import android.os.Build;
import android.os.Looper;
import android.os.PersistableBundle;
import android.util.Log;
import cal.a;
import cal.brg;
import cal.brh;
import cal.bsj;
import cal.bsm;
import cal.bta;
import cal.btg;
import cal.bth;
import cal.bti;
import cal.buc;
import cal.bud;
import cal.buf;
import cal.byk;
import cal.cao;
import cal.cba;
import java.util.Arrays;
import java.util.HashMap;
import java.util.Map;
import java.util.Objects;
import org.chromium.net.UrlRequest;

/* compiled from: PG */
/* loaded from: classes.dex */
public class SystemJobService extends JobService implements bsm {
    private static final String a = brh.a("SystemJobService");
    private buf b;
    private final Map c = new HashMap();
    private final bth d = new bti();
    private bud e;

    private static byk b(JobParameters jobParameters) {
        try {
            PersistableBundle extras = jobParameters.getExtras();
            if (extras != null && extras.containsKey("EXTRA_WORK_SPEC_ID")) {
                return new byk(extras.getString("EXTRA_WORK_SPEC_ID"), extras.getInt("EXTRA_WORK_SPEC_GENERATION"));
            }
            return null;
        } catch (NullPointerException unused) {
            return null;
        }
    }

    private static void c(String str) {
        if (Looper.getMainLooper().getThread() == Thread.currentThread()) {
        } else {
            throw new IllegalStateException(a.a(str, "Cannot invoke ", " on a background thread"));
        }
    }

    @Override // cal.bsm
    public final void a(byk bykVar, boolean z) {
        c("onExecuted");
        synchronized (brh.a) {
            if (brh.b == null) {
                brh.b = new brg();
            }
            brh brhVar = brh.b;
        }
        JobParameters jobParameters = (JobParameters) this.c.remove(bykVar);
        if (jobParameters != null) {
            jobFinished(jobParameters, z);
        }
    }

    @Override // android.app.Service
    public final void onCreate() {
        super.onCreate();
        try {
            buf a2 = buf.a(getApplicationContext());
            this.b = a2;
            bta btaVar = a2.e;
            this.e = new bud(btaVar, a2.j);
            synchronized (btaVar.j) {
                btaVar.i.add(this);
            }
        } catch (IllegalStateException e) {
            if (Application.class.equals(getApplication().getClass())) {
                synchronized (brh.a) {
                    if (brh.b == null) {
                        brh.b = new brg();
                    }
                    brh brhVar = brh.b;
                    Log.w(a, "Could not find WorkManager instance; this may be because an auto-backup is in progress. Ignoring JobScheduler commands for now. Please make sure that you are initializing WorkManager if you have manually disabled WorkManagerInitializer.");
                    return;
                }
            }
            throw new IllegalStateException("WorkManager needs to be initialized via a ContentProvider#onCreate() or an Application#onCreate().", e);
        }
    }

    @Override // android.app.Service
    public final void onDestroy() {
        super.onDestroy();
        buf bufVar = this.b;
        if (bufVar != null) {
            bta btaVar = bufVar.e;
            synchronized (btaVar.j) {
                btaVar.i.remove(this);
            }
        }
    }

    @Override // android.app.job.JobService
    public final boolean onStartJob(JobParameters jobParameters) {
        Uri[] triggeredContentUris;
        String[] triggeredContentAuthorities;
        String[] triggeredContentAuthorities2;
        Uri[] triggeredContentUris2;
        c("onStartJob");
        if (this.b == null) {
            synchronized (brh.a) {
                if (brh.b == null) {
                    brh.b = new brg();
                }
                brh brhVar = brh.b;
            }
            jobFinished(jobParameters, true);
            return false;
        }
        byk b = b(jobParameters);
        if (b == null) {
            synchronized (brh.a) {
                if (brh.b == null) {
                    brh.b = new brg();
                }
                brh brhVar2 = brh.b;
            }
            Log.e(a, "WorkSpec id not found!");
            return false;
        }
        if (this.c.containsKey(b)) {
            synchronized (brh.a) {
                if (brh.b == null) {
                    brh.b = new brg();
                }
                brh brhVar3 = brh.b;
            }
            Objects.toString(b);
            b.toString();
            return false;
        }
        synchronized (brh.a) {
            if (brh.b == null) {
                brh.b = new brg();
            }
            brh brhVar4 = brh.b;
        }
        Objects.toString(b);
        b.toString();
        this.c.put(b, jobParameters);
        bsj bsjVar = new bsj();
        triggeredContentUris = jobParameters.getTriggeredContentUris();
        if (triggeredContentUris != null) {
            triggeredContentUris2 = jobParameters.getTriggeredContentUris();
            Arrays.asList(triggeredContentUris2);
        }
        triggeredContentAuthorities = jobParameters.getTriggeredContentAuthorities();
        if (triggeredContentAuthorities != null) {
            triggeredContentAuthorities2 = jobParameters.getTriggeredContentAuthorities();
            Arrays.asList(triggeredContentAuthorities2);
        }
        if (Build.VERSION.SDK_INT >= 28) {
            jobParameters.getNetwork();
        }
        bud budVar = this.e;
        btg a2 = this.d.a(b);
        cba cbaVar = budVar.b;
        cbaVar.a.execute(new buc(budVar, a2, bsjVar));
        return true;
    }

    @Override // android.app.job.JobService
    public final boolean onStopJob(JobParameters jobParameters) {
        boolean contains;
        int stopReason;
        c("onStopJob");
        if (this.b == null) {
            synchronized (brh.a) {
                if (brh.b == null) {
                    brh.b = new brg();
                }
                brh brhVar = brh.b;
            }
            return true;
        }
        byk b = b(jobParameters);
        if (b == null) {
            synchronized (brh.a) {
                if (brh.b == null) {
                    brh.b = new brg();
                }
                brh brhVar2 = brh.b;
            }
            Log.e(a, "WorkSpec id not found!");
            return false;
        }
        synchronized (brh.a) {
            if (brh.b == null) {
                brh.b = new brg();
            }
            brh brhVar3 = brh.b;
        }
        Objects.toString(b);
        b.toString();
        this.c.remove(b);
        btg btgVar = (btg) ((bti) this.d).a.remove(b);
        if (btgVar != null) {
            int i = -512;
            if (Build.VERSION.SDK_INT >= 31) {
                stopReason = jobParameters.getStopReason();
                switch (stopReason) {
                    case 0:
                    case 1:
                    case 2:
                    case 3:
                    case 4:
                    case 5:
                    case 6:
                    case 7:
                    case 8:
                    case 9:
                    case 10:
                    case 11:
                    case UrlRequest.Status.SENDING_REQUEST /* 12 */:
                    case UrlRequest.Status.WAITING_FOR_RESPONSE /* 13 */:
                    case UrlRequest.Status.READING_RESPONSE /* 14 */:
                    case 15:
                        i = stopReason;
                        break;
                }
            }
            bud budVar = this.e;
            cba cbaVar = budVar.b;
            cbaVar.a.execute(new cao(budVar.a, btgVar, false, i));
        }
        bta btaVar = this.b.e;
        String str = b.a;
        synchronized (btaVar.j) {
            contains = btaVar.h.contains(str);
        }
        if (!contains) {
            return true;
        }
        return false;
    }
}
