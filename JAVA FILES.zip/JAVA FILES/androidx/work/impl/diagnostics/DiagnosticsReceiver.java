package androidx.work.impl.diagnostics;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.util.Log;
import androidx.work.impl.workers.DiagnosticsWorker;
import cal.brg;
import cal.brh;
import cal.brj;
import cal.brk;
import cal.btp;
import cal.buf;
import java.util.Collections;
import java.util.List;

/* compiled from: PG */
/* loaded from: classes.dex */
public class DiagnosticsReceiver extends BroadcastReceiver {
    private static final String a = brh.a("DiagnosticsRcvr");

    @Override // android.content.BroadcastReceiver
    public final void onReceive(Context context, Intent intent) {
        if (intent == null) {
            return;
        }
        synchronized (brh.a) {
            if (brh.b == null) {
                brh.b = new brg();
            }
            brh brhVar = brh.b;
        }
        try {
            context.getClass();
            buf a2 = buf.a(context);
            List singletonList = Collections.singletonList((brk) new brj(DiagnosticsWorker.class).b());
            singletonList.getClass();
            if (!singletonList.isEmpty()) {
                new btp(a2, null, 2, singletonList).a();
                return;
            }
            throw new IllegalArgumentException("enqueue needs at least one WorkRequest.");
        } catch (IllegalStateException e) {
            synchronized (brh.a) {
                if (brh.b == null) {
                    brh.b = new brg();
                }
                brh brhVar2 = brh.b;
                Log.e(a, "WorkManager is not initialized", e);
            }
        }
    }
}
