package androidx.work.impl.foreground;

import android.app.Notification;
import android.app.NotificationManager;
import android.content.Intent;
import android.os.Build;
import android.text.TextUtils;
import android.util.Log;
import cal.auy;
import cal.brg;
import cal.brh;
import cal.bxs;
import cal.bxt;
import cal.bxu;
import cal.bxv;
import cal.caa;
import cal.cba;
import java.util.Objects;
import java.util.UUID;

/* compiled from: PG */
/* loaded from: classes.dex */
public class SystemForegroundService extends auy implements bxt {
    public static final String a = brh.a("SystemFgService");
    bxu b;
    NotificationManager c;
    private boolean d;

    private final void e() {
        this.c = (NotificationManager) getApplicationContext().getSystemService("notification");
        bxu bxuVar = new bxu(getApplicationContext());
        this.b = bxuVar;
        if (bxuVar.i != null) {
            synchronized (brh.a) {
                if (brh.b == null) {
                    brh.b = new brg();
                }
                brh brhVar = brh.b;
            }
            Log.e(bxu.a, "A callback already exists.");
            return;
        }
        bxuVar.i = this;
    }

    @Override // cal.bxt
    public final void a(int i) {
        this.c.cancel(i);
    }

    @Override // cal.bxt
    public final void b(int i, Notification notification) {
        this.c.notify(i, notification);
    }

    @Override // cal.bxt
    public final void c(int i, int i2, Notification notification) {
        if (Build.VERSION.SDK_INT >= 31) {
            bxv.a(this, i, notification, i2);
        } else if (Build.VERSION.SDK_INT < 29) {
            startForeground(i, notification);
        } else {
            startForeground(i, notification, i2);
        }
    }

    @Override // cal.bxt
    public final void d() {
        this.d = true;
        synchronized (brh.a) {
            if (brh.b == null) {
                brh.b = new brg();
            }
            brh brhVar = brh.b;
        }
        stopForeground(true);
        stopSelf();
    }

    @Override // cal.auy, android.app.Service
    public final void onCreate() {
        super.onCreate();
        e();
    }

    @Override // cal.auy, android.app.Service
    public final void onDestroy() {
        super.onDestroy();
        this.b.c();
    }

    @Override // android.app.Service
    public final int onStartCommand(Intent intent, int i, int i2) {
        super.onStartCommand(intent, i, i2);
        if (this.d) {
            synchronized (brh.a) {
                if (brh.b == null) {
                    brh.b = new brg();
                }
                brh brhVar = brh.b;
            }
            this.b.c();
            e();
            this.d = false;
        }
        if (intent != null) {
            bxu bxuVar = this.b;
            String action = intent.getAction();
            if ("ACTION_START_FOREGROUND".equals(action)) {
                synchronized (brh.a) {
                    if (brh.b == null) {
                        brh.b = new brg();
                    }
                    brh brhVar2 = brh.b;
                }
                Objects.toString(intent);
                intent.toString();
                String stringExtra = intent.getStringExtra("KEY_WORKSPEC_ID");
                cba cbaVar = bxuVar.j;
                cbaVar.a.execute(new bxs(bxuVar, stringExtra));
                bxuVar.b(intent);
                return 3;
            }
            if ("ACTION_NOTIFY".equals(action)) {
                bxuVar.b(intent);
                return 3;
            }
            if ("ACTION_CANCEL_WORK".equals(action)) {
                synchronized (brh.a) {
                    if (brh.b == null) {
                        brh.b = new brg();
                    }
                    brh brhVar3 = brh.b;
                }
                Objects.toString(intent);
                intent.toString();
                String stringExtra2 = intent.getStringExtra("KEY_WORKSPEC_ID");
                if (stringExtra2 != null && !TextUtils.isEmpty(stringExtra2)) {
                    caa.b(UUID.fromString(stringExtra2), bxuVar.b);
                    return 3;
                }
                return 3;
            }
            if ("ACTION_STOP_FOREGROUND".equals(action)) {
                synchronized (brh.a) {
                    if (brh.b == null) {
                        brh.b = new brg();
                    }
                    brh brhVar4 = brh.b;
                }
                bxt bxtVar = bxuVar.i;
                if (bxtVar != null) {
                    bxtVar.d();
                    return 3;
                }
                return 3;
            }
            return 3;
        }
        return 3;
    }

    @Override // android.app.Service
    public final void onTimeout(int i) {
        if (Build.VERSION.SDK_INT >= 35) {
            return;
        }
        this.b.d(2048);
    }

    public final void onTimeout(int i, int i2) {
        this.b.d(i2);
    }
}
