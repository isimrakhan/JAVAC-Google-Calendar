package androidx.work;

import android.content.Context;
import cal.bid;
import cal.bpv;
import cal.bpx;
import cal.brg;
import cal.brh;
import cal.brz;
import cal.buf;
import java.util.Collections;
import java.util.List;

/* compiled from: PG */
/* loaded from: classes.dex */
public final class WorkManagerInitializer implements bid<brz> {
    static {
        brh.a("WrkMgrInitializer");
    }

    @Override // cal.bid
    public final /* synthetic */ Object a(Context context) {
        synchronized (brh.a) {
            if (brh.b == null) {
                brh.b = new brg();
            }
            brh brhVar = brh.b;
        }
        bpx bpxVar = new bpx(new bpv());
        context.getClass();
        buf.c(context, bpxVar);
        context.getClass();
        return buf.a(context);
    }

    @Override // cal.bid
    public final List b() {
        return Collections.emptyList();
    }
}
