package androidx.work;

import android.content.Context;
import cal.aca;
import cal.ajdo;
import cal.bre;
import cal.brf;
import cal.bsc;
import cal.bsd;
import cal.bsi;

/* compiled from: PG */
/* loaded from: classes.dex */
public abstract class Worker extends brf {
    /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
    public Worker(Context context, WorkerParameters workerParameters) {
        super(context, workerParameters);
        context.getClass();
        workerParameters.getClass();
    }

    @Override // cal.brf
    public final ajdo a() {
        return aca.a(new bsi(this.b.d, new bsc()));
    }

    @Override // cal.brf
    public final ajdo b() {
        return aca.a(new bsi(this.b.d, new bsd(this)));
    }

    public abstract bre c();
}
