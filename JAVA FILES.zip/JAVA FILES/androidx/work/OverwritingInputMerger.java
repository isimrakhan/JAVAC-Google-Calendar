package androidx.work;

import cal.bqg;
import cal.bqh;
import cal.bqk;
import cal.bqs;
import j$.util.DesugarCollections;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

/* compiled from: PG */
/* loaded from: classes.dex */
public final class OverwritingInputMerger extends bqs {
    @Override // cal.bqs
    public final bqk a(List list) {
        LinkedHashMap linkedHashMap = new LinkedHashMap();
        LinkedHashMap linkedHashMap2 = new LinkedHashMap();
        Iterator it = list.iterator();
        while (it.hasNext()) {
            Map unmodifiableMap = DesugarCollections.unmodifiableMap(((bqk) it.next()).b);
            unmodifiableMap.getClass();
            linkedHashMap2.putAll(unmodifiableMap);
        }
        bqg.a(linkedHashMap2, linkedHashMap);
        bqk bqkVar = new bqk(linkedHashMap);
        bqh.b(bqkVar);
        return bqkVar;
    }
}
