package androidx.work;

import cal.aqbk;
import cal.bqk;
import cal.bqr;
import cal.bse;
import cal.cba;
import java.util.Collection;
import java.util.HashSet;
import java.util.UUID;
import java.util.concurrent.Executor;

/* compiled from: PG */
/* loaded from: classes.dex */
public final class WorkerParameters {
    public final UUID a;
    public final bqk b;
    public final int c;
    public final Executor d;
    public final aqbk e;
    public final bse f;
    public final bqr g;
    public final cba h;

    public WorkerParameters(UUID uuid, bqk bqkVar, Collection collection, int i, Executor executor, aqbk aqbkVar, cba cbaVar, bse bseVar, bqr bqrVar) {
        this.a = uuid;
        this.b = bqkVar;
        new HashSet(collection);
        this.c = i;
        this.d = executor;
        this.e = aqbkVar;
        this.h = cbaVar;
        this.f = bseVar;
        this.g = bqrVar;
    }
}
