package androidx.work;

import android.content.Context;
import cal.aca;
import cal.ajdo;
import cal.aqbe;
import cal.aqbk;
import cal.aqiq;
import cal.aqiz;
import cal.aqki;
import cal.bqd;
import cal.bqe;
import cal.bqf;
import cal.bqv;
import cal.brf;

/* compiled from: PG */
/* loaded from: classes.dex */
public abstract class CoroutineWorker extends brf {
    private final WorkerParameters e;
    private final aqiq f;

    /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
    public CoroutineWorker(Context context, WorkerParameters workerParameters) {
        super(context, workerParameters);
        context.getClass();
        workerParameters.getClass();
        this.e = workerParameters;
        this.f = bqd.a;
    }

    @Override // cal.brf
    public final ajdo a() {
        aqbk plus = this.f.plus(new aqki(null));
        bqe bqeVar = new bqe(this, null);
        aqiz aqizVar = aqiz.DEFAULT;
        plus.getClass();
        aqizVar.getClass();
        return aca.a(new bqv(plus, aqizVar, bqeVar));
    }

    @Override // cal.brf
    public final ajdo b() {
        aqbk aqbkVar;
        if (!this.f.equals(bqd.a)) {
            aqbkVar = this.f;
        } else {
            aqbkVar = this.e.e;
        }
        aqbkVar.getClass();
        aqbk plus = aqbkVar.plus(new aqki(null));
        bqf bqfVar = new bqf(this, null);
        aqiz aqizVar = aqiz.DEFAULT;
        plus.getClass();
        aqizVar.getClass();
        return aca.a(new bqv(plus, aqizVar, bqfVar));
    }

    public abstract Object c(aqbe aqbeVar);
}
