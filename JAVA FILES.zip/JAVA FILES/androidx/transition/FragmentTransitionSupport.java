package androidx.transition;

import android.graphics.Rect;
import android.os.Build;
import android.view.View;
import android.view.ViewGroup;
import cal.aiq;
import cal.bjh;
import cal.bji;
import cal.bjj;
import cal.bjk;
import cal.bjl;
import cal.bjm;
import cal.bjv;
import cal.bkd;
import cal.bkg;
import cal.bkh;
import cal.bkl;
import cal.et;
import com.google.android.calendar.R;
import java.util.ArrayList;
import java.util.Objects;

/* compiled from: PG */
/* loaded from: classes.dex */
public class FragmentTransitionSupport extends et {
    @Override // cal.et
    public final Object a(Object obj) {
        if (obj != null) {
            return ((bkd) obj).clone();
        }
        return null;
    }

    @Override // cal.et
    public final Object b(Object obj, Object obj2, Object obj3) {
        bkd bkdVar = (bkd) obj;
        bkd bkdVar2 = (bkd) obj2;
        bkd bkdVar3 = (bkd) obj3;
        if (bkdVar != null && bkdVar2 != null) {
            bkl bklVar = new bkl();
            bklVar.f(bkdVar);
            bklVar.f(bkdVar2);
            bklVar.z = false;
            bkdVar = bklVar;
        } else if (bkdVar == null) {
            if (bkdVar2 != null) {
                bkdVar = bkdVar2;
            } else {
                bkdVar = null;
            }
        }
        if (bkdVar3 != null) {
            bkl bklVar2 = new bkl();
            if (bkdVar != null) {
                bklVar2.f(bkdVar);
            }
            bklVar2.f(bkdVar3);
            return bklVar2;
        }
        return bkdVar;
    }

    @Override // cal.et
    public final Object c(Object obj) {
        if (obj == null) {
            return null;
        }
        bkl bklVar = new bkl();
        bklVar.f((bkd) obj);
        return bklVar;
    }

    @Override // cal.et
    public final void d(Object obj, View view) {
        ((bkd) obj).F(view);
    }

    @Override // cal.et
    public final void e(Object obj, ArrayList arrayList) {
        bkd bkdVar = (bkd) obj;
        if (bkdVar != null) {
            int i = 0;
            if (bkdVar instanceof bkl) {
                bkl bklVar = (bkl) bkdVar;
                int size = bklVar.y.size();
                while (i < size) {
                    bkd bkdVar2 = null;
                    if (i >= 0 && i < bklVar.y.size()) {
                        bkdVar2 = (bkd) bklVar.y.get(i);
                    }
                    e(bkdVar2, arrayList);
                    i++;
                }
                return;
            }
            if (bkdVar.f.isEmpty() && bkdVar.g.isEmpty()) {
                int size2 = arrayList.size();
                while (i < size2) {
                    bkdVar.F((View) arrayList.get(i));
                    i++;
                }
            }
        }
    }

    @Override // cal.et
    public final void f(ViewGroup viewGroup, Object obj) {
        bkh.b(viewGroup, (bkd) obj);
    }

    public final void g(Object obj, ArrayList arrayList, ArrayList arrayList2) {
        int size;
        bkd bkdVar = (bkd) obj;
        int i = 0;
        if (bkdVar instanceof bkl) {
            bkl bklVar = (bkl) bkdVar;
            int size2 = bklVar.y.size();
            while (i < size2) {
                bkd bkdVar2 = null;
                if (i >= 0 && i < bklVar.y.size()) {
                    bkdVar2 = (bkd) bklVar.y.get(i);
                }
                g(bkdVar2, arrayList, arrayList2);
                i++;
            }
            return;
        }
        if (bkdVar.f.isEmpty()) {
            ArrayList arrayList3 = bkdVar.g;
            if (arrayList3.size() == arrayList.size() && arrayList3.containsAll(arrayList)) {
                if (arrayList2 == null) {
                    size = 0;
                } else {
                    size = arrayList2.size();
                }
                while (i < size) {
                    bkdVar.F((View) arrayList2.get(i));
                    i++;
                }
                int size3 = arrayList.size();
                while (true) {
                    size3--;
                    if (size3 >= 0) {
                        bkdVar.H((View) arrayList.get(size3));
                    } else {
                        return;
                    }
                }
            }
        }
    }

    @Override // cal.et
    public final void h(Object obj, View view, ArrayList arrayList) {
        ((bkd) obj).E(new bjj(view, arrayList));
    }

    @Override // cal.et
    public final void i(Object obj, Rect rect) {
        ((bkd) obj).y(new bjm());
    }

    @Override // cal.et
    public final void j(Object obj, View view) {
        if (view != null) {
            x(view, new Rect());
            ((bkd) obj).y(new bji());
        }
    }

    @Override // cal.et
    public final void k(Object obj, View view, ArrayList arrayList) {
        bkl bklVar = (bkl) obj;
        ArrayList arrayList2 = bklVar.g;
        arrayList2.clear();
        int size = arrayList.size();
        for (int i = 0; i < size; i++) {
            v(arrayList2, (View) arrayList.get(i));
        }
        arrayList2.add(view);
        arrayList.add(view);
        e(bklVar, arrayList);
    }

    @Override // cal.et
    public final void l(Object obj, ArrayList arrayList, ArrayList arrayList2) {
        bkl bklVar = (bkl) obj;
        if (bklVar != null) {
            bklVar.g.clear();
            bklVar.g.addAll(arrayList2);
            g(bklVar, arrayList, arrayList2);
        }
    }

    @Override // cal.et
    public final boolean m(Object obj) {
        return obj instanceof bkd;
    }

    @Override // cal.et
    public final boolean n() {
        return true;
    }

    @Override // cal.et
    public final boolean o(Object obj) {
        boolean d = ((bkd) obj).d();
        if (!d) {
            Objects.toString(obj);
        }
        return d;
    }

    @Override // cal.et
    public final Object p(Object obj, Object obj2) {
        bkl bklVar = new bkl();
        if (obj != null) {
            bklVar.f((bkd) obj);
        }
        bklVar.f((bkd) obj2);
        return bklVar;
    }

    @Override // cal.et
    public final void q(Object obj, Object obj2, ArrayList arrayList, Object obj3, ArrayList arrayList2) {
        ((bkd) obj).E(new bjk(this, obj2, arrayList, obj3, arrayList2));
    }

    @Override // cal.et
    public final void r(Object obj, aiq aiqVar, Runnable runnable) {
        bkd bkdVar = (bkd) obj;
        aiqVar.b(new bjh(null, bkdVar, runnable));
        bkdVar.E(new bjl(runnable));
    }

    @Override // cal.et
    public final Object s(ViewGroup viewGroup, Object obj) {
        bkd bkdVar = (bkd) obj;
        if (bkh.a.contains(viewGroup) || !viewGroup.isLaidOut() || Build.VERSION.SDK_INT < 34) {
            return null;
        }
        if (bkdVar.d()) {
            bkh.a.add(viewGroup);
            bkd clone = bkdVar.clone();
            bkl bklVar = new bkl();
            bklVar.f(clone);
            bkh.c(viewGroup, bklVar);
            viewGroup.setTag(R.id.transition_current_scene, null);
            bkg bkgVar = new bkg(bklVar, viewGroup);
            viewGroup.addOnAttachStateChangeListener(bkgVar);
            viewGroup.getViewTreeObserver().addOnPreDrawListener(bkgVar);
            viewGroup.invalidate();
            bklVar.w = new bjv(bklVar);
            bjv bjvVar = bklVar.w;
            if (bklVar.r == null) {
                bklVar.r = new ArrayList();
            }
            bklVar.r.add(bjvVar);
            return bklVar.w;
        }
        throw new IllegalArgumentException("The Transition must support seeking.");
    }

    @Override // cal.et
    public final void t(Object obj) {
        ((bjv) obj).h();
    }

    @Override // cal.et
    public final void u(Object obj, Runnable runnable) {
        ((bjv) obj).i(runnable);
    }

    /* JADX WARN: Code restructure failed: missing block: B:18:0x0032, code lost:
    
        if (r11 > 0) goto L28;
     */
    @Override // cal.et
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct code enable 'Show inconsistent code' option in preferences
    */
    public final void w(java.lang.Object r14, float r15) {
        /*
            r13 = this;
            cal.bjv r14 = (cal.bjv) r14
            boolean r0 = r14.b
            if (r0 == 0) goto L6c
            cal.bkd r0 = r14.h
            long r1 = r0.v
            float r3 = (float) r1
            float r15 = r15 * r3
            long r3 = (long) r15
            r5 = 0
            int r15 = (r3 > r5 ? 1 : (r3 == r5 ? 0 : -1))
            r7 = 1
            if (r15 != 0) goto L16
            r3 = r7
        L16:
            int r15 = (r3 > r1 ? 1 : (r3 == r1 ? 0 : -1))
            r9 = -1
            if (r15 != 0) goto L1e
            long r3 = r1 + r9
        L1e:
            cal.arf r15 = r14.e
            if (r15 != 0) goto L64
            long r11 = r14.a
            int r15 = (r3 > r11 ? 1 : (r3 == r11 ? 0 : -1))
            if (r15 == 0) goto L6c
            boolean r15 = r14.c
            if (r15 != 0) goto L4c
            int r15 = (r3 > r5 ? 1 : (r3 == r5 ? 0 : -1))
            if (r15 != 0) goto L35
            int r15 = (r11 > r5 ? 1 : (r11 == r5 ? 0 : -1))
            if (r15 <= 0) goto L36
            goto L42
        L35:
            r5 = r3
        L36:
            int r15 = (r5 > r1 ? 1 : (r5 == r1 ? 0 : -1))
            if (r15 != 0) goto L41
            int r15 = (r11 > r1 ? 1 : (r11 == r1 ? 0 : -1))
            if (r15 >= 0) goto L41
            long r9 = r1 + r7
            goto L42
        L41:
            r9 = r5
        L42:
            int r15 = (r9 > r11 ? 1 : (r9 == r11 ? 0 : -1))
            if (r15 == 0) goto L4b
            r0.x(r9, r11)
            r14.a = r9
        L4b:
            r3 = r9
        L4c:
            cal.bkp r14 = r14.f
            long r0 = android.view.animation.AnimationUtils.currentAnimationTimeMillis()
            int r15 = r14.c
            int r15 = r15 + 1
            int r15 = r15 % 20
            r14.c = r15
            long[] r2 = r14.a
            r2[r15] = r0
            float[] r14 = r14.b
            float r0 = (float) r3
            r14[r15] = r0
            return
        L64:
            java.lang.IllegalStateException r14 = new java.lang.IllegalStateException
            java.lang.String r15 = "setCurrentPlayTimeMillis() called after animation has been started"
            r14.<init>(r15)
            throw r14
        L6c:
            return
        */
        throw new UnsupportedOperationException("Method not decompiled: androidx.transition.FragmentTransitionSupport.w(java.lang.Object, float):void");
    }

    @Override // cal.et
    public final void y(Object obj, aiq aiqVar, Runnable runnable, Runnable runnable2) {
        bkd bkdVar = (bkd) obj;
        aiqVar.b(new bjh(runnable, bkdVar, runnable2));
        bkdVar.E(new bjl(runnable2));
    }
}
